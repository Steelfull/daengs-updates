"""Daengs: local, offline search for passages in PDF deliveries."""

__version__ = "0.1.0"

# Marking of a pre-release (R-15, D-082): the one place that decides. An empty string means no
# marking (1.0). Window title, start screen, update dialog and diagnostic report take it from here.
RELEASE_LABEL = "Vorabversion"

# Product name (D-023). Window, messages, installer and UI take it from here; the earlier
# working name only appears in daengs.migrate, which takes over an old installation.
PRODUCT = "Daengs"


def release_name() -> str:
    """ "Vorabversion 0.1.0", or "" when the release carries no marking."""
    return f"{RELEASE_LABEL} {__version__}" if RELEASE_LABEL else ""


def window_title() -> str:
    """Title of the program window: product, en dash, release name; just the product if none."""
    return f"{PRODUCT} \N{EN DASH} {release_name()}" if RELEASE_LABEL else PRODUCT


# Named mutex held while Daengs runs: one Daengs per user session; setup and uninstall wait for it.
RUNNING_MUTEX = f"{PRODUCT}-laeuft-8b1e6c2a"

# The wiki for all projects (M9d) lies in its own folder next to the projects, not among them.
GLOBAL_WIKI_FOLDER = "Gesamt-Wiki"
