"""The program writes the sentence when the model denies or cannot prove (AP-9.38 round 2, CEO-53).

The small model sometimes denies what a passage says (B02, B03) or states a value that no passage
has. Marking such a sentence was not enough in round 1: it stayed in the answer. Now the program
takes it out and puts a fixed sentence in its place, by rules alone, so that it can be measured:

- a sentence that denies or says "nothing" (``negation.denials``) is replaced by
  - a quotation of the passage that names a value next to what was asked, if there is one,
  - or a pointer to the page of another passage of a sure hit (``neighbours``, only to see that
    the denial is wrong: the model never reads it, it is no source of the answer, D-053),
  - or "In den N verwendeten Stellen steht dazu nichts";
  it is left out when the rest of the answer already names the value (it would contradict);
- a sentence with a value of the kind asked for and no passage anywhere that has one next to
  the question's words becomes the "nichts" sentence;
- a sentence with a number that is not in its cited sources becomes the "nicht belegt" sentence,
  unless the number stands in another source: then it only gets that citation;
- an answer that gives no value of the kind asked for gets, at the end, the quotation or the
  page pointer if a passage has one, or the "nichts" sentence if the question names the quantity
  ("Temperatur", "Verbrauch") and no passage has it.
Round 4 (D-081), errors of form only:
- the value that makes an answer complete must belong to the quantity asked (a service life is no
  re-lubrication interval): otherwise the page pointer is added;
- a sentence of the model that imitates one of the program ("in den 4 verwendeten Stellen ...",
  a tail "bitte selbst prüfen", a quotation, a pointer) is cleaned: the statement stays, the
  phrase goes;
- an answer with no valid citation at all gets the sentence "Ohne Quellenangabe" (NO_SOURCE).
Every sentence the program writes ends in ``negation.TAIL_CHECK`` or ``TAIL_PAGE``.
"""

import re
from collections.abc import Sequence
from dataclasses import dataclass

from daengs.answer import check as checks
from daengs.answer import negation
from daengs.answer.check import check, split
from daengs.answer.terms import subject

NOTHING = "In den {n} verwendeten Stellen steht dazu nichts " + negation.TAIL_CHECK
NOTHING_ONE = "In der verwendeten Stelle steht dazu nichts " + negation.TAIL_CHECK
UNPROVEN = "Eine Zahl in der Antwort steht so nicht in den verwendeten Stellen " + (
    negation.TAIL_CHECK
)
FOUND = negation.QUOTE_OPEN + " (Seite {page}): „… {quote} …“ " + negation.TAIL_CHECK
FOUND_ELSEWHERE = (
    negation.QUOTE_OPEN + " in {file}, Seite {page}: „… {quote} …“ " + negation.TAIL_CHECK
)
NO_SOURCE = "Ohne Quellenangabe " + negation.TAIL_CHECK
PAGE = "Auf Seite {page} ({file}) steht dazu etwas " + negation.TAIL_PAGE
# "Dazu steht nichts": says nothing about this or that, only that the whole answer is missing.
_GENERIC = re.compile(
    r"^(?:dazu|hierzu|darüber|zu dieser frage|in den (?:\w+ )?(?:fundstellen|unterlagen|stellen)"
    r"|in der (?:\w+ )?(?:fundstelle|stelle))\b[^.]{0,80}\bnichts\b",
    re.IGNORECASE,
)


# The model never saw a sentence of the program, so one in its answer is an imitation (round 4).
_TAIL = re.compile(r"\s*–\s*bitte (?:selbst prüfen|dort nachsehen)(?=\.)")
_IMITATED_QUOTE = re.compile(
    negation.QUOTE_OPEN + r"[^„]*„.*?“(?:\s*–\s*bitte (?:selbst prüfen|dort nachsehen)\.?)?"
    r"(?:\s*\[\d+\])*\s*"
)
_IMITATED_POINTER = re.compile(r"Auf Seite \d+ \([^)]*\) steht dazu etwas[^.]*\.(?:\s*\[\d+\])*\s*")
_PLACES = r"(?:den|der)\s+(?:\d+\s+)?(?:verwendeten\s+Stellen?|Fundstellen?)\b"
_PLACES_MID = re.compile(r"\s+(?:in|aus)\s+" + _PLACES)
_PLACES_START = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=\n))In\s+" + _PLACES)
_CITATION = re.compile(r"\[(\d+(?:\s*[,;]\s*\d+)*)\]")


def _clean_imitation(piece: str) -> str:
    """The sentence without what imitates the program: its tail, a place count ("in den 4
    verwendeten Stellen", also what the old rewrite of "in den Fundstellen" made of it)."""
    piece = _TAIL.sub("", piece)
    piece = _PLACES_START.sub("Laut den Unterlagen", piece)
    return _PLACES_MID.sub("", piece)


def _has_valid_citation(texts: Sequence[str], count: int) -> bool:
    for text in texts:
        for group in _CITATION.findall(text):
            if any(1 <= int(n) <= count for n in re.split(r"[,;]", group)):
                return True
    return False


# A sentence that leans on the one the program took out ("Diese Einstellung ...", "stattdessen").
_BACKREF = re.compile(
    r"^(?:diese[rsmn]?|dies|dabei|daher|deshalb|somit|hierbei|dort|darin|davon)\b|\bstattdessen\b",
    re.IGNORECASE,
)


def _loose_after_replacement(sentence) -> bool:
    """After the program replaced a sentence, a sentence that leans back on it, or that states a
    value (number, number word, interval) without citing a source, goes too (round 3, CEO-55):
    nothing ties it to a passage, and its meaning came from the sentence that is gone."""
    return bool(_BACKREF.search(sentence.text)) or (not sentence.sources and bool(sentence.numbers))


@dataclass(frozen=True)
class Place:
    """A passage that can prove or disprove a sentence. ``n`` is its number among the sources
    of the answer, None when the model did not get it."""

    rel_path: str
    page_no: int
    text: str
    n: int | None = None


@dataclass(frozen=True)
class Replacement:
    kind: str  # "denial" | "value" | "number" | "missing" | "follow"
    original: str
    how: str  # "quote" | "page" | "nothing" | "unproven" | "dropped" | "recited"
    new: str = ""


@dataclass(frozen=True)
class Result:
    text: str
    replacements: list[Replacement]


def _file(rel_path: str) -> str:
    return rel_path.replace("\\", "/").rsplit("/", 1)[-1]


def _proof(
    question: str, seen: Sequence[Place], neighbours: Sequence[Place]
) -> tuple[str, str] | None:
    """The best passage that names a value next to what was asked, as (sentence, "quote" or
    "page"): a quotation from a passage the search found, a pointer when the best one is only
    another passage of the page of a sure hit. Weak matches count for nothing (a wrong quotation
    is worse than none)."""
    best: tuple[int, Place, str, bool] | None = None
    for places, near in ((seen, False), (neighbours, True)):
        for item in negation.evidence(question, [p.text for p in places]):
            if item.score >= -negation.STRONG and (best is None or item.score > best[0]):
                best = (item.score, places[item.index], item.text, near)
    if best is None:
        return None
    _, place, text, near = best
    cite = f" [{place.n}]" if place.n else ""
    if near:
        return PAGE.format(page=place.page_no, file=_file(place.rel_path)) + cite, "page"
    quote = " ".join(text.split())
    if place.n:
        return FOUND.format(page=place.page_no, quote=quote) + cite, "quote"
    return (
        FOUND_ELSEWHERE.format(file=_file(place.rel_path), page=place.page_no, quote=quote),
        "quote",
    )


def _answers(asked, text: str) -> bool:
    low = text.lower()
    nouns = not asked.nouns or any(any(f in low for f in group) for group in asked.nouns)
    props = not asked.props or any(any(f in low for f in group) for group in asked.props)
    return nouns and props


def _recite(
    checked: Sequence, kinds: list[str], used: Sequence[str]
) -> tuple[list[str], dict[int, str]]:
    """A sentence whose numbers are all in another source than the one it cites was cited wrongly:
    it gets the citation of the source that has them, not the "unproven" sentence."""
    known = {n: checks.numbers_in(text) for n, text in enumerate(used, start=1)}
    kinds = list(kinds)
    fixed: dict[int, str] = {}
    for index, sentence in enumerate(checked):
        if kinds[index] != "number":
            continue
        wanted = [n.value for n in sentence.numbers]
        for n, numbers in known.items():
            if all(checks.known_in(value, numbers) for value in wanted):
                fixed[index] = f" [{n}]"
                kinds[index] = "keep"
                break
    return kinds, fixed


def enforce(
    question: str,
    answer: str,
    used: Sequence[str],
    seen: Sequence[Place],
    neighbours: Sequence[Place] = (),
) -> Result:
    """The answer with every denial, unproven value and unproven number replaced.

    ``used`` are the texts of the sources the model got, in order (the numbers are checked
    against them); ``seen`` all sure passages of the search, used or not (a denial is checked
    against them); ``neighbours`` other passages of the same page as a sure hit."""
    answer = _IMITATED_POINTER.sub("", _IMITATED_QUOTE.sub("", answer)).strip()
    cleaned = [_clean_imitation(p) for p in split(answer)]
    imitated = [
        Replacement("imitation", " ".join(old.split()), "cleaned", new)
        for old, new in zip(split(answer), cleaned, strict=True)
        if old != new
    ]
    answer = " ".join(cleaned)
    pieces = split(answer)
    checked = check(answer, list(used)).sentences
    asked = subject(question)
    proven = bool(negation.evidence(question, [p.text for p in seen]))  # weak ones count here
    kinds: list[str] = []
    for sentence in checked:
        if sentence.program:
            kinds.append("keep")
        elif negation.denials(sentence.text):
            kinds.append("denial")
        elif negation.unsupported_claims(question, sentence.text) and not proven:
            kinds.append("value")
        elif any(not number.found for number in sentence.numbers):
            kinds.append("number")
        else:
            kinds.append("keep")
    kinds, recite = _recite(checked, kinds, used)
    kept = [s for s, k in zip(checked, kinds, strict=True) if k == "keep" and not s.program]
    # A kept sentence that names the question's noun and quantity (and gives a value, if one is
    # asked for) is an answer: a "Dazu steht nichts" beside it contradicts it. Sentences about
    # something else do not count, however well cited (N05, A08).
    answering = [s for s in kept if _answers(asked, s.text)]
    value_kept = bool(asked.kind) and any(negation.has_value(question, s.text) for s in answering)
    cited_kept = any(s.sources for s in answering)
    proof = _proof(question, seen, neighbours)
    count = len(used)
    nothing = NOTHING_ONE if count == 1 else NOTHING.format(n=count)
    # Once the program says "nichts", no kept sentence may still name the quantity asked for.
    says_nothing = any(
        k == "value" or (k == "denial" and proof is None and not value_kept and not cited_kept)
        for k in kinds
    )
    named = (*asked.quantities, *negation.SYNONYMS)
    done: set[str] = set()
    out: list[str] = []
    changes: list[Replacement] = list(imitated)
    replaced = False  # a sentence of the program stands in the text now
    for index, (piece, sentence, kind) in enumerate(zip(pieces, checked, kinds, strict=True)):
        if kind == "keep":
            if replaced and not sentence.program and _loose_after_replacement(sentence):
                changes.append(Replacement("follow", sentence.text, "dropped"))
                continue
            if says_nothing and not sentence.program and any(q in piece.lower() for q in named):
                changes.append(Replacement("value", sentence.text, "dropped"))
                continue
            out.append(sentence.text + recite[index] if index in recite else piece)
            if index in recite:
                changes.append(Replacement("number", sentence.text, "recited", out[-1]))
            continue
        if kind == "denial":
            if value_kept or (cited_kept and _GENERIC.match(sentence.text)):
                changes.append(Replacement(kind, sentence.text, "dropped"))
                continue
            new, how = proof or (nothing, "nothing")
        elif kind == "value":
            new, how = nothing, "nothing"
        else:
            new, how = UNPROVEN, "unproven"
        changes.append(Replacement(kind, sentence.text, how, new))
        replaced = True
        if new not in done:
            done.add(new)
            out.append(new)
    # The answer gives no value of the kind asked for. If a passage has one, say where (or quote
    # it); if the question names the quantity and no passage has it, say that nothing is there.
    if asked.kind or asked.quantities:
        gives = any(
            negation.gives_value(question, text)
            and negation.belongs_to_question(question, text)
            and _answers(asked, text)
            for text in (negation.plain(o) for o in out)
        )
        if not gives:
            extra = proof or ((nothing, "nothing") if asked.quantities else None)
            if extra and extra[0] not in done:
                out.append(extra[0])
                changes.append(Replacement("missing", "", extra[1], extra[0]))
    own_model = [o for o in out if not negation.is_program(o)]
    if own_model and not _has_valid_citation(own_model, count) and NO_SOURCE not in out:
        out.append(NO_SOURCE)
        changes.append(Replacement("source", "", "unsourced", NO_SOURCE))
    text = " ".join(out) if out else nothing
    if not out:
        changes.append(Replacement("denial", "", "nothing", nothing))
    return Result(text, changes)
