"""Checks of a model answer against its sources (D-008): citations and every number.

The answer is split into sentences; each sentence keeps its citations [n] separately, and each
number in it is looked up in the sources it cites (all sources if it cites none). The UI shows
unknown citations, uncited sentences and numbers not found in the cited sources.
"""

import re
from dataclasses import dataclass, field

from daengs.answer.negation import QUOTE_OPEN, is_program, self_contradiction

_CITE = re.compile(r"\[(\d{1,2}(?:\s*[,;]\s*\d{1,2})*)\]")
_SENTENCE_END = re.compile(r"[.!?]+(?:\s*\[[\d,;\s]+\])*(?=\s|$)")
_NUMBER = re.compile(r"\d+(?:[.,]\d+)*")
# Thousands separated by a space, no-break space or narrow no-break space: 8 000.
_SPACE = "[ \u00a0\u202f]"
_ANSWER_NUMBER = re.compile(rf"\d{{1,3}}(?:{_SPACE}\d{{3}})+(?:[.,]\d+)?|\d+(?:[.,]\d+)*")
_THOUSANDS_SPACE = re.compile(rf"(?<=\d){_SPACE}(?=\d{{3}}\b)")

# Number words and interval words state a value just like digits (round 3, CEO-55): they must
# stand in the sources too, in German, in English or as digits.
_WORD_VALUES = {
    "eins": 1, "zwei": 2, "drei": 3, "vier": 4, "fünf": 5, "sechs": 6, "sieben": 7, "acht": 8,
    "neun": 9, "zehn": 10, "elf": 11, "zwölf": 12, "zwanzig": 20, "dreißig": 30, "dreissig": 30,
    "hundert": 100, "tausend": 1000,
}  # fmt: skip
_ENGLISH_WORDS = {
    1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight",
    9: "nine", 10: "ten", 11: "eleven", 12: "twelve", 20: "twenty", 30: "thirty",
    100: "hundred", 1000: "thousand",
}  # fmt: skip
# What a source must have for an interval word: its own word or the English or German root.
_INTERVAL_PROOF = {
    "halbjährlich": r"halbjährlich|half-year|semi-?annual|six months|6 months|sechs monate",
    "vierteljährlich": r"vierteljährlich|quarter|three months|3 months|drei monate",
    "jährlich": r"jährlich|annual|year|jahr",
    "monatlich": r"monatlich|monthly|month|monat",
    "wöchentlich": r"wöchentlich|weekly|week|woche",
    "täglich": r"täglich|daily|\bday|\btag",
}
_WORD_CLAIM = re.compile(
    r"\b(?:" + "|".join(sorted(_WORD_VALUES, key=len, reverse=True)) + r"|halbe?[nmrs]?"
    r"|doppelt\w*|verdoppelt\w*|" + "|".join(_INTERVAL_PROOF) + r")\b",
    re.IGNORECASE,
)


def word_known(word: str, texts: list[str]) -> bool:
    """A number word, "halb", "doppelt" or an interval word of an answer stands in the sources."""
    low = " ".join(texts).lower()
    word = word.lower()
    if word in _INTERVAL_PROOF:
        return bool(re.search(_INTERVAL_PROOF[word], low))
    if word.startswith("halb"):
        return bool(re.search(r"\bhalb|\bhalf\b|\b0[.,]5\b|1/2|50\s?%", low))
    if word.startswith(("doppelt", "verdoppelt")):
        return bool(re.search(r"doppel|double|twice|\b2\s?x\b|verdoppel", low))
    value = _WORD_VALUES[word]
    if word in low or re.search(rf"\b{_ENGLISH_WORDS[value]}\b", low):
        return True
    digits = numbers_in(low)
    return str(value) in digits or (value == 1000 and bool(digits & {"1.000", "1000"}))


@dataclass
class Number:
    value: str
    start: int  # position inside Sentence.text
    end: int
    found: bool


@dataclass
class Sentence:
    text: str  # without the citation brackets
    sources: list[int] = field(default_factory=list)
    invalid_sources: list[int] = field(default_factory=list)
    numbers: list[Number] = field(default_factory=list)
    flag: str = ""  # "selbstwiderspruch": the same name twice in "X statt X" (B05)
    program: bool = False  # written by the program, not by the model (CEO-53): not checked

    @property
    def cited(self) -> bool:
        return bool(self.sources)


@dataclass
class Checked:
    sentences: list[Sentence]

    @property
    def unverified_numbers(self) -> int:
        return sum(not n.found for s in self.sentences for n in s.numbers)

    @property
    def uncited(self) -> int:
        return sum(not s.cited for s in self.sentences)

    @property
    def invalid_citations(self) -> int:
        return sum(len(s.invalid_sources) for s in self.sentences)

    @property
    def contradictions(self) -> int:
        return sum(bool(s.flag) for s in self.sentences)


def forms(token: str) -> set[str]:
    """Spellings of one number: 2.000 / 2000, 0,5 / 0.5."""
    plain = token.strip(".,")
    return {
        plain,
        plain.replace(",", "."),
        plain.replace(".", "").replace(",", "."),
        plain.replace(",", ""),
    }


def known_in(value: str, numbers: set[str]) -> bool:
    """The number of an answer (any spelling of it) is among the numbers of a source."""
    return bool(forms(_THOUSANDS_SPACE.sub("", value)) & numbers)


def numbers_in(text: str) -> set[str]:
    joined = _THOUSANDS_SPACE.sub("", text)
    found: set[str] = set()
    for token in _NUMBER.findall(joined):
        found |= forms(token)
    return found


def split(answer: str) -> list[str]:
    """The sentences of an answer as written, with their citation brackets. A sentence the
    program wrote around a quotation (``QUOTE_OPEN`` ... "bitte selbst prüfen.") stays in one
    piece although the quotation has full stops of its own."""
    answer = answer.strip()
    starts = [0] + [m.end() for m in _SENTENCE_END.finditer(answer)]
    pieces = [
        answer[begin:end].strip()
        for begin, end in zip(starts, [*starts[1:], len(answer)], strict=True)
    ]
    sentences: list[str] = []
    open_quote = False
    for piece in (p for p in pieces if p):
        if open_quote:
            sentences[-1] += " " + piece
        else:
            sentences.append(piece)
        open_quote = sentences[-1].startswith(QUOTE_OPEN) and not is_program(sentences[-1])
    return sentences


def check(answer: str, sources: list[str]) -> Checked:
    known = {n: numbers_in(text) for n, text in enumerate(sources, start=1)}
    everything = set().union(*known.values()) if known else set()
    sentences = []
    for raw in split(answer):
        cited = [int(n) for group in _CITE.findall(raw) for n in re.split(r"[,;]", group)]
        text = _CITE.sub("", raw)
        text = re.sub(r"\s+([.!?,;:])", r"\1", " ".join(text.split()))
        sentence = Sentence(
            text=text,
            sources=[n for n in dict.fromkeys(cited) if n in known],
            invalid_sources=[n for n in dict.fromkeys(cited) if n not in known],
            flag="selbstwiderspruch" if self_contradiction(text) else "",
            program=is_program(raw),
        )
        pool = (
            set().union(*(known[n] for n in sentence.sources)) if sentence.sources else everything
        )
        for number in () if sentence.program else _ANSWER_NUMBER.finditer(text):
            value = number.group(0).strip(".,")
            found = known_in(value, pool)
            sentence.numbers.append(
                Number(value, number.start(), number.start() + len(value), found)
            )
        pool_texts = (
            [sources[n - 1] for n in sentence.sources] if sentence.sources else list(sources)
        )
        for word in () if sentence.program else _WORD_CLAIM.finditer(text):
            sentence.numbers.append(
                Number(
                    word.group(0), word.start(), word.end(), word_known(word.group(0), pool_texts)
                )
            )
        sentences.append(sentence)
    return Checked(sentences)
