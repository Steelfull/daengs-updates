"""Denials in a model answer, checked against the passages (AP-9.38, D-078 B02/B03/B05).

The small model sometimes writes "no torque is given" or "the oil need not be changed" although
a passage says otherwise (Nutzertest m23). The program decides, not the model:
- ``denials`` finds the sentences that deny or say nothing;
- ``evidence`` looks in passages for a value (number with unit, interval word) that stands next
  to what the question asks for;
- ``self_contradiction`` finds "'X' statt 'X'" (the same name twice).
A denial with evidence is rewritten with those passages or marked, never left alone.
"""

import re
from collections.abc import Sequence
from dataclasses import dataclass

from daengs.answer.terms import PROPERTY, subject

_CITE = re.compile(r"\[\d{1,2}(?:\s*[,;]\s*\d{1,2})*\]")
_SENTENCE = re.compile(r"(?<=[.!?])\s+|\n+")
# Things a denial is about; "keine Wechselintervalle", "kein konkreter Drehmomentwert".
_INFO = (
    r"(?:angabe|information|hinweis|intervall|wechsel|wert|drehmoment|anzugsmoment|frist|"
    r"häufigkeit|abstand|abstände|vorgabe|daten|aussage|zeitraum|zyklus|menge|zahl|"
    r"fest|spezifisch|konkret|genau|bestimmt|vorgeschrieben|vorgegeben|explizit|ausdrücklich)"
)
_ADVERB = r"(?:\s+(?:explizit|ausdrücklich|konkret|näher|eindeutig|genau|direkt))?"
_DENIAL = re.compile(
    r"\bnichts\b"
    rf"|\bkein(?:e|en|em|er|es)?\s+(?:\w+\s+){{0,2}}?\w*{_INFO}\w*"
    rf"|\bnicht{_ADVERB}\s+(?:\w+\s+){{0,2}}?(?:angegeben|genannt|enthalten|beschrieben|erwähnt|"
    r"aufgeführt|festgelegt|vorgegeben|definiert|vorhanden|spezifiziert|bekannt|zu\s+finden|"
    r"erforderlich|notwendig|nötig)"
    # "nicht als regelmäßiges Intervall ... beschrieben", "keine Garantie ... genannt"
    r"|\bnicht\b[^.!?,;]{0,80}?\b(?:angegeben|genannt|erwähnt|beschrieben|aufgeführt|aufgelistet|"
    r"festgelegt|vorgegeben|dokumentiert|gefunden)\b"
    r"|\bkein\w*\b[^.!?,;]{0,60}?\b(?:angegeben|genannt|erwähnt|beschrieben|aufgeführt|"
    r"enthalten|vorhanden|festgelegt|definiert|gemacht|angeführt)\b"
    r"|\b(?:muss|müssen|braucht|brauchen|bedarf|bedürfen)\s+(?:\w+\s+){0,3}?nicht\b"
    r"|\b(?:steht|stehen|findet|finden)\b[^.!?]{0,60}?\bnicht\b"
    # round 3: "keine weiteren Angaben/Schrauben", "benötigt keine …"
    r"|\bkein(?:e|en|em|er|es)?\s+weiter\w*"
    r"|\b(?:benötigt|benötigen|erfordert|erfordern)\s+(?:\w+\s+){0,2}?kein\w*"
    r"|lebenslang|wartungsfrei|\bohne\s+angabe",
    re.IGNORECASE,
)
# Other words for a quantity that the answer may use ("Druckluftbedarf" for "Druckluftverbrauch").
SYNONYMS = ("bedarf",)
_SELF = re.compile(
    r"[„\"‚»'‘]?(?P<w>[\wÄÖÜäöüß][\wÄÖÜäöüß\- ]{2,40}?)[“\"‘«'’]?\s+statt\s+"
    r"[„\"‚»'‘]?(?P=w)\b",
    re.IGNORECASE,
)
_UNITS = (
    r"Nm|N·m|mm²|mm|cm|km|m|kg|g|bar|mbar|°\s?C|°\s?F|kV|V|mA|A|kW|W|Hz|min|h|s|Stunden|"
    r"Betriebsstunden|operating\s+hours|hours|hrs?|years?|months?|weeks?|days?|Jahre[n]?|"
    r"Monate[n]?|Wochen|Tage[n]?|Tag|%|ml|l|rpm|U/min|µm|Ω"
)
_NUMBER = r"\d(?:[\d.,   ]*\d)?\s?"
_AFTER = r"(?![\wäöüÄÖÜ])"
# What counts as a value, by what the question asks for (terms.Subject.kind).
_VALUES = {
    "": re.compile(rf"{_NUMBER}(?:{_UNITS}){_AFTER}", re.IGNORECASE),
    "torque": re.compile(rf"{_NUMBER}(?:Nm|N·m|Nmm|lb-?ft|in-?lb){_AFTER}", re.IGNORECASE),
    "temperature": re.compile(rf"{_NUMBER}°\s?[CF]{_AFTER}", re.IGNORECASE),
    # A consumption is an amount per time ("12 l/min"), not a pressure ("6 bar").
    "consumption": re.compile(
        rf"{_NUMBER}(?:N?l|m³|m3|kg|g|kWh|Nm³)\s?/\s?(?:min|h|s|d|Tag){_AFTER}", re.IGNORECASE
    ),
    "protection": re.compile(r"\bIP\s?\d{2}\b|\bNEMA\s?\d", re.IGNORECASE),
    "time": re.compile(
        rf"{_NUMBER}(?:Sekunden?|Minuten?|seconds?|minutes?|min|Stunden|Betriebsstunden|"
        rf"operating\s+hours|hours|hrs?|h|years?|months?|"
        rf"weeks?|days?|Jahre[n]?|Monate[n]?|Wochen|Tage[n]?|Tag){_AFTER}"
        r"|\b(?:täglich|wöchentlich|monatlich|halbjährlich|vierteljährlich|jährlich|daily|weekly|"
        r"monthly|annually|yearly|every)\b|\balle\s+\d",
        re.IGNORECASE,
    ),
}
# Sentences the program writes itself (CEO-53, D-079): they end in one of two fixed tails and are
# not model output. A sentence that quotes a passage starts with QUOTE_OPEN.
QUOTE_OPEN = "Dazu nennt die Stelle"
TAIL_CHECK = "– bitte selbst prüfen."
TAIL_PAGE = "– bitte dort nachsehen."
_PROGRAM = re.compile(r"–\s*bitte (?:selbst prüfen|dort nachsehen)\.(?:\s*\[[\d,;\s]+\])*\s*$")
NEAR = 160  # characters (about 25 words) between a value and what is asked: "next to"
# A passage is quoted or added to a redraft only when value and quantity stand this close: the
# true rows of the answer gold score -6 to -33, the wrong ones found (m25 round 2) -61 to -112.
STRONG = 40


def sentences(text: str) -> list[str]:
    plain = re.sub(r"\s+([.!?,;:])", r"\1", " ".join(_CITE.sub("", text).split()))
    return [s.strip() for s in _SENTENCE.split(plain) if s.strip()]


def denials(answer: str) -> list[str]:
    """The sentences of the answer that deny something or say there is nothing."""
    return [s for s in sentences(answer) if _DENIAL.search(s)]


def is_program(sentence: str) -> bool:
    """A fixed sentence or a quotation the program wrote (not the model)."""
    return bool(_PROGRAM.search(sentence))


def plain(text: str) -> str:
    """The text of a sentence without its citation brackets and stray spaces."""
    return re.sub(r"\s+([.!?,;:])", r"\1", " ".join(_CITE.sub("", text).split()))


def self_contradiction(sentence: str) -> bool:
    """The same name twice in "'X' statt 'X'" (B05)."""
    return bool(_SELF.search(sentence))


@dataclass(frozen=True)
class Evidence:
    index: int  # of the passage in the list given
    text: str  # the words around the value, as they stand in the passage
    score: int = 0  # minus the distance of value and quantity in characters: closer is higher


def evidence(question: str, passages: Sequence[str]) -> list[Evidence]:
    """Passages with a value next to what the question asks for, at most one place per passage.

    A passage counts if every noun of the question is in it (anywhere, in German or in the
    English words of terms.BRIDGE) and a value of the kind asked for (a torque, a time) stands
    within ``NEAR`` words of the quantity or action asked for ("Anzugsmoment ... 20 Nm",
    "Every 10,000 operating hours ... Change the oil") and has one of the nouns in its
    neighbourhood. The closest pair wins. Without a quantity or action in the question nothing
    counts: no guessing.
    """
    asked = subject(question)
    if not asked.props:
        return []
    value = _VALUES[asked.kind]
    found: list[Evidence] = []
    for index, text in enumerate(passages):
        low = text.lower()
        if not all(any(f in low for f in group) for group in asked.nouns):
            continue
        marks = [m.start() for m in value.finditer(text)]
        if not marks:
            continue
        props = _positions(low, [f for g in asked.props for f in g])
        nouns = _positions(low, [f for g in asked.nouns for f in g])
        best: tuple[int, int, int] | None = None  # distance in characters, value, quantity
        for mark in marks:
            for prop in props:
                gap = abs(mark - prop)
                if gap > NEAR and (best is None or gap >= best[0]):
                    continue
                if asked.nouns and not any(abs(mark - n) <= NEAR for n in nouns):
                    continue
                if best is None or gap < best[0]:
                    best = (gap, mark, prop)
        if best is None or best[0] > NEAR:
            continue
        begin = max(0, min(best[1], best[2]) - 60)
        end = min(len(text), max(best[1], best[2]) + 120)
        begin = text.rfind(" ", 0, begin) + 1 if begin else 0
        end = text.find(" ", end) if text.find(" ", end) != -1 else len(text)
        found.append(Evidence(index, text[begin:end].strip(), -best[0]))
    return sorted(found, key=lambda e: -e.score)


def unsupported_claims(question: str, answer: str) -> list[str]:
    """Sentences that state a value of the kind asked for (a temperature, a torque, a time) about
    the question's nouns, without any passage having been found for it. Only for questions that
    name such a quantity; the check is the same one as ``evidence``. A sentence that names the
    quantity itself ("Verbrauch") and gives any number with a unit counts too: "Der
    Druckluftverbrauch beträgt 6 bar" is a pressure, not the consumption asked for. The caller
    decides whether a passage exists: this only finds the sentences that make the claim."""
    asked = subject(question)
    # Only for a question that names the quantity ("Temperatur", "Verbrauch", "Gewährleistung"):
    # "Wie oft ...?" has no such word, and an interval is often worded far from the noun (G04).
    if not asked.quantities or not asked.nouns:
        return []
    value = _VALUES[asked.kind]
    claims = []
    for sentence in sentences(answer):
        low = sentence.lower()
        names_quantity = any(q in low for q in (*asked.quantities, *SYNONYMS))
        if (
            (value.search(sentence) or (names_quantity and _VALUES[""].search(sentence)))
            and not _DENIAL.search(sentence)
            and any(any(f in low for f in group) for group in asked.nouns)
        ):
            claims.append(sentence)
    return claims


def has_value(question: str, text: str) -> bool:
    """A value of the kind the question asks for stands in the text (nothing: no such kind)."""
    kind = subject(question).kind
    return bool(kind) and bool(_VALUES[kind].search(text))


def gives_value(question: str, text: str) -> bool:
    """Like ``has_value``, but a question without a kind accepts any number with a unit."""
    return bool(_VALUES[subject(question).kind].search(text))


def _positions(low: str, fragments: list[str]) -> list[int]:
    found: list[int] = []
    for fragment in set(fragments):
        at = low.find(fragment)
        while at != -1:
            found.append(at)
            at = low.find(fragment, at + 1)
    return found


# Quantities that a value can belong to besides the one asked ("Lebensdauer" is no "Frist"): the
# German keys of terms.PROPERTY that name no interval, and their English words (round 4).
_OTHER_QUANTITIES = (
    *(k for k in PROPERTY if k not in {"intervall", "abstand", "abstände", "frist", "dauer"}),
    "service life",
    "lifetime",
    "nominal life",
)


def belongs_to_question(question: str, text: str) -> bool:
    """The value of a sentence belongs to the quantity asked, not to another one.

    A value counts as the asked one unless a different quantity word ("Lebensdauer", "Gewicht")
    stands nearer to it than every word of what was asked (A07 round 3: "100.000 Betriebsstunden"
    Lebensdauer for a question about the re-lubrication). Values near no quantity word count."""
    asked = subject(question)
    if not asked.props:
        return True
    low = text.lower()
    own = _positions(low, [f for g in asked.props for f in g])
    own_words = {f for g in asked.props for f in g}
    other = _positions(low, [w for w in _OTHER_QUANTITIES if w not in own_words])
    marks = [m.start() for m in _VALUES[subject(question).kind].finditer(text)]
    if not marks:
        return False
    for mark in marks:
        d_own = min((abs(mark - p) for p in own), default=None)
        d_other = min((abs(mark - p) for p in other), default=None)
        if d_other is None or d_other > NEAR:
            return True
        if d_own is not None and d_own <= d_other:
            return True
    return False
