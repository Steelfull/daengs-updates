"""What a question asks about, and what that is called in an English document (AP-9.38, B02).

A German question to an English table ("Wie oft muss das Öl im Getriebe gewechselt werden?" to
"Every 10,000 operating hours ... Change the oil") shares no word with it. Without a bridge the
shortened source (excerpt) loses the row and the program cannot tell whether a denial is wrong.
The list is small on purpose: maintenance words of manuals, not a dictionary.
"""

import re

WORD = re.compile(r"[\wäöüÄÖÜß]+")
# Question words and common verbs that name nothing to look for.
STOP = frozenset(
    "wie was wer wo wann warum wieso welche welcher welches welchen welchem wieviel viel viele "
    "lange oft hoch groß der die das den dem des ein eine einer einem einen und oder mit für bei "
    "beim auf aus von nach über unter im in am an zu zum zur ich man mein meine ist sind war "
    "wird werden muss müssen kann können soll sollen darf dürfen gibt hat haben beträgt "
    "betragen gilt gelten heißt heißen steht stehen nicht auch noch nur dann wenn dass als "
    "sich es sie er wir ihr bitte dazu davon dafür dabei damit daran hier dort "
    "betriebsanleitung anleitung unterlagen dokument dokumenten handbuch fundstellen".split()
)
# Nouns that name the quantity asked for; the value in a document stands next to them.
PROPERTY = {
    "drehmoment": ("torque", "anzugsmoment"),
    "anzugsmoment": ("torque", "anzugsmoment", "drehmoment"),
    "temperatur": ("temperature", "temperatur"),
    "verbrauch": ("consumption", "verbrauch"),
    "intervall": ("interval", "every", "intervall"),
    "abstand": ("interval", "every", "abstand", "abstände"),
    "abstände": ("interval", "every", "abstand", "abstände"),
    "frist": ("period", "frist"),
    "dauer": ("duration", "dauer"),
    "menge": ("quantity", "amount", "menge"),
    "gewicht": ("weight", "gewicht"),
    "drehzahl": ("speed", "rpm", "drehzahl"),
    "leistung": ("power", "output", "leistung"),
    "spannung": ("voltage", "spannung"),
    "durchmesser": ("diameter", "durchmesser"),
    "schutzart": ("protection", "schutzart", "ip "),
    "gewährleistung": ("warranty", "gewährleistung", "garantie"),
    "garantie": ("warranty", "garantie", "gewährleistung"),
    "lebensdauer": ("service life", "lifetime", "lebensdauer"),
}
# German stem (as found inside a question word) -> English words of manuals, and verb forms.
BRIDGE = {
    "getrie": ("gear",),
    "wechs": ("chang", "replac", "exchang", "wechs"),
    "schmie": ("lubric", "greas", "schmier"),
    "fett": ("greas", "lubric"),
    "kontroll": ("check", "inspect", "kontroll"),
    "prüf": ("check", "inspect", "test", "prüf"),
    "überhol": ("overhaul", "überhol"),
    "überprü": ("check", "inspect", "überprü"),
    "angezog": ("tighten", "torque", "anzug", "anzieh"),
    "anzieh": ("tighten", "torque", "anzug", "anzieh"),
    "anzug": ("tighten", "torque", "anzug"),
    "einstell": ("set", "adjust", "einstell"),
    "reinig": ("clean", "reinig"),
    "ersetz": ("replac", "ersetz", "tausch"),
    "tausch": ("replac", "tausch", "ersetz"),
    "wartung": ("maintenan", "service", "wartung"),
    "schrau": ("screw", "bolt", "schrau"),
    "lager": ("bearing", "lager"),
    "kette": ("chain", "kette"),
    "dichtung": ("seal", "dichtung"),
    "bremse": ("brake", "bremse"),
    "kupplung": ("coupling", "kupplung"),
    "pumpe": ("pump", "pumpe"),
    "filter": ("filter",),
    "lagerung": ("storage", "lagerung"),
}
_PREFIXES = ("nach", "ein", "aus", "auf", "ab", "an", "ver", "be", "ge", "zu")
_OIL = re.compile(r"^öl|öl$|ölwechsel", re.IGNORECASE)
# What an answer to "how often / when" looks like when no other quantity is named.
INTERVAL = ("every", "interval", "alle ", "jährlich", "monatlich", "täglich", "wöchentlich")
_INTERVAL_QUESTION = re.compile(
    r"\b(?:wie\s+oft|wann|wie\s+lange|abstände?n?|intervalle?)\b", re.IGNORECASE
)


def _stem(word: str) -> str:
    for prefix in _PREFIXES:
        if word.startswith(prefix) and len(word) - len(prefix) >= 5:
            word = word[len(prefix) :]
    return word[:5]


def _bridged(word: str) -> set[str]:
    found: set[str] = set()
    if _OIL.search(word):
        found.add("oil")
    for key, english in BRIDGE.items():
        if key in word:
            found.update(english)
    return found


def english_stems(question: str) -> set[str]:
    """First five letters of the English words that belong to the question's words (excerpt).
    German variants are left out: the excerpt already compares German stems."""
    german = (*BRIDGE, *PROPERTY)
    stems: set[str] = set()
    for raw in WORD.findall(question):
        word = raw.lower()
        found = _bridged(word)
        for key, names in PROPERTY.items():
            if key in word:
                found.update(names)
        stems |= {f[:5] for f in found if not f.startswith(german)}
    return {s for s in stems if len(s) >= 3}


class Subject:
    """What the question is about: ``nouns`` (all must be in a passage) and ``props`` (the
    quantity or action asked for; one must stand next to the value). Each group is a set of
    fragments, any of which, found in the lowercase text, satisfies the group. ``kind`` is the
    sort of value asked for: "torque", "temperature", "time", "consumption", "protection" or
    "" (any)."""

    def __init__(
        self,
        nouns: list[set[str]],
        props: list[set[str]],
        kind: str,
        quantities: frozenset[str] = frozenset(),
    ) -> None:
        self.nouns = nouns
        self.props = props
        self.kind = kind
        self.quantities = quantities  # the quantity words of the question: "verbrauch", "gewicht"


def _noun_fragment(word: str) -> str:
    """Long compounds keep more letters: "Schrumpftunnel" must not find "Schrumpffolie"."""
    return word[: max(6, len(word) - 3)]


def subject(question: str) -> Subject:
    nouns: list[set[str]] = []
    props: list[set[str]] = []
    keys: set[str] = set()
    for raw in re.split(r"[\s/\-]+", question):
        match = WORD.search(raw)
        if not match:
            continue
        raw = match.group(0)
        word = raw.lower()
        if word in STOP or any(c.isdigit() for c in raw) or (len(raw) < 3 and word != "öl"):
            continue
        if len(raw) <= 3 and raw.isupper():  # a code like "VM"
            continue
        bridged = _bridged(word)
        prop_key = max((k for k in PROPERTY if k in word), key=len, default=None)
        if prop_key:
            props.append({prop_key, *PROPERTY[prop_key]})
            keys.add(prop_key)
            rest = word.replace(prop_key, "")
            if len(rest) >= 4:
                nouns.append({_noun_fragment(rest), *_bridged(rest)})
        elif raw[:1].isupper() or word == "öl":
            nouns.append({_noun_fragment(word) if word != "öl" else "öl", *bridged})
        else:
            props.append({_stem(word), *bridged})
    interval = bool(_INTERVAL_QUESTION.search(question)) or bool(
        keys & {"intervall", "abstand", "abstände", "frist", "dauer"}
    )
    if not props and interval:
        props.append(set(INTERVAL))
    if keys & {"drehmoment", "anzugsmoment"}:
        kind = "torque"
    elif "temperatur" in keys:
        kind = "temperature"
    elif "verbrauch" in keys:
        kind = "consumption"
    elif "schutzart" in keys:
        kind = "protection"
    else:
        kind = "time" if interval else ""
    return Subject(nouns, props, kind, frozenset(keys))
