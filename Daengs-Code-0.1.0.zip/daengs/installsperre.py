"""One installation step at a time (AP-9.42): program, extension and removal share one lock.

The delivery has two scripts; a user may start both at once, or start the removal while a copy
runs. The extension script even runs the *installed* Python, which the program copy replaces.
A named mutex (like ``RUNNING_MUTEX``) is the lock: Windows drops it when the holder ends, so a
crash never leaves a stale lock behind (unlike a lock file). The second one does not wait, it
stops with a clear message: waiting inside the installed Python would itself block the swap.
"""

import contextlib
import sys
from collections.abc import Iterator

from daengs import PRODUCT

INSTALL_MUTEX = f"{PRODUCT}-installation-5d3f0c7e"
ERROR_ALREADY_EXISTS = 183

BUSY_MESSAGE = (
    f"Es läuft gerade schon eine andere Installation oder Deinstallation von {PRODUCT} "
    "(Programm, Sprachmodell oder Entfernen). Bitte warte, bis sie fertig ist, "
    "und starte diese dann erneut."
)


class InstallationBusy(Exception):
    """Another installation step holds the lock; ``str(exc)`` is the message for the user."""


@contextlib.contextmanager
def installation_lock(name: str | None = None) -> Iterator[None]:
    """Hold the installation lock for the ``with`` block, or raise ``InstallationBusy``."""
    if sys.platform != "win32":
        yield
        return
    import ctypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    handle = kernel32.CreateMutexW(None, False, name or INSTALL_MUTEX)
    if not handle:
        raise OSError("Die Installationssperre konnte nicht angelegt werden.")
    try:
        if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
            raise InstallationBusy(BUSY_MESSAGE)
        yield
    finally:
        kernel32.CloseHandle(handle)
