"""Uninstall Daengs (F9, D-021) with Daengs's own Python instead of a separate uninstaller program.

Why: Windows Smart App Control blocks unsigned programs it does not know, and the uninstaller that
Inno Setup writes at install time is unknown by definition (found in the M6 Probelauf). Daengs's
Python is allowed, so the "Apps > Daengs > Deinstallieren" entry runs:
    pythonw.exe -I -m daengs.uninstall            (asks)
    pythonw.exe -I -m daengs.uninstall --still    (no questions; projects are deleted)
"""

import argparse
import contextlib
import os
import shutil
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from daengs import GLOBAL_WIKI_FOLDER, PRODUCT
from daengs.core.settings import PREFERENCES_FILE
from daengs.core.updates import FOLDER as UPDATE_FOLDER
from daengs.installsperre import InstallationBusy, installation_lock

UNINSTALL_KEY = rf"Software\Microsoft\Windows\CurrentVersion\Uninstall\{PRODUCT}"
# Extensions have their own "Apps" entry (D-022); removing Daengs removes them too.
EXTENSIONS = {"sprachmodell": UNINSTALL_KEY + "-Sprachmodell"}
MB_YESNO, MB_ICONQUESTION, MB_ICONINFORMATION, MB_DEFBUTTON2 = 0x4, 0x20, 0x40, 0x100
MB_ICONWARNING = 0x30
# In front of other windows: a question hidden behind the Explorer looks like "never asked".
MB_SETFOREGROUND, MB_TOPMOST = 0x10000, 0x40000
CREATE_NO_WINDOW = 0x08000000
IDYES = 6
SYSTEM_ROOT = os.environ.get("SYSTEMROOT", r"C:\Windows")

Ask = Callable[[str, bool], bool]  # (question, default yes) -> answer


@dataclass
class Places:
    install_dir: Path
    local_appdata: Path
    shortcuts: list[Path] = field(default_factory=list)

    @property
    def program_data(self) -> Path:
        return self.local_appdata / PRODUCT

    @property
    def global_wiki(self) -> Path:
        return self.program_data / GLOBAL_WIKI_FOLDER

    @classmethod
    def current(cls) -> "Places":
        install = Path(sys.executable).resolve().parent.parent  # <install>/python/pythonw.exe
        appdata = Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
        desktop = Path(os.environ["USERPROFILE"]) / "Desktop"
        return cls(
            install_dir=install,
            local_appdata=Path(os.environ["LOCALAPPDATA"]),
            shortcuts=[appdata / f"{PRODUCT}.lnk", desktop / f"{PRODUCT}.lnk"],
        )


def message_box(text: str, flags: int) -> int:
    import ctypes

    flags |= MB_SETFOREGROUND | MB_TOPMOST
    return ctypes.windll.user32.MessageBoxW(None, text, f"{PRODUCT} deinstallieren", flags)


def ask_with_box(question: str, default_yes: bool) -> bool:
    flags = MB_YESNO | MB_ICONQUESTION | (0 if default_yes else MB_DEFBUTTON2)
    return message_box(question, flags) == IDYES


def is_running() -> bool:
    if sys.platform != "win32":
        return False
    import ctypes

    from daengs import RUNNING_MUTEX

    synchronize = 0x00100000
    handle = ctypes.windll.kernel32.OpenMutexW(synchronize, False, RUNNING_MUTEX)
    if handle:
        ctypes.windll.kernel32.CloseHandle(handle)
        return True
    return False


def remove_registry_entry(*keys: str) -> None:
    if sys.platform != "win32":
        return
    import winreg

    for key in keys or (UNINSTALL_KEY, *EXTENSIONS.values()):
        with contextlib.suppress(FileNotFoundError):
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, key)


WAIT_ROUNDS = 300  # each round takes about 0.2 s (one ``tasklist`` call): about a minute


def remove_command(folder: Path, wait_for_pid: int) -> str:
    """cmd line: wait until process ``wait_for_pid`` has ended, then remove ``folder``, retrying.

    No ``ping``/``timeout``: each round asks ``tasklist`` for the process (that call is also the
    pause). While it lives, nothing is removed; once it is gone every round tries ``rmdir`` until
    the folder is gone (virus scanner or indexer may hold a file for a moment).
    """
    system32 = os.path.join(SYSTEM_ROOT, "System32")
    cmd = os.path.join(system32, "cmd.exe")
    # Full paths: a ``find`` of another toolset (Git for Windows) may come first on PATH.
    tasklist, find = (os.path.join(system32, name) for name in ("tasklist.exe", "find.exe"))
    alive = f'"{tasklist}" /fi "PID eq {wait_for_pid}" /nh | "{find}" " {wait_for_pid} " >nul'
    body = (
        f'for /l %i in (1,1,{WAIT_ROUNDS}) do @if exist "{folder}" '
        f'({alive} || rmdir /s /q "{folder}" 2>nul)'
    )
    # Passed verbatim: /s makes cmd strip only the outer quotes, the folder keeps its own.
    return f'"{cmd}" /s /c "{body}"'


def remove_later(folder: Path, wait_for_pid: int | None = None) -> None:
    """The running Python lives in ``folder``: a hidden cmd removes it once this process has ended.

    ``CREATE_NO_WINDOW`` alone, not combined with ``DETACHED_PROCESS`` (that pair opens a console
    window). ``wait_for_pid`` defaults to this process.
    """
    command = remove_command(folder, wait_for_pid or os.getpid())
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 0  # SW_HIDE
    subprocess.Popen(  # noqa: S603 - fixed system program, path from our own installation
        command,
        creationflags=CREATE_NO_WINDOW,
        startupinfo=startup,
        close_fds=True,
        cwd=SYSTEM_ROOT,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def uninstall(
    places: Places,
    ask: Ask,
    remove_install_dir: Callable[[Path], None] = remove_later,
    remove_registry: Callable[[], None] = remove_registry_entry,
) -> dict[str, Any]:
    """Remove Daengs. Delivery folders are never touched. Returns what was removed.

    ``reste`` lists what could not be removed (after retries), so the final message can say so.
    The program folder is handed to ``remove_install_dir`` (it holds the running Python).
    """
    reste: list[str] = []

    def drop(path: Path) -> None:
        if not _remove(path):
            reste.append(str(path))

    if not ask(f"{PRODUCT} von diesem Rechner entfernen?", True):
        return {"entfernt": False, "projekte": False, "gesamtwiki": False, "reste": reste}
    projects = ask(
        f"Auch alle Projekte von {PRODUCT} löschen?\n\n"
        "Gelöscht werden Suchindex, Übersicht und Wiki aller Projekte. "
        "Deine Lieferordner mit den Kundendateien bleiben unverändert.\n\n"
        f"Wähl „Nein“ nur, wenn du {PRODUCT} gleich wieder installieren möchtest.",
        True,
    )
    # Asked whenever the folder exists, whatever the answer above was; the default follows it.
    global_wiki = places.global_wiki.is_dir() and ask(
        "Auch das Gesamt-Wiki löschen?\n\n"
        "Es gilt für alle Projekte und enthält deine Regeln, dein Glossar und dein Vorgehen.\n\n"
        f"Wähl „Nein“, wenn du es bei einer neuen Installation von {PRODUCT} "
        "wieder nutzen möchtest.",
        projects,
    )
    for shortcut in places.shortcuts:
        drop(shortcut)
    remove_registry()
    if global_wiki:
        drop(places.global_wiki)
    if projects and not places.global_wiki.is_dir():
        drop(places.program_data)
    elif projects:
        for entry in places.program_data.iterdir():
            if entry != places.global_wiki:
                drop(entry)
    else:
        drop(places.program_data / "fenster")
        drop(places.program_data / "Projekte" / "_tmp")
        drop(places.program_data / UPDATE_FOLDER)
        drop(places.program_data / PREFERENCES_FILE)
    remove_install_dir(places.install_dir)
    return {"entfernt": True, "projekte": projects, "gesamtwiki": global_wiki, "reste": reste}


def uninstall_extension(
    places: Places,
    name: str,
    ask: Ask,
    remove_registry: Callable[..., None] = remove_registry_entry,
    reste: list[str] | None = None,
) -> bool:
    """Remove one extension; Daengs and the projects stay. Chat histories stay in the projects."""
    if name not in EXTENSIONS:
        raise ValueError("unbekannte Erweiterung")
    if not ask(f"Die Erweiterung {PRODUCT}-Sprachmodell entfernen? {PRODUCT} selbst bleibt.", True):
        return False
    folder = places.install_dir / "erweiterungen" / name
    if not _remove(folder) and reste is not None:
        reste.append(str(folder))
    remove_registry(EXTENSIONS[name])
    return True


def _remove(path: Path) -> bool:
    """Remove a file or folder, retrying while Windows holds it. True = it is gone."""
    for attempt in range(6):
        try:
            if path.is_dir() and not path.is_symlink():
                shutil.rmtree(path)
            else:
                path.unlink(missing_ok=True)
            return True
        except FileNotFoundError:
            return True
        except OSError:
            time.sleep(0.3 * (attempt + 1))
    if path.is_dir():
        shutil.rmtree(path, ignore_errors=True)  # take what can go; the check below tells the rest
    return not path.exists() and not path.is_symlink()


def leftovers_message(reste: list[str]) -> str:
    shown = "\n".join(f"  {path}" for path in reste[:8])
    more = f"\n  … und {len(reste) - 8} weitere" if len(reste) > 8 else ""
    return (
        f"{PRODUCT} wurde entfernt, aber das konnte nicht gelöscht werden:\n\n{shown}{more}\n\n"
        "Bitte schließ Programme, die darin etwas geöffnet haben, und lösch es selbst im Explorer."
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="daengs.uninstall")
    parser.add_argument("--still", action="store_true", help="ohne Rückfragen, alles löschen")
    parser.add_argument("--erweiterung", choices=sorted(EXTENSIONS), help="nur diese Erweiterung")
    args = parser.parse_args(argv)
    if is_running():
        if not args.still:
            message_box(
                f"{PRODUCT} läuft noch. Bitte {PRODUCT} zuerst schließen.", MB_ICONINFORMATION
            )
        return 3
    ask = (lambda question, default_yes: default_yes) if args.still else ask_with_box
    try:
        with installation_lock():
            return _run(args, ask)
    except InstallationBusy as exc:
        if not args.still:
            message_box(str(exc), MB_ICONINFORMATION)
        return 5


def _run(args: argparse.Namespace, ask: Ask) -> int:
    places = Places.current()
    reste: list[str] = []
    if args.erweiterung:
        if uninstall_extension(places, args.erweiterung, ask, reste=reste) and not args.still:
            message_box(
                leftovers_message(reste) if reste else "Die Erweiterung wurde entfernt.",
                MB_ICONWARNING if reste else MB_ICONINFORMATION,
            )
        return 4 if reste else 0
    pending: list[Path] = []
    result = uninstall(places, ask, remove_install_dir=pending.append)
    if result["entfernt"] and not args.still:
        reste = result["reste"]
        message_box(
            leftovers_message(reste) if reste else f"{PRODUCT} wurde entfernt.",
            MB_ICONWARNING if reste else MB_ICONINFORMATION,
        )
    # Only now, after the last window: the hidden helper waits for this process to end.
    for folder in pending:
        remove_later(folder)
    return 4 if result["reste"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
