"""The Daengs window: pywebview with Microsoft WebView2, shut off from the network (D-012, D-020).

The page inside is served by the local service; the session token reaches it only through the
window's own bridge (``pywebview.api.token``), never through a URL.
"""

import json
import os
from collections.abc import Callable
from pathlib import Path
from typing import Any

from daengs import PRODUCT, window_title

# Chromium switches for WebView2: no SmartScreen lookups, no background or update traffic, no
# proxy. The firewall test (M6) proves that no connection leaves the computer.
WEBVIEW2_ARGUMENTS = " ".join(
    [
        "--disable-features=msSmartScreenProtection,msEdgeEnhanceTextContrast",
        "--disable-background-networking",
        "--disable-component-update",
        "--disable-domain-reliability",
        "--disable-sync",
        "--disable-breakpad",
        "--no-pings",
        "--no-proxy-server",
        "--no-first-run",
    ]
)


def program_data() -> Path:
    """Customer-free program data of Daengs (window profile), separate from project data."""
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(base) / PRODUCT


class WindowApi:
    """Bridge offered to the page in the window. Only underscore attributes stay private."""

    def __init__(self, token: str, url: str) -> None:
        self._token = token
        self._url = url
        self._window = None

    def token(self) -> str | None:
        # Only the Daengs page itself gets the token, never a page navigated to by accident.
        current = self._window.get_current_url() if self._window is not None else None
        if current is None or not current.startswith(self._url + "/"):
            return None
        return self._token

    def close_window(self) -> bool:
        """Close the program for an update the user has started (13 §3)."""
        if self.token() is None:
            return False
        self._window.destroy()
        return True

    def choose_folder(self) -> str | None:
        import webview

        if self._window is None:
            return None
        result = self._window.create_file_dialog(webview.FileDialog.FOLDER)
        return result[0] if result else None

    def save_file(self, filename: str, text: str) -> bool:
        """Save dialog for exports and the diagnostic report; the user picks the place."""
        import webview

        if self.token() is None or not isinstance(text, str) or len(text) > 50 * 2**20:
            return False
        name = Path(filename).name or f"{PRODUCT}.txt"
        result = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename=name)
        if not result:
            return False
        target = Path(result if isinstance(result, str) else result[0])
        target.write_text(text, encoding="utf-8", newline="")
        return True

    def save_binary(self, filename: str, data: str) -> bool:
        """Save dialog for a binary export (Excel), handed over as base64."""
        import base64
        import binascii

        import webview

        if self.token() is None or not isinstance(data, str) or len(data) > 70 * 2**20:
            return False
        try:
            content = base64.b64decode(data, validate=True)
        except (binascii.Error, ValueError):
            return False
        name = Path(filename).name or f"{PRODUCT}.xlsx"
        result = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename=name)
        if not result:
            return False
        target = Path(result if isinstance(result, str) else result[0])
        target.write_bytes(content)
        return True


def _on_drop(window, register: Callable[[list[str]], dict[str, Any]]) -> None:
    """Files dragged from the Explorer (D-038). The full paths come from Windows through pywebview
    and stay on this side; the page learns the names and a number to ask for the copy with."""
    from webview.dom import DOMEventHandler

    def dropped(event: dict[str, Any]) -> None:
        files = event.get("dataTransfer", {}).get("files", [])
        paths = [f["pywebviewFullPath"] for f in files if f.get("pywebviewFullPath")]
        if paths:
            window.evaluate_js(f"window.daengsDropped({json.dumps(register(paths))})")

    window.dom.document.events.drop += DOMEventHandler(dropped, prevent_default=True)


def run_window(
    url: str, token: str, register_drop: Callable[[list[str]], dict[str, Any]] | None = None
) -> None:
    """Open the window and block until it is closed."""
    os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = WEBVIEW2_ARGUMENTS
    import webview

    webview.settings["ALLOW_DOWNLOADS"] = False
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = False
    api = WindowApi(token, url)
    window = webview.create_window(
        window_title(), url + "/", js_api=api, width=1280, height=820, min_size=(900, 600)
    )
    api._window = window
    if register_drop is not None:
        window.events.loaded += lambda: _on_drop(window, register_drop)
    storage = program_data() / "fenster"
    storage.mkdir(parents=True, exist_ok=True)
    webview.start(gui="edgechromium", private_mode=True, storage_path=str(storage), debug=False)
