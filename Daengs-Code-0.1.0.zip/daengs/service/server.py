"""Local JSON interface for the UI, bound to 127.0.0.1 on a random port (D-012, 09 §4).

Standard library only (http.server): no extra dependency, nothing that reaches outside.
"""

import contextlib
import json
import re
import threading
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import parse_qs

import daengs
from daengs import PRODUCT
from daengs.core import DaengsError, PathNotAllowedError, ProjectNotFoundError
from daengs.core.settings import allowed_preference
from daengs.service.security import LOOPBACK, check, new_token

MAX_BODY = 256 * 1024  # a wiki page may be long
# Keys of rows and chapters of the overview table: generated hex, standard chapter names.
_TABLE_KEY = re.compile(r"[a-z0-9_]{1,40}")
MAX_QUESTION = 2000
MAX_IDS = 20  # passages of one answer (D-055)
REQUEST_TIMEOUT = 30

_COMMON = {
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Resource-Policy": "same-origin",
}
_API_CSP = "default-src 'none'; frame-ancestors 'none'"
# The UI: own scripts and styles only, page images as blob URLs, requests only to this port.
_UI_CSP = (
    "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' blob:;"
    " connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
)
_STATIC_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".svg": "image/svg+xml",
}
_PROJECT = r"(?P<pid>[^/]+)"
_PAGE = r"/files/(?P<fid>\d{1,9})/pages/(?P<page>\d{1,6})"


@dataclass(frozen=True)
class Binary:
    data: bytes
    content_type: str


@dataclass(frozen=True)
class EventStream:
    """Server-sent events (M9a): each item goes out as one ``data:`` line as soon as it exists."""

    events: Iterator[dict[str, Any]]


class Backend(Protocol):
    """What the service offers; implemented by the composition root (daengs.app)."""

    def list_projects(self) -> list[dict[str, Any]]: ...
    def create_project(self, name: str, folders: list[str]) -> dict[str, Any]: ...
    def project(self, project_id: str) -> dict[str, Any]: ...
    def grant_folder(self, project_id: str, folder: str) -> dict[str, Any]: ...
    def revoke_folder(self, project_id: str, folder: str) -> dict[str, Any]: ...
    def start_ingest(self, project_id: str) -> dict[str, Any]: ...
    def ingest_status(self, project_id: str) -> dict[str, Any]: ...
    def search(self, project_id: str, question: str, limit: int) -> dict[str, Any]: ...
    def page_marks(
        self, project_id: str, file_id: int, page_no: int, chunk_id: int | None, question: str
    ) -> dict[str, Any]: ...
    def page_image(self, project_id: str, file_id: int, page_no: int, width: int) -> bytes: ...
    def open_original(self, project_id: str, file_id: int, page_no: int) -> dict[str, Any]: ...
    def files(self, project_id: str) -> dict[str, Any]: ...
    def open_file(self, project_id: str, folder: str, rel_path: str) -> dict[str, Any]: ...
    def overview(self, project_id: str) -> dict[str, Any]: ...
    def set_assemblies(self, project_id: str, text: str) -> dict[str, Any]: ...
    def decide(
        self, project_id: str, assembly_id: int, file_id: int, page_no: int, decision: str | None
    ) -> dict[str, Any]: ...
    def export_overview(self, project_id: str) -> dict[str, Any]: ...
    def table(self, project_id: str) -> dict[str, Any]: ...
    def table_cell(self, project_id: str, component: str, chapter: str) -> dict[str, Any]: ...
    def table_components(self, project_id: str, change: dict[str, Any]) -> dict[str, Any]: ...
    def table_chapters(self, project_id: str, change: dict[str, Any]) -> dict[str, Any]: ...
    def table_set_cell(
        self, project_id: str, component: str, chapter: str, status: str | None, note: str | None
    ) -> dict[str, Any]: ...
    def table_decide(
        self,
        project_id: str,
        component: str,
        chapter: str,
        folder: str,
        rel_path: str,
        page_no: int,
        decision: str | None,
    ) -> dict[str, Any]: ...
    def table_document(
        self, project_id: str, folder: str, rel_path: str, status: str | None, stand: str | None
    ) -> dict[str, Any]: ...
    def table_view(
        self, project_id: str, intro_seen: bool | None, view: dict[str, Any] | None
    ) -> dict[str, Any]: ...
    def table_suggestions(self, project_id: str) -> dict[str, Any]: ...
    def examples(self, project_id: str) -> dict[str, Any]: ...
    def table_questions(self, project_id: str) -> dict[str, Any]: ...
    def table_export(self, project_id: str, what: str, fmt: str) -> dict[str, Any]: ...
    def wiki_pages(self, project_id: str) -> list[dict[str, Any]]: ...
    def wiki_create(self, project_id: str, title: str) -> dict[str, Any]: ...
    def wiki_page(self, project_id: str, page_id: int) -> dict[str, Any]: ...
    def wiki_save(self, project_id: str, page_id: int, title: str, body: str) -> dict[str, Any]: ...
    def wiki_delete(self, project_id: str, page_id: int) -> dict[str, Any]: ...
    def wiki_remember(
        self,
        project_id: str,
        page_id: int,
        file_id: int,
        page_no: int,
        chunk_id: int | None,
        note: str,
    ) -> dict[str, Any]: ...
    def wiki_forget(self, project_id: str, page_id: int, ref_id: int) -> dict[str, Any]: ...
    def delete_project(self, project_id: str, confirm_name: str) -> dict[str, Any]: ...
    def diagnostics(self) -> dict[str, Any]: ...
    def llm_status(self) -> dict[str, Any]: ...
    def preload_search_model(self) -> bool: ...
    def answer(
        self,
        project_id: str,
        question: str,
        chat_id: int | None = None,
        chunk_ids: list[int] | None = None,
    ) -> dict[str, Any]: ...
    def chat_history(self, project_id: str, chat_id: int | None = None) -> list[dict[str, Any]]: ...
    def chats(self, project_id: str) -> list[dict[str, Any]]: ...
    def answer_stream(
        self,
        project_id: str,
        question: str,
        chat_id: int | None = None,
        chunk_ids: list[int] | None = None,
    ) -> Iterator[dict[str, Any]]: ...
    def answer_stop(self, project_id: str) -> dict[str, Any]: ...
    def wiki_suggestion(self, project_id: str, chat_id: int, message_id: int) -> dict[str, Any]: ...
    def wiki_accept(
        self,
        project_id: str,
        title: str,
        body: str,
        refs: list[dict[str, Any]],
        page_id: int | None,
    ) -> dict[str, Any]: ...
    def wiki_restore(self, project_id: str, page_id: int) -> dict[str, Any]: ...
    def preferences(self) -> dict[str, str]: ...
    def set_preferences(self, changes: dict[str, str]) -> dict[str, str]: ...
    def update_status(self) -> dict[str, Any]: ...
    def update_settings(self, enabled: bool | None, hint_seen: bool | None) -> dict[str, Any]: ...
    def update_check(self) -> dict[str, Any]: ...
    def update_download(self) -> dict[str, Any]: ...
    def update_cancel(self) -> dict[str, Any]: ...
    def update_install(self) -> dict[str, Any]: ...
    def update_result_seen(self) -> dict[str, Any]: ...
    def watch_files(self, project_id: str) -> dict[str, Any]: ...
    def place_files(
        self, project_id: str, drop_id: str, folder: str | None, subfolder: str
    ) -> dict[str, Any]: ...
    def placing_status(self, project_id: str) -> dict[str, Any]: ...
    def global_wiki_pages(self) -> list[dict[str, Any]]: ...
    def global_wiki_create(self, title: str) -> dict[str, Any]: ...
    def global_wiki_page(self, page_id: int) -> dict[str, Any]: ...
    def global_wiki_save(self, page_id: int, title: str, body: str) -> dict[str, Any]: ...
    def global_wiki_restore(self, page_id: int) -> dict[str, Any]: ...
    def global_wiki_delete(self, page_id: int) -> dict[str, Any]: ...
    def global_wiki_check(self, project_id: str, title: str, body: str) -> dict[str, Any]: ...
    def global_wiki_accept(self, title: str, body: str) -> dict[str, Any]: ...
    def chat_rate(
        self, project_id: str, chat_id: int, message_id: int, value: int, note: str
    ) -> dict[str, Any]: ...
    def chat_create(self, project_id: str, title: str) -> dict[str, Any]: ...
    def chat_rename(self, project_id: str, chat_id: int, title: str) -> dict[str, Any]: ...
    def chat_delete(self, project_id: str, chat_id: int) -> dict[str, Any]: ...
    def chat_clear(self, project_id: str) -> dict[str, Any]: ...


class ApiError(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.message = message


Route = tuple[str, re.Pattern[str], Callable[..., tuple[int, Any]]]


def _routes(backend: Backend) -> list[Route]:
    def body_str(body: dict[str, Any], key: str, max_len: int = 1000) -> str:
        value = body.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > max_len:
            raise ApiError(400, f"Feld '{key}' fehlt oder ist ungültig")
        return value

    def body_int(body: dict[str, Any], key: str, required: bool = True) -> int | None:
        value = body.get(key)
        if value is None and not required:
            return None
        if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value < 10**9:
            raise ApiError(400, f"Feld '{key}' fehlt oder ist ungültig")
        return value

    def body_ids(body: dict[str, Any], key: str) -> list[int] | None:
        """Optional list of 1 to MAX_IDS distinct IDs, in rank order."""
        value = body.get(key)
        if value is None:
            return None
        if (
            not isinstance(value, list)
            or not 1 <= len(value) <= MAX_IDS
            or len(set(value)) != len(value)
            or any(
                isinstance(v, bool) or not isinstance(v, int) or not 1 <= v < 10**9 for v in value
            )
        ):
            raise ApiError(400, f"Feld '{key}' fehlt oder ist ungültig")
        return value

    def confirmed(body: dict[str, Any]) -> None:
        # Changing a folder grant needs an explicit confirmation from the UI (09 §4).
        if body.get("confirm") is not True:
            raise ApiError(409, "Änderung der Ordnerfreigabe muss bestätigt werden")

    def create(body, query):
        folders = body.get("folders", [])
        if not isinstance(folders, list) or not all(isinstance(f, str) for f in folders):
            raise ApiError(400, "Feld 'folders' muss eine Liste von Pfaden sein")
        return 201, backend.create_project(body_str(body, "name", 200), folders)

    def grant(body, query, pid):
        confirmed(body)
        return 200, backend.grant_folder(pid, body_str(body, "folder"))

    def revoke(body, query, pid):
        confirmed(body)
        return 200, backend.revoke_folder(pid, body_str(body, "folder"))

    def search(body, query, pid):
        limit = body.get("limit", 10)
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ApiError(400, "Feld 'limit' muss zwischen 1 und 100 liegen")
        return 200, backend.search(pid, body_str(body, "question", MAX_QUESTION), limit)

    def marks(body, query, pid, fid, page):
        question = body.get("question", "")
        if not isinstance(question, str) or len(question) > MAX_QUESTION:
            raise ApiError(400, "Feld 'question' ist ungültig")
        chunk = body_int(body, "chunk_id", required=False)
        return 200, backend.page_marks(pid, int(fid), int(page), chunk, question)

    def image(query, pid, fid, page):
        try:
            width = int(query.get("width", ["1200"])[0])
        except ValueError:
            raise ApiError(400, "Parameter 'width' ist ungültig") from None
        return 200, Binary(backend.page_image(pid, int(fid), int(page), width), "image/png")

    def open_original(body, query, pid):
        return 200, backend.open_original(pid, body_int(body, "file_id"), body_int(body, "page_no"))

    def body_text(body: dict[str, Any], key: str, max_len: int) -> str:
        value = body.get(key, "")
        if not isinstance(value, str) or len(value) > max_len:
            raise ApiError(400, f"Feld '{key}' ist ungültig")
        return value

    def assemblies(body, query, pid):
        return 200, backend.set_assemblies(pid, body_text(body, "text", 50_000))

    # -- overview table (D-070) --------------------------------------------------------------

    def key_of(body: dict[str, Any], name: str) -> str:
        value = body.get(name)
        if not isinstance(value, str) or not _TABLE_KEY.fullmatch(value):
            raise ApiError(400, f"Feld '{name}' fehlt oder ist ungültig")
        return value

    def str_list(body: dict[str, Any], name: str, max_items: int, max_len: int) -> list[str]:
        value = body.get(name, [])
        if (
            not isinstance(value, list)
            or len(value) > max_items
            or not all(isinstance(v, str) and len(v) <= max_len for v in value)
        ):
            raise ApiError(400, f"Feld '{name}' ist ungültig")
        return value

    def maybe(body: dict[str, Any], name: str, kind: type) -> Any:
        value = body.get(name)
        # bool is a subclass of int: True must not pass for a name, nor 1 for a flag.
        wrong_kind = not isinstance(value, kind) or (isinstance(value, bool) != (kind is bool))
        if value is not None and wrong_kind:
            raise ApiError(400, f"Feld '{name}' ist ungültig")
        return value

    def query_key(query: dict[str, list[str]], name: str) -> str:
        value = query.get(name, [""])[0]
        if not _TABLE_KEY.fullmatch(value):
            raise ApiError(400, f"Parameter '{name}' ist ungültig")
        return value

    def table_components(body, query, pid):
        action = body.get("action")
        if action == "add":
            change = {"action": action, "names": str_list(body, "names", 300, 100)}
        elif action == "update":
            change = {
                "action": action,
                "key": key_of(body, "key"),
                "name": maybe(body, "name", str),
                "hidden": maybe(body, "hidden", bool),
                "aliases": str_list(body, "aliases", 20, 100) if "aliases" in body else None,
            }
        elif action == "merge":
            others = str_list(body, "others", 50, 40)
            if not all(_TABLE_KEY.fullmatch(o) for o in others):
                raise ApiError(400, "Feld 'others' ist ungültig")
            change = {"action": action, "key": key_of(body, "key"), "others": others}
        elif action == "remove":
            change = {"action": action, "key": key_of(body, "key")}
        elif action == "move":
            position = body.get("position")
            if isinstance(position, bool) or not isinstance(position, int) or position < 0:
                raise ApiError(400, "Feld 'position' ist ungültig")
            change = {"action": action, "key": key_of(body, "key"), "position": position}
        else:
            raise ApiError(400, "Feld 'action' ist ungültig")
        return 200, backend.table_components(pid, change)

    def table_chapters(body, query, pid):
        action = body.get("action")
        if action == "add":
            change = {
                "action": action,
                "name": body_str(body, "name", 100),
                "words_de": str_list(body, "words_de", 40, 60),
                "words_en": str_list(body, "words_en", 40, 60),
            }
        elif action == "update":
            change = {
                "action": action,
                "key": key_of(body, "key"),
                "name": maybe(body, "name", str),
                "words_de": str_list(body, "words_de", 40, 60) if "words_de" in body else None,
                "words_en": str_list(body, "words_en", 40, 60) if "words_en" in body else None,
                "visible": maybe(body, "visible", bool),
                "reset": body.get("reset") is True,
            }
        elif action == "remove":
            change = {"action": action, "key": key_of(body, "key")}
        elif action == "template":
            if body.get("template") not in ("standard", "kurz"):
                raise ApiError(400, "Feld 'template' ist ungültig")
            change = {"action": action, "template": body["template"]}
        else:
            raise ApiError(400, "Feld 'action' ist ungültig")
        return 200, backend.table_chapters(pid, change)

    def table_cell_set(body, query, pid):
        status = body.get("status")
        if status not in (None, "offen", "ok", "rueckfrage", "nicht_relevant"):
            raise ApiError(400, "Feld 'status' ist ungültig")
        note = body.get("note")
        if note is not None and (not isinstance(note, str) or len(note) > 2000):
            raise ApiError(400, "Feld 'note' ist ungültig")
        return 200, backend.table_set_cell(
            pid, key_of(body, "component"), key_of(body, "chapter"), status, note
        )

    def table_decide(body, query, pid):
        decision = body.get("decision")
        if decision not in ("passt", "passt_nicht", None):
            raise ApiError(400, "Feld 'decision' ist ungültig")
        return 200, backend.table_decide(
            pid,
            key_of(body, "component"),
            key_of(body, "chapter"),
            body_str(body, "folder", 1000),
            body_str(body, "rel_path", 1000),
            body_int(body, "page_no"),
            decision,
        )

    def table_document(body, query, pid):
        status = body.get("status")
        if status not in (None, "offen", "gesichtet", "nicht_relevant"):
            raise ApiError(400, "Feld 'status' ist ungültig")
        stand = body.get("stand")
        if stand is not None and (not isinstance(stand, str) or len(stand) > 200):
            raise ApiError(400, "Feld 'stand' ist ungültig")
        return 200, backend.table_document(
            pid, body_str(body, "folder", 1000), body_str(body, "rel_path", 1000), status, stand
        )

    def table_view(body, query, pid):
        view = body.get("view")
        if view is not None and (not isinstance(view, dict) or len(json.dumps(view)) > 4000):
            raise ApiError(400, "Feld 'view' ist ungültig")
        return 200, backend.table_view(pid, maybe(body, "intro_seen", bool), view)

    def table_cell_get(query, pid):
        return 200, backend.table_cell(
            pid, query_key(query, "component"), query_key(query, "chapter")
        )

    def table_export(query, pid):
        what = query.get("what", ["tabelle"])[0]
        fmt = query.get("format", ["csv"])[0]
        if what not in ("tabelle", "rueckfragen") or fmt not in ("csv", "xlsx"):
            raise ApiError(400, "Parameter 'what' oder 'format' ist ungültig")
        return 200, backend.table_export(pid, what, fmt)

    def decide(body, query, pid):
        decision = body.get("decision")
        if decision not in ("bestaetigt", "verworfen", None):
            raise ApiError(400, "Feld 'decision' ist ungültig")
        return 200, backend.decide(
            pid,
            body_int(body, "assembly_id"),
            body_int(body, "file_id"),
            body_int(body, "page_no"),
            decision,
        )

    def wiki_save(body, query, pid, wid):
        return 200, backend.wiki_save(
            pid, int(wid), body_str(body, "title", 200), body_text(body, "body", 200_000)
        )

    def wiki_delete(body, query, pid, wid):
        # Deleting a wiki page needs an explicit confirmation from the UI (09 §4).
        if body.get("confirm") is not True:
            raise ApiError(409, "Löschen der Wiki-Seite muss bestätigt werden")
        return 200, backend.wiki_delete(pid, int(wid))

    def wiki_remember(body, query, pid, wid):
        return 200, backend.wiki_remember(
            pid,
            int(wid),
            body_int(body, "file_id"),
            body_int(body, "page_no"),
            body_int(body, "chunk_id", required=False),
            body_text(body, "note", 2000),
        )

    def delete_project(body, query, pid):
        # The name must be typed in (09 §4); the backend compares it with the project name.
        return 200, backend.delete_project(pid, body_str(body, "confirm_name", 200))

    def answer(body, query, pid):
        chat_id = body_int(body, "chat_id", required=False)
        question = body_str(body, "question", MAX_QUESTION)
        return 200, backend.answer(pid, question, chat_id, body_ids(body, "chunk_ids"))

    def answer_stream(body, query, pid):
        chat_id = body_int(body, "chat_id", required=False)
        question = body_str(body, "question", MAX_QUESTION)
        ids = body_ids(body, "chunk_ids")
        return 200, EventStream(backend.answer_stream(pid, question, chat_id, ids))

    def chat_rate(body, query, pid, cid, mid):
        value = body.get("value")
        if value not in (-1, 0, 1) or isinstance(value, bool):
            raise ApiError(400, "Feld 'value' ist ungültig")
        return 200, backend.chat_rate(pid, int(cid), int(mid), value, body_text(body, "note", 500))

    def wiki_accept(body, query, pid):
        # The user confirmed a suggestion (M9b): only now anything is written.
        refs = body.get("refs", [])
        if not isinstance(refs, list) or len(refs) > 20:
            raise ApiError(400, "Feld 'refs' ist ungültig")
        clean = []
        for ref in refs:
            if not isinstance(ref, dict):
                raise ApiError(400, "Feld 'refs' ist ungültig")
            clean.append(
                {
                    "file_id": body_int(ref, "file_id"),
                    "page_no": body_int(ref, "page_no"),
                    "chunk_id": body_int(ref, "chunk_id", required=False),
                    "note": body_text(ref, "note", 200),
                }
            )
        return 200, backend.wiki_accept(
            pid,
            body_str(body, "title", 200),
            body_text(body, "body", 200_000),
            clean,
            body_int(body, "page_id", required=False),
        )

    def chat_delete(body, query, pid, cid):
        # Deleting a chat with its answers needs an explicit confirmation from the UI.
        if body.get("confirm") is not True:
            raise ApiError(409, "Löschen des Chats muss bestätigt werden")
        return 200, backend.chat_delete(pid, int(cid))

    def chat_clear(body, query, pid):
        # Deleting the chat history needs an explicit confirmation from the UI.
        if body.get("confirm") is not True:
            raise ApiError(409, "Löschen des Verlaufs muss bestätigt werden")
        return 200, backend.chat_clear(pid)

    def global_wiki_delete(body, query, gid):
        # Deleting a page needs an explicit confirmation from the UI (09 §4).
        if body.get("confirm") is not True:
            raise ApiError(400, "Löschen muss bestätigt werden")
        return 200, backend.global_wiki_delete(int(gid))

    def global_wiki_accept(body, query):
        # Into the Gesamt-Wiki only with the user's explicit confirmation (A-31).
        if body.get("confirm") is not True:
            raise ApiError(400, "Übernahme muss bestätigt werden")
        return 200, backend.global_wiki_accept(
            body_str(body, "title", 200), body_text(body, "body", 200_000)
        )

    def place_files(body, query, pid):
        # Only a number from the window's own drop comes in here, never a path (D-038).
        folder = body.get("folder")
        if folder is not None and not isinstance(folder, str):
            raise ApiError(400, "Feld 'folder' ist ungültig")
        return 200, backend.place_files(
            pid, body_str(body, "drop", 64), folder, body_text(body, "subfolder", 1000)
        )

    def set_preferences(body, query):
        for key, value in body.items():
            if not allowed_preference(key, value):
                raise ApiError(400, f"Feld '{key}' ist ungültig")
        return 200, backend.set_preferences(body)

    def update_settings(body, query):
        def flag(key: str) -> bool | None:
            value = body.get(key)
            if value is not None and not isinstance(value, bool):
                raise ApiError(400, f"Feld '{key}' ist ungültig")
            return value

        return 200, backend.update_settings(flag("enabled"), flag("hint_seen"))

    def update_install(body, query):
        # Closing the app and installing only with the user's click (D-030).
        confirmed(body)
        return 200, backend.update_install()

    p = rf"/api/projects/{_PROJECT}"
    g = r"/api/global-wiki"
    gw = r"/(?P<gid>\d{1,9})"
    w = r"/wiki/(?P<wid>\d{1,9})"
    c = r"/chats/(?P<cid>\d{1,9})"
    table: list[tuple[str, str, Callable[..., tuple[int, Any]]]] = [
        (
            "GET",
            r"/api/status",
            lambda q: (
                200,
                {
                    "ok": True,
                    "product": PRODUCT,
                    "version": daengs.__version__,
                    "release": daengs.release_name(),
                },
            ),
        ),
        ("GET", r"/api/projects", lambda q: (200, backend.list_projects())),
        ("POST", r"/api/projects", create),
        ("GET", p, lambda q, pid: (200, backend.project(pid))),
        ("POST", rf"{p}/folders/grant", grant),
        ("POST", rf"{p}/folders/revoke", revoke),
        ("POST", rf"{p}/ingest", lambda b, q, pid: (202, backend.start_ingest(pid))),
        ("GET", rf"{p}/ingest", lambda q, pid: (200, backend.ingest_status(pid))),
        ("POST", rf"{p}/search", search),
        ("POST", rf"{p}{_PAGE}/marks", marks),
        ("GET", rf"{p}{_PAGE}/image", image),
        ("POST", rf"{p}/open", open_original),
        ("GET", rf"{p}/files", lambda q, pid: (200, backend.files(pid))),
        ("POST", rf"{p}/files/watch", lambda b, q, pid: (200, backend.watch_files(pid))),
        ("POST", rf"{p}/files/place", place_files),
        ("GET", rf"{p}/files/place", lambda q, pid: (200, backend.placing_status(pid))),
        (
            "POST",
            rf"{p}/files/open",
            lambda b, q, pid: (
                200,
                backend.open_file(pid, body_str(b, "folder", 1000), body_str(b, "path", 1000)),
            ),
        ),
        ("GET", rf"{p}/overview", lambda q, pid: (200, backend.overview(pid))),
        ("POST", rf"{p}/overview/assemblies", assemblies),
        ("POST", rf"{p}/overview/decide", decide),
        ("GET", rf"{p}/overview/export", lambda q, pid: (200, backend.export_overview(pid))),
        ("GET", rf"{p}/table", lambda q, pid: (200, backend.table(pid))),
        ("GET", rf"{p}/table/cell", table_cell_get),
        ("POST", rf"{p}/table/components", table_components),
        ("POST", rf"{p}/table/chapters", table_chapters),
        ("POST", rf"{p}/table/cell", table_cell_set),
        ("POST", rf"{p}/table/decide", table_decide),
        ("POST", rf"{p}/table/document", table_document),
        ("POST", rf"{p}/table/view", table_view),
        ("GET", rf"{p}/table/suggestions", lambda q, pid: (200, backend.table_suggestions(pid))),
        ("GET", rf"{p}/examples", lambda q, pid: (200, backend.examples(pid))),
        ("GET", rf"{p}/table/questions", lambda q, pid: (200, backend.table_questions(pid))),
        ("GET", rf"{p}/table/export", table_export),
        ("GET", rf"{p}/wiki", lambda q, pid: (200, backend.wiki_pages(pid))),
        (
            "POST",
            rf"{p}/wiki",
            lambda b, q, pid: (201, backend.wiki_create(pid, body_str(b, "title", 200))),
        ),
        ("GET", rf"{p}{w}", lambda q, pid, wid: (200, backend.wiki_page(pid, int(wid)))),
        ("POST", rf"{p}{w}", wiki_save),
        ("POST", rf"{p}{w}/delete", wiki_delete),
        ("POST", rf"{p}{w}/refs", wiki_remember),
        (
            "POST",
            rf"{p}{w}/refs/(?P<rid>\d{{1,9}})/delete",
            lambda b, q, pid, wid, rid: (200, backend.wiki_forget(pid, int(wid), int(rid))),
        ),
        ("POST", rf"{p}/delete", delete_project),
        ("GET", r"/api/diagnostics", lambda q: (200, backend.diagnostics())),
        ("GET", r"/api/llm", lambda q: (200, backend.llm_status())),
        (
            "POST",
            r"/api/search-model/preload",
            lambda b, q: (202, {"started": backend.preload_search_model()}),
        ),
        ("POST", rf"{p}/answer", answer),
        ("GET", rf"{p}/chat", lambda q, pid: (200, backend.chat_history(pid))),
        ("POST", rf"{p}/chat/clear", chat_clear),
        ("GET", rf"{p}/chats", lambda q, pid: (200, backend.chats(pid))),
        (
            "POST",
            rf"{p}/chats",
            lambda b, q, pid: (201, backend.chat_create(pid, body_text(b, "title", 200))),
        ),
        ("GET", rf"{p}{c}", lambda q, pid, cid: (200, backend.chat_history(pid, int(cid)))),
        (
            "POST",
            rf"{p}{c}/rename",
            lambda b, q, pid, cid: (
                200,
                backend.chat_rename(pid, int(cid), body_str(b, "title", 200)),
            ),
        ),
        ("POST", rf"{p}{c}/delete", chat_delete),
        ("POST", rf"{p}/answer/stream", answer_stream),
        ("POST", rf"{p}/answer/stop", lambda b, q, pid: (200, backend.answer_stop(pid))),
        (
            "GET",
            rf"{p}{c}/messages/(?P<mid>\d{{1,9}})/wiki",
            lambda q, pid, cid, mid: (200, backend.wiki_suggestion(pid, int(cid), int(mid))),
        ),
        ("POST", rf"{p}/wiki/accept", wiki_accept),
        (
            "POST",
            rf"{p}{w}/restore",
            lambda b, q, pid, wid: (200, backend.wiki_restore(pid, int(wid))),
        ),
        ("POST", rf"{p}{c}/messages/(?P<mid>\d{{1,9}})/rating", chat_rate),
        ("GET", r"/api/preferences", lambda q: (200, backend.preferences())),
        ("POST", r"/api/preferences", set_preferences),
        ("GET", r"/api/updates", lambda q: (200, backend.update_status())),
        ("POST", r"/api/updates/settings", update_settings),
        ("POST", r"/api/updates/check", lambda b, q: (200, backend.update_check())),
        ("POST", r"/api/updates/download", lambda b, q: (200, backend.update_download())),
        ("POST", r"/api/updates/cancel", lambda b, q: (200, backend.update_cancel())),
        ("POST", r"/api/updates/install", update_install),
        ("POST", r"/api/updates/result", lambda b, q: (200, backend.update_result_seen())),
        ("GET", g, lambda q: (200, backend.global_wiki_pages())),
        ("POST", g, lambda b, q: (201, backend.global_wiki_create(body_str(b, "title", 200)))),
        ("POST", rf"{g}/accept", global_wiki_accept),
        ("GET", rf"{g}{gw}", lambda q, gid: (200, backend.global_wiki_page(int(gid)))),
        (
            "POST",
            rf"{g}{gw}",
            lambda b, q, gid: (
                200,
                backend.global_wiki_save(
                    int(gid), body_str(b, "title", 200), body_text(b, "body", 200_000)
                ),
            ),
        ),
        ("POST", rf"{g}{gw}/delete", global_wiki_delete),
        (
            "POST",
            rf"{g}{gw}/restore",
            lambda b, q, gid: (200, backend.global_wiki_restore(int(gid))),
        ),
        (
            "POST",
            rf"{p}/global-wiki/check",
            lambda b, q, pid: (
                200,
                backend.global_wiki_check(
                    pid, body_str(b, "title", 200), body_text(b, "body", 200_000)
                ),
            ),
        ),
    ]
    return [(method, re.compile(f"^{pattern}$"), fn) for method, pattern, fn in table]


def _static_files(folder: Path | None) -> dict[str, Path]:
    """Fixed list of UI files, read once; nothing outside it is ever served."""
    if folder is None:
        return {}
    files = {f"/ui/{p.name}": p for p in sorted(folder.iterdir()) if p.suffix in _STATIC_TYPES}
    if "/ui/index.html" in files:
        files["/"] = files["/ui/index.html"]
    return files


class _QuietServer(ThreadingHTTPServer):
    def handle_error(self, request, client_address) -> None:
        # Aborted connections (window closed) are normal; nothing goes to the console or a log.
        return


class LocalService:
    """Runs the interface in a background thread until ``stop``."""

    def __init__(
        self, backend: Backend, token: str | None = None, static_dir: Path | None = None
    ) -> None:
        self.token = token or new_token()
        routes = _routes(backend)
        static = _static_files(static_dir)
        service = self

        class Handler(BaseHTTPRequestHandler):
            server_version = PRODUCT
            sys_version = ""
            protocol_version = "HTTP/1.1"
            timeout = REQUEST_TIMEOUT

            def version_string(self) -> str:
                return PRODUCT  # no Python or library versions to the caller

            def do_GET(self) -> None:
                self._handle("GET")

            def do_POST(self) -> None:
                self._handle("POST")

            def do_PUT(self) -> None:
                self._reply(405, {"fehler": "Methode nicht erlaubt"})

            do_DELETE = do_PATCH = do_OPTIONS = do_HEAD = do_PUT

            def _handle(self, method: str) -> None:
                try:
                    path, _, raw_query = self.path.partition("?")
                    if method == "GET" and path in static:
                        # UI files hold no data: no token, but Host and Origin are still checked.
                        denied = check(
                            self.headers, service.token, service.port, token_required=False
                        )
                        if denied:
                            raise ApiError(*denied)
                        self._static(static[path])
                        return
                    denied = check(self.headers, service.token, service.port)
                    if denied:
                        raise ApiError(*denied)
                    query = parse_qs(raw_query, max_num_fields=5)
                    for route_method, pattern, fn in routes:
                        match = pattern.match(path)
                        if match and route_method == method:
                            args = list(match.groupdict().values())
                            if method == "POST":
                                status, payload = fn(self._body(), query, *args)
                            else:
                                status, payload = fn(query, *args)
                            self._reply(status, payload)
                            return
                    raise ApiError(404, "Nicht gefunden")
                except ApiError as exc:
                    self._reply(exc.status, {"fehler": exc.message})
                except (ProjectNotFoundError, ValueError):
                    self._reply(404, {"fehler": "Nicht gefunden"})
                except PathNotAllowedError as exc:
                    self._reply(403, {"fehler": str(exc)})
                except DaengsError as exc:
                    self._reply(400, {"fehler": str(exc)})
                except Exception:  # never leak a stack trace or content to the caller
                    self._reply(500, {"fehler": "Interner Fehler"})

            def _body(self) -> dict[str, Any]:
                if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
                    raise ApiError(415, "Nur application/json")
                try:
                    length = int(self.headers.get("Content-Length", ""))
                except ValueError:
                    raise ApiError(411, "Content-Length fehlt") from None
                if length < 0 or length > MAX_BODY:
                    self.close_connection = True
                    raise ApiError(413, "Anfrage zu groß")
                try:
                    body = json.loads(self.rfile.read(length) or b"{}")
                except (UnicodeDecodeError, json.JSONDecodeError):
                    raise ApiError(400, "Ungültiges JSON") from None
                if not isinstance(body, dict):
                    raise ApiError(400, "JSON-Objekt erwartet")
                return body

            def _static(self, file: Path) -> None:
                self._send(200, file.read_bytes(), _STATIC_TYPES[file.suffix], _UI_CSP)

            def _reply(self, status: int, payload: Any) -> None:
                if isinstance(payload, EventStream):
                    self._stream(payload.events)
                    return
                if isinstance(payload, Binary):
                    self._send(status, payload.data, payload.content_type, _API_CSP)
                    return
                data = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
                self._send(status, data, "application/json; charset=utf-8", _API_CSP)

            def _stream(self, events: Iterator[dict[str, Any]]) -> None:
                # No length known in advance: the connection ends with the stream.
                self.close_connection = True
                self.send_response(200, "OK")
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Content-Security-Policy", _API_CSP)
                for name, value in _COMMON.items():
                    self.send_header(name, value)
                self.send_header("Connection", "close")
                self.end_headers()

                def send(event: dict[str, Any]) -> None:
                    data = json.dumps(event, ensure_ascii=False, default=str)
                    self.wfile.write(f"data: {data}\n\n".encode())
                    self.wfile.flush()

                try:
                    for event in events:
                        send(event)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    pass  # the window closed or stopped reading; the answer is kept as stopped
                except DaengsError as exc:
                    with contextlib.suppress(OSError):
                        send({"type": "error", "fehler": str(exc)})
                except Exception:  # never leak a stack trace or content to the caller
                    with contextlib.suppress(OSError):
                        send({"type": "error", "fehler": "Interner Fehler"})
                finally:
                    close = getattr(events, "close", None)
                    if close is not None:
                        close()

            def _send(self, status: int, data: bytes, content_type: str, csp: str) -> None:
                if status >= 400:
                    # The request body may be unread; never reuse such a connection.
                    self.close_connection = True
                self.send_response(status, HTTPStatus(status).phrase)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Security-Policy", csp)
                for name, value in _COMMON.items():
                    self.send_header(name, value)
                self.send_header("Content-Length", str(len(data)))
                if self.close_connection:
                    self.send_header("Connection", "close")
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(data)

            def log_message(self, format: str, *args: Any) -> None:
                # No access log: paths and bodies may carry customer content.
                return

        self._server = _QuietServer((LOOPBACK, 0), Handler)
        self._server.daemon_threads = True
        self.port: int = self._server.server_address[1]
        self._thread: threading.Thread | None = None

    @property
    def url(self) -> str:
        return f"http://{LOOPBACK}:{self.port}"

    def start(self) -> "LocalService":
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            kwargs={"poll_interval": 0.1},
            name="daengs-service",
            daemon=True,
        )
        self._thread.start()
        return self

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)
