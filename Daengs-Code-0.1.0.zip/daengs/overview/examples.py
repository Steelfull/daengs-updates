"""Two example questions from a delivery, for the start screen of a read project (B09, D-078).

No language model and no store of the overview: only the project's own database. Names come from
the name column of Excel sheets (parts lists) and count when other documents mention them too;
without such a list the cleaned titles of the documents stand in.
"""

import json
from pathlib import Path
from typing import Any

from daengs.core import ProjectContext
from daengs.overview.table import (
    _LETTERS,
    NAME_HEADERS,
    _header_key,
    _restore_case,
    kind_of,
    norm,
    strip_document_kind,
)

CANDIDATES = 60
SHORTEST, LONGEST = 4, 40
TEMPLATES = ("Wie wird {} gewartet?", "Was steht zu {} in den Unterlagen?")


def _clean(name: str) -> str:
    return " ".join(name.split())


def example_questions(context: ProjectContext, count: int = 2) -> list[str]:
    names = _from_sheets(context)
    if len(names) < count:
        names += [n for n in _from_titles(context) if n not in names]
    return [TEMPLATES[i].format(name) for i, name in enumerate(names[:count])]


def _from_sheets(context: ProjectContext) -> list[str]:
    candidates: dict[str, int] = {}
    with context.transaction() as con:
        sheets = con.execute(
            "select f.id, p.cells from page p join file f on f.id = p.file_id"
            " where p.cells is not null order by f.id, p.page_no"
        ).fetchall()
        for file_id, cells_json in sheets:
            try:
                rows = json.loads(cells_json)
            except ValueError:
                continue
            if not rows:
                continue
            header = {col: _header_key(v) for col, v in rows[0][1]}
            columns = {col for col, h in header.items() if h in NAME_HEADERS}
            for _row, values in rows[1:]:
                for col, value in values:
                    name = _clean(str(value))
                    if (
                        col in columns
                        and SHORTEST <= len(name) <= LONGEST
                        and _LETTERS.search(name.lower())
                        and kind_of(name) != "normteil"
                    ):
                        candidates.setdefault(name, file_id)
        scored = []
        for name, own in list(candidates.items())[:CANDIDATES]:
            like = "%" + name.lower().replace("%", "").replace("_", "") + "%"
            elsewhere = con.execute(
                "select count(distinct file_id) from page"
                " where file_id != ? and lower(text) like ?",
                (own, like),
            ).fetchone()[0]
            if elsewhere:
                scored.append((-elsewhere, name.lower(), name))
    return [name for _, _, name in sorted(scored)]


def _from_titles(context: ProjectContext) -> list[str]:
    with context.transaction() as con:
        rows = con.execute(
            "select rel_path, title from file where status = 'ok' order by rel_path"
        ).fetchall()
    out: list[str] = []
    for rel, title in rows:
        if Path(rel).suffix.lower() == ".xlsx" or ":" in (title or ""):
            continue
        words = [w for w in strip_document_kind(title or "").split() if _LETTERS.search(w)]
        name = " ".join(_restore_case(w, title) for w in words)
        if 2 <= len(words) <= 4 and norm(name) not in {norm(o) for o in out}:
            out.append(name)
    return out


def as_payload(context: ProjectContext) -> dict[str, Any]:
    return {"questions": example_questions(context)}
