"""Composition root: wires projects, ingest and search behind the local service.

The only place that knows all modules; modules themselves know only ``daengs.core`` (07 §3).
"""

import contextlib
import dataclasses
import shutil
import subprocess
import sys
import threading
import time
import uuid
from collections.abc import Callable, Iterator
from pathlib import Path
from typing import Any

from daengs import GLOBAL_WIKI_FOLDER, PRODUCT, __version__, diagnostics
from daengs.answer import Answerer, LlamaServer, suggestion
from daengs.core import (
    PREFERENCES_FILE,
    DaengsError,
    PathNotAllowedError,
    Preferences,
    ProjectContext,
    Settings,
)
from daengs.core.updates import FOLDER as UPDATE_FOLDER
from daengs.core.updates import UPDATE_URL, UpdateFiles, is_newer
from daengs.ingest import OPENABLE, Ingestor, OcrEngine, RapidOcrEngine, inventory
from daengs.ingest.inventory import CHANGED, NEW, Inventory
from daengs.ingest.inventory import DONE as DONE_FILE
from daengs.ingest.watch import FileWatch
from daengs.jobs import FAILED, FIRST, OCR, QUEUED, READ, RUNNING, TABLE, JobQueue
from daengs.overview import TABLE_DB, Overview, Table
from daengs.placing import place_file
from daengs.projects import FIRST_RUNNING, ProjectInfo, ProjectRegistry
from daengs.search import Embedder, OnnxEmbedder, SearchIndex
from daengs.search.query import terms
from daengs.viewer import PageView, open_at_page
from daengs.wiki import GlobalWiki, Wiki, customer_hints

# Stages of reading a project (D-066): text and embeddings, then OCR with its embeddings.
READ_STAGE, OCR_STAGE = "lesen", "texterkennung"
# The overview table runs as a task of its own key, so the reading state of the project (what the
# UI shows as "liest ein") never says "läuft" because cells are being searched.
TABLE_STAGE, TABLE_KEY = "uebersicht", "/uebersicht"
UPDATE_PROGRAM = "daengs-update.exe"
CHECK_EVERY_SECONDS = 24 * 3600
MAX_DROP_FILES = 500


class App:
    """Implements ``daengs.service.Backend``. Background work runs one job at a time (RAM, R-14)."""

    def __init__(
        self,
        settings: Settings,
        ocr_engine: Callable[[], OcrEngine] | None = None,
        embedder: Callable[[], Embedder] | None = None,
        llm: Callable[[], Any] | None = None,
    ) -> None:
        self.settings = settings
        self.registry = ProjectRegistry(settings.data_dir)
        self._ocr_factory = ocr_engine or self._default_ocr()
        self._embedder_factory = embedder or self._default_embedder()
        self._ocr: OcrEngine | None = None
        self._embedder: Embedder | None = None
        self._lock = threading.Lock()
        self._index_lock = threading.Lock()
        self._indexes: dict[str, SearchIndex] = {}
        self._stop = threading.Event()
        # What the running reading of a project has got to, for the progress (D-065).
        self._progress: dict[str, dict[str, Any]] = {}
        self._table_progress: dict[str, tuple[int, int]] = {}  # cells done, of (D-070)
        # Language model extension (D-022): only when installed; started on the first question.
        self._llm_factory = llm or (
            (lambda: LlamaServer(settings.llm)) if settings.llm is not None else None
        )
        self._llm: Any = None
        self._answer_stops: dict[str, threading.Event] = {}  # running answer per project (M9a)
        self._file_watches: dict[str, FileWatch] = {}
        self._drops: dict[str, list[Path]] = {}  # the last drop of the window, by number (D-038)
        self._placing: dict[str, list[dict[str, Any]]] = {}
        self._tasks = JobQueue(self._run_task)
        # A first reading cut short by closing the app goes on at the next start (D-066).
        for info in self.registry.list():
            if info.too_new:
                continue
            with contextlib.suppress(DaengsError, OSError, ValueError):
                if self.registry.first_ingest(info.project_id) == FIRST_RUNNING:
                    self._tasks.add(info.project_id, READ_STAGE, FIRST)

    # -- models, loaded once and shared ------------------------------------------------------

    def _default_ocr(self) -> Callable[[], OcrEngine] | None:
        models, threads = self.settings.ocr_models, self.settings.ingest.ocr_threads
        return None if models is None else lambda: RapidOcrEngine(models, threads)

    def _default_embedder(self) -> Callable[[], Embedder] | None:
        model, threads = self.settings.embedding, self.settings.search.embedding_threads
        return None if model is None else lambda: OnnxEmbedder(model, threads)

    def _shared_ocr(self) -> OcrEngine:
        with self._lock:
            if self._ocr is None:
                if self._ocr_factory is None:
                    raise DaengsError("Keine Texterkennung eingerichtet")
                self._ocr = self._ocr_factory()
            return self._ocr

    def _shared_embedder(self) -> Embedder:
        with self._lock:
            if self._embedder is None:
                if self._embedder_factory is None:
                    raise DaengsError("Kein Einbettungsmodell eingerichtet")
                self._embedder = self._embedder_factory()
            return self._embedder

    def _index(self, context: ProjectContext) -> SearchIndex:
        # One index object per project, created once even when the UI and the background job
        # ask at the same moment.
        with self._index_lock:
            index = self._indexes.get(context.project_id)
            if index is None:
                index = SearchIndex(context, self.settings.search, self._shared_embedder)
                self._indexes[context.project_id] = index
        return index

    def _ingestor(self, context: ProjectContext) -> Ingestor:
        ocr = self._shared_ocr if self._ocr_factory is not None else None
        return Ingestor(context, self.settings.ingest, ocr_engine=ocr)

    # -- Backend -----------------------------------------------------------------------------

    def list_projects(self) -> list[dict[str, Any]]:
        return [_project(p) for p in self.registry.list()]

    def create_project(self, name: str, folders: list[str]) -> dict[str, Any]:
        context = self.registry.create(name, [Path(f) for f in folders])
        return _project(self.registry.info(context.project_id))

    def project(self, project_id: str) -> dict[str, Any]:
        return _project(self.registry.info(project_id))

    def grant_folder(self, project_id: str, folder: str) -> dict[str, Any]:
        self.registry.grant_folder(project_id, Path(folder))
        return self.project(project_id)

    def revoke_folder(self, project_id: str, folder: str) -> dict[str, Any]:
        self.registry.revoke_folder(project_id, Path(folder))
        return self.project(project_id)

    def start_ingest(self, project_id: str) -> dict[str, Any]:
        context = self.registry.open(project_id)
        first = self.registry.first_ingest(context.project_id) == FIRST_RUNNING
        self._tasks.add(context.project_id, READ_STAGE, FIRST if first else READ)
        return self.ingest_status(project_id)

    def ingest_status(self, project_id: str) -> dict[str, Any]:
        """Counts of the project, the state of its reading and how far it has got (D-065)."""
        context = self.registry.open(project_id)
        ingestor = self._ingestor(context)
        status = dataclasses.asdict(ingestor.status())
        status["job"] = self._tasks.state(context.project_id)
        status["first"] = self.registry.first_ingest(context.project_id)
        reading = self._reading(context, ingestor)
        status["vectors_pending"] = reading["vectors_pending"]
        status["unreachable"] = reading["unreachable"]
        status["phase"] = reading["phase"]
        status["files_total"] = len(reading["total"])
        status["files_done"] = len(reading["total"] - reading["open"])
        status["current"] = reading["current"][1] if reading["current"] else None
        status["ahead"] = None
        running = self._tasks.running()
        if status["job"] == QUEUED and running and running[0] != context.project_id:
            with contextlib.suppress(DaengsError, OSError, ValueError):
                status["ahead"] = self.registry.info(running[0].removesuffix(TABLE_KEY)).name
        return status

    def _reading(self, context: ProjectContext, ingestor: Ingestor) -> dict[str, Any]:
        """Which files the reading in progress covers and which of them are still open.

        A file counts as done when its text and all its embeddings are there (D-065). The files
        of a run are those new or changed when it began and those with open embeddings."""
        project_id = context.project_id
        try:
            pending = self._index(context).pending_by_file()
            vectors_pending: int | None = sum(pending.values())
        except DaengsError:
            pending, vectors_pending = {}, None
        progress = self._progress.get(project_id, {})
        running = self._tasks.running()
        phase = progress.get("phase") if running and running[0] == project_id else None
        current = None
        open_ = set(pending)
        if phase == "text":
            current = progress.get("current")
            open_ |= progress["work"] - progress["scanned"]
            if current:
                open_.add(current)
        elif phase == "suchindex" and pending:
            current = next(iter(pending))
        elif phase == "texterkennung":
            queue = ingestor.ocr_queue()
            current = (queue[0][0], queue[0][1]) if queue else None
        total = (progress.get("work", set()) if progress.get("active") else set()) | set(pending)
        unreachable = [str(f) for f in context.folders if not f.is_dir()]
        if unreachable and self.registry.first_ingest(project_id) == FIRST_RUNNING:
            # Nothing can finish without that folder: said plainly, no endless animation.
            phase = "ordner_fehlt"
        return {
            "phase": phase,
            "current": current,
            "open": open_ & total,
            "total": total,
            "pending": pending,
            "vectors_pending": vectors_pending,
            "unreachable": unreachable,
        }

    # -- file explorer (A-33, A-34) -------------------------------------------------------------

    def watch_files(self, project_id: str) -> dict[str, Any]:
        """The regular look of the open project (A-42): the listing, and reading starts by itself
        once new or changed files have settled. Never restarts a run, never with a folder away."""
        context = self.registry.open(project_id)
        start = time.perf_counter()
        listing = inventory(context)
        result = self._file_listing(context, listing)
        result["seconds"] = round(time.perf_counter() - start, 2)
        watch = self._file_watches.setdefault(context.project_id, FileWatch())
        reading = self._tasks.has(context.project_id, READ_STAGE)
        if not reading and not listing.unreachable:
            settled = watch.should_start(listing.files)
            # A first reading that could not finish (a folder was away) goes on by itself.
            unfinished = (
                self.registry.first_ingest(context.project_id) == FIRST_RUNNING
                and result["job"] != FAILED
            )
            if settled or unfinished:
                self.start_ingest(project_id)
                result["started"] = True
                result["job"] = QUEUED
        return result

    def files(self, project_id: str) -> dict[str, Any]:
        """All files of the delivery with their state."""
        context = self.registry.open(project_id)
        return self._file_listing(context, inventory(context))

    def _file_listing(self, context: ProjectContext, listing: Inventory) -> dict[str, Any]:
        """While reading waits or runs, the file in work is "laeuft" and the other open ones
        (new, changed, embeddings missing) are "wartet" (D-066)."""
        job = self._tasks.state(context.project_id)
        reading = self._tasks.has(context.project_id, READ_STAGE)
        progress = self._reading(context, self._ingestor(context)) if reading else None
        entries = []
        for entry in listing.files:
            item = dataclasses.asdict(entry)
            key = (entry.folder, entry.rel_path)
            open_file = entry.state in (NEW, CHANGED) or (
                entry.state == DONE_FILE and key in progress["pending"] if progress else False
            )
            if progress is not None and open_file:
                item["state"] = RUNNING if key == progress["current"] else QUEUED
            entries.append(item)
        return {
            "files": entries,
            "truncated": listing.truncated,
            "folders": [str(f) for f in context.folders],
            "unreachable": listing.unreachable,
            "job": job,
        }

    def open_file(self, project_id: str, folder: str, rel_path: str) -> dict[str, Any]:
        """Open a delivery file with its own program; programs, scripts and links never."""
        context = self.registry.open(project_id)
        if folder not in {str(f) for f in context.folders}:
            raise PathNotAllowedError("Ordner ist nicht freigegeben")
        path = context.readable(Path(folder) / rel_path)
        if path.suffix.lower() not in OPENABLE:
            raise DaengsError(
                f"Diese Art Datei öffnet {PRODUCT} nicht (Programm, Skript oder Verknüpfung)"
            )
        if not path.is_file():
            raise DaengsError("Datei nicht gefunden")
        self._open(path, 1)
        return {"geoeffnet": True}

    def search(self, project_id: str, question: str, limit: int) -> dict[str, Any]:
        context = self.registry.open(project_id)
        hits = self._index(context).search(question, limit=limit)
        return {
            # The search terms, so the UI marks the same words the search used.
            "terms": terms(question),
            "hits": [{**dataclasses.asdict(h), "folder": str(h.folder)} for h in hits],
        }

    def page_marks(
        self, project_id: str, file_id: int, page_no: int, chunk_id: int | None, question: str
    ) -> dict[str, Any]:
        view = PageView(self.registry.open(project_id))
        return dataclasses.asdict(view.marks(file_id, page_no, chunk_id, terms(question)))

    def page_image(self, project_id: str, file_id: int, page_no: int, width: int) -> bytes:
        return PageView(self.registry.open(project_id)).image(file_id, page_no, width)

    def open_original(self, project_id: str, file_id: int, page_no: int) -> dict[str, Any]:
        path = PageView(self.registry.open(project_id)).original(file_id, page_no)
        return {"page_jump": self._open(path, page_no)}

    # Replaceable in tests; opens the user's PDF program.
    _open = staticmethod(open_at_page)

    # -- overview by assembly (F5) -----------------------------------------------------------

    def _overview(self, project_id: str) -> Overview:
        context = self.registry.open(project_id)
        index = self._index(context)

        def search(question: str, limit: int) -> list[dict[str, Any]]:
            return [dataclasses.asdict(h) for h in index.search(question, limit=limit)]

        return Overview(context, search)

    def overview(self, project_id: str) -> dict[str, Any]:
        overview = self._overview(project_id)
        results = overview.compute()
        return {
            "assemblies": overview.assemblies(),
            "results": [{**dataclasses.asdict(r), "files": r.files} for r in results],
        }

    def set_assemblies(self, project_id: str, text: str) -> dict[str, Any]:
        self._overview(project_id).set_assemblies(text)
        return self.overview(project_id)

    def decide(
        self, project_id: str, assembly_id: int, file_id: int, page_no: int, decision: str | None
    ) -> dict[str, Any]:
        self._overview(project_id).decide(assembly_id, file_id, page_no, decision)
        return {"ok": True}

    def export_overview(self, project_id: str) -> dict[str, Any]:
        return {
            "filename": "Uebersicht_Baugruppen.csv",
            "csv": self._overview(project_id).export_csv(),
        }

    # -- overview table (D-070, D-071) -------------------------------------------------------

    def _table(self, project_id: str) -> Table:
        return Table(self.registry.open(project_id))

    def _table_search(self, context: ProjectContext) -> Callable[[str, int], list[dict]]:
        index = self._index(context)

        def search(question: str, limit: int) -> list[dict[str, Any]]:
            return [dataclasses.asdict(h) for h in index.search(question, limit=limit)]

        return search

    def _queue_table(self, project_id: str) -> None:
        """Cells are searched in the background (D-066): after reading, never during the first
        reading of the project, only for a project whose overview was opened."""
        context = self.registry.open(project_id)
        if not (context.project_dir / TABLE_DB).exists():
            return
        if self.registry.first_ingest(context.project_id) == FIRST_RUNNING:
            return
        self._tasks.add(context.project_id + TABLE_KEY, TABLE_STAGE, TABLE)

    def table(self, project_id: str) -> dict[str, Any]:
        table = self._table(project_id)
        data = table.table()
        pending, total = table.pending_cells()
        key = table.context.project_id + TABLE_KEY
        state = self._tasks.state(key)
        if pending and state not in (QUEUED, RUNNING):
            self._queue_table(project_id)
            state = self._tasks.state(key)
        done, of = self._table_progress.get(table.context.project_id, (0, 0))
        data["computing"] = {
            "pending": pending,
            "total": total,
            "state": state,
            "done": done if state == RUNNING else 0,
            "of": of if state == RUNNING else pending,
            "first": self.registry.first_ingest(table.context.project_id),
        }
        return data

    def table_cell(self, project_id: str, component: str, chapter: str) -> dict[str, Any]:
        return self._table(project_id).cell(component, chapter)

    def table_components(self, project_id: str, change: dict[str, Any]) -> dict[str, Any]:
        table = self._table(project_id)
        action = change["action"]
        if action == "add":
            table.add_components(change["names"])
        elif action == "update":
            table.update_component(
                change["key"], change.get("name"), change.get("hidden"), change.get("aliases")
            )
        elif action == "merge":
            table.merge_components(change["key"], change["others"])
        elif action == "remove":
            table.remove_component(change["key"])
        elif action == "move":
            table.move_component(change["key"], change["position"])
        self._queue_table(project_id)
        return self.table(project_id)

    def table_chapters(self, project_id: str, change: dict[str, Any]) -> dict[str, Any]:
        table = self._table(project_id)
        action = change["action"]
        if action == "add":
            table.add_chapter(
                change["name"], change.get("words_de", []), change.get("words_en", [])
            )
        elif action == "update":
            table.update_chapter(
                change["key"],
                change.get("name"),
                change.get("words_de"),
                change.get("words_en"),
                change.get("visible"),
                bool(change.get("reset")),
            )
        elif action == "remove":
            table.remove_chapter(change["key"])
        elif action == "template":
            table.use_template(change["template"])
        self._queue_table(project_id)
        return self.table(project_id)

    def table_set_cell(
        self, project_id: str, component: str, chapter: str, status: str | None, note: str | None
    ) -> dict[str, Any]:
        return self._table(project_id).set_cell(component, chapter, status, note)

    def table_decide(
        self,
        project_id: str,
        component: str,
        chapter: str,
        folder: str,
        rel_path: str,
        page_no: int,
        decision: str | None,
    ) -> dict[str, Any]:
        table = self._table(project_id)
        table.decide(component, chapter, folder, rel_path, page_no, decision)
        return table.cell(component, chapter)

    def table_document(
        self, project_id: str, folder: str, rel_path: str, status: str | None, stand: str | None
    ) -> dict[str, Any]:
        self._table(project_id).set_document(folder, rel_path, status, stand)
        return {"ok": True}

    def table_view(
        self, project_id: str, intro_seen: bool | None, view: dict[str, Any] | None
    ) -> dict[str, Any]:
        self._table(project_id).set_view(intro_seen, view)
        return {"ok": True}

    def table_suggestions(self, project_id: str) -> dict[str, Any]:
        return self._table(project_id).suggestions()

    def table_questions(self, project_id: str) -> dict[str, Any]:
        table = self._table(project_id)
        return {"items": table.questions(), "text": table.questions_text()}

    def table_export(self, project_id: str, what: str, fmt: str) -> dict[str, Any]:
        return self._table(project_id).export(what, fmt)

    def _run_table(self, project_id: str, stop: threading.Event) -> bool:
        context = self.registry.open(project_id)
        if self.registry.first_ingest(context.project_id) == FIRST_RUNNING:
            return True  # queued again when the first reading is done
        table = Table(context)

        def on_cell(done: int, total: int) -> None:
            self._table_progress[context.project_id] = (done, total)

        self._table_progress[context.project_id] = (0, table.pending_cells()[0])
        try:
            return table.compute(self._table_search(context), stop=stop, on_cell=on_cell)
        finally:
            self._table_progress.pop(context.project_id, None)

    # -- wiki (F6) ---------------------------------------------------------------------------

    def _wiki(self, project_id: str) -> Wiki:
        return Wiki(self.registry.open(project_id))

    def wiki_pages(self, project_id: str) -> list[dict[str, Any]]:
        return self._wiki(project_id).pages()

    def wiki_create(self, project_id: str, title: str) -> dict[str, Any]:
        return dataclasses.asdict(self._wiki(project_id).create(title))

    def wiki_page(self, project_id: str, page_id: int) -> dict[str, Any]:
        return dataclasses.asdict(self._wiki(project_id).page(page_id))

    def wiki_save(self, project_id: str, page_id: int, title: str, body: str) -> dict[str, Any]:
        return dataclasses.asdict(self._wiki(project_id).save(page_id, title, body))

    def wiki_delete(self, project_id: str, page_id: int) -> dict[str, Any]:
        self._wiki(project_id).delete(page_id)
        return {"ok": True}

    def wiki_remember(
        self,
        project_id: str,
        page_id: int,
        file_id: int,
        page_no: int,
        chunk_id: int | None,
        note: str,
    ) -> dict[str, Any]:
        page = self._wiki(project_id).remember(page_id, file_id, page_no, chunk_id, note)
        return dataclasses.asdict(page)

    def wiki_suggestion(self, project_id: str, chat_id: int, message_id: int) -> dict[str, Any]:
        """A wiki page made from an answer, for the user to confirm (M9b); nothing is written."""
        answerer = self._answerer(project_id)
        entry = answerer.message(chat_id, message_id)
        title = suggestion.quoted_title(entry["question"]) or answerer.title_for(entry["question"])
        proposal = suggestion.build(entry, title)
        target = self._wiki(project_id).similar(title) if proposal["body"] else None
        if target is not None:
            page = self._wiki(project_id).page(target["id"])
            proposal.update(page_id=page.id, page_title=page.title, page_body=page.body)
        return proposal

    def wiki_accept(
        self,
        project_id: str,
        title: str,
        body: str,
        refs: list[dict[str, Any]],
        page_id: int | None,
    ) -> dict[str, Any]:
        page = self._wiki(project_id).apply_suggestion(title, body, refs, page_id)
        return dataclasses.asdict(page)

    def wiki_restore(self, project_id: str, page_id: int) -> dict[str, Any]:
        return dataclasses.asdict(self._wiki(project_id).restore(page_id))

    def wiki_forget(self, project_id: str, page_id: int, ref_id: int) -> dict[str, Any]:
        return dataclasses.asdict(self._wiki(project_id).forget(page_id, ref_id))

    # -- Gesamt-Wiki (M9d, A-31): for all projects, outside of every project -------------------

    def _global_wiki(self) -> GlobalWiki:
        return GlobalWiki(self.settings.data_dir.parent / GLOBAL_WIKI_FOLDER)

    def global_wiki_pages(self) -> list[dict[str, Any]]:
        return self._global_wiki().pages()

    def global_wiki_create(self, title: str) -> dict[str, Any]:
        return dataclasses.asdict(self._global_wiki().create(title))

    def global_wiki_page(self, page_id: int) -> dict[str, Any]:
        return dataclasses.asdict(self._global_wiki().page(page_id))

    def global_wiki_save(self, page_id: int, title: str, body: str) -> dict[str, Any]:
        return dataclasses.asdict(self._global_wiki().save(page_id, title, body))

    def global_wiki_restore(self, page_id: int) -> dict[str, Any]:
        return dataclasses.asdict(self._global_wiki().restore(page_id))

    def global_wiki_delete(self, page_id: int) -> dict[str, Any]:
        self._global_wiki().delete(page_id)
        return {"geloescht": True}

    def global_wiki_check(self, project_id: str, title: str, body: str) -> dict[str, Any]:
        """What looks like customer content in this text, for the user to decide; writes nothing."""
        wiki = self._wiki(project_id)
        name = self.registry.info(project_id).name
        return {
            "hints": customer_hints(wiki.context, name, title, body),
            "existing": self._global_wiki().same_title(title) is not None,
        }

    def global_wiki_accept(self, title: str, body: str) -> dict[str, Any]:
        return dataclasses.asdict(self._global_wiki().take_over(title, body))

    # -- interface choices (D-045) -------------------------------------------------------------

    def _preferences(self) -> Preferences:
        return Preferences(self.settings.data_dir.parent / PREFERENCES_FILE)

    def preferences(self) -> dict[str, str]:
        return self._preferences().read()

    def set_preferences(self, changes: dict[str, str]) -> dict[str, str]:
        return self._preferences().write(**changes)

    # -- updates (13, D-037): the update program does the network, the app only reads its files --

    def _update_files(self) -> UpdateFiles:
        return UpdateFiles(self.settings.data_dir.parent / UPDATE_FOLDER)

    def _update_program(self) -> Path | None:
        """Only the installed package has it, and only once the server's address is fixed."""
        program = Path(sys.executable).parent / UPDATE_PROGRAM
        return program if UPDATE_URL and program.is_file() else None

    def _run_update_program(self, task: str) -> None:
        program = self._update_program()
        if program is None:
            raise DaengsError("Updates sind hier nicht verfügbar")
        no_window = 0x08000000 if sys.platform == "win32" else 0
        subprocess.Popen(  # noqa: S603 - our own program next to this Python, fixed arguments
            [
                str(program),
                "-I",
                "-m",
                "daengs.updater",
                task,
                "--ordner",
                str(self._update_files().folder),
            ],
            creationflags=no_window,
            close_fds=True,
        )

    def update_status(self) -> dict[str, Any]:
        files = self._update_files()
        settings, state = files.read("settings"), files.read("state")
        available = state.get("available")
        if available and not is_newer(available["version"], __version__):
            available = None
        return {
            "offered": self._update_program() is not None,
            "version": __version__,
            "enabled": settings.get("enabled", True),
            "hint_pending": not settings.get("hint_seen", False),
            "last_check": state.get("last_check"),
            "available": available,
            "progress": files.read("progress") if available else {},
            "result": files.read("result"),
        }

    def update_on_start(self) -> None:
        """Called once by the program at its start: what became of the last update, and the check
        at most once a day. Before the user has seen the hint nothing goes out (D-037)."""
        self._finish_update_attempt()
        files = self._update_files()
        settings = files.read("settings")
        last = files.read("state").get("last_try", 0)
        if (
            self._update_program() is not None
            and settings.get("enabled", True)
            and settings.get("hint_seen", False)
            and time.time() - last > CHECK_EVERY_SECONDS
        ):
            with contextlib.suppress(OSError):
                self._run_update_program("pruefen")

    def _finish_update_attempt(self) -> None:
        files = self._update_files()
        attempt = files.read("attempt")
        if not attempt:
            return
        version = attempt.get("version", "")
        if attempt.get("error"):
            result = {"ok": False, "version": version, "message": attempt["error"]}
        elif version == __version__:
            broken = _own_code_that_does_not_load()
            checks = diagnostics.selftest(self.settings)
            passed = not broken and all(c.ok for c in checks)
            message = "Der Selbsttest nach dem Update meldet einen Fehler."
            if broken:
                message = f"Ein Teil des Programms lädt nicht ({broken})."
            result = {"ok": passed, "version": version, "message": "" if passed else message}
            shutil.rmtree(files.download_dir, ignore_errors=True)
            files.remove("progress")
        else:
            message = "Das Update wurde nicht abgeschlossen."
            result = {"ok": False, "version": version, "message": message}
        files.write("result", result)
        files.remove("attempt")

    def update_settings(self, enabled: bool | None, hint_seen: bool | None) -> dict[str, Any]:
        files = self._update_files()
        first_time = hint_seen and not files.read("settings").get("hint_seen", False)
        changes = {"enabled": enabled, "hint_seen": hint_seen}
        files.update("settings", **{k: v for k, v in changes.items() if v is not None})
        status = self.update_status()
        if first_time and status["enabled"] and status["offered"]:
            with contextlib.suppress(OSError):
                self._run_update_program("pruefen")
        return status

    def update_check(self) -> dict[str, Any]:
        if not self.update_status()["enabled"]:
            raise DaengsError("Updates sind ausgeschaltet")
        self._run_update_program("pruefen")
        return {"gestartet": True}

    def update_download(self) -> dict[str, Any]:
        status = self.update_status()
        if not status["offered"]:
            raise DaengsError("Updates sind hier nicht verfügbar")
        available = status["available"]
        if available and available.get("loadable") is False:
            raise DaengsError(
                "Diese Fassung ist für das Update zu alt; es gibt einen Vollinstaller."
            )
        self._update_files().write("progress", {"state": "laedt", "done": 0, "size": 0})
        self._run_update_program("laden")
        return {"gestartet": True}

    def update_cancel(self) -> dict[str, Any]:
        files = self._update_files()
        files.folder.mkdir(parents=True, exist_ok=True)
        files.cancel_file.write_text("", encoding="ascii")
        return {"abgebrochen": True}

    def update_install(self) -> dict[str, Any]:
        """The program waits until this app has closed, then setup runs; the UI closes it."""
        if self._tasks.busy():
            raise DaengsError("Es wird eingelesen. Das Update wartet, bis das fertig ist.")
        if self._update_files().read("progress").get("state") != "bereit":
            raise DaengsError("Das Update ist noch nicht geladen")
        self._run_update_program("installieren")
        return {"schliessen": True}

    def update_result_seen(self) -> dict[str, Any]:
        self._update_files().remove("result")
        return {"gesehen": True}

    # -- dropping files into the delivery (M12, D-038) ------------------------------------------

    def register_drop(self, paths: list[str]) -> dict[str, Any]:
        """Called by the window with what Windows dropped. The page only ever gets a number, so
        no path it sends can reach the file system."""
        drop_id = uuid.uuid4().hex
        with self._lock:
            self._drops = {drop_id: [Path(p) for p in paths[:MAX_DROP_FILES]]}
        return {
            "id": drop_id,
            "names": [Path(p).name for p in paths[:MAX_DROP_FILES]],
            "too_many": len(paths) > MAX_DROP_FILES,
        }

    def place_files(
        self, project_id: str, drop_id: str, folder: str | None, subfolder: str
    ) -> dict[str, Any]:
        """Copy the dropped files. One folder: there. Several: where they were dropped; if that is
        not known the page is told to ask (never guessed)."""
        context = self.registry.open(project_id)
        with self._lock:
            sources = self._drops.get(drop_id)
        if sources is None:
            raise DaengsError("Bitte die Dateien noch einmal ablegen")
        if folder is None and len(context.folders) > 1:
            return {"choose": [str(f) for f in context.folders]}
        if len(context.folders) == 1:
            folder, subfolder = str(context.folders[0]), ""
        directory = context.place_dir(folder or "", subfolder)
        with self._lock:
            if any(i["state"] in ("wartet", "kopiert") for i in self._placing.get(project_id, [])):
                raise DaengsError("Es wird gerade kopiert. Bitte danach noch einmal ablegen.")
            self._drops.pop(drop_id)
            items = [
                {"name": s.name, "state": "wartet", "done": 0, "size": 0, "placed": "", "error": ""}
                for s in sources
            ]
            self._placing[project_id] = items
        threading.Thread(
            target=self._place_all,
            args=(context, sources, directory, items),
            name="daengs-ablegen",
            daemon=True,
        ).start()
        return {"items": items}

    def _place_all(self, context, sources, directory, items) -> None:
        placed = 0
        for source, item in zip(sources, items, strict=True):

            def progress(done: int, size: int, item=item) -> None:
                item.update(state="kopiert", done=done, size=size)

            try:
                item["state"] = "kopiert"
                item["placed"] = place_file(source, directory, progress, self._stop)
                item["state"] = "fertig"
                placed += 1
            except DaengsError as exc:
                item.update(state="fehler", error=str(exc))
        context.log_event("dateien_abgelegt", dateien=placed, fehler=len(sources) - placed)
        if placed:
            self.start_ingest(context.project_id)

    def placing_status(self, project_id: str) -> dict[str, Any]:
        context = self.registry.open(project_id)
        return {"items": self._placing.get(context.project_id, [])}

    # -- delete a project (F7) ---------------------------------------------------------------

    def delete_project(self, project_id: str, confirm_name: str) -> dict[str, Any]:
        context = self.registry.open(project_id)
        if self._tasks.state(context.project_id) in (QUEUED, RUNNING):
            raise DaengsError("Das Projekt wird gerade eingelesen. Bitte danach löschen.")
        if self._tasks.state(context.project_id + TABLE_KEY) == RUNNING:
            raise DaengsError("Die Übersicht wird gerade berechnet. Bitte gleich noch einmal.")
        with self._lock:
            # Drop everything that refers to the project before its folder goes.
            self._indexes.pop(context.project_id, None)
            self._progress.pop(context.project_id, None)
            self._tasks.forget(context.project_id)
            self._tasks.forget(context.project_id + TABLE_KEY)
        result = self.registry.delete(context.project_id, confirm_name)
        self._preferences().forget_project(context.project_id)
        return result

    # -- answers with sources (F10, D-022) ---------------------------------------------------

    def llm_status(self) -> dict[str, Any]:
        model = self.settings.llm
        return {
            "available": self._llm_factory is not None,
            "model_id": model.model_id if model else None,
            "running": bool(self._llm is not None and getattr(self._llm, "running", False)),
        }

    def _shared_llm(self) -> Any:
        with self._lock:
            if self._llm_factory is None:
                raise DaengsError(f"Die Erweiterung {PRODUCT}-Sprachmodell ist nicht installiert")
            if self._llm is None:
                self._llm = self._llm_factory()
            return self._llm

    def _answerer(self, project_id: str) -> Answerer:
        context = self.registry.open(project_id)
        index = self._index(context)

        def search(question: str, limit: int) -> list[dict[str, Any]]:
            return [dataclasses.asdict(h) for h in index.search(question, limit=limit)]

        return Answerer(context, search, self._shared_llm(), index.sure_chunks)

    def answer(
        self,
        project_id: str,
        question: str,
        chat_id: int | None = None,
        chunk_ids: list[int] | None = None,
    ) -> dict[str, Any]:
        return self._answerer(project_id).answer(question, chat_id, chunk_ids)

    def answer_stream(
        self,
        project_id: str,
        question: str,
        chat_id: int | None = None,
        chunk_ids: list[int] | None = None,
    ) -> Iterator[dict[str, Any]]:
        """The answer step by step for the chat (M9a); ``answer_stop`` ends it early."""
        answerer = self._answerer(project_id)
        stop = threading.Event()
        with self._lock:
            self._answer_stops[project_id] = stop
        try:
            for event in answerer.answer_events(question, chat_id, stop, chunk_ids):
                yield event
                entry = event.get("entry") if event["type"] == "done" else None
                # "Leg mir eine Wiki-Seite an ...": the suggestion card comes by itself (A-39).
                if entry and not entry["stopped"] and suggestion.wants_wiki(question):
                    proposal = self.wiki_suggestion(project_id, entry["chat_id"], entry["id"])
                    if proposal["body"]:
                        yield {"type": "wiki_suggestion", "suggestion": proposal}
        finally:
            with self._lock:
                if self._answer_stops.get(project_id) is stop:
                    del self._answer_stops[project_id]

    def answer_stop(self, project_id: str) -> dict[str, Any]:
        with self._lock:
            stop = self._answer_stops.get(project_id)
        if stop is not None:
            stop.set()
            if self._llm is not None and hasattr(self._llm, "cancel"):
                self._llm.cancel()
        return {"gestoppt": stop is not None}

    def chat_rate(
        self, project_id: str, chat_id: int, message_id: int, value: int, note: str
    ) -> dict[str, Any]:
        return self._answerer(project_id).rate(chat_id, message_id, value, note)

    def chat_history(self, project_id: str, chat_id: int | None = None) -> list[dict[str, Any]]:
        if self._llm_factory is None:
            return []
        return self._answerer(project_id).history(chat_id)

    def chats(self, project_id: str) -> list[dict[str, Any]]:
        if self._llm_factory is None:
            return []
        return self._answerer(project_id).chats()

    def chat_create(self, project_id: str, title: str) -> dict[str, Any]:
        answerer = self._answerer(project_id)
        chat_id = answerer.create_chat(title)
        return next(c for c in answerer.chats() if c["id"] == chat_id)

    def chat_rename(self, project_id: str, chat_id: int, title: str) -> dict[str, Any]:
        return self._answerer(project_id).rename_chat(chat_id, title)

    def chat_delete(self, project_id: str, chat_id: int) -> dict[str, Any]:
        return {"geloescht": self._answerer(project_id).delete_chat(chat_id)}

    def chat_clear(self, project_id: str) -> dict[str, Any]:
        return {"geloescht": self._answerer(project_id).clear()}

    # -- self-test and diagnostic report (F8) ------------------------------------------------

    def diagnostics(self) -> dict[str, Any]:
        stats = []
        for info in self.registry.list():
            try:
                stats.append(self._project_numbers(info))
            except Exception:  # a broken project must not stop the report
                stats.append({"lesbar": 0})
        data = diagnostics.report(self.settings, stats)
        status = self.update_status()
        data["updates"] = {
            "angeboten": status["offered"],
            "eingeschaltet": status["enabled"],
            "letzte_pruefung": time.strftime("%Y-%m-%d %H:%M", time.localtime(status["last_check"]))
            if status["last_check"]
            else "noch keine",
        }
        return {"report": data, "text": diagnostics.as_text(data)}

    def _project_numbers(self, info: ProjectInfo) -> dict[str, int]:
        context = self.registry.open(info.project_id)
        numbers = dataclasses.asdict(self._ingestor(context).status())
        with contextlib.suppress(DaengsError):
            numbers["vectors_pending"] = self._index(context).pending()
        numbers["folders"] = len(info.folders)
        numbers["bytes"] = sum(
            p.stat().st_size for p in context.project_dir.rglob("*") if p.is_file()
        )
        with context.transaction() as con:
            tables = {
                n for (n,) in con.execute("select name from sqlite_master where type = 'table'")
            }
            for key, table in (("wiki_pages", "wiki_page"), ("assemblies", "assembly")):
                if table in tables:
                    numbers[key] = con.execute(f"select count(*) from {table}").fetchone()[0]  # noqa: S608
        return numbers

    # -- background jobs ---------------------------------------------------------------------

    def _run_task(self, project_id: str, stage: str, stop: threading.Event) -> bool:
        """One stage of reading a project; False when it stopped early for another (D-066).

        Reading: quick index, then embeddings for it; when that ran through with every folder
        there, the first reading is done (D-065). OCR: scanned pages, then their embeddings.
        Every step commits per file, batch or page, so a stop leaves nothing half written.
        The overview table has a key of its own (project id + TABLE_KEY)."""
        if stage == TABLE_STAGE:
            return self._run_table(project_id.removesuffix(TABLE_KEY), stop)
        context = self.registry.open(project_id)
        ingestor = self._ingestor(context)
        embeds = self._embedder_factory is not None
        progress = self._progress.setdefault(project_id, {"work": set(), "active": False})
        try:
            if stage == OCR_STAGE:
                progress["phase"] = "texterkennung"
                ingestor.run_ocr(stop=stop)
                if stop.is_set() and ingestor.status().ocr_pending:
                    return False
                if embeds:
                    progress["phase"] = "suchindex"
                    search = self._index(context)
                    search.update(stop=stop)
                    if stop.is_set() and search.pending():
                        return False
                self._queue_table(project_id)
                return True
            if not progress["active"]:  # a new run; a resumed one keeps its files
                progress["work"] = {
                    (f.folder, f.rel_path)
                    for f in inventory(context).files
                    if f.state in (NEW, CHANGED)
                }
                progress["active"] = True
            progress.update(phase="text", scanned=set(), current=None)

            def on_file(_i: int, _total: int, folder: str, rel: str) -> None:
                if progress["current"]:
                    progress["scanned"].add(progress["current"])
                progress["current"] = (folder, rel)

            report = ingestor.scan(stop=stop, on_file=on_file)
            if report.stopped:
                return False
            progress.update(phase="suchindex", current=None)
            pending = 0
            if embeds:
                search = self._index(context)
                progress["work"] |= set(search.pending_by_file())
                search.update(stop=stop)
                pending = search.pending()
                if pending and stop.is_set():
                    return False
            everything_there = all(f.is_dir() for f in context.folders)
            if everything_there and not pending:
                self.registry.finish_first_ingest(project_id)
            progress["active"] = False
            if self._ocr_factory is not None and ingestor.status().ocr_pending:
                self._tasks.add(project_id, OCR_STAGE, OCR)
            self._queue_table(project_id)
            return True
        finally:
            progress["phase"] = None

    def wait_idle(self, timeout: float = 60) -> bool:
        """For tests and shutdown: wait until no job is queued or running."""
        return self._tasks.wait_idle(timeout)

    def close(self) -> None:
        if self._llm is not None and hasattr(self._llm, "close"):
            self._llm.close()
        self._stop.set()
        self._tasks.close()


def _project(info: ProjectInfo) -> dict[str, Any]:
    return {
        "id": info.project_id,
        "name": info.name,
        "created": info.created,
        "folders": [str(f) for f in info.folders],
        "too_new": info.too_new,
    }


def _own_code_that_does_not_load() -> str:
    """After a code update (D-077): every module of Daengs must load, or the old code comes back.
    The update program is left out: the app never loads it (13 §2), it checks itself."""
    import importlib
    import pkgutil

    import daengs

    for module in pkgutil.walk_packages(daengs.__path__, "daengs."):
        name = module.name
        if name.startswith("daengs.updater") or name.endswith("__main__"):
            continue
        try:
            importlib.import_module(name)
        except Exception:
            return name
    return ""
