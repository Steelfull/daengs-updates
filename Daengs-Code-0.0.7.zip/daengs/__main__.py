"""Start Daengs: ``python -m daengs --config daengs.toml`` opens the window.

``--browser`` (development) prints an address for a normal browser instead; the token travels in
the URL fragment, which the browser never sends to the server, and the page removes it at once.
``--selbsttest`` prints the self-test and diagnostic report and exits (installation check).
"""

import argparse
import contextlib
import os
import shutil
import sys
import tempfile
import threading
from pathlib import Path

from daengs import PRODUCT, RUNNING_MUTEX
from daengs.app import App
from daengs.config import ConfigError, load_settings
from daengs.service import LocalService
from daengs.ui import STATIC_DIR


def redirect_temp(folder: Path) -> None:
    """Temporary files of all libraries go into Daengs's data location, never the user's TEMP
    (09 §4); the folder is emptied at every start."""
    shutil.rmtree(folder, ignore_errors=True)
    folder.mkdir(parents=True, exist_ok=True)
    for name in ("TMP", "TEMP"):
        os.environ[name] = str(folder)
    tempfile.tempdir = str(folder)


def tell(message: str, error: bool = False) -> None:
    """Console when there is one; a message box when started without (pythonw, shortcut)."""
    stream = sys.stderr if error else sys.stdout
    if stream is not None:
        print(message, file=stream)
    elif sys.platform == "win32":
        import ctypes

        flags = 0x10 if error else 0x40  # MB_ICONERROR / MB_ICONINFORMATION
        ctypes.windll.user32.MessageBoxW(None, message, PRODUCT, flags)


def single_instance() -> object | None:
    """Handle of the mutex if this is the only running Daengs, else None (Windows only)."""
    if sys.platform != "win32":
        return object()
    import ctypes

    kernel32 = ctypes.windll.kernel32
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    handle = kernel32.CreateMutexW(None, False, RUNNING_MUTEX)
    already_exists = 183
    if not handle or kernel32.GetLastError() == already_exists:
        return None
    return handle


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="daengs", description=PRODUCT)
    parser.add_argument("--config", type=Path, required=True, help="Einstellungsdatei (TOML)")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--browser", action="store_true", help="ohne Fenster starten (nur zum Entwickeln)"
    )
    mode.add_argument("--selbsttest", action="store_true", help="Selbsttest ausgeben und beenden")
    args = parser.parse_args(argv)
    try:
        settings = load_settings(args.config)
    except ConfigError as exc:
        tell(f"{PRODUCT} kann nicht starten. Einstellungsdatei fehlerhaft: {exc}", error=True)
        return 2
    if args.selbsttest:
        app = App(settings)
        try:
            result = app.diagnostics()
        finally:
            app.close()
        tell(result["text"])
        return 0 if all(c["ok"] for c in result["report"]["selbsttest"]) else 1
    mutex = single_instance()
    if mutex is None:
        tell(f"{PRODUCT} läuft bereits. Bitte das vorhandene Fenster verwenden.")
        return 3
    if sys.platform == "win32":
        # Projects of an installation under the earlier working name (D-023), if setup could
        # not move them; idempotent and quick when there is nothing left.
        from daengs.migrate import Places as LegacyPlaces
        from daengs.migrate import take_over_projects

        with contextlib.suppress(OSError):
            take_over_projects(LegacyPlaces.current(settings.data_dir))
    redirect_temp(settings.data_dir / "_tmp")
    app = App(settings)
    service = LocalService(app, static_dir=STATIC_DIR).start()
    app.update_on_start()
    try:
        if args.browser:
            tell(f"{PRODUCT} läuft auf {service.url} (nur dieser Rechner). Beenden mit Strg+C.")
            tell(f"Im Browser öffnen: {service.url}/#token={service.token}")
            threading.Event().wait()
        else:
            from daengs.window import run_window

            run_window(service.url, service.token, app.register_drop)
    except KeyboardInterrupt:
        pass
    except Exception as exc:  # shown to the user; no content, only the kind of error
        tell(f"{PRODUCT} wurde mit einem Fehler beendet ({type(exc).__name__}).", error=True)
        return 1
    finally:
        service.stop()
        app.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
