"""Project wiki (F6, A-29): plain-text pages with saved passages that lead back to file and page.

Lives in the project's own database, so it is deleted with the project. Deliberately simple:
no file management, no formatting (R-07); only the version before the last change is kept.

M9b (A-39, D-028): the language model suggests pages from its answers. Nothing is written until
the user confirms; a page made that way is marked as a draft until the user saves it once.

M9d (A-31): the Gesamt-Wiki holds pages for all projects, in its own folder and database, without
customer content: no references into a delivery, and text only comes in after the user confirmed.
"""

import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from daengs.core import DaengsError, DataZone, ProjectContext, ProjectId

MAX_TITLE = 200
MAX_BODY = 200_000
MAX_NOTE = 2_000
QUOTE_CHARS = 300
GLOBAL_WIKI_VERSION = 1  # pragma user_version of the Gesamt-Wiki (13 §7)

_SCHEMA = """
create table if not exists wiki_page(
    id integer primary key autoincrement,
    title text not null,
    body text not null default '',
    created text not null,
    updated text not null
);
"""
_REF_SCHEMA = """
create table if not exists wiki_ref(
    id integer primary key autoincrement,
    page_id integer not null references wiki_page(id) on delete cascade,
    file_id integer references file(id) on delete set null,
    rel_path text not null,
    page_no integer not null,
    chunk_id integer,
    quote text not null,
    note text not null default '',
    created text not null
);
"""


@dataclass
class WikiRef:
    id: int
    file_id: int | None  # None once the file left the delivery; the reference text stays
    rel_path: str
    page_no: int
    chunk_id: int | None
    quote: str
    note: str
    created: str
    place: str = ""  # Word and Excel: section or sheet and rows instead of a page (A-35)


@dataclass
class WikiPage:
    id: int
    title: str
    body: str
    created: str
    updated: str
    draft: bool = False  # written from a suggestion of the model, not yet saved by the user
    can_restore: bool = False  # the version before the last change is there
    refs: list[WikiRef] = field(default_factory=list)


# Columns added in M9b; older project databases get them on open.
_ADDED = [
    ("draft", "integer not null default 0"),
    ("previous_title", "text"),
    ("previous_body", "text"),
]
_WORD = re.compile(r"[\wäöüÄÖÜß]{4,}")


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _title(value: str) -> str:
    value = " ".join(value.split())
    if not value or len(value) > MAX_TITLE:
        raise DaengsError(f"Titel muss 1 bis {MAX_TITLE} Zeichen lang sein")
    return value


class _Pages:
    """Pages with a title, plain text and the version before the last change."""

    def __init__(self, context: ProjectContext) -> None:
        self.context = context
        with context.transaction() as con:
            self._prepare(con)
            con.executescript(_SCHEMA)
            present = {row[1] for row in con.execute("pragma table_info(wiki_page)")}
            for name, kind in _ADDED:
                if name not in present:
                    con.execute(f"alter table wiki_page add column {name} {kind}")

    def _prepare(self, con: Any) -> None:
        pass

    def page(self, page_id: int) -> WikiPage:
        with self.context.transaction() as con:
            row = con.execute(
                "select id, title, body, created, updated, draft != 0, previous_body is not null"
                " from wiki_page where id = ?",
                (page_id,),
            ).fetchone()
        if row is None:
            raise DaengsError("Wiki-Seite nicht gefunden")
        return WikiPage(*row)

    def create(self, title: str) -> WikiPage:
        now = _now()
        with self.context.transaction() as con:
            page_id = con.execute(
                "insert into wiki_page(title, created, updated) values (?, ?, ?)",
                (_title(title), now, now),
            ).lastrowid
        self.context.log_event("wiki_seite_angelegt")
        return self.page(page_id)

    def save(self, page_id: int, title: str, body: str) -> WikiPage:
        if len(body) > MAX_BODY:
            raise DaengsError("Text zu lang")
        with self.context.transaction() as con:
            # Saved by the user: no longer a draft; the version before stays restorable.
            updated = con.execute(
                "update wiki_page set previous_title = title, previous_body = body, title = ?,"
                " body = ?, updated = ?, draft = 0 where id = ? and (title != ? or body != ?)",
                (_title(title), body, _now(), page_id, _title(title), body),
            ).rowcount
            if not updated:
                updated = con.execute(
                    "update wiki_page set draft = 0 where id = ?", (page_id,)
                ).rowcount
        if not updated:
            raise DaengsError("Wiki-Seite nicht gefunden")
        return self.page(page_id)

    def restore(self, page_id: int) -> WikiPage:
        """The version before the last change, back; the current one becomes the previous."""
        with self.context.transaction() as con:
            row = con.execute(
                "select previous_title, previous_body from wiki_page where id = ?", (page_id,)
            ).fetchone()
            if row is None or row[1] is None:
                raise DaengsError("Keine frühere Fassung vorhanden")
            con.execute(
                "update wiki_page set previous_title = title, previous_body = body, title = ?,"
                " body = ?, updated = ? where id = ?",
                (row[0], row[1], _now(), page_id),
            )
        self.context.log_event("wiki_fassung_zurueck")
        return self.page(page_id)

    def delete(self, page_id: int) -> None:
        with self.context.transaction() as con:
            if not con.execute("delete from wiki_page where id = ?", (page_id,)).rowcount:
                raise DaengsError("Wiki-Seite nicht gefunden")
        self.context.log_event("wiki_seite_geloescht")


class Wiki(_Pages):
    """The wiki of one project: its pages may hold passages from the project's delivery."""

    def _prepare(self, con: Any) -> None:
        if not con.execute("select 1 from sqlite_master where name = 'file'").fetchone():
            raise DaengsError("Projekt ist noch nicht eingelesen")
        con.executescript(_REF_SCHEMA)

    def pages(self) -> list[dict[str, Any]]:
        with self.context.transaction() as con:
            rows = con.execute(
                "select p.id, p.title, p.updated, count(r.id) from wiki_page p"
                " left join wiki_ref r on r.page_id = p.id group by p.id order by p.title"
            )
            return [{"id": i, "title": t, "updated": u, "refs": n} for i, t, u, n in rows]

    def page(self, page_id: int) -> WikiPage:
        page = super().page(page_id)
        with self.context.transaction() as con:
            page.refs = [
                WikiRef(*r)
                for r in con.execute(
                    "select r.id, r.file_id, r.rel_path, r.page_no, r.chunk_id, r.quote, r.note,"
                    " r.created, coalesce(p.label, '') from wiki_ref r"
                    " left join page p on p.file_id = r.file_id and p.page_no = r.page_no"
                    " where r.page_id = ? order by r.id",
                    (page_id,),
                )
            ]
        return page

    def similar(self, title: str) -> dict[str, Any] | None:
        """An existing page about the same thing (same title, or most title words shared)."""
        wanted = {w.lower() for w in _WORD.findall(title)}
        best, best_share = None, 0.0
        for page in self.pages():
            words = {w.lower() for w in _WORD.findall(page["title"])}
            if page["title"].lower() == " ".join(title.split()).lower():
                return page
            if wanted and words:
                share = len(wanted & words) / len(wanted | words)
                if share > best_share:
                    best, best_share = page, share
        return best if best_share >= 0.5 else None

    def apply_suggestion(
        self, title: str, body: str, refs: list[dict[str, Any]], page_id: int | None = None
    ) -> WikiPage:
        """Write a suggestion the user has confirmed (A-39): a new draft page, or the text added
        to an existing page (whose earlier version stays restorable); its sources as references."""
        if len(body) > MAX_BODY:
            raise DaengsError("Text zu lang")
        if page_id is None:
            now = _now()
            with self.context.transaction() as con:
                page_id = con.execute(
                    "insert into wiki_page(title, body, created, updated, draft)"
                    " values (?, ?, ?, ?, 1)",
                    (_title(title), body, now, now),
                ).lastrowid
        else:
            current = self.page(page_id)
            joined = f"{current.body.rstrip()}\n\n{body}" if current.body.strip() else body
            with self.context.transaction() as con:
                con.execute(
                    "update wiki_page set previous_title = title, previous_body = body, body = ?,"
                    " updated = ? where id = ?",
                    (joined, _now(), page_id),
                )
        known = {(r.file_id, r.page_no) for r in self.page(page_id).refs}
        for ref in refs:
            key = (ref.get("file_id"), ref.get("page_no"))
            if key in known or None in key:
                continue
            known.add(key)
            self.remember(
                page_id, key[0], key[1], ref.get("chunk_id"), str(ref.get("note", ""))[:MAX_NOTE]
            )
        self.context.log_event("wiki_vorschlag_uebernommen", neu=int(page_id is not None))
        return self.page(page_id)

    def remember(
        self, page_id: int, file_id: int, page_no: int, chunk_id: int | None, note: str = ""
    ) -> WikiPage:
        """'Fundstelle merken': file, page and a short quote of the chunk (or page)."""
        if len(note) > MAX_NOTE:
            raise DaengsError("Notiz zu lang")
        with self.context.transaction() as con:
            if not con.execute("select 1 from wiki_page where id = ?", (page_id,)).fetchone():
                raise DaengsError("Wiki-Seite nicht gefunden")
            row = con.execute(
                "select f.rel_path, p.text from page p join file f on f.id = p.file_id"
                " where p.file_id = ? and p.page_no = ?",
                (file_id, page_no),
            ).fetchone()
            if row is None:
                raise DaengsError("Seite nicht gefunden")
            rel_path, text = row
            if chunk_id is not None:
                chunk = con.execute(
                    "select text from chunk where id = ? and file_id = ? and page_no = ?",
                    (chunk_id, file_id, page_no),
                ).fetchone()
                if chunk is None:
                    chunk_id = None
                else:
                    text = chunk[0]
            quote = " ".join(text.replace("￾", "").split())[:QUOTE_CHARS]
            con.execute(
                "insert into wiki_ref(page_id, file_id, rel_path, page_no, chunk_id, quote, note,"
                " created) values (?, ?, ?, ?, ?, ?, ?, ?)",
                (page_id, file_id, rel_path, page_no, chunk_id, quote, note.strip(), _now()),
            )
            con.execute("update wiki_page set updated = ? where id = ?", (_now(), page_id))
        self.context.log_event("fundstelle_gemerkt")
        return self.page(page_id)

    def forget(self, page_id: int, ref_id: int) -> WikiPage:
        with self.context.transaction() as con:
            if not con.execute(
                "delete from wiki_ref where id = ? and page_id = ?", (ref_id, page_id)
            ).rowcount:
                raise DaengsError("Fundstelle nicht gefunden")
        return self.page(page_id)


class GlobalWiki(_Pages):
    """The wiki for all projects (A-31): deleting a project leaves it alone, nothing in it points
    to a project. Same storage rules as a project, but it never reads any folder."""

    def __init__(self, folder: Path) -> None:
        folder.mkdir(parents=True, exist_ok=True)
        super().__init__(
            ProjectContext(ProjectId("gesamtwiki"), folder, (), DataZone.CUSTOMER_FREE)
        )
        with self.context.transaction() as con:
            version = con.execute("pragma user_version").fetchone()[0]
            if version > GLOBAL_WIKI_VERSION:
                raise DaengsError(
                    "Das Gesamt-Wiki stammt aus einer neueren Fassung. "
                    "Bitte aktualisiere das Programm."
                )
            con.execute(f"pragma user_version = {GLOBAL_WIKI_VERSION}")

    def pages(self) -> list[dict[str, Any]]:
        with self.context.transaction() as con:
            rows = con.execute("select id, title, updated from wiki_page order by title")
            return [{"id": i, "title": t, "updated": u} for i, t, u in rows]

    def same_title(self, title: str) -> dict[str, Any] | None:
        wanted = " ".join(title.split()).casefold()
        return next((p for p in self.pages() if p["title"].casefold() == wanted), None)

    def take_over(self, title: str, body: str) -> WikiPage:
        """Text the user has confirmed: a new page, or added to the page with the same title
        (whose earlier version stays restorable). Nothing about its origin is kept."""
        if not body.strip():
            raise DaengsError("Die Seite hat noch keinen Text")
        if len(body) > MAX_BODY:
            raise DaengsError("Text zu lang")
        self.context.log_event("gesamtwiki_uebernommen")
        existing = self.same_title(title)
        if existing is None:
            now = _now()
            with self.context.transaction() as con:
                page_id = con.execute(
                    "insert into wiki_page(title, body, created, updated) values (?, ?, ?, ?)",
                    (_title(title), body, now, now),
                ).lastrowid
            return self.page(page_id)
        page = self.page(existing["id"])
        joined = f"{page.body.rstrip()}\n\n{body}" if page.body.strip() else body
        return self.save(page.id, page.title, joined)
