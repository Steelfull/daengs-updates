"""What looks like customer content in a text going to the Gesamt-Wiki (M9d, A-31).

Only a hint for the user, who decides: it finds what can be told from the text and the delivery,
not everything. Nothing here writes; the text is compared with the project's own files and pages.
"""

import re
from collections import Counter
from pathlib import PurePath
from typing import Any

from daengs.core import ProjectContext
from daengs.core.language import COMMON_WORDS

MAX_ITEMS = 15
QUOTE_WORDS = 8  # this many words in a row, the same as in the delivery: taken over word for word
QUOTE_CHARS = 90

_FILE = re.compile(r"[\w.\-]+\.(?:pdf|docx?|xlsx?|pptx?|txt|csv|zip|dwg|stp|step)\b", re.IGNORECASE)
# Part numbers and codes: letters with digits (KP-200, A4711), digit groups (200/433), long numbers.
_CODE = re.compile(
    r"\b(?:(?=[\w/.\-]*\d)(?=[\w/.\-]*[^\W\d_])\w+(?:[/.\-]\w+)*"
    r"|\d+(?:[/\-]\d+)+"
    r"|\d{5,})\b"
)
_UNIT = r"(?:Nm|mm|cm|km|kg|mg|bar|kW|kWh|Hz|°C|%|min|ml|U/min|[mgVAWhsl])(?![^\W\d_])"
_NUMBER = re.compile(rf"(?<![\w.,])\d+(?:[.,]\d+)?(?:\s?{_UNIT})?")
_NAME = re.compile(r"\b[A-ZÄÖÜ]\w{3,}")
_TOKEN = re.compile(r"\w+")


def _group(label: str, items: list[str]) -> dict[str, Any]:
    return {"label": label, "items": items[:MAX_ITEMS], "more": max(0, len(items) - MAX_ITEMS)}


def _unique(items: list[str]) -> list[str]:
    return list(dict.fromkeys(items))


def _has_word(lower: str, name: str) -> bool:
    return re.search(rf"(?<!\w){re.escape(name.casefold())}(?!\w)", lower) is not None


def _file_names(text: str, paths: list[str]) -> list[str]:
    """File and folder names of the delivery in the text, and anything written like a file name."""
    found = _FILE.findall(text)
    lower = text.casefold()
    for rel_path in paths:
        path = PurePath(rel_path.replace("\\", "/"))
        for name in (path.stem, *path.parent.parts):
            if len(name) >= 4 and _has_word(lower, name):
                found.append(name)
    return _unique(found)


def _numbers(text: str) -> tuple[list[str], list[str]]:
    """Part numbers and codes, then other numbers; a lone small number (step 1) is not a hint."""
    codes = [m.group() for m in _CODE.finditer(text)]
    taken = [m.span() for m in _CODE.finditer(text)]
    numbers = []
    for match in _NUMBER.finditer(text):
        value = match.group()
        if any(start <= match.start() < end for start, end in taken):
            continue
        if len(value) >= 2:
            numbers.append(" ".join(value.split()))
    return _unique(codes), _unique(numbers)


def _scan_delivery(
    context: ProjectContext, words: set[str], tokens: list[str]
) -> tuple[Counter[str], list[str]]:
    """On how many pages each word stands, and the runs of the text found word for word."""
    grams = {tuple(tokens[i : i + QUOTE_WORDS]): i for i in range(len(tokens) - QUOTE_WORDS + 1)}
    starts = {gram[0] for gram in grams}
    counts: Counter[str] = Counter()
    hit = [False] * len(tokens)
    with context.transaction() as con:
        for (text,) in con.execute("select text from page"):
            page = _TOKEN.findall(text.replace("￾", "").casefold())
            counts.update(words.intersection(page))
            for i, token in enumerate(page):
                if (
                    token in starts
                    and (at := grams.get(tuple(page[i : i + QUOTE_WORDS]))) is not None
                ):
                    hit[at : at + QUOTE_WORDS] = [True] * QUOTE_WORDS
    runs, run = [], []
    for flag, token in zip([*hit, False], [*tokens, ""], strict=True):
        if flag:
            run.append(token)
        elif run:
            runs.append(" ".join(run)[:QUOTE_CHARS])
            run = []
    return counts, runs


def customer_hints(
    context: ProjectContext, name: str, title: str, body: str
) -> list[dict[str, Any]]:
    """Groups of what looks like customer content; only groups with a finding."""
    text = f"{title}\n{body}"
    with context.transaction() as con:
        paths = [row[0] for row in con.execute("select rel_path from file")]
    files = _file_names(text, paths)
    codes, numbers = _numbers(text)
    candidates: dict[str, str] = {}
    for word in _NAME.findall(text):
        if word.casefold() not in COMMON_WORDS:
            candidates.setdefault(word.casefold(), word)
    counts, quotes = _scan_delivery(context, set(candidates), _TOKEN.findall(text.casefold()))
    # Rare words first: the more special a word of the delivery, the likelier it is the customer's.
    delivery = [
        candidates[w] for w, _ in sorted(counts.items(), key=lambda item: (item[1], item[0]))
    ]
    shown = {item.casefold() for item in [*files, *codes]}
    names = [word for word in delivery if word.casefold() not in shown]
    lower = text.casefold()
    project = [name] if _has_word(lower, name) else []
    project += [w for w in _TOKEN.findall(name) if len(w) >= 4 and _has_word(lower, w)]
    groups = [
        ("Projektname", _unique(project)),
        ("Dateinamen", files),
        ("Teilenummern und Kennungen", codes),
        ("Zahlen", numbers),
        ("Wörter aus der Lieferung, seltene zuerst", names),
        ("Wörtlich aus der Lieferung", _unique(quotes)),
    ]
    return [_group(label, items) for label, items in groups if items]
