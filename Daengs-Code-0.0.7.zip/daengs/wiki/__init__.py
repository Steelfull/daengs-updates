"""Wiki: project pages with saved passages ("Fundstelle merken", F6) and the Gesamt-Wiki (M9d)."""

from daengs.wiki.hints import customer_hints
from daengs.wiki.wiki import GlobalWiki, Wiki, WikiPage, WikiRef

__all__ = ["GlobalWiki", "Wiki", "WikiPage", "WikiRef", "customer_hints"]
