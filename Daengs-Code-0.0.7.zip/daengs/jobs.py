"""One background worker for reading, with priorities (D-066).

Reading stays one task at a time (RAM, R-14). A task of a higher priority does not wait behind a
long one: the running task is told to stop after its current batch or page, goes back into the
queue and continues later. Tasks are only names here; what they do is up to the caller.
"""

import itertools
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field

QUEUED, RUNNING, DONE, FAILED = "wartet", "laeuft", "fertig", "fehler"

# Lower runs first: the first reading of a project, then reading of others, then the overview
# table (a few seconds to a minute, one search per cell), then OCR (minutes to hours).
FIRST, READ, TABLE, OCR = 0, 1, 2, 3


@dataclass(order=True)
class Task:
    priority: int
    seq: int
    key: str = field(compare=False)
    stage: str = field(compare=False)


# run(key, stage, stop) -> True when the task is done, False when it stopped early.
Runner = Callable[[str, str, threading.Event], bool]


class JobQueue:
    def __init__(self, run: Runner) -> None:
        self._run = run
        self._cond = threading.Condition()
        self._pending: list[Task] = []
        self._running: Task | None = None
        self._stop_running = threading.Event()
        self._results: dict[str, str] = {}
        self._seq = itertools.count()
        self._closed = False
        self._worker = threading.Thread(target=self._work, name="daengs-jobs", daemon=True)
        self._worker.start()

    # -- asking -----------------------------------------------------------------------------

    def add(self, key: str, stage: str, priority: int) -> None:
        """Queue a task unless the same one waits or runs already; a higher priority stops the
        running task after its current step."""
        with self._cond:
            if self._closed:
                return
            if self._running and (self._running.key, self._running.stage) == (key, stage):
                return
            for task in self._pending:
                if (task.key, task.stage) == (key, stage):
                    task.priority = min(task.priority, priority)
                    break
            else:
                self._pending.append(Task(priority, next(self._seq), key, stage))
            self._results.pop(key, None)
            if self._running is not None and priority < self._running.priority:
                self._stop_running.set()
            self._cond.notify_all()

    def state(self, key: str) -> str | None:
        with self._cond:
            if self._running is not None and self._running.key == key:
                return RUNNING
            if any(t.key == key for t in self._pending):
                return QUEUED
            return self._results.get(key)

    def has(self, key: str, stage: str) -> bool:
        """Whether this task waits or runs."""
        with self._cond:
            tasks = [*self._pending, *([self._running] if self._running else [])]
            return any((t.key, t.stage) == (key, stage) for t in tasks)

    def running(self) -> tuple[str, str] | None:
        with self._cond:
            return (self._running.key, self._running.stage) if self._running else None

    def busy(self) -> bool:
        with self._cond:
            return self._running is not None or bool(self._pending)

    def forget(self, key: str) -> None:
        with self._cond:
            self._results.pop(key, None)

    def wait_idle(self, timeout: float = 60) -> bool:
        deadline = time.monotonic() + timeout
        with self._cond:
            while self._running is not None or self._pending:
                left = deadline - time.monotonic()
                if left <= 0:
                    return False
                self._cond.wait(min(left, 0.05))
        return True

    def close(self, timeout: float = 10) -> None:
        with self._cond:
            self._closed = True
            self._pending.clear()
            self._stop_running.set()
            self._cond.notify_all()
        self._worker.join(timeout=timeout)

    @property
    def closed(self) -> bool:
        return self._closed

    # -- the worker -------------------------------------------------------------------------

    def _work(self) -> None:
        while True:
            with self._cond:
                while not self._pending and not self._closed:
                    self._cond.wait()
                if self._closed:
                    return
                task = min(self._pending)
                self._pending.remove(task)
                self._running = task
                self._stop_running.clear()
            try:
                finished = self._run(task.key, task.stage, self._stop_running)
                failed = False
            except Exception:  # the state tells the UI; details stay out of logs
                finished, failed = True, True
            with self._cond:
                self._running = None
                if failed:
                    self._pending = [t for t in self._pending if t.key != task.key]
                    self._results[task.key] = FAILED
                elif not finished and not self._closed:
                    # Stopped for a task of higher priority: back in line, at its old place.
                    self._pending.append(task)
                elif task.key not in self._results or self._results[task.key] != FAILED:
                    self._results[task.key] = DONE
                self._cond.notify_all()
