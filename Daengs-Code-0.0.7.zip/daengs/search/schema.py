"""Tables owned by the search module inside the project database.

Reads the ingest tables ``chunk(id, file_id, page_no, text)``, ``page`` and ``file`` by SQL only;
that table layout is the contract between the two modules.
"""

import contextlib
import sqlite3

_TABLES = """
create table if not exists search_meta(key text primary key, value text not null);
create table if not exists chunk_vector(
    chunk_id integer primary key references chunk(id) on delete cascade,
    title text not null,
    vec blob not null
);
"""

# Full text over the chunks: words (umlauts folded) and trigrams (compounds, part numbers).
_FTS = """
create virtual table if not exists fts_word using fts5(
    text, content='chunk', content_rowid='id', tokenize='unicode61 remove_diacritics 2'
);
create virtual table if not exists fts_tri using fts5(
    text, content='chunk', content_rowid='id', tokenize='trigram'
);
create trigger if not exists chunk_fts_insert after insert on chunk begin
    insert into fts_word(rowid, text) values (new.id, new.text);
    insert into fts_tri(rowid, text) values (new.id, new.text);
end;
create trigger if not exists chunk_fts_delete after delete on chunk begin
    insert into fts_word(fts_word, rowid, text) values ('delete', old.id, old.text);
    insert into fts_tri(fts_tri, rowid, text) values ('delete', old.id, old.text);
end;
"""
_REBUILD = """
insert into fts_word(fts_word) values ('rebuild');
insert into fts_tri(fts_tri) values ('rebuild');
"""


def ensure_schema(con: sqlite3.Connection) -> None:
    con.executescript(_TABLES)
    exists = con.execute("select 1 from sqlite_master where name = 'fts_word'").fetchone()
    # Idempotent: the UI's status request and the background job may open the index at the
    # same moment (found in M6); a second, concurrent creation is a no-op.
    con.executescript(_FTS)
    if not exists:
        # Created after ingest may already have filled chunks: the rebuild indexes them once.
        con.executescript(_REBUILD)
    # Hits read the place label of Word and Excel parts and the chunk language (M8); older
    # projects get the columns (a parallel open may have added them already).
    if "label" not in {row[1] for row in con.execute("pragma table_info(page)")}:
        with contextlib.suppress(sqlite3.OperationalError):
            con.execute("alter table page add column label text")
    if "lang" not in {row[1] for row in con.execute("pragma table_info(chunk)")}:
        with contextlib.suppress(sqlite3.OperationalError):
            con.execute("alter table chunk add column lang text")
    # Hyphenation marks in chunks of older projects split words for the word search (D-029).
    if con.execute("select 1 from chunk where instr(text, char(65534)) limit 1").fetchone():
        con.execute(
            "update chunk set text = replace(replace(text, char(65534) || ' ', ''),"
            " char(65534), '') where instr(text, char(65534))"
        )
        con.executescript(_REBUILD)
