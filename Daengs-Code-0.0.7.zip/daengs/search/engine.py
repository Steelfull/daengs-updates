"""Search over one project: embeddings as the base, full text for codes and numbers (F3)."""

import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from daengs.core import DaengsError, ProjectContext, SearchSettings, detect_language
from daengs.search.embedding import Embedder
from daengs.search.query import fts_query, identifiers, rrf, terms
from daengs.search.schema import ensure_schema

SNIPPET_CHARS = 240
_UPDATE_BATCH = 64


@dataclass(frozen=True)
class Hit:
    rank: int
    file_id: int
    folder: Path
    rel_path: str
    page_no: int
    title: str
    snippet: str
    # Best chunk of this page; the viewer marks its words on the page.
    chunk_id: int
    # Word and Excel (A-35): "Abschnitt ...", "Blatt ..., Zeilen ..." instead of a page number.
    place: str = ""
    kind: str = "pdf"
    # False: no safe sign of a match (D-040). Only a mark: the order stays, nothing is left out.
    sure: bool = True


@dataclass(frozen=True)
class IndexReport:
    embedded: int
    removed_model: bool
    seconds: float


@dataclass(frozen=True)
class Rankings:
    """Chunk IDs per method, best first; kept for evaluation and diagnosis."""

    dense: list[int]
    word: list[int]
    trigram: list[int]
    identifiers: list[str]
    # Similarity of every chunk with a vector to the question.
    similarity: dict[int, float] = field(default_factory=dict)


class SearchIndex:
    """Vectors and full text of one project. Every query stays inside this project's database."""

    def __init__(
        self,
        context: ProjectContext,
        settings: SearchSettings,
        embedder: Callable[[], Embedder],
    ) -> None:
        self.context = context
        self.settings = settings
        self._embedder_factory = embedder
        self._embedder: Embedder | None = None
        self._lock = threading.Lock()
        self._matrix: np.ndarray | None = None
        self._matrix_ids: np.ndarray | None = None
        self._matrix_token: tuple[str, int] | None = None
        with context.transaction() as con:
            if not con.execute("select 1 from sqlite_master where name = 'chunk'").fetchone():
                raise DaengsError("Projekt ist noch nicht eingelesen")
            ensure_schema(con)

    @property
    def embedder(self) -> Embedder:
        with self._lock:
            if self._embedder is None:
                self._embedder = self._embedder_factory()
            return self._embedder

    # -- index -------------------------------------------------------------------------------

    def update(self, stop: threading.Event | None = None) -> IndexReport:
        """Embed chunks without a vector or whose document title changed; committed per batch."""
        start = time.perf_counter()
        embedder = self.embedder
        removed = False
        with self.context.transaction() as con:
            stored = dict(con.execute("select key, value from search_meta"))
            if stored.get("model_id") != embedder.model_id:
                # Vectors of different models are not comparable (07 §5): recompute all.
                con.execute("delete from chunk_vector")
                con.execute(
                    "insert or replace into search_meta(key, value) values ('model_id', ?)",
                    (embedder.model_id,),
                )
                removed = bool(stored.get("model_id"))
            todo = con.execute(
                "select c.id, f.title, c.text from chunk c join file f on f.id = c.file_id"
                " left join chunk_vector v on v.chunk_id = c.id"
                " where v.chunk_id is null or v.title != f.title order by c.id"
            ).fetchall()
        done = 0
        for begin in range(0, len(todo), _UPDATE_BATCH):
            if stop is not None and stop.is_set():
                break
            batch = todo[begin : begin + _UPDATE_BATCH]
            # Same input as praxistest: document title, newline, chunk text.
            vectors = embedder.encode([f"{title}\n{text}" for _, title, text in batch])
            with self.context.transaction() as con:
                con.executemany(
                    "insert or replace into chunk_vector(chunk_id, title, vec)"
                    " select ?, ?, ? where exists(select 1 from chunk where id = ?)",
                    [
                        (cid, title, vec.astype("float32").tobytes(), cid)
                        for (cid, title, _), vec in zip(batch, vectors, strict=True)
                    ],
                )
                con.execute(
                    "insert into search_meta(key, value) values ('generation', '1')"
                    " on conflict(key) do update set value = cast(value as integer) + 1"
                )
            done += len(batch)
        report = IndexReport(done, removed, time.perf_counter() - start)
        if done:
            self.context.log_event("suchindex", abschnitte=done, sekunden=round(report.seconds, 1))
        return report

    def pending(self) -> int:
        with self.context.transaction() as con:
            (count,) = con.execute(
                "select count(*) from chunk c join file f on f.id = c.file_id"
                " left join chunk_vector v on v.chunk_id = c.id"
                " where v.chunk_id is null or v.title != f.title"
            ).fetchone()
        return count

    def pending_by_file(self) -> dict[tuple[str, str], int]:
        """Open chunks per file (folder, rel_path), in the order ``update`` embeds them; for the
        progress of reading (D-065). Reads only, changes nothing."""
        with self.context.transaction() as con:
            rows = con.execute(
                "select f.folder, f.rel_path, count(*), min(c.id) from chunk c"
                " join file f on f.id = c.file_id left join chunk_vector v on v.chunk_id = c.id"
                " where v.chunk_id is null or v.title != f.title"
                " group by c.file_id order by min(c.id)"
            ).fetchall()
        return {(folder, rel): count for folder, rel, count, _ in rows}

    # -- query -------------------------------------------------------------------------------

    def rankings(self, question: str) -> Rankings:
        words = terms(question)
        codes = identifiers(words)
        n = self.settings.candidates
        with self.context.transaction() as con:
            word = _bm25(con, "fts_word", words, n)
            trigram = _bm25(con, "fts_tri", [w for w in codes if len(w) >= 3], n)
        dense, similarity = self._dense(question, n)
        return Rankings(dense, word, trigram, codes, similarity)

    def fuse(self, r: Rankings) -> list[int]:
        """Embedding ranking as the base. Full text counts fully for codes, part numbers and
        abbreviations, where exact matching beats meaning; for plain questions with a small
        weight (D-029; 06 §3: equal weight pushed English documents out of German questions)."""
        k = self.settings.rrf_k
        if not r.identifiers:
            return rrf([(r.dense, 1.0), (r.word, self.settings.word_weight)], k)
        return rrf([(r.dense, 1.0), (rrf([(r.word, 1.0), (r.trigram, 1.0)], k), 1.0)], k)

    def search(self, question: str, limit: int = 10) -> list[Hit]:
        """Up to ``limit`` pages, best first; each page once, with a snippet of its best chunk."""
        if not question.strip():
            return []
        words = terms(question)
        ranked = self.rankings(question)
        chunk_ids = self.prefer_language(self.fuse(ranked), question)
        hits: list[Hit] = []
        seen: set[tuple[int, int]] = set()
        with self.context.transaction() as con:
            for cid in chunk_ids:
                row = con.execute(
                    "select c.file_id, c.page_no, c.text, f.folder, f.rel_path, f.title, p.label"
                    " from chunk c join file f on f.id = c.file_id"
                    " join page p on p.file_id = c.file_id and p.page_no = c.page_no"
                    " where c.id = ?",
                    (cid,),
                ).fetchone()
                if row is None:
                    continue  # removed since the vectors were loaded
                file_id, page_no, text, folder, rel_path, title, label = row
                if (file_id, page_no) in seen:
                    continue
                seen.add((file_id, page_no))
                hits.append(
                    Hit(
                        len(hits) + 1,
                        file_id,
                        Path(folder),
                        rel_path,
                        page_no,
                        title,
                        snippet(text, words),
                        cid,
                        label or "",
                        Path(rel_path).suffix.lower().lstrip(".") or "pdf",
                        self._is_sure(ranked, cid, text, words),
                    )
                )
                if len(hits) >= limit:
                    break
        return hits

    def _is_sure(self, ranked: Rankings, chunk_id: int, text: str, words: list[str]) -> bool:
        return ranked.similarity.get(chunk_id, 0.0) >= self.settings.sure_similarity or (
            has_all_words(text, words)
        )

    def sure_chunks(self, question: str, chunk_ids: list[int]) -> dict[int, bool]:
        """Same verdict as ``Hit.sure`` for given passages, for the answer (D-053): the answer
        service does not take the caller's word for it. Unknown IDs are left out."""
        if not chunk_ids or not question.strip():
            return {}
        words = terms(question)
        ranked = self.rankings(question)
        marks = ",".join("?" * len(chunk_ids))
        with self.context.transaction() as con:
            rows = con.execute(
                f"select id, text from chunk where id in ({marks})",  # noqa: S608 (only ? marks)
                list(chunk_ids),
            ).fetchall()
        return {cid: self._is_sure(ranked, cid, text, words) for cid, text in rows}

    def prefer_language(self, chunk_ids: list[int], question: str) -> list[int]:
        """Multilingual manuals (D-026): where a file has passages in the question's language,
        its passages in other languages move behind all others. Files in one language only
        (an English manual, asked in German) keep their place."""
        lang = detect_language(question, min_score=1) or self.settings.language
        if not lang or not chunk_ids:
            return chunk_ids
        with self.context.transaction() as con:
            self._fill_languages(con)
            files = {
                f
                for (f,) in con.execute(
                    "select distinct file_id from chunk where lang = ?", (lang,)
                )
            }
            if not files:
                return chunk_ids
            marks = ",".join("?" * len(chunk_ids))
            info = {
                cid: (fid, chunk_lang)
                for cid, fid, chunk_lang in con.execute(
                    f"select id, file_id, lang from chunk where id in ({marks})",  # noqa: S608 - only placeholders
                    chunk_ids,
                )
            }

        def other(cid: int) -> bool:
            fid, chunk_lang = info.get(cid, (None, ""))
            return fid in files and bool(chunk_lang) and chunk_lang != lang

        return [c for c in chunk_ids if not other(c)] + [c for c in chunk_ids if other(c)]

    def _fill_languages(self, con) -> None:
        """Older projects: chunk language filled, or redone after a change of the rule, once."""
        stored = con.execute("select value from search_meta where key = 'language_rule'").fetchone()
        if not stored or stored[0] != LANGUAGE_RULE:
            con.execute("update chunk set lang = null")
            con.execute(
                "insert or replace into search_meta(key, value) values ('language_rule', ?)",
                (LANGUAGE_RULE,),
            )
        rows = con.execute("select id, text from chunk where lang is null").fetchall()
        if rows:
            con.executemany(
                "update chunk set lang = ? where id = ?",
                [(detect_language(text.split(" · ", 1)[-1]), cid) for cid, text in rows],
            )

    def _dense(self, question: str, n: int) -> tuple[list[int], dict[int, float]]:
        matrix, ids = self._vectors()
        if matrix is None or not len(ids):
            return [], {}
        query = self.embedder.encode([question])[0]
        scores = matrix @ query
        n = min(n, len(ids))
        best = np.argpartition(-scores, n - 1)[:n]
        best = best[np.lexsort((ids[best], -scores[best]))]
        return [int(i) for i in ids[best]], dict(zip(ids.tolist(), scores.tolist(), strict=True))

    def _vectors(self) -> tuple[np.ndarray | None, np.ndarray]:
        with self.context.transaction() as con:
            generation = dict(con.execute("select key, value from search_meta")).get(
                "generation", "0"
            )
            (count,) = con.execute("select count(*) from chunk_vector").fetchone()
            token = (generation, count)
            with self._lock:
                if token == self._matrix_token:
                    return self._matrix, self._matrix_ids
            rows = con.execute(
                "select chunk_id, vec from chunk_vector order by chunk_id"
            ).fetchall()
        dim = self.embedder.dim
        ids = np.array([cid for cid, _ in rows], dtype="int64")
        matrix = np.frombuffer(b"".join(vec for _, vec in rows), dtype="float32").reshape(-1, dim)
        with self._lock:
            self._matrix, self._matrix_ids, self._matrix_token = matrix, ids, token
        return matrix, ids


# Raise when detect_language changes: projects then get their chunk languages again.
LANGUAGE_RULE = "2"


def _bm25(con, table: str, words: list[str], n: int) -> list[int]:
    if not words:
        return []
    sql = {
        "fts_word": "select rowid from fts_word where fts_word match ?"
        " order by bm25(fts_word) limit ?",
        "fts_tri": "select rowid from fts_tri where fts_tri match ? order by bm25(fts_tri) limit ?",
    }[table]
    return [row[0] for row in con.execute(sql, (fts_query(words), n))]


def _flat(text: str) -> str:
    # PDFium marks hyphenation points with U+FFFE; soft hyphens are invisible in the PDF too.
    return " ".join(text.replace("\ufffe", "").replace("\u00ad", "").split())


def has_all_words(text: str, words: list[str]) -> bool:
    """Every word of the question stands in the passage, also inside a longer word."""
    lower = _flat(text).lower()
    return bool(words) and all(w.lower() in lower for w in words)


def snippet(text: str, words: list[str], size: int = SNIPPET_CHARS) -> str:
    """Window of ``size`` characters around the first query term found, else the beginning."""
    flat = _flat(text)
    lower = flat.lower()
    positions = [p for w in words if (p := lower.find(w.lower())) >= 0]
    if not positions or len(flat) <= size:
        return flat[:size]
    begin = max(0, min(positions) - size // 3)
    begin = flat.rfind(" ", 0, begin) + 1 if begin else 0
    return ("… " if begin else "") + flat[begin : begin + size].rstrip() + " …"
