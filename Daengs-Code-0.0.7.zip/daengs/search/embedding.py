"""Text embeddings without PyTorch: tokenizer, ONNX Runtime, CLS pooling, normalization (D-013)."""

from typing import Protocol

import numpy as np

from daengs.core import DaengsError, EmbeddingModel


class Embedder(Protocol):
    model_id: str
    dim: int

    def encode(self, texts: list[str]) -> np.ndarray:
        """Unit-length float32 vectors, one row per text."""
        ...


class OnnxEmbedder:
    """Granite-Embedding over ONNX Runtime; same vectors as sentence-transformers (08)."""

    def __init__(self, model: EmbeddingModel, threads: int, batch: int = 16) -> None:
        missing = [p.name for p in model.files() if not p.is_file()]
        if missing:
            raise DaengsError(f"Modelldateien für die Einbettung fehlen: {missing}")
        import onnxruntime as ort
        from tokenizers import Tokenizer

        self.model_id = model.model_id
        self.dim = model.dim
        self._batch = batch
        # Tokenizer.from_file reads the local file only; nothing goes through huggingface_hub.
        self._tokenizer = Tokenizer.from_file(str(model.tokenizer))
        self._tokenizer.enable_truncation(model.max_tokens)
        pad = self._tokenizer.token_to_id("<pad>")
        self._tokenizer.enable_padding(pad_id=0 if pad is None else pad, pad_token="<pad>")  # noqa: S106
        options = ort.SessionOptions()
        options.intra_op_num_threads = threads
        options.inter_op_num_threads = 1
        self._session = ort.InferenceSession(
            str(model.onnx), options, providers=["CPUExecutionProvider"]
        )

    def encode(self, texts: list[str]) -> np.ndarray:
        result = np.zeros((len(texts), self.dim), dtype="float32")
        # Sorted by length, so a batch carries little padding; the order is restored on write.
        order = sorted(range(len(texts)), key=lambda i: len(texts[i]))
        for start in range(0, len(texts), self._batch):
            idx = order[start : start + self._batch]
            encoded = self._tokenizer.encode_batch([texts[i] for i in idx])
            ids = np.array([e.ids for e in encoded], dtype="int64")
            mask = np.array([e.attention_mask for e in encoded], dtype="int64")
            state = self._session.run(None, {"input_ids": ids, "attention_mask": mask})[0]
            cls = state[:, 0, :]
            result[idx] = cls / np.linalg.norm(cls, axis=1, keepdims=True)
        return result
