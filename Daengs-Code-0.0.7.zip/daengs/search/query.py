"""Query terms for the full-text search and the fusion rule (07 §3, 06 §3)."""

import re
from collections import defaultdict
from collections.abc import Iterable

# Question words and filler without search meaning (praxistest/skripte/auswertung_suche.py).
STOPWORDS = frozenset(
    """
der die das den dem des ein eine einer eines einem einen und oder aber wenn weil dass ob wie was
wer wo wann warum welche welcher welches welchem welchen woran wofür womit wieviel viel viele muss
müssen kann können darf dürfen soll sollen ist sind war wird werden wurde hat haben habe gibt es
ich man mir mich mein meine sie er wir ihr bei beim mit von vom zu zum zur im in an am auf aus für
über unter nach vor bis um als auch noch nicht nur so da dann denn doch schon sehr mehr höchstens
mindestens dabei damit dazu hier dort ab gegen ohne lange oft wieder bekomme herunter liegen sein
steht stehen zwischen direkt angebaut ins ans aufs ums fürs übers durchs
""".split()
)

_WORD = re.compile(r"[\wäöüÄÖÜß][\wäöüÄÖÜß.\-]*")


def terms(question: str) -> list[str]:
    """Words of the question without stopwords and one-letter tokens."""
    result = []
    for word in _WORD.findall(question):
        word = word.strip(".-")
        if len(word) >= 2 and word.lower() not in STOPWORDS:
            result.append(word)
    return result


def identifiers(words: Iterable[str]) -> list[str]:
    """Terms that look like codes, part numbers, sizes or abbreviations: anything with a digit,
    or written in capitals (``DR``, ``ATEX``). Plain words are left to the embedding search."""
    return [w for w in words if any(c.isdigit() for c in w) or (len(w) >= 2 and w.isupper())]


def fts_query(words: Iterable[str]) -> str:
    """FTS5 OR query with every term quoted, so no user input is read as FTS syntax."""
    return " OR ".join('"' + w.replace('"', "") + '"' for w in words)


def rrf(rankings: Iterable[tuple[list[int], float]], k: int) -> list[int]:
    """Weighted reciprocal rank fusion over (ranking, weight) pairs; stable for equal scores."""
    scores: dict[int, float] = defaultdict(float)
    first_seen: dict[int, int] = {}
    for ranking, weight in rankings:
        for rank, item in enumerate(ranking):
            scores[item] += weight / (k + rank + 1)
            first_seen.setdefault(item, len(first_seen))
    return sorted(scores, key=lambda item: (-scores[item], first_seen[item]))
