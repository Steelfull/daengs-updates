"""Answer with sources (F10): search, numbered sources, model, checks, chat history per project.

Reads the ingest tables chunk/file by SQL (contract, see daengs.search.schema); the chat history
lives in the project's own database and is deleted with the project (A-30).
"""

import dataclasses
import json
import re
import threading
import time
from collections.abc import Callable, Iterator, Mapping
from typing import Any, Protocol

from daengs.answer import prompt, suggestion
from daengs.answer.check import check
from daengs.answer.excerpt import excerpt, missing_terms, names_a_subject
from daengs.core import DaengsError, ProjectContext

LABEL = "KI-Entwurf – bitte anhand der Quellen prüfen"
MAX_QUESTION = 2000
SearchFn = Callable[[str, int], list[Mapping[str, Any]]]
# Verdict "sure" for given passages (D-053); the answer never reads search code itself.
AssessFn = Callable[[str, list[int]], Mapping[int, bool]]
CHAT_TITLE_CHARS = 60
SNIPPET_WORDS = 40  # words of the place shown for a passage given by ID (D-055)
EXCERPT_WORDS = 60  # words per source for the model (D-028, see LlmModel.sources)
# M9c (Stufe 1, 12_Konzept_M9 §7): one more search when the model finds nothing in the passages.
# Offering it as a tool did not work: with passages in front of it the small model never asked
# (praxistest/ergebnisse/m9c_werkzeug_versuch_*.md, 0 of 39), and its text cost 1.7 s per answer.
MAX_EXTRA_SEARCHES = 1
NEW_SOURCES = 2
NEW_LOOKAHEAD = 6  # hits to look through for sources not seen yet
MAX_QUERY = 200
_NOTHING = re.compile(
    r"nichts|keine angabe|nicht genannt|nicht enthalten|nicht beschrieben|nicht angegeben",
    re.IGNORECASE,
)
FOLLOW_UP_WORDS = (
    6  # a question this short is read together with the one before ("Und bei KV-510?")
)

# Several chats per project (D-025, A-36): every message belongs to one chat. Until the sidebar
# of M8 exists, the UI uses the first chat; older databases (one history) are moved into it.
_SCHEMA = """
create table if not exists chat(
    id integer primary key autoincrement,
    title text not null,
    created text not null
);
create table if not exists chat_message(
    id integer primary key autoincrement,
    chat_id integer references chat(id) on delete cascade,
    question text not null,
    answer text not null,
    payload text not null,
    created text not null
);
"""
DEFAULT_CHAT = "Chat 1"


def _title(title: str) -> str:
    return " ".join(title.split())[:200]


def _chat_title(question: str) -> str:
    """The first question as the name of its history, cut at a word."""
    text = " ".join(question.split())
    if len(text) <= CHAT_TITLE_CHARS:
        return text
    return text[:CHAT_TITLE_CHARS].rsplit(" ", 1)[0].rstrip(",;:") + " …"


def _renumber(sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{**s, "n": n} for n, s in enumerate(sources, start=1)]


def _says_nothing(answer: str) -> bool:
    return bool(_NOTHING.search(answer))


class Model(Protocol):
    model: Any

    def chat(self, messages: list[dict[str, str]], max_tokens: int) -> tuple[str, dict]: ...

    # Optional (M9a): chat_stream(messages, max_tokens) -> iterator of progress/delta/timings
    # dictionaries, and cancel(). Models without them answer in one piece.


class Answerer:
    def __init__(
        self,
        context: ProjectContext,
        search: SearchFn,
        model: Model,
        assess: AssessFn | None = None,
    ) -> None:
        self.context = context
        self._search = search
        self._model = model
        self._assess = assess
        with context.transaction() as con:
            if not con.execute("select 1 from sqlite_master where name = 'chunk'").fetchone():
                raise DaengsError("Projekt ist noch nicht eingelesen")
            con.executescript(_SCHEMA)
            columns = {row[1] for row in con.execute("pragma table_info(chat_message)")}
            for name, kind in (("rating", "integer"), ("rating_note", "text")):  # M9a
                if name not in columns:
                    con.execute(f"alter table chat_message add column {name} {kind}")
            if "chat_id" not in columns:  # database from before D-025
                con.execute(
                    "alter table chat_message add column chat_id integer references chat(id)"
                    " on delete cascade"
                )
            con.execute("create index if not exists chat_message_chat on chat_message(chat_id)")

    def chats(self) -> list[dict[str, Any]]:
        # Answers from before D-025 have no chat yet; they move into the first one. A project
        # without any answer has no history (D-055): it is made with the first answer.
        with self.context.transaction() as con:
            orphans = con.execute("select 1 from chat_message where chat_id is null").fetchone()
        if orphans:
            self.default_chat()
        with self.context.transaction() as con:
            rows = con.execute(
                "select c.id, c.title, c.created, count(m.id) from chat c"
                " left join chat_message m on m.chat_id = c.id group by c.id order by c.id"
            ).fetchall()
        return [{"id": i, "title": t, "created": c, "messages": n} for i, t, c, n in rows]

    def create_chat(self, title: str = "") -> int:
        with self.context.transaction() as con:
            count = con.execute("select count(*) from chat").fetchone()[0]
            title = _title(title) or (f"Chat {count + 1}" if count else DEFAULT_CHAT)
            return con.execute(
                "insert into chat(title, created) values (?, ?)",
                (title, time.strftime("%Y-%m-%dT%H:%M:%S%z")),
            ).lastrowid

    def rename_chat(self, chat_id: int, title: str) -> dict[str, Any]:
        title = _title(title)
        if not title:
            raise DaengsError("Name des Chats fehlt")
        self._chat(chat_id)
        with self.context.transaction() as con:
            con.execute("update chat set title = ? where id = ?", (title, chat_id))
        return {"id": chat_id, "title": title}

    def delete_chat(self, chat_id: int) -> int:
        """Removes the chat with all its answers; the last chat is replaced by an empty one."""
        self._chat(chat_id)
        with self.context.transaction() as con:
            removed = con.execute("delete from chat_message where chat_id = ?", (chat_id,)).rowcount
            con.execute("delete from chat where id = ?", (chat_id,))
        self.context.log_event("chat_geloescht", eintraege=removed)
        return removed

    def default_chat(self) -> int:
        """The first chat of the project; created on first use, older messages moved into it."""
        with self.context.transaction() as con:
            row = con.execute("select id from chat order by id limit 1").fetchone()
        chat_id = row[0] if row else self.create_chat()
        with self.context.transaction() as con:
            con.execute("update chat_message set chat_id = ? where chat_id is null", (chat_id,))
        return chat_id

    def _chat(self, chat_id: int | None) -> int:
        if chat_id is None:
            return self.default_chat()
        with self.context.transaction() as con:
            if not con.execute("select 1 from chat where id = ?", (chat_id,)).fetchone():
                raise DaengsError("Chat nicht gefunden")
        return chat_id

    def answer(
        self, question: str, chat_id: int | None = None, chunk_ids: list[int] | None = None
    ) -> dict[str, Any]:
        """The whole answer at once (M7 interface); built from the same steps as the stream."""
        for event in self.answer_events(question, chat_id, chunk_ids=chunk_ids):
            if event["type"] == "done":
                return event["entry"]
            if event["type"] == "error":
                raise DaengsError(event["fehler"])
        raise DaengsError("Keine Antwort")

    def answer_events(
        self,
        question: str,
        chat_id: int | None = None,
        stop: threading.Event | None = None,
        chunk_ids: list[int] | None = None,
    ) -> Iterator[dict[str, Any]]:
        """The answer as it comes about (M9a, A-38): search, sources, reading progress, text,
        check, done. ``stop`` ends it early; the part written so far is stored as stopped.

        With ``chunk_ids`` (D-055) the answer summarizes exactly these passages of the hit list
        and does not search; without ``chat_id`` it starts a new history, created when the
        answer is stored. Without them (follow-up) it searches. Passages that are not sure never
        go to the model (D-053): if none is sure, there is no draft, only the hint and the places.
        """
        question = " ".join(question.split())
        if not question or len(question) > MAX_QUESTION:
            raise DaengsError("Frage fehlt oder ist zu lang")
        stop = stop or threading.Event()
        settings = self._model.model
        new_chat = chunk_ids is not None and chat_id is None
        chat_id = None if new_chat else self._chat(chat_id)
        previous = None if new_chat else self._previous(chat_id)
        query = question
        if previous and len(question.split()) <= FOLLOW_UP_WORDS and not names_a_subject(question):
            # "Und wie oft?" is read together with the question before; a follow-up with a subject
            # of its own ("Und der Hydraulikdruck?") is judged by itself (AP-9.22, D-053).
            query = f"{question} {previous[0]}"
        times: dict[str, float] = {}
        start = time.perf_counter()
        yield {"type": "step", "step": "suche" if chunk_ids is None else "stellen"}
        if chunk_ids is None:
            found = self._search_sources(query, settings.sources + NEW_LOOKAHEAD)
        else:
            found = self._passages(question, chunk_ids)
        sources = _renumber([s for s in found if s["sure"]][: settings.sources])
        no_sure = not sources and bool(found)
        if no_sure:
            sources = _renumber(found[: settings.sources])  # shown, never read by the model
        times["suche"] = round(time.perf_counter() - start, 1)
        public = [{k: v for k, v in s.items() if k != "text"} for s in sources]
        texts = [s["text"] for s in sources]
        missing = missing_terms(question, texts)
        yield {
            "type": "sources",
            "sources": public,
            "seconds": times["suche"],
            "missing_terms": missing,
        }
        pieces: list[str] = []
        timings: dict[str, Any] = {}
        stopped = False
        searches: list[str] = []
        if no_sure:
            pieces.append(prompt.NO_SURE)  # no draft: the passages are shown, not summarized
        elif not sources:
            pieces.append(prompt.NOTHING)
        else:
            messages = prompt.messages(question, texts, previous)
            try:
                for attempt in range(MAX_EXTRA_SEARCHES + 1):
                    yield {"type": "step", "step": "lesen"}
                    for event in self._stream(messages, settings.max_tokens):
                        if stop.is_set():
                            stopped = True
                            break
                        if "progress" in event:
                            done, total = event["progress"]
                            yield {"type": "progress", "done": done, "total": total}
                        elif "delta" in event:
                            if not pieces:
                                times["lesen"] = round(
                                    time.perf_counter() - start - times["suche"], 1
                                )
                                yield {"type": "step", "step": "schreiben"}
                            pieces.append(event["delta"])
                            yield {"type": "delta", "text": event["delta"]}
                        elif "timings" in event:
                            timings = event["timings"]
                    stopped = stopped or stop.is_set()
                    # Nothing found in the passages? Once more with other words (M9c): the
                    # program decides, the model only rephrases. Others pay nothing for this.
                    if (
                        stopped
                        or attempt == MAX_EXTRA_SEARCHES
                        or not _says_nothing("".join(pieces))
                    ):
                        break
                    began = time.perf_counter()
                    yield {"type": "step", "step": "suche", "query": ""}
                    wanted = self._rephrase(question)
                    yield {"type": "step", "step": "suche", "query": wanted}
                    searches.append(wanted)
                    new = self._more(f"{question} {wanted}", sources)
                    times["suche"] = round(times["suche"] + time.perf_counter() - began, 1)
                    sources += new
                    missing = missing_terms(question, [s["text"] for s in sources])
                    yield {
                        "type": "sources",
                        "sources": [{k: v for k, v in s.items() if k != "text"} for s in sources],
                        "new": len(new),
                        "missing_terms": missing,
                    }
                    if not new:  # the first answer stands
                        break
                    pieces.clear()
                    times.pop("lesen", None)
                    yield {"type": "reset"}
                    messages = prompt.messages(question, [s["text"] for s in sources], previous)
            except GeneratorExit:  # the window went away: stop the model, keep what was written
                self._cancel()
                self._finish(
                    question,
                    chat_id,
                    sources,
                    pieces,
                    timings,
                    times,
                    start,
                    True,
                    missing,
                    searches,
                    no_sure,
                    chunk_ids is not None,
                )
                raise
            if stopped:
                self._cancel()
        times.setdefault("lesen", round(time.perf_counter() - start - times["suche"], 1))
        if not no_sure:
            yield {"type": "step", "step": "pruefen"}
        entry = self._finish(
            question, chat_id, sources, pieces, timings, times, start, stopped, missing, searches,
            no_sure, chunk_ids is not None,
        )  # fmt: skip
        yield {"type": "done", "entry": entry}

    def _rephrase(self, question: str) -> str:
        """Other words for the question, from the model; short call without any sources."""
        text, _ = self._model.chat(
            [
                {"role": "system", "content": prompt.REWRITE},
                {"role": "user", "content": f"Frage: {question}"},
            ],
            30,
        )
        lines = (text or "").strip().splitlines()
        return " ".join(lines[0].split()).strip("\"'„“”")[:MAX_QUERY] if lines else ""

    def _more(self, query: str, sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Hits of a further search that are not among the sources yet, numbered on."""
        known = {s["chunk_id"] for s in sources}
        new = []
        for hit in self._search_sources(query, self._model.model.sources + NEW_LOOKAHEAD):
            if not hit["sure"] or hit["chunk_id"] in known:
                continue
            known.add(hit["chunk_id"])
            new.append({**hit, "n": len(sources) + len(new) + 1})
            if len(new) >= NEW_SOURCES:
                break
        return new

    def _stream(self, messages: list[dict[str, str]], max_tokens: int) -> Iterator[dict[str, Any]]:
        stream = getattr(self._model, "chat_stream", None)
        if stream is not None:
            yield from stream(messages, max_tokens)
            return
        text, timings = self._model.chat(messages, max_tokens)
        yield {"delta": text}
        yield {"timings": timings}

    def _cancel(self) -> None:
        cancel = getattr(self._model, "cancel", None)
        if cancel is not None:
            cancel()

    def _finish(
        self, question, chat_id, sources, pieces, timings, times, start, stopped, missing,
        searches, no_sure=False, from_hits=False,
    ):  # fmt: skip
        settings = self._model.model
        if chat_id is None:  # the first answer of a new history (D-055)
            chat_id = self.create_chat(_chat_title(question))
        text = "".join(pieces).strip()
        checked = check(text, [s["text"] for s in sources])
        total = time.perf_counter() - start
        times["schreiben"] = round(total - times.get("suche", 0) - times.get("lesen", 0), 1)
        result = {
            "question": question,
            "answer": text,
            "label": LABEL,
            "model_id": settings.model_id,
            "sentences": [dataclasses.asdict(s) for s in checked.sentences],
            "checks": {
                "unbelegte_zahlen": checked.unverified_numbers,
                "saetze_ohne_beleg": checked.uncited,
                "ungueltige_belege": checked.invalid_citations,
            },
            "sources": [{k: v for k, v in s.items() if k != "text"} for s in sources],
            "seconds": round(total, 1),
            "steps": times,
            "tokens": timings.get("predicted_n"),
            "stopped": stopped,
            "missing_terms": missing,
            "searches": searches,
            "chat_id": chat_id,
            "no_sure": no_sure,
        }
        result["no_sure"] = no_sure
        if from_hits:
            result["from_hits"] = True  # the passages came from the hit list, no search was made
        result["id"] = self._store(result)
        self.context.log_event(
            "antwort", sekunden=result["seconds"], quellen=len(sources),
            unbelegte_zahlen=checked.unverified_numbers, abgebrochen=int(stopped),
        )  # fmt: skip
        return result

    def message(self, chat_id: int, message_id: int) -> dict[str, Any]:
        for entry in self.history(chat_id):
            if entry["id"] == message_id:
                return entry
        raise DaengsError("Antwort nicht gefunden")

    def title_for(self, question: str) -> str:
        """A short page title for a wiki suggestion (M9b), written by the model."""
        try:
            text, _ = self._model.chat(
                [
                    {"role": "system", "content": prompt.TITLE},
                    {"role": "user", "content": f"Frage: {question}"},
                ],
                24,
            )
        except DaengsError:
            text = ""
        return suggestion.clean_title(text, question)

    def _previous(self, chat_id: int) -> tuple[str, str] | None:
        with self.context.transaction() as con:
            row = con.execute(
                "select question, answer from chat_message where chat_id = ?"
                " order by id desc limit 1",
                (chat_id,),
            ).fetchone()
        return (row[0], row[1]) if row else None

    def rate(self, chat_id: int, message_id: int, value: int, note: str = "") -> dict[str, Any]:
        """Thumbs up or down (D-028): stays in the project, a source for new gold questions."""
        if value not in (-1, 0, 1):
            raise DaengsError("Bewertung ungültig")
        self._chat(chat_id)
        with self.context.transaction() as con:
            updated = con.execute(
                "update chat_message set rating = ?, rating_note = ? where id = ? and chat_id = ?",
                (value or None, " ".join(note.split())[:500] or None, message_id, chat_id),
            ).rowcount
        if not updated:
            raise DaengsError("Antwort nicht gefunden")
        self.context.log_event("bewertung", wert=value)
        return {"id": message_id, "rating": value or None}

    def _search_sources(self, question: str, count: int) -> list[dict[str, Any]]:
        """Hits of a search with their passages, ``sure`` taken from the hit itself (D-049)."""
        hits = self._search(question, count)
        sources = []
        with self.context.transaction() as con:
            for hit in hits:
                row = con.execute(
                    "select text from chunk where id = ?", (hit["chunk_id"],)
                ).fetchone()
                if row is None:
                    continue
                sources.append(
                    {
                        "n": len(sources) + 1,
                        "file_id": hit["file_id"],
                        "rel_path": hit["rel_path"],
                        "page_no": hit["page_no"],
                        "place": hit.get("place", ""),
                        "chunk_id": hit["chunk_id"],
                        "snippet": hit["snippet"],
                        "sure": bool(hit.get("sure", True)),
                        # Only the sentences around the question words go to the model (D-028).
                        "text": excerpt(row[0], question, EXCERPT_WORDS),
                    }
                )
        return sources

    def _passages(self, question: str, chunk_ids: list[int]) -> list[dict[str, Any]]:
        """Exactly these passages of this project in the given order (D-055); IDs that are not
        in its database are ignored. Whether a passage is sure is asked anew (D-053)."""
        ids = list(dict.fromkeys(chunk_ids))
        rows = {}
        with self.context.transaction() as con:
            for cid in ids:
                row = con.execute(
                    "select c.file_id, c.page_no, c.text, f.rel_path, p.label from chunk c"
                    " join file f on f.id = c.file_id"
                    " join page p on p.file_id = c.file_id and p.page_no = c.page_no"
                    " where c.id = ?",
                    (cid,),
                ).fetchone()
                if row is not None:
                    rows[cid] = row
        verdict = self._assess(question, list(rows)) if self._assess else {}
        sources = []
        for cid, (file_id, page_no, text, rel_path, label) in rows.items():
            sources.append(
                {
                    "n": len(sources) + 1,
                    "file_id": file_id,
                    "rel_path": rel_path,
                    "page_no": page_no,
                    "place": label or "",
                    "chunk_id": cid,
                    "snippet": excerpt(text, question, SNIPPET_WORDS),
                    "sure": bool(verdict.get(cid, False)),  # unknown to the check: not sure
                    "text": excerpt(text, question, EXCERPT_WORDS),
                }
            )
        return sources

    def _store(self, result: dict[str, Any]) -> int:
        with self.context.transaction() as con:
            return con.execute(
                "insert into chat_message(chat_id, question, answer, payload, created)"
                " values (?, ?, ?, ?, ?)",
                (
                    result["chat_id"],
                    result["question"],
                    result["answer"],
                    json.dumps(result, ensure_ascii=False),
                    time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                ),
            ).lastrowid

    def history(self, chat_id: int | None = None) -> list[dict[str, Any]]:
        chat_id = self._chat(chat_id)
        with self.context.transaction() as con:
            rows = con.execute(
                "select id, payload, created, rating, rating_note from chat_message"
                " where chat_id = ? order by id",
                (chat_id,),
            ).fetchall()
        return [
            {**json.loads(p), "id": i, "created": c, "rating": r, "rating_note": n}
            for i, p, c, r, n in rows
        ]

    def clear(self, chat_id: int | None = None) -> int:
        chat_id = self._chat(chat_id)
        with self.context.transaction() as con:
            removed = con.execute("delete from chat_message where chat_id = ?", (chat_id,)).rowcount
        self.context.log_event("chatverlauf_geloescht", eintraege=removed)
        return removed
