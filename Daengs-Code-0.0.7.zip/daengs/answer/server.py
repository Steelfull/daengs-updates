"""llama.cpp llama-server as a local child process (F10, 07 §7, D-022).

Hardening: only 127.0.0.1, random port, API key via environment (not visible in the command
line), no web UI, no MCP proxy, no tools, no slots endpoint, offline mode, no output logged.
Started on the first question, stopped after an idle time (RAM, R-14), and bound to a Windows job
object so it ends together with Daengs even after a crash.
"""

import contextlib
import ctypes
import http.client
import json
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
from collections.abc import Iterator
from typing import Any

from daengs.core import DaengsError, LlmModel

LOOPBACK = "127.0.0.1"
START_TIMEOUT = 240
REQUEST_TIMEOUT = 900


def _events(response) -> Iterator[dict[str, Any]]:
    """Server-sent events of llama-server's OpenAI endpoint, as small dictionaries."""
    timings: dict[str, Any] = {}
    for raw in response:
        line = raw.decode("utf-8", errors="replace").strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            break
        event = json.loads(data)
        if "prompt_progress" in event:
            progress = event["prompt_progress"]
            yield {"progress": (progress.get("processed", 0), progress.get("total", 0))}
            continue
        timings = event.get("timings") or timings
        for choice in event.get("choices") or []:
            text = (choice.get("delta") or {}).get("content")
            if text:
                yield {"delta": text}
    yield {"timings": timings}


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind((LOOPBACK, 0))
        return probe.getsockname()[1]


class _KillOnClose:
    """Windows job object: every process assigned to it dies when Daengs's handle closes."""

    def __init__(self) -> None:
        self.handle = None
        if sys.platform != "win32":
            return

        class Limits(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", ctypes.c_int64),
                ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", ctypes.c_uint32),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", ctypes.c_uint32),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", ctypes.c_uint32),
                ("SchedulingClass", ctypes.c_uint32),
            ]

        class IoCounters(ctypes.Structure):
            _fields_ = [
                (name, ctypes.c_uint64)
                for name in (
                    "ReadOperationCount",
                    "WriteOperationCount",
                    "OtherOperationCount",
                    "ReadTransferCount",
                    "WriteTransferCount",
                    "OtherTransferCount",
                )
            ]

        class ExtendedLimits(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", Limits),
                ("IoInfo", IoCounters),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]

        kernel32 = ctypes.windll.kernel32
        kernel32.CreateJobObjectW.restype = ctypes.c_void_p
        handle = kernel32.CreateJobObjectW(None, None)
        info = ExtendedLimits()
        info.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        extended_limit_information = 9
        kernel32.SetInformationJobObject(
            ctypes.c_void_p(handle),
            extended_limit_information,
            ctypes.byref(info),
            ctypes.sizeof(info),
        )
        self.handle = handle

    def assign(self, process: subprocess.Popen) -> None:
        if self.handle is not None:
            ctypes.windll.kernel32.AssignProcessToJobObject(
                ctypes.c_void_p(self.handle), ctypes.c_void_p(int(process._handle))
            )


def peak_working_set(process: subprocess.Popen) -> int | None:
    """Peak working set of a running child in bytes (Windows' own counter, as in 08)."""
    if sys.platform != "win32" or process.poll() is not None:
        return None

    class Counters(ctypes.Structure):
        _fields_ = [("cb", ctypes.c_uint32), ("PageFaultCount", ctypes.c_uint32)] + [
            (name, ctypes.c_size_t)
            for name in (
                "PeakWorkingSetSize",
                "WorkingSetSize",
                "QuotaPeakPagedPoolUsage",
                "QuotaPagedPoolUsage",
                "QuotaPeakNonPagedPoolUsage",
                "QuotaNonPagedPoolUsage",
                "PagefileUsage",
                "PeakPagefileUsage",
            )
        ]

    counters = Counters(cb=ctypes.sizeof(Counters))
    ok = ctypes.windll.psapi.GetProcessMemoryInfo(
        ctypes.c_void_p(int(process._handle)), ctypes.byref(counters), ctypes.sizeof(counters)
    )
    return counters.PeakWorkingSetSize if ok else None


class LlamaServer:
    """One llama-server for the whole program; questions are answered one after another."""

    WATCH_INTERVAL = 5.0

    def __init__(self, model: LlmModel) -> None:
        missing = [p.name for p in model.files() if not p.is_file()]
        if missing:
            raise DaengsError(f"Dateien des Sprachmodells fehlen: {missing}")
        self.model = model
        self._lock = threading.RLock()
        self._current: socket.socket | None = None
        self._cancelled = False
        self._process: subprocess.Popen | None = None
        self._port = 0
        self._key = ""
        self._last_used = 0.0
        self._busy = False
        self._job = _KillOnClose()
        self._stop = threading.Event()
        self._watch = threading.Thread(target=self._idle_watch, name="daengs-llm-idle", daemon=True)
        self._watch.start()

    @property
    def running(self) -> bool:
        return self._process is not None and self._process.poll() is None

    def command(self, port: int) -> list[str]:
        m = self.model
        cpu = m.device == "none"
        return [
            str(m.server), "-m", str(m.model), "-c", str(m.context), "-t", str(m.threads),
            "-dev", m.device, "-ngl", "0" if cpu else "99", "-np", "1",
            "-fa", "on", "-ctk", "q8_0", "-ctv", "q8_0",
            "--chat-template-kwargs", '{"enable_thinking": false}',
            "--host", LOOPBACK, "--port", str(port),
            "--no-webui", "--no-webui-mcp-proxy", "--no-slots", "--offline",
            # No prompt states kept in RAM: every question is new (cache_prompt is off), and the
            # default cache of 8 GiB raised the peak by 1-2 GB over a session (M9a measurement).
            "--cache-ram", "0",
        ]  # fmt: skip

    def _start(self) -> None:
        self._port = _free_port()
        self._key = secrets.token_urlsafe(32)
        env = {k: v for k, v in os.environ.items() if not k.startswith(("LLAMA_", "HF_"))}
        env["LLAMA_API_KEY"] = self._key
        self._process = subprocess.Popen(  # noqa: S603 - fixed program from the extension
            self.command(self._port),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=0x08000000 if sys.platform == "win32" else 0,  # CREATE_NO_WINDOW
            cwd=str(self.model.server.parent),
        )
        self._job.assign(self._process)
        deadline = time.monotonic() + START_TIMEOUT
        while time.monotonic() < deadline:
            if self._process.poll() is not None:
                self._process = None
                raise DaengsError("Das Sprachmodell konnte nicht gestartet werden")
            try:
                status, _ = self._request("GET", "/health", None, timeout=2)
                if status == 200:
                    return
            except OSError:
                pass
            time.sleep(0.5)
        self.stop()
        raise DaengsError("Das Sprachmodell startet nicht (Zeitüberschreitung)")

    def _request(
        self, method: str, path: str, body: dict | None, timeout: float
    ) -> tuple[int, dict[str, Any]]:
        con = http.client.HTTPConnection(LOOPBACK, self._port, timeout=timeout)
        try:
            data = None if body is None else json.dumps(body).encode("utf-8")
            headers = {"Authorization": f"Bearer {self._key}", "Content-Type": "application/json"}
            con.request(method, path, body=data, headers=headers)
            response = con.getresponse()
            raw = response.read()
            return response.status, json.loads(raw) if raw else {}
        finally:
            con.close()

    def chat(self, messages: list[dict[str, str]], max_tokens: int) -> tuple[str, dict[str, Any]]:
        """Answer of the model to ``messages``; starts the server when needed."""
        with self._lock:
            self._busy = True
            try:
                if not self.running:
                    self._start()
                status, result = self._request(
                    "POST",
                    "/v1/chat/completions",
                    {
                        "messages": messages,
                        "temperature": 0.1,
                        "max_tokens": max_tokens,
                        "cache_prompt": False,
                    },
                    timeout=REQUEST_TIMEOUT,
                )
                if status != 200:
                    raise DaengsError("Das Sprachmodell hat keine Antwort geliefert")
                return result["choices"][0]["message"]["content"], result.get("timings", {})
            finally:
                self._busy = False
                self._last_used = time.monotonic()

    def chat_stream(
        self, messages: list[dict[str, str]], max_tokens: int
    ) -> Iterator[dict[str, Any]]:
        """The answer piece by piece (M9a): ``{"progress": (done, total)}`` while the model reads
        the sources, ``{"delta": text}`` while it writes, finally ``{"timings": {...}}``.
        ``cancel()`` from another thread ends it at once, even while the model is still reading."""
        with self._lock:
            self._busy = True
            try:
                if not self.running:
                    self._start()
                con = http.client.HTTPConnection(LOOPBACK, self._port, timeout=REQUEST_TIMEOUT)
                body = {
                    "messages": messages,
                    "temperature": 0.1,
                    "max_tokens": max_tokens,
                    "cache_prompt": False,
                    "stream": True,
                    "return_progress": True,
                }
                headers = {
                    "Authorization": f"Bearer {self._key}",
                    "Content-Type": "application/json",
                }
                try:
                    con.request("POST", "/v1/chat/completions", json.dumps(body), headers)
                    # The response keeps the socket; http.client may drop it from ``con``.
                    self._current = con.sock
                    response = con.getresponse()
                    if response.status != 200:
                        raise DaengsError("Das Sprachmodell hat keine Antwort geliefert")
                    yield from _events(response)
                except (OSError, http.client.HTTPException, ValueError) as exc:
                    if self._cancelled:
                        return
                    raise DaengsError("Das Sprachmodell hat die Antwort abgebrochen") from exc
                finally:
                    self._current = None
                    self._cancelled = False
                    con.close()
            finally:
                self._busy = False
                self._last_used = time.monotonic()

    def cancel(self) -> None:
        """Stop the running answer: closing the connection makes llama-server stop at once."""
        sock = self._current
        if sock is not None:
            self._cancelled = True
            with contextlib.suppress(OSError):
                sock.shutdown(socket.SHUT_RDWR)

    def peak_memory(self) -> int | None:
        return peak_working_set(self._process) if self.running else None

    def stop(self) -> None:
        with self._lock:
            process, self._process = self._process, None
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()

    def _idle_watch(self) -> None:
        while not self._stop.wait(self.WATCH_INTERVAL):
            idle = time.monotonic() - self._last_used
            if self.running and not self._busy and idle > self.model.idle_seconds:
                self.stop()

    def close(self) -> None:
        self._stop.set()
        self.stop()
