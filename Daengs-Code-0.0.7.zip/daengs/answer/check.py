"""Checks of a model answer against its sources (D-008): citations and every number.

The answer is split into sentences; each sentence keeps its citations [n] separately, and each
number in it is looked up in the sources it cites (all sources if it cites none). The UI shows
unknown citations, uncited sentences and numbers not found in the cited sources.
"""

import re
from dataclasses import dataclass, field

_CITE = re.compile(r"\[(\d{1,2}(?:\s*[,;]\s*\d{1,2})*)\]")
_SENTENCE_END = re.compile(r"[.!?]+(?:\s*\[[\d,;\s]+\])*(?=\s|$)")
_NUMBER = re.compile(r"\d+(?:[.,]\d+)*")
# Thousands separated by a space, no-break space or narrow no-break space: 8 000.
_SPACE = "[ \u00a0\u202f]"
_ANSWER_NUMBER = re.compile(rf"\d{{1,3}}(?:{_SPACE}\d{{3}})+(?:[.,]\d+)?|\d+(?:[.,]\d+)*")
_THOUSANDS_SPACE = re.compile(rf"(?<=\d){_SPACE}(?=\d{{3}}\b)")


@dataclass
class Number:
    value: str
    start: int  # position inside Sentence.text
    end: int
    found: bool


@dataclass
class Sentence:
    text: str  # without the citation brackets
    sources: list[int] = field(default_factory=list)
    invalid_sources: list[int] = field(default_factory=list)
    numbers: list[Number] = field(default_factory=list)

    @property
    def cited(self) -> bool:
        return bool(self.sources)


@dataclass
class Checked:
    sentences: list[Sentence]

    @property
    def unverified_numbers(self) -> int:
        return sum(not n.found for s in self.sentences for n in s.numbers)

    @property
    def uncited(self) -> int:
        return sum(not s.cited for s in self.sentences)

    @property
    def invalid_citations(self) -> int:
        return sum(len(s.invalid_sources) for s in self.sentences)


def _forms(token: str) -> set[str]:
    """Spellings of one number: 2.000 / 2000, 0,5 / 0.5."""
    plain = token.strip(".,")
    return {
        plain,
        plain.replace(",", "."),
        plain.replace(".", "").replace(",", "."),
        plain.replace(",", ""),
    }


def numbers_in(text: str) -> set[str]:
    joined = _THOUSANDS_SPACE.sub("", text)
    found: set[str] = set()
    for token in _NUMBER.findall(joined):
        found |= _forms(token)
    return found


def check(answer: str, sources: list[str]) -> Checked:
    known = {n: numbers_in(text) for n, text in enumerate(sources, start=1)}
    everything = set().union(*known.values()) if known else set()
    sentences = []
    answer = answer.strip()
    starts = [0] + [m.end() for m in _SENTENCE_END.finditer(answer)]
    for begin, end in zip(starts, [*starts[1:], len(answer)], strict=True):
        raw = answer[begin:end].strip()
        if not raw:
            continue
        cited = [int(n) for group in _CITE.findall(raw) for n in re.split(r"[,;]", group)]
        text = _CITE.sub("", raw)
        text = re.sub(r"\s+([.!?,;:])", r"\1", " ".join(text.split()))
        sentence = Sentence(
            text=text,
            sources=[n for n in dict.fromkeys(cited) if n in known],
            invalid_sources=[n for n in dict.fromkeys(cited) if n not in known],
        )
        pool = (
            set().union(*(known[n] for n in sentence.sources)) if sentence.sources else everything
        )
        for number in _ANSWER_NUMBER.finditer(text):
            value = number.group(0).strip(".,")
            found = bool(_forms(_THOUSANDS_SPACE.sub("", value)) & pool)
            sentence.numbers.append(
                Number(value, number.start(), number.start() + len(value), found)
            )
        sentences.append(sentence)
    return Checked(sentences)
