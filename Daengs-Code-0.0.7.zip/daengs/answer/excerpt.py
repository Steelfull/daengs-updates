"""Shorter sources for the model (M9a, D-028): the sentences around the question's words.

The model spends most of its time reading the sources before it writes the first word
(praxistest/ergebnisse/m9_streaming_werkzeuge.md: 15 s for 5 full chunks, 2 s for short ones).
A chunk is cut to the sentences that share words with the question, with their neighbours,
up to ``max_words``; the document context in front of the chunk (" · ", M8) stays.
"""

import re

_SENTENCE = re.compile(r"(?<=[.!?;:])\s+|\n+")
_WORD = re.compile(r"[\wäöüÄÖÜß][\wäöüÄÖÜß\-/]*")
_NUMBER = re.compile(r"\d")
# Question words without content; short so it stays readable (the search has the full list).
_IGNORE = frozenset(
    "wie was wer wo wann warum welche welcher welches welchen wird werden muss müssen kann "
    "können soll sollen darf dürfen gibt eine einer einem einen der die das den dem des und "
    "oder mit für bei beim auf aus von nach über unter ich man mein meine ist sind".split()
)


def _stems(text: str) -> set[str]:
    words = (w.lower() for w in _WORD.findall(text))
    return {w[:5] for w in words if len(w) >= 3 and w not in _IGNORE}


def excerpt(text: str, question: str, max_words: int = 80) -> str:
    context, sep, body = text.rpartition(" · ")
    if not sep:
        context, body = "", text
    sentences = [s.strip() for s in _SENTENCE.split(body) if s.strip()]
    if len(body.split()) <= max_words or not sentences:
        return text
    wanted = _stems(question)
    stems = [_stems(s) & wanted for s in sentences]
    sizes = [len(s.split()) for s in sentences]
    chosen: set[int] = set()
    covered: set[str] = set()
    words = 0
    # First cover as many different question words as possible; a sentence with a number wins a
    # tie (values are what is asked most). Found in M9a: "Laufrad mit 45 Nm anziehen" was lost
    # to sentences that only repeated "Gleitringdichtung".
    while True:
        best, gain = None, (0, False)
        for i, found in enumerate(stems):
            if i in chosen or (words + sizes[i] > max_words and chosen):
                continue
            candidate = (len(found - covered), bool(_NUMBER.search(sentences[i])))
            if candidate[0] and candidate > gain:
                best, gain = i, candidate
        if best is None:
            break
        chosen.add(best)
        covered |= stems[best]
        words += sizes[best]
    # Then the neighbours of what was chosen, for context, while the budget lasts.
    for i in sorted(chosen):
        for k in (i - 1, i + 1):
            if 0 <= k < len(sentences) and k not in chosen and words + sizes[k] <= max_words:
                chosen.add(k)
                words += sizes[k]
    if not chosen:  # no question word in this source: its beginning
        for i, size in enumerate(sizes):
            if words + size > max_words and chosen:
                break
            chosen.add(i)
            words += size
    parts, last = [], -2
    for k in sorted(chosen):
        if k != last + 1 and parts:
            parts.append("…")
        parts.append(sentences[k])
        last = k
    short = " ".join(parts)
    return f"{context} · {short}" if context else short


def names_a_subject(question: str) -> bool:
    """A noun or a code of its own ("Hydraulikdruck", "KV-510"), not only words like "Und wie oft?".
    German nouns are capitalised; the first word is capitalised anyway, unless it stands alone."""
    words = _WORD.findall(question)
    for word in words[1:] if len(words) > 1 else words:
        if any(c.isdigit() for c in word) or (word[:1].isupper() and len(word) >= 4):
            return True
    return False


def missing_terms(question: str, sources: list[str]) -> list[str]:
    """Longer question words that appear in no source (M9a): the document may call it otherwise
    ("Kettenabdeckung" -> "Kettenschutz"); the answer shows a hint above the text."""
    text = " ".join(sources).lower()
    seen, result = set(), []
    words = _WORD.findall(question)
    # The first word is capitalised anyway ("Brauche ich ..."); a lone noun stays.
    for word in words[1:] if len(words) > 1 else words:
        lower = word.lower()
        # Nouns only (capitalised in German), compared by stem: "Muttern" matches "Mutter".
        if not word[:1].isupper() or len(lower) < 6 or lower in _IGNORE or lower in seen:
            continue
        if lower[: max(5, len(lower) - 2)] not in text:
            seen.add(lower)
            result.append(word)
    return result
