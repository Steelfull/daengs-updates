"""Wiki suggestion from an answer (M9b, A-39, D-028): only what the answer can back up.

A suggestion is never written by itself: the user sees it as a card and confirms, edits or
discards it. The text holds only sentences with a valid source number; a sentence whose number
was not found in its source is marked. The cited sources come along as wiki references.
"""

import re
from typing import Any

# "Leg mir eine Wiki-Seite an", "ins Wiki", "fürs Wiki": the chat offers the card by itself.
_WISH = re.compile(r"\bwiki", re.IGNORECASE)
_QUOTED = re.compile(r"[„\"'‚“‘]([^„\"'‚“”‘’]{3,80})[“\"'‘”’]")
TITLE_WORDS = 8


def wants_wiki(question: str) -> bool:
    return bool(_WISH.search(question))


def quoted_title(question: str) -> str:
    """A title the user wrote out: „Kette spannen“, 'Kette spannen' or "Kette spannen"."""
    match = _QUOTED.search(question)
    return " ".join(match.group(1).split()) if match else ""


def clean_title(text: str, question: str) -> str:
    """The model's title, or failing that the question itself, as a short page title."""
    line = (text or "").strip().splitlines()[0] if (text or "").strip() else ""
    line = line.strip().removeprefix("Titel").strip(" \"'„“”‚‘’*#:.-")
    words = line.split()
    if not 1 <= len(words) <= TITLE_WORDS:
        words = re.sub(r"[?!.]+$", "", question).split()[:TITLE_WORDS]
    return " ".join(words)[:120]


def build(entry: dict[str, Any], title: str) -> dict[str, Any]:
    sources = {s["n"]: s for s in entry["sources"]}
    lines, used = [], []
    skipped = 0
    for sentence in entry["sentences"]:
        numbers = [n for n in sentence["sources"] if n in sources]
        if not numbers:
            skipped += 1
            continue
        mark = "⚠ Zahl bitte prüfen: " if any(not x["found"] for x in sentence["numbers"]) else ""
        cites = "".join(f"[{n}]" for n in numbers)
        lines.append(f"- {mark}{sentence['text']} {cites}")
        used += [n for n in numbers if n not in used]
    if not lines:
        return {"title": title, "body": "", "refs": [], "skipped": skipped}
    footer = ["", "Quellen:"] + [
        f"[{n}] {sources[n]['rel_path']}, {sources[n].get('place') or 'Seite ' + str(sources[n]['page_no'])}"
        for n in sorted(used)
    ]
    footer.append("")
    footer.append(f"Aus der Antwort auf: {entry['question']}")
    refs = [
        {
            "file_id": sources[n]["file_id"],
            "page_no": sources[n]["page_no"],
            "chunk_id": sources[n].get("chunk_id"),
            "note": f"Quelle [{n}]",
        }
        for n in sorted(used)
    ]
    return {"title": title, "body": "\n".join(lines + footer), "refs": refs, "skipped": skipped}
