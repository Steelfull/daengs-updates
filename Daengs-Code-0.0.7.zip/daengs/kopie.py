"""Install Daengs by copying the program folder, e.g. from a stick (AP-9.42, D-079 (5)).

Why: Windows Smart App Control blocks every freshly built, unsigned setup program. Copying files
runs no new program: Daengs's own Python (signed by the Python Software Foundation) copies the
folder, checks it against ``pruefsummen.txt``, creates the shortcut and the "Apps" entry. Updates
(D-077) and removal (``daengs.uninstall``) work on the copy exactly as on a setup installation.

    <stick>\\Daengs-installieren.cmd  ->  python.exe -I -m daengs.kopie installieren [Optionen]
    <folder>\\Sprachmodell-installieren.cmd  ->  installed python.exe -m daengs.kopie sprachmodell

The delivery may be two ZIP files (program, extension; Google Drive, CEO-52): the extension is
installed on its own into an existing installation. A download carries the internet mark
(``Zone.Identifier``) and ``shutil.copy2`` copies it; ``--markierung-entfernen`` drops it after
the check.

Per user, no administrator rights, nothing downloaded. Delivery folders are never touched.
"""

import argparse
import contextlib
import hashlib
import shutil
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from daengs import PRODUCT, __version__
from daengs.uninstall import UNINSTALL_KEY, Places, is_running

MANIFEST = "pruefsummen.txt"
EXTENSION_FOLDER = "Sprachmodell"  # next to the program folder on the stick
EXTENSION_MANIFEST = "erweiterung.toml"
RETRY_SECONDS = 30.0

Say = Callable[[str], None]


class InstallError(Exception):
    """The installation cannot go on; the message is for the user, in German."""


@dataclass
class Plan:
    source: Path  # program folder with python/, app/, modelle/ ...
    target: Path  # %LOCALAPPDATA%\Programs\Daengs
    extension: Path | None = None  # extension folder (erweiterung.toml) or None
    shortcuts: list[Path] = field(default_factory=list)  # [start menu, desktop] as in Places
    desktop: bool = False
    uninstall_key: str = UNINSTALL_KEY
    strip_marks: bool = False  # remove the internet mark from installed files after the check


@dataclass
class ExtensionPlan:
    source: Path  # extension folder with erweiterung.toml and pruefsummen.txt
    target: Path  # the installed program folder (%LOCALAPPDATA%\Programs\Daengs)
    uninstall_key: str = UNINSTALL_KEY
    strip_marks: bool = False


# --- checks ---------------------------------------------------------------------------------


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while block := handle.read(1 << 22):
            digest.update(block)
    return digest.hexdigest()


def manifest_entries(folder: Path) -> dict[str, str]:
    """relative path -> SHA-256 from ``pruefsummen.txt`` (written by the package build)."""
    entries: dict[str, str] = {}
    try:
        text = (folder / MANIFEST).read_text(encoding="utf-8")
    except OSError as exc:
        raise InstallError(f"{MANIFEST} fehlt in {folder}") from exc
    for line in text.splitlines():
        if line and not line.startswith("#"):
            digest, _, name = line.partition("  ")
            entries[name] = digest
    return entries


def verify(folder: Path) -> list[str]:
    """Names of files that are missing or differ from the manifest; empty = complete."""
    problems = []
    for name, digest in manifest_entries(folder).items():
        path = folder / name
        if not path.is_file() or _sha256(path) != digest:
            problems.append(name)
    return problems


MARK_STREAM = ":Zone.Identifier"


def strip_marks(folder: Path) -> int:
    """Remove the internet mark (NTFS stream ``Zone.Identifier``) from every file; count removed.

    Only called after ``verify`` succeeded: the mark says "this came from the internet". We drop
    it only for files proven complete and unchanged against ``pruefsummen.txt``, so a damaged
    download keeps its mark and is never made to look trusted. (The manifest comes from the same
    download, so this guards against damage, not deliberate manipulation; trust in the delivery
    link is the user's, CEO-52.)
    """
    removed = 0
    for path in folder.rglob("*"):
        if path.is_file():
            try:
                Path(str(path) + MARK_STREAM).unlink()
                removed += 1
            except OSError:  # no stream (or no NTFS): nothing to remove
                pass
    return removed


def _tree_size(folder: Path) -> int:
    return sum(p.stat().st_size for p in folder.rglob("*") if p.is_file())


def _is_ours(folder: Path) -> bool:
    """An existing target is replaced only if it is an installation of Daengs (or empty)."""
    if folder.is_dir() and not any(folder.iterdir()):
        return True
    return (folder / "python" / "pythonw.exe").is_file() and (folder / "daengs.toml").is_file()


def check_program(folder: Path) -> None:
    if not (folder / "python" / "pythonw.exe").is_file() or not (folder / "app").is_dir():
        raise InstallError(f"Das ist kein {PRODUCT}-Programmordner: {folder}")
    if not (folder / "daengs.toml").is_file():
        raise InstallError(f"daengs.toml fehlt in {folder}")


# --- copying --------------------------------------------------------------------------------


def copy_tree(source: Path, target: Path, say: Say, label: str) -> None:
    """Copy with a progress line every 10 %; no file is overwritten silently."""
    files = [p for p in source.rglob("*") if p.is_file()]
    total = sum(p.stat().st_size for p in files) or 1
    done, shown = 0, -1
    for path in files:
        destination = target / path.relative_to(source)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        done += path.stat().st_size
        percent = done * 100 // total // 10 * 10
        if percent != shown:
            shown = percent
            say(f"{label}: {percent} %")
    for folder in (p for p in source.rglob("*") if p.is_dir()):
        (target / folder.relative_to(source)).mkdir(parents=True, exist_ok=True)


def _retry(action: Callable[[], None], what: str) -> None:
    """Windows may hold a file for a moment (Defender, indexer): try again for a while."""
    deadline = time.monotonic() + RETRY_SECONDS
    while True:
        try:
            action()
            return
        except PermissionError as exc:
            if time.monotonic() > deadline:
                raise InstallError(f"{what} gelingt nicht. Läuft {PRODUCT} noch?") from exc
            time.sleep(0.5)


def _remove(folder: Path) -> None:
    for attempt in range(5):
        shutil.rmtree(folder, ignore_errors=True)
        if not folder.exists():
            return
        time.sleep(0.3 * (attempt + 1))


# --- Windows: shortcut and "Apps" entry -----------------------------------------------------


def create_shortcut(link: Path, program: Path, arguments: str, workdir: Path, text: str) -> None:
    """A .lnk file through the shell's own COM object (IShellLinkW): no PowerShell, no script."""
    import ctypes
    from ctypes import (
        HRESULT,
        POINTER,
        WINFUNCTYPE,
        byref,
        c_int,
        c_ubyte,
        c_uint16,
        c_uint32,
        c_ulong,
        c_void_p,
        c_wchar_p,
    )

    class Guid(ctypes.Structure):
        _fields_ = [("a", c_uint32), ("b", c_uint16), ("c", c_uint16), ("d", c_ubyte * 8)]

    ole32 = ctypes.oledll.ole32

    def guid(text: str) -> Guid:
        value = Guid()
        ole32.CLSIDFromString(text, byref(value))
        return value

    def call(obj: c_void_p, index: int, types: tuple, *args, result=HRESULT):
        table = ctypes.cast(obj, POINTER(POINTER(c_void_p)))[0]
        return WINFUNCTYPE(result, c_void_p, *types)(table[index])(obj, *args)

    link.parent.mkdir(parents=True, exist_ok=True)
    ole32.CoInitialize(None)
    shell_link, persist = c_void_p(), c_void_p()
    try:
        ole32.CoCreateInstance(
            byref(guid("{00021401-0000-0000-C000-000000000046}")),  # CLSID_ShellLink
            None,
            1,  # CLSCTX_INPROC_SERVER
            byref(guid("{000214F9-0000-0000-C000-000000000046}")),  # IID_IShellLinkW
            byref(shell_link),
        )
        call(shell_link, 20, (c_wchar_p,), str(program))  # SetPath
        call(shell_link, 11, (c_wchar_p,), arguments)  # SetArguments
        call(shell_link, 9, (c_wchar_p,), str(workdir))  # SetWorkingDirectory
        call(shell_link, 7, (c_wchar_p,), text)  # SetDescription
        call(
            shell_link,
            0,
            (POINTER(Guid), POINTER(c_void_p)),
            byref(guid("{0000010B-0000-0000-C000-000000000046}")),  # IID_IPersistFile
            byref(persist),
        )
        call(persist, 6, (c_wchar_p, c_int), str(link), 1)  # IPersistFile.Save
    finally:
        for obj in (persist, shell_link):
            if obj.value:
                call(obj, 2, (), result=c_ulong)  # Release
        ole32.CoUninitialize()


def write_uninstall_entry(key: str, values: dict[str, str | int]) -> None:
    import winreg

    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key) as handle:
        for name, value in values.items():
            kind = winreg.REG_DWORD if isinstance(value, int) else winreg.REG_SZ
            winreg.SetValueEx(handle, name, 0, kind, value)


def uninstall_values(target: Path, version: str, size_kb: int) -> dict[str, str | int]:
    """What "Apps > Daengs" shows and runs: the same as the setup wrote (packaging/daengs.iss)."""
    pythonw = target / "python" / "pythonw.exe"
    return {
        "DisplayName": PRODUCT,
        "DisplayVersion": version,
        "DisplayIcon": str(pythonw),
        "InstallLocation": str(target),
        "UninstallString": f'"{pythonw}" -I -m daengs.uninstall',
        "QuietUninstallString": f'"{pythonw}" -I -m daengs.uninstall --still',
        "NoModify": 1,
        "NoRepair": 1,
        "EstimatedSize": size_kb,
    }


def extension_values(target: Path, version: str, size_kb: int) -> dict[str, str | int]:
    pythonw = target / "python" / "pythonw.exe"
    folder = target / "erweiterungen" / "sprachmodell"
    return {
        "DisplayName": f"{PRODUCT}-Sprachmodell",
        "DisplayVersion": version,
        "InstallLocation": str(folder),
        "UninstallString": f'"{pythonw}" -I -m daengs.uninstall --erweiterung sprachmodell',
        "QuietUninstallString": (
            f'"{pythonw}" -I -m daengs.uninstall --erweiterung sprachmodell --still'
        ),
        "NoModify": 1,
        "NoRepair": 1,
        "EstimatedSize": size_kb,
    }


def _extension_version(folder: Path) -> str:
    import tomllib

    with contextlib.suppress(OSError, ValueError):
        return str(tomllib.loads((folder / EXTENSION_MANIFEST).read_text("utf-8"))["version"])
    return __version__


# --- the installation -----------------------------------------------------------------------


@dataclass
class Hooks:
    """What touches Windows outside the folders; replaced in tests."""

    running: Callable[[], bool] = is_running
    shortcut: Callable[..., None] = create_shortcut
    registry: Callable[[str, dict[str, str | int]], None] = write_uninstall_entry


def install(plan: Plan, say: Say = print, hooks: Hooks | None = None) -> dict[str, bool]:
    """Copy, check, swap in, then shortcut and "Apps" entry. Returns what was done."""
    hooks = hooks or Hooks()
    source, target = plan.source.resolve(), plan.target.resolve()
    check_program(source)
    if source == target or target in source.parents or source in target.parents:
        raise InstallError("Quelle und Ziel dürfen nicht ineinander liegen.")
    if hooks.running():
        raise InstallError(f"{PRODUCT} läuft noch. Bitte zuerst schließen und erneut starten.")
    if plan.extension is not None and not (plan.extension / EXTENSION_MANIFEST).is_file():
        raise InstallError(f"Das ist keine Erweiterung: {plan.extension}")

    if target.exists() and not _is_ours(target):
        raise InstallError(
            f"{target} gibt es schon und es ist keine {PRODUCT}-Installation; "
            "nichts wurde verändert. Anderen Zielordner wählen oder den Ordner selbst entfernen."
        )
    need = _tree_size(source) + (_tree_size(plan.extension) if plan.extension else 0)
    target.parent.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(target.parent).free
    if free < need * 1.1:
        raise InstallError(
            f"Zu wenig Platz: gebraucht werden etwa {need * 1.1 / 2**30:.1f} GB, "
            f"frei sind {free / 2**30:.1f} GB."
        )

    fresh = target.with_name(target.name + ".neu")
    old = target.with_name(target.name + ".alt")
    for leftover in (fresh, old):
        _remove(leftover)  # from an installation that was interrupted
    done = {"programm": False, "erweiterung": False, "aktualisiert": target.exists()}
    try:
        say(f"{PRODUCT} wird kopiert nach {target} ...")
        copy_tree(source, fresh, say, "Programm")
        say("Prüfe die Kopie ...")
        if bad := verify(fresh):
            raise InstallError(
                f"Die Kopie ist nicht vollständig ({len(bad)} Datei(en) weichen ab, z. B. "
                f"{bad[0]}). Stick oder ZIP prüfen und erneut versuchen."
            )
        if plan.strip_marks:
            strip_marks(fresh)
        kept = target / "erweiterungen"
        if plan.extension is not None:
            ext_target = fresh / "erweiterungen" / "sprachmodell"
            copy_tree(plan.extension, ext_target, say, "Sprachmodell")
            if bad := verify(ext_target):
                raise InstallError(
                    f"Die Kopie des Sprachmodells ist nicht vollständig ({bad[0]}). "
                    "Stick oder ZIP prüfen und erneut versuchen."
                )
            if plan.strip_marks:
                strip_marks(ext_target)
            done["erweiterung"] = True
        elif kept.is_dir():
            shutil.move(str(kept), str(fresh / "erweiterungen"))  # an update keeps the extension
            done["erweiterung"] = True
    except BaseException:
        _remove(fresh)
        raise

    try:
        if target.exists():
            _retry(lambda: target.rename(old), "Das Ersetzen der alten Fassung")
        _retry(lambda: fresh.rename(target), "Das Einsetzen der neuen Fassung")
    except InstallError:
        if old.exists() and not target.exists():
            old.rename(target)
        # An extension moved out of the old folder goes back with it.
        if (fresh / "erweiterungen").is_dir() and not (target / "erweiterungen").exists():
            shutil.move(str(fresh / "erweiterungen"), str(target / "erweiterungen"))
        _remove(fresh)
        raise
    done["programm"] = True

    program = target / "python" / "pythonw.exe"
    arguments = f'-I -m daengs --config "{target / "daengs.toml"}"'
    text = "Fundstellen in Kundenunterlagen finden"
    links = plan.shortcuts[:2] if plan.desktop else plan.shortcuts[:1]
    for link in links:
        hooks.shortcut(link, program, arguments, target, text)
    size_kb = need // 1024
    hooks.registry(plan.uninstall_key, uninstall_values(target, __version__, size_kb))
    if done["erweiterung"] and (target / "erweiterungen" / "sprachmodell").is_dir():
        ext_key = plan.uninstall_key + "-Sprachmodell"
        ext_folder = target / "erweiterungen" / "sprachmodell"
        hooks.registry(ext_key, extension_values(target, _extension_version(ext_folder), size_kb))
    _remove(old)
    return done


def install_extension(plan: ExtensionPlan, say: Say = print, hooks: Hooks | None = None) -> None:
    """Add or replace the language-model extension of an installed Daengs (separate ZIP).

    Same safety as the program: copy to ``.neu``, check against the manifest, swap through
    ``.alt``; on any error the old extension stays. The program folder itself is not touched.
    """
    hooks = hooks or Hooks()
    source, target = plan.source.resolve(), plan.target.resolve()
    if not (source / EXTENSION_MANIFEST).is_file():
        raise InstallError(f"Das ist keine Erweiterung ({EXTENSION_MANIFEST} fehlt): {source}")
    if not (source / MANIFEST).is_file():
        raise InstallError(f"{MANIFEST} fehlt in {source}")
    if not (target / "python" / "pythonw.exe").is_file() or not (target / "daengs.toml").is_file():
        raise InstallError(
            f"{PRODUCT} ist noch nicht installiert. Zuerst das Programm installieren "
            f"(Daengs-installieren.cmd aus dem ZIP „{PRODUCT}-…“), danach das Sprachmodell."
        )
    if source == target or target in source.parents or source in target.parents:
        raise InstallError("Quelle und Ziel dürfen nicht ineinander liegen.")
    if hooks.running():
        raise InstallError(f"{PRODUCT} läuft noch. Bitte zuerst schließen und erneut starten.")
    need = _tree_size(source)
    folder = target / "erweiterungen"
    folder.mkdir(parents=True, exist_ok=True)
    if (free := shutil.disk_usage(folder).free) < need * 1.1:
        raise InstallError(
            f"Zu wenig Platz: gebraucht werden etwa {need * 1.1 / 2**30:.1f} GB, "
            f"frei sind {free / 2**30:.1f} GB."
        )
    final = folder / "sprachmodell"
    fresh, old = final.with_name("sprachmodell.neu"), final.with_name("sprachmodell.alt")
    for leftover in (fresh, old):
        _remove(leftover)
    try:
        say(f"Sprachmodell wird kopiert nach {final} ...")
        copy_tree(source, fresh, say, "Sprachmodell")
        say("Prüfe die Kopie ...")
        if bad := verify(fresh):
            raise InstallError(
                f"Die Kopie ist nicht vollständig ({len(bad)} Datei(en) weichen ab, z. B. "
                f"{bad[0]}). ZIP erneut herunterladen und entpacken."
            )
        if plan.strip_marks:
            strip_marks(fresh)
    except BaseException:
        _remove(fresh)
        raise
    try:
        if final.exists():
            _retry(lambda: final.rename(old), "Das Ersetzen des alten Sprachmodells")
        _retry(lambda: fresh.rename(final), "Das Einsetzen des neuen Sprachmodells")
    except InstallError:
        if old.exists() and not final.exists():
            old.rename(final)
        _remove(fresh)
        raise
    ext_key = plan.uninstall_key + "-Sprachmodell"
    hooks.registry(ext_key, extension_values(target, _extension_version(final), need // 1024))
    _remove(old)


def default_plan(args: argparse.Namespace) -> Plan:
    """Source: the program folder this Python belongs to; target: per-user Programs folder."""
    source = Path(sys.executable).resolve().parent.parent  # <stick>/Daengs/python/python.exe
    places = Places.current()
    target = args.ziel or places.local_appdata / "Programs" / PRODUCT
    extension = args.erweiterung
    if extension is None and not args.ohne_sprachmodell:
        candidate = source.parent / EXTENSION_FOLDER
        extension = candidate if (candidate / EXTENSION_MANIFEST).is_file() else None
    return Plan(
        source=source,
        target=target,
        extension=None if args.ohne_sprachmodell else extension,
        shortcuts=places.shortcuts,
        desktop=args.desktop,
        strip_marks=args.markierung_entfernen,
    )


def _ask_desktop() -> bool:
    if not sys.stdin or not sys.stdin.isatty():
        return False
    return input("Verknüpfung auch auf dem Desktop anlegen? [j/N] ").strip().lower() in ("j", "y")


def _main_extension(args: argparse.Namespace) -> int:
    try:
        if args.quelle is None:
            raise InstallError("--quelle fehlt: der entpackte Ordner „Sprachmodell“ aus dem ZIP.")
        target = args.ziel or Places.current().local_appdata / "Programs" / PRODUCT
        plan = ExtensionPlan(args.quelle, target, strip_marks=args.markierung_entfernen)
        hooks = Hooks(registry=lambda *_: None) if args.ohne_eintraege else None
        install_extension(plan, hooks=hooks)
    except (InstallError, OSError) as exc:
        print(f"\nFEHLER: {exc}", file=sys.stderr)
        return 1
    print(f"\nDas {PRODUCT}-Sprachmodell ist installiert. Antworten mit Quellen sind verfügbar.")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="daengs.kopie")
    parser.add_argument("aufgabe", choices=["installieren", "sprachmodell", "deinstallieren"])
    parser.add_argument("--ziel", type=Path, help="Zielordner (Standard: Programs\\Daengs)")
    parser.add_argument("--quelle", type=Path, help="Aufgabe sprachmodell: entpackter Ordner")
    parser.add_argument(
        "--markierung-entfernen",
        action="store_true",
        help="nach bestandener Prüfung die Internet-Markierung (Zone.Identifier) entfernen",
    )
    parser.add_argument("--erweiterung", type=Path, help="Ordner der Sprachmodell-Erweiterung")
    parser.add_argument("--ohne-sprachmodell", action="store_true")
    parser.add_argument("--desktop", action="store_true", help="auch eine Desktop-Verknüpfung")
    parser.add_argument("--still", action="store_true", help="ohne Rückfragen")
    parser.add_argument(
        "--ohne-eintraege",
        action="store_true",
        help="nur Dateien: keine Verknüpfung, kein Apps-Eintrag (für Tests mit eigenem --ziel)",
    )
    args = parser.parse_args(argv)
    if args.aufgabe == "deinstallieren":
        from daengs.uninstall import main as uninstall_main

        return uninstall_main(["--still"] if args.still else [])
    if args.aufgabe == "sprachmodell":
        return _main_extension(args)
    try:
        if not args.still and not args.desktop:
            args.desktop = _ask_desktop()
        no_entries = Hooks(shortcut=lambda *_: None, registry=lambda *_: None)
        done = install(default_plan(args), hooks=no_entries if args.ohne_eintraege else None)
    except (InstallError, OSError) as exc:
        print(f"\nFEHLER: {exc}", file=sys.stderr)
        return 1
    print(f"\n{PRODUCT} ist installiert. Start über das Startmenü: „{PRODUCT}“.")
    if not done["erweiterung"]:
        print("Ohne Sprachmodell: Antworten mit Quellen sind nicht verfügbar, die Suche schon.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
