"""Service: local API for the UI, bound to 127.0.0.1 only and hardened (09 §4, R-21)."""

from daengs.service.server import Backend, LocalService

__all__ = ["Backend", "LocalService"]
