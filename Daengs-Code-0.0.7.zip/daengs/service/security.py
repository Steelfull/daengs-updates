"""Checks for every request to the local port (09 §4, R-21, R1 §5).

Threats: other programs and web pages on the same computer. A web page can send requests to
127.0.0.1 (CSRF) or reach it under its own domain name via DNS rebinding. Defence in depth:
loopback only, exact Host header, session token in a header, no foreign Origin, no CORS.
"""

import hmac
import secrets
from collections.abc import Mapping

LOOPBACK = "127.0.0.1"


def new_token() -> str:
    return secrets.token_urlsafe(32)


def allowed_hosts(port: int) -> frozenset[str]:
    return frozenset({f"{LOOPBACK}:{port}", f"localhost:{port}"})


def allowed_origins(port: int) -> frozenset[str]:
    return frozenset({f"http://{host}" for host in allowed_hosts(port)})


def check(
    headers: Mapping[str, str], token: str, port: int, *, token_required: bool = True
) -> tuple[int, str] | None:
    """None if the request may pass, else (HTTP status, reason). Order: cheapest first."""
    host = headers.get("Host", "").strip().lower()
    if host not in allowed_hosts(port):
        # A rebound domain name arrives with its own Host header (DNS rebinding).
        return 403, "Host nicht erlaubt"
    origin = headers.get("Origin")
    if origin is not None and origin.strip().lower() not in allowed_origins(port):
        return 403, "Ursprung nicht erlaubt"
    if headers.get("Sec-Fetch-Site", "").lower() == "cross-site":
        return 403, "Ursprung nicht erlaubt"
    if not token_required:
        return None
    auth = headers.get("Authorization", "")
    scheme, _, value = auth.partition(" ")
    if scheme.lower() != "bearer" or not hmac.compare_digest(
        value.strip().encode(), token.encode()
    ):
        return 401, "Sitzungstoken fehlt oder ist falsch"
    return None
