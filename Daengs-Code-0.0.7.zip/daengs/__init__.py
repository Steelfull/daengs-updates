"""Daengs: local, offline search for passages in PDF deliveries."""

__version__ = "0.0.7"

# Product name (D-023). Window, messages, installer and UI take it from here; the earlier
# working name only appears in daengs.migrate, which takes over an old installation.
PRODUCT = "Daengs"

# Named mutex held while Daengs runs: one Daengs per user session; setup and uninstall wait for it.
RUNNING_MUTEX = f"{PRODUCT}-laeuft-8b1e6c2a"

# The wiki for all projects (M9d) lies in its own folder next to the projects, not among them.
GLOBAL_WIKI_FOLDER = "Gesamt-Wiki"
