"""The published file latest.json: a manifest text and Ed25519 signatures over exactly that text.

Format 2 (D-077): an update is a package of Daengs's own code only (``code``), never a setup. It
fits only an installation with the same basis (Python, libraries, DLLs, models, data formats); any
other installation is told that the new version comes as a full installer on a medium.
"""

import base64
import json
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

from daengs import PRODUCT
from daengs.core import DaengsError
from daengs.core.updates import is_newer, version_key

FORMAT = 2
MAX_LATEST_BYTES = 256 * 1024
MAX_PACKAGE_BYTES = 100 * 2**20
_SHA256_CHARS = frozenset("0123456789abcdef")

# A manifest signed once with a key that was thrown away right after: the check after an update
# verifies it with the new update program, offline, so a broken one never stays (D-077).
SELFTEST_KEY = "EMGJ/V1GDBf3FNdiG95NHS/9KhR9kxTd386u8SQzoRU="
SELFTEST_LATEST = json.dumps(
    {
        "manifest": (
            '{"format":2,"product":"Daengs","version":"0.0.0","date":"","changes":[],'
            '"min_update_from":"0.0.0","basis":"' + "0" * 64 + '","code":{"url":'
            '"https://selbsttest.invalid/daengs.zip","size":1,"sha256":"' + "0" * 64 + '"}}'
        ),
        "signatures": [
            {
                "key": "t",
                "sig": "JTXiTMle4GvzzwK96Iehyh2fYQej9B4lrpf4pWcc7jypV/mk9hJB5OsFTNbl"
                "FKFBREu4F9f83dG2DTDam/6cAw==",
            }
        ],
    }
).encode("utf-8")


class ManifestError(DaengsError):
    """Not signed by a known key, or not a valid manifest."""


class FullInstallerNeeded(ManifestError):
    """Another basis or too old a version: the new version comes as a full installer (D-077)."""


@dataclass(frozen=True)
class Package:
    url: str
    size: int
    sha256: str


def verify(latest: bytes, keys: dict[str, str]) -> tuple[dict[str, Any], str, list[dict[str, str]]]:
    """Check latest.json and return the manifest, its text and the signatures. The text is only
    read as JSON after a signature matched, so nothing unsigned reaches the parser below."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    if len(latest) > MAX_LATEST_BYTES:
        raise ManifestError("Antwort zu groß")
    try:
        outer = json.loads(latest)
        text, signatures = outer["manifest"], outer["signatures"]
    except (ValueError, KeyError, TypeError) as exc:
        raise ManifestError("Antwort hat nicht das erwartete Format") from exc
    if not isinstance(text, str) or not isinstance(signatures, list):
        raise ManifestError("Antwort hat nicht das erwartete Format")
    for entry in signatures:
        try:
            key = Ed25519PublicKey.from_public_bytes(base64.b64decode(keys[entry["key"]]))
            key.verify(base64.b64decode(entry["sig"]), text.encode("utf-8"))
        except (InvalidSignature, KeyError, TypeError, ValueError):
            continue
        return _checked(json.loads(text)), text, signatures
    raise ManifestError("Keine gültige Signatur")


def selftest() -> bool:
    """The whole check once, without network: signature, format, fields."""
    found, _, _ = verify(SELFTEST_LATEST, {"t": SELFTEST_KEY})
    return found["version"] == "0.0.0" and _package(found["code"]).size == 1


def _checked(manifest: Any) -> dict[str, Any]:
    try:
        if manifest["format"] != FORMAT:
            raise ManifestError("Manifest hat ein anderes Format")
        if manifest["product"] != PRODUCT:
            raise ManifestError("Manifest gehört zu einem anderen Produkt")
        version_key(manifest["version"])
        version_key(manifest["min_update_from"])
        if not all(isinstance(line, str) for line in manifest["changes"]):
            raise ManifestError("Änderungen ungültig")
        _sha256(manifest["basis"])
        _package(manifest["code"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ManifestError("Manifest ungültig") from exc
    return manifest


def _sha256(value: Any) -> str:
    if not isinstance(value, str) or len(value) != 64 or not _SHA256_CHARS.issuperset(value):
        raise ManifestError("Prüfsumme ungültig")
    return value


def _package(raw: Any) -> Package:
    package = Package(raw["url"], raw["size"], _sha256(raw["sha256"]))
    if (
        not isinstance(package.url, str)
        or not isinstance(package.size, int)
        or isinstance(package.size, bool)
        or not 0 < package.size <= MAX_PACKAGE_BYTES
    ):
        raise ManifestError("Paket-Angaben ungültig")
    return package


def needs_full(manifest: dict[str, Any], installed: str, basis: str) -> bool:
    """Too old, or Python, libraries, models or data formats differ: no update over the net."""
    return is_newer(manifest["min_update_from"], installed) or manifest["basis"] != basis


def choose_package(
    manifest: dict[str, Any], installed: str, basis: str, update_url: str
) -> Package:
    """The code package, only for the same basis, only from the update server, only over HTTPS."""
    if needs_full(manifest, installed, basis):
        raise FullInstallerNeeded(
            "Diese Fassung lässt sich nicht online aktualisieren. Die neue Version kommt per "
            "Vollinstaller (Datenträger)."
        )
    package = _package(manifest["code"])
    wanted, given = urlsplit(update_url), urlsplit(package.url)
    if given.scheme != "https" or given.netloc != wanted.netloc:
        raise ManifestError("Paket liegt nicht auf dem Update-Server")
    return package
