"""Entry of the update program: daengs-update.exe -I -m daengs.updater <task> --ordner <dir>

``selbsttest`` needs no folder: after an update the old update program runs the new one this way,
offline, before the old code is thrown away (D-077).
"""

import argparse
import contextlib
import os
import sys
from pathlib import Path

from daengs import PRODUCT
from daengs.core.updates import UpdateFiles
from daengs.updater.run import Config, check, download, install, recover, selftest

ONE_AT_A_TIME = f"{PRODUCT}-Update-3f1a9c70"


def _only_one() -> object | None:
    """Handle of the mutex, or None if another update program runs (the check and a download)."""
    if sys.platform != "win32":
        return object()
    import ctypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    handle = kernel32.CreateMutexW(None, True, ONE_AT_A_TIME)
    already_exists = 183
    return None if ctypes.get_last_error() == already_exists else handle


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="daengs.updater")
    parser.add_argument("task", choices=["pruefen", "laden", "installieren", "selbsttest"])
    parser.add_argument("--ordner", type=Path)
    args = parser.parse_args(argv)
    if args.task == "selbsttest":
        try:
            return selftest()
        except Exception:
            return 1
    if args.ordner is None:
        parser.error("--ordner fehlt")
    holder = _only_one()
    if holder is None:
        return 3
    config = Config()
    # Never stand in the code folder that may be swapped: next to the program instead.
    with contextlib.suppress(OSError):
        os.chdir(Path(sys.executable).parent)
    files = UpdateFiles(args.ordner)
    with contextlib.suppress(OSError):
        recover(files, config)
    if args.task == "pruefen":
        check(files, config)
        return 0
    if args.task == "laden":
        return 0 if download(files, config) else 1
    return 0 if install(files, config) else 1


if __name__ == "__main__":
    raise SystemExit(main())
