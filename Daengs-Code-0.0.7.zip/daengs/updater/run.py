"""Check, download, install (13 §3, D-077). Everything the program does on the network is in here.

Installing swaps Daengs's own code folder (``app/daengs``) and starts no other program: an unsigned
setup would be stopped by Smart App Control (AP-9.37). The old folder stays as ``daengs.alt`` until
the new version has started and passed its self-test; otherwise the old one comes back.
"""

import base64
import contextlib
import hashlib
import http.client
import json
import os
import shutil
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from daengs import PRODUCT, RUNNING_MUTEX, __version__
from daengs.core import DaengsError
from daengs.core.updates import UPDATE_URL, UpdateFiles, is_newer
from daengs.updater import manifest
from daengs.updater import package as pkg
from daengs.updater.keys import PUBLIC_KEYS

CHECK_TIMEOUT = 5
DOWNLOAD_TIMEOUT = 30
CHUNK = 256 * 1024
WAIT_FOR_APP = 300  # seconds the app may take to close before the update is given up
WATCH_NEW_VERSION = 180  # seconds the new version has to start and report its self-test
BASIS_FILE = "basis.json"
_AGENT = {"User-Agent": PRODUCT}  # no version, no machine: the server sees only the address


def _install_dir() -> Path:
    return Path(sys.executable).resolve().parent.parent  # <install>/python/daengs-update.exe


def installed_basis(install_dir: Path) -> str:
    """Written by the build next to the program (packaging/build.py); empty if missing."""
    with contextlib.suppress(OSError, ValueError, KeyError, TypeError):
        return str(json.loads((install_dir / BASIS_FILE).read_text(encoding="utf-8"))["basis"])
    return ""


@dataclass(frozen=True)
class Config:
    url: str = UPDATE_URL
    keys: dict[str, str] = field(default_factory=lambda: dict(PUBLIC_KEYS))
    ca_file: str | None = None  # only for the local test server; the program uses Windows's store
    installed: str = __version__
    install_dir: Path = field(default_factory=_install_dir)
    basis: str | None = None  # read from install_dir when not given

    @property
    def own_basis(self) -> str:
        return self.basis if self.basis is not None else installed_basis(self.install_dir)

    @property
    def code_dir(self) -> Path:
        return self.install_dir / "app" / pkg.ROOT


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise urllib.error.URLError("Weiterleitung nicht erlaubt")


def _request(config: Config, url: str, timeout: float, headers: dict[str, str] | None = None):
    """HTTPS to the fixed host only: no proxy, no redirect, certificates checked."""
    wanted, given = urlsplit(config.url), urlsplit(url)
    if given.scheme != "https" or given.netloc != wanted.netloc:
        raise DaengsError("Adresse nicht erlaubt")
    context = ssl.create_default_context(cafile=config.ca_file)
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context), _NoRedirect
    )
    # The address is the fixed one checked above.
    request = urllib.request.Request(url, headers={**_AGENT, **(headers or {})})  # noqa: S310
    return opener.open(request, timeout=timeout)


def _switched_off(files: UpdateFiles) -> bool:
    """Checked here too, not only in the app: off means no connection at all (D-037)."""
    return files.read("settings").get("enabled", True) is False


# -- check ---------------------------------------------------------------------------------------


def check(files: UpdateFiles, config: Config) -> dict:
    """Ask once whether there is a newer version. Failing is quiet: Daengs works on as usual."""
    now = time.time()
    if not config.url or _switched_off(files):
        return {}
    try:
        with _request(config, config.url, CHECK_TIMEOUT) as response:
            latest = response.read(manifest.MAX_LATEST_BYTES + 1)
        found, text, signatures = manifest.verify(latest, config.keys)
    except (OSError, http.client.HTTPException, DaengsError) as exc:
        state = {**files.read("state"), "last_try": now, "last_error": type(exc).__name__}
        files.write("state", state)
        return state
    state: dict[str, Any] = {"last_check": now, "last_try": now, "last_error": ""}
    if is_newer(found["version"], config.installed):
        full_only = manifest.needs_full(found, config.installed, config.own_basis)
        state["available"] = {
            "version": found["version"],
            "date": found.get("date", ""),
            "changes": found["changes"],
            "size": 0 if full_only else found["code"]["size"],
            "full_only": full_only,
            "loadable": not full_only,
        }
        state["signed"] = {"manifest": text, "signatures": signatures}
    files.write("state", state)
    return state


def _signed_manifest(files: UpdateFiles, config: Config) -> dict:
    """The manifest as saved at the check, verified again: the files lie in a user folder."""
    signed = files.read("state").get("signed")
    if not signed:
        raise DaengsError("Kein Update vorgemerkt")
    found, _, _ = manifest.verify(json.dumps(signed).encode("utf-8"), config.keys)
    if not is_newer(found["version"], config.installed):
        raise DaengsError("Kein Zurückstufen")
    return found


# -- download ------------------------------------------------------------------------------------


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _package_path(files: UpdateFiles, version: str) -> Path:
    return files.download_dir / f"{PRODUCT}-Code-{version}.zip"


def download(files: UpdateFiles, config: Config) -> bool:
    """Download with resume, progress and cancelling; True when the checked package is there."""
    try:
        if _switched_off(files):
            raise DaengsError("Updates sind ausgeschaltet")
        found = _signed_manifest(files, config)
        package = manifest.choose_package(found, config.installed, config.own_basis, config.url)
        target = _package_path(files, found["version"])
        if target.exists() and _sha256(target) == package.sha256:
            _progress(files, "bereit", package.size, package.size)
            return True
        files.download_dir.mkdir(parents=True, exist_ok=True)
        files.cancel_file.unlink(missing_ok=True)
        part = files.download_dir / f"{package.sha256}.part"
        _fetch(files, config, package, part)
        if part.stat().st_size < package.size:  # the line broke off: the rest comes next time
            raise DaengsError("Verbindung unterbrochen, das Laden geht beim nächsten Mal weiter")
        if _sha256(part) != package.sha256:
            part.unlink(missing_ok=True)
            raise DaengsError("Datei beschädigt")
        pkg.check(part)  # signed and whole, and still only what the list allows
        part.replace(target)
    except _Cancelled:
        files.write("progress", {"state": "abgebrochen"})
        return False
    except (OSError, http.client.HTTPException, DaengsError) as exc:
        files.write("progress", {"state": "fehler", "error": _message(exc)})
        return False
    _progress(files, "bereit", package.size, package.size)
    return True


class _Cancelled(Exception):
    pass


def _progress(files: UpdateFiles, state: str, done: int, size: int) -> None:
    files.write("progress", {"state": state, "done": done, "size": size})


def _message(exc: Exception) -> str:
    return str(exc) if isinstance(exc, DaengsError) else "Keine Verbindung zum Update-Server"


def _fetch(files: UpdateFiles, config: Config, package: manifest.Package, part: Path) -> None:
    done = part.stat().st_size if part.exists() else 0
    if done > package.size:
        part.unlink()
        done = 0
    free = shutil.disk_usage(files.download_dir).free
    if free < package.size - done + 100 * 2**20:
        raise DaengsError("Nicht genug Platz auf dem Datenträger")
    headers = {"Range": f"bytes={done}-"} if done else {}
    try:
        response = _request(config, package.url, DOWNLOAD_TIMEOUT, headers)
    except urllib.error.HTTPError as exc:
        if exc.code != 416:  # the part is complete or stale; the check below decides
            raise
        return
    with response:
        mode = "ab" if response.status == 206 else "wb"  # the server ignored the range: anew
        done = done if response.status == 206 else 0
        last = 0.0
        with part.open(mode) as stream:
            while chunk := response.read1(CHUNK):
                stream.write(chunk)
                done += len(chunk)
                if done > package.size:
                    stream.close()
                    part.unlink(missing_ok=True)
                    raise DaengsError("Datei beschädigt")
                if files.cancel_file.exists():
                    files.cancel_file.unlink(missing_ok=True)
                    raise _Cancelled
                if time.monotonic() - last > 0.5:
                    last = time.monotonic()
                    files.write("progress", {"state": "laedt", "done": done, "size": package.size})


# -- install -------------------------------------------------------------------------------------


def _mutex_held(name: str) -> bool:
    if sys.platform != "win32":
        return False
    import ctypes

    synchronize = 0x00100000
    handle = ctypes.windll.kernel32.OpenMutexW(synchronize, False, name)
    if handle:
        ctypes.windll.kernel32.CloseHandle(handle)
        return True
    return False


def _start_app(install_dir: Path) -> subprocess.Popen | None:
    """Daengs with the code that lies in its folder now."""
    pythonw = install_dir / "python" / "pythonw.exe"
    toml = install_dir / f"{PRODUCT.lower()}.toml"
    if not (pythonw.exists() and toml.exists()):
        return None
    detached = 0x00000008
    return subprocess.Popen(  # noqa: S603 - our own program in our own folder, fixed arguments
        [str(pythonw), "-I", "-m", PRODUCT.lower(), "--config", str(toml)],
        cwd=install_dir,
        creationflags=detached if sys.platform == "win32" else 0,
        close_fds=True,
    )


def _stop_app(process: subprocess.Popen | None) -> None:
    """The started app and its window, nothing else (it was started by this program)."""
    if process is None or process.poll() is not None:
        return
    if sys.platform == "win32":
        subprocess.run(  # noqa: S603 - Windows tool, the PID of our own child
            ["taskkill", "/PID", str(process.pid), "/T", "/F"],  # noqa: S607
            capture_output=True,
            check=False,
        )
    else:
        process.kill()
    with contextlib.suppress(subprocess.TimeoutExpired):
        process.wait(10)


def _updater_selftest(install_dir: Path) -> bool:
    """The new update program, offline: it must load and check a signature once (D-077)."""
    program = install_dir / "python" / "daengs-update.exe"
    if not program.exists():
        program = Path(sys.executable)
    try:
        result = subprocess.run(  # noqa: S603 - our own program, fixed arguments
            [str(program), "-I", "-m", "daengs.updater", "selbsttest"],
            cwd=program.parent,
            capture_output=True,
            timeout=60,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def selftest() -> int:
    """Task ``selbsttest``: 0 when this update program can do its work."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    if not manifest.selftest() or not PUBLIC_KEYS:
        return 1
    for value in PUBLIC_KEYS.values():
        Ed25519PublicKey.from_public_bytes(base64.b64decode(value, validate=True))
    return 0


def _set_display_version(install_dir: Path, version: str) -> None:
    """Windows "Apps" shows the new version, but only for the installation it describes."""
    if sys.platform != "win32":
        return
    import winreg

    key = rf"Software\Microsoft\Windows\CurrentVersion\Uninstall\{PRODUCT}"
    with (
        contextlib.suppress(OSError),
        winreg.OpenKey(winreg.HKEY_CURRENT_USER, key, 0, winreg.KEY_ALL_ACCESS) as handle,
    ):
        location, _ = winreg.QueryValueEx(handle, "InstallLocation")
        if os.path.normcase(os.path.abspath(location)) == os.path.normcase(str(install_dir)):
            winreg.SetValueEx(handle, "DisplayVersion", 0, winreg.REG_SZ, version)


@dataclass
class Hooks:
    """What touches the outside world while installing; replaced in tests."""

    start: Callable[[Path], Any] = _start_app
    stop: Callable[[Any], None] = _stop_app
    updater_ok: Callable[[Path], bool] = _updater_selftest
    display_version: Callable[[Path, str], None] = _set_display_version
    poll: Callable[[Any], int | None] = lambda process: process.poll() if process else 0
    watch: float = WATCH_NEW_VERSION
    grace: float = 3.0  # a last moment for the result file of a version that has ended
    retry: float = pkg.RETRY_SECONDS


def _folders(config: Config) -> tuple[Path, Path, Path, Path]:
    code = config.code_dir
    return (
        code,
        code.with_name("daengs.neu"),
        code.with_name("daengs.alt"),
        code.with_name("daengs.kaputt"),
    )


def install(
    files: UpdateFiles,
    config: Config,
    wait: float = WAIT_FOR_APP,
    mutex: str = RUNNING_MUTEX,
    hooks: Hooks | None = None,
) -> bool:
    """Swap the code once the app has closed, start the new version and watch it. True only when
    the new version reported a good self-test and the new update program works; otherwise the old
    code is back and running. The attempt is written down first, so a stop in between is mended by
    recover() at the next run."""
    hooks = hooks or Hooks()
    cur, new, old, _ = _folders(config)
    version = "?"
    try:
        found = _signed_manifest(files, config)
        version = found["version"]
        package = manifest.choose_package(found, config.installed, config.own_basis, config.url)
        target = _package_path(files, version)
        if _sha256(target) != package.sha256:
            raise DaengsError("Datei beschädigt")
        pkg.unpack(target, new)
        if pkg.version_in(new) != version:
            raise pkg.PackageError("Version im Paket passt nicht zum Manifest")
        deadline = time.monotonic() + wait
        while _mutex_held(mutex):
            if time.monotonic() > deadline:
                raise DaengsError(f"{PRODUCT} wurde nicht beendet")
            time.sleep(0.2)
        files.remove("result")
        files.write("attempt", {"version": version, "from": config.installed, "time": time.time()})
        pkg.remove_tree(old, hooks.retry)
        pkg.rename(cur, old, hooks.retry)
        try:
            pkg.rename(new, cur, hooks.retry)
        except OSError:
            pkg.rename(old, cur, hooks.retry)
            raise
    except (OSError, DaengsError) as exc:
        pkg.remove_tree(new, 2)
        with contextlib.suppress(OSError):
            files.write(
                "attempt",
                {"version": version, "from": config.installed, "error": _install_error(exc)},
            )
        hooks.start(config.install_dir)  # nothing was swapped: the old version comes back
        return False

    process = hooks.start(config.install_dir)
    problem = _watch(files, version, process, hooks)
    if not problem and not hooks.updater_ok(config.install_dir):
        problem = "das neue Update-Programm arbeitet nicht"
    if problem:
        return _fall_back(files, config, version, problem, process, hooks)
    pkg.remove_tree(old, hooks.retry)
    hooks.display_version(config.install_dir, version)
    shutil.rmtree(files.download_dir, ignore_errors=True)
    return True


def _watch(files: UpdateFiles, version: str, process: Any, hooks: Hooks) -> str:
    """Empty when the new version reported a good self-test, else what went wrong."""
    deadline = time.monotonic() + hooks.watch
    ended = None
    while time.monotonic() < deadline:
        result = files.read("result")
        if result.get("version") == version and not files.read("attempt"):
            return "" if result.get("ok") else result.get("message") or "Selbsttest gescheitert"
        if hooks.poll(process) is not None:
            ended = ended or time.monotonic()
            if time.monotonic() - ended > hooks.grace:
                return "die neue Fassung hat sich beendet"
        time.sleep(0.5)
    return "die neue Fassung hat sich nicht gemeldet"


def _fall_back(
    files: UpdateFiles, config: Config, version: str, problem: str, process: Any, hooks: Hooks
) -> bool:
    cur, _, old, broken = _folders(config)
    hooks.stop(process)
    deadline = time.monotonic() + 30
    while _mutex_held(RUNNING_MUTEX) and time.monotonic() < deadline:
        time.sleep(0.2)
    message = f"Das Update auf {version} hat nicht geklappt: {problem.rstrip('.')}."
    try:
        pkg.remove_tree(broken, 2)
        pkg.rename(cur, broken, hooks.retry)
        pkg.rename(old, cur, hooks.retry)
        message += " Deine bisherige Fassung läuft wieder."
    except OSError:
        message += " Bitte Daengs neu starten; die bisherige Fassung wird dann wiederhergestellt."
    files.remove("attempt")
    files.write("result", {"ok": False, "version": version, "message": message})
    hooks.start(config.install_dir)
    return False


def recover(files: UpdateFiles, config: Config) -> None:
    """Leftovers of an earlier run: a swap that was cut off is undone, finished ones tidied."""
    cur, new, old, broken = _folders(config)
    pkg.remove_tree(new, 2)
    pkg.remove_tree(broken, 2)
    if not old.exists():
        return
    if not cur.exists():
        pkg.rename(old, cur)
        return
    result = files.read("result")
    with contextlib.suppress(OSError, DaengsError):
        if result.get("ok") and result.get("version") == pkg.version_in(cur):
            pkg.remove_tree(old)
            return
    if _mutex_held(RUNNING_MUTEX):
        return  # Daengs runs; it is mended when it has closed
    pkg.rename(cur, broken)
    pkg.rename(old, cur)
    pkg.remove_tree(broken, 2)
    files.remove("attempt")
    files.write(
        "result",
        {
            "ok": False,
            "version": result.get("version", ""),
            "message": "Ein Update wurde unterbrochen. Die bisherige Fassung ist wieder aktiv.",
        },
    )


def _install_error(exc: Exception) -> str:
    if isinstance(exc, DaengsError):
        return str(exc)
    return "Die Programmdateien ließen sich nicht austauschen"
