"""The code package (D-077): checked against a fixed list, unpacked next to the code, swapped in.

Only Daengs's own code changes this way: Python files and the window's files under ``daengs/``.
Nothing that Windows would run as a program (EXE, DLL, PYD) can come in. The swap is two renames of
whole folders, each retried while Windows briefly holds a file (Defender, indexer).
"""

import shutil
import stat
import time
import zipfile
from collections.abc import Callable
from pathlib import Path, PurePosixPath

from daengs.core import DaengsError

ROOT = "daengs"
SUFFIXES = frozenset(
    {".py", ".pyc", ".typed", ".html", ".js", ".css", ".json", ".svg", ".png", ".woff2", ".txt"}
)
MAX_FILES = 2000
MAX_UNPACKED = 50 * 2**20
RETRY_SECONDS = 30.0


class PackageError(DaengsError):
    """The package holds something that is not on the list."""


def check(path: Path) -> list[zipfile.ZipInfo]:
    """Every entry on the list, or the whole package is refused."""
    try:
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            bad = archive.testzip()
    except (OSError, zipfile.BadZipFile) as exc:
        raise PackageError("Paket ist beschädigt") from exc
    if bad is not None:
        raise PackageError("Paket ist beschädigt")
    files = [e for e in entries if not e.is_dir()]
    if not files or len(files) > MAX_FILES:
        raise PackageError("Paket hat nicht die erwartete Größe")
    if sum(e.file_size for e in files) > MAX_UNPACKED:
        raise PackageError("Paket ist zu groß")
    names = set()
    for entry in entries:
        name = entry.filename
        parts = PurePosixPath(name).parts
        if (
            "\\" in name
            or name.startswith("/")
            or ":" in name
            or not parts
            or parts[0] != ROOT
            or any(p in ("", ".", "..") for p in parts)
            or (not entry.is_dir() and PurePosixPath(name).suffix.lower() not in SUFFIXES)
            or stat.S_ISLNK(entry.external_attr >> 16)
        ):
            raise PackageError(f"Nicht erlaubt im Paket: {name}")
        if name.lower() in names:
            raise PackageError(f"Doppelt im Paket: {name}")
        names.add(name.lower())
    if not any(e.filename == f"{ROOT}/__init__.py" for e in files):
        raise PackageError("Paket enthält kein Daengs")
    return files


def unpack(path: Path, target: Path) -> None:
    """Into target (the future daengs folder), only after check() passed."""
    files = check(path)
    remove_tree(target)
    target.mkdir(parents=True)
    with zipfile.ZipFile(path) as archive:
        for entry in files:
            relative = PurePosixPath(entry.filename).relative_to(ROOT)
            out = target.joinpath(*relative.parts)
            out.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(entry) as source, out.open("xb") as sink:
                shutil.copyfileobj(source, sink)
            if out.stat().st_size != entry.file_size:
                raise PackageError(f"Datei unvollständig: {entry.filename}")


def version_in(folder: Path) -> str:
    """__version__ of a daengs folder, read as text: nothing of it is run."""
    text = (folder / "__init__.py").read_text(encoding="utf-8")
    for line in text.splitlines():
        if line.startswith("__version__ = "):
            return line.split('"')[1]
    raise PackageError("Keine Versionsangabe im Paket")


def rename(
    source: Path,
    target: Path,
    seconds: float = RETRY_SECONDS,
    sleep: Callable[[float], None] = time.sleep,
) -> None:
    """Retried while Windows holds a file in the folder; afterwards the error stands."""
    deadline = time.monotonic() + seconds
    pause = 0.2
    while True:
        try:
            source.rename(target)
            return
        except PermissionError:
            if time.monotonic() + pause > deadline:
                raise
            sleep(pause)
            pause = min(pause * 2, 2.0)


def remove_tree(folder: Path, seconds: float = RETRY_SECONDS) -> bool:
    """Best effort with retries; False if something is left (removed on a later run)."""
    deadline = time.monotonic() + seconds
    while folder.exists():
        shutil.rmtree(folder, ignore_errors=True)
        if not folder.exists() or time.monotonic() > deadline:
            break
        time.sleep(0.5)
    return not folder.exists()
