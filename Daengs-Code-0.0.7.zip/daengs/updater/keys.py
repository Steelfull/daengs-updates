"""Public keys that may sign an update (13 §4, D-074), by number: the active one and the reserve.

Made by Tim on 2026-11-09 with packaging/release_schluessel.py: "a" lies on his computer, "b" on a
USB stick, both protected by a password, never in the repository and never in CI. A release is
signed with "a"; if it is lost or stolen, the next update is signed with "b" and drops "a".
"""

PUBLIC_KEYS: dict[str, str] = {
    "a": "EMXRL3JyRegNrm/ld0+yTNTnDLbNRs0lHGsJ3czs7bs=",
    "b": "MQ08j6hXge6PmO7+u0uZQyfELwdWahydmKVyLUBT7wU=",
}
