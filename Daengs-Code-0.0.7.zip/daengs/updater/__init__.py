"""The update program (13 §2): the only part of Daengs with a connection to the outside.

Runs as its own process, ``python\\daengs-update.exe -I -m daengs.updater``, so that the program
holding customer data can stay blocked by a firewall rule. It uses daengs.core only, reads no
project, sends nothing but the request itself, and no other module imports it.
"""
