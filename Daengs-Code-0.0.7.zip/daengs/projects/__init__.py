"""Projects: create a project, grant folders, manage and delete the project folder (F1, F7)."""

from daengs.projects.registry import FIRST_DONE, FIRST_RUNNING, ProjectInfo, ProjectRegistry

__all__ = ["FIRST_DONE", "FIRST_RUNNING", "ProjectInfo", "ProjectRegistry"]
