"""One folder per project under the data location; one database per project (07 §6)."""

import json
import os
import shutil
import sqlite3
import stat
import time
from collections.abc import Callable
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path

from daengs import PRODUCT
from daengs.core import (
    DaengsError,
    DataZone,
    PathNotAllowedError,
    ProjectContext,
    ProjectId,
    ProjectNotFoundError,
    ProjectTooNewError,
    is_within,
    new_project_id,
    validate_project_id,
)
from daengs.core.project import DB_NAME, SCHEMA_VERSION


# From version n to n + 1. A change of any table raises SCHEMA_VERSION and adds a step here; the
# reference in tests/fixtures shows when one was forgotten (13 §7). Modules may still add their
# tables on first use: a project that never used a module has no tables of it.
def _file_title_columns(con: sqlite3.Connection) -> None:
    """Version 2 (D-063): PDF metadata title and title rule on the file table, if it exists.
    The title rule stays empty, so the next scan builds the titles anew."""
    present = {row[1] for row in con.execute("pragma table_info(file)")}
    if not present:
        return
    for name, kind in (("meta_title", "text"), ("title_rule", "integer")):
        if name not in present:
            con.execute(f"alter table file add column {name} {kind}")


MIGRATIONS: dict[int, Callable[[sqlite3.Connection], None]] = {1: _file_title_columns}

_SCHEMA = """
create table if not exists meta(key text primary key, value text not null);
create table if not exists folder(id integer primary key, path text not null unique);
"""
_SUBDIRS = ("tmp", "protokoll", "vorschau")
MAX_NAME = 200

# First reading of a project (D-065, D-066): a row in ``meta``, no change of the schema. A new
# project starts with RUNNING; a project without the row (made before) counts as DONE.
FIRST_INGEST_KEY = "erstes_einlesen"
FIRST_RUNNING, FIRST_DONE = "laeuft", "fertig"


@dataclass(frozen=True)
class ProjectInfo:
    project_id: ProjectId
    name: str
    created: str
    folders: tuple[Path, ...]
    too_new: bool = False  # from a newer Daengs: listed, but it cannot be opened


class ProjectRegistry:
    """Projects in one data location. Never writes outside ``data_dir``."""

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = data_dir.resolve()

    def create(self, name: str, folders: list[Path]) -> ProjectContext:
        name = _clean_name(name)
        checked = [self._check_folder(f) for f in folders]
        self.data_dir.mkdir(parents=True, exist_ok=True)
        project_id = new_project_id()
        project_dir = self.data_dir / project_id
        project_dir.mkdir()
        for sub in _SUBDIRS:
            (project_dir / sub).mkdir()
        context = ProjectContext(project_id, project_dir, ())
        with context.transaction() as con:
            con.executescript(_SCHEMA)
            con.executemany(
                "insert into meta(key, value) values (?, ?)",
                [
                    ("schema_version", str(SCHEMA_VERSION)),
                    ("project_id", project_id),
                    ("name", name),
                    ("created", time.strftime("%Y-%m-%dT%H:%M:%S%z")),
                    ("zone", DataZone.CUSTOMER.value),
                    (FIRST_INGEST_KEY, FIRST_RUNNING),
                ],
            )
            con.executemany(
                "insert or ignore into folder(path) values (?)", [(str(f),) for f in checked]
            )
        context = self.open(project_id)
        context.log_event("projekt_angelegt", ordner=len(context.folders))
        return context

    def open(self, project_id: str) -> ProjectContext:
        project_id = validate_project_id(project_id)
        project_dir = self.data_dir / project_id
        if not (project_dir / DB_NAME).is_file():
            raise ProjectNotFoundError("Projekt nicht gefunden")
        meta, folders = _read(project_dir / DB_NAME)
        if meta.get("project_id") != project_id:
            # The folder was copied or renamed: refuse rather than mix projects.
            raise ProjectNotFoundError("Projektordner passt nicht zur Projekt-ID")
        context = ProjectContext(project_id, project_dir, folders, DataZone(meta["zone"]))
        _bring_up_to_date(context, int(meta["schema_version"]))
        return context

    def info(self, project_id: str) -> ProjectInfo:
        context = self.open(project_id)
        meta, _ = _read(context.db_path)
        return ProjectInfo(context.project_id, meta["name"], meta["created"], context.folders)

    def first_ingest(self, project_id: str) -> str:
        """RUNNING until text and embeddings of all readable files were there once."""
        meta, _ = _read(self.open(project_id).db_path)
        return FIRST_RUNNING if meta.get(FIRST_INGEST_KEY) == FIRST_RUNNING else FIRST_DONE

    def finish_first_ingest(self, project_id: str) -> None:
        context = self.open(project_id)
        with context.transaction() as con:
            con.execute(
                "insert or replace into meta(key, value) values (?, ?)",
                (FIRST_INGEST_KEY, FIRST_DONE),
            )

    def list(self) -> list[ProjectInfo]:
        if not self.data_dir.is_dir():
            return []
        result = []
        for entry in sorted(self.data_dir.iterdir()):
            try:
                result.append(self.info(entry.name))
            except ProjectTooNewError:
                # Stays visible: the user should not think the project is gone.
                meta, _ = _read(entry / DB_NAME)
                result.append(
                    ProjectInfo(ProjectId(entry.name), meta["name"], meta["created"], (), True)
                )
            except (ValueError, ProjectNotFoundError, sqlite3.Error):
                continue
        return sorted(result, key=lambda p: p.created)

    def grant_folder(self, project_id: str, folder: Path) -> ProjectContext:
        context = self.open(project_id)
        checked = self._check_folder(folder)
        with context.transaction() as con:
            con.execute("insert or ignore into folder(path) values (?)", (str(checked),))
        context = self.open(project_id)
        context.log_event("ordner_freigegeben", ordner=len(context.folders))
        return context

    def revoke_folder(self, project_id: str, folder: Path) -> ProjectContext:
        """Remove the grant. Indexed pages from this folder are removed by the next ingest run."""
        context = self.open(project_id)
        resolved = str(folder.resolve())
        with context.transaction() as con:
            con.execute("delete from folder where path = ?", (resolved,))
        context = self.open(project_id)
        context.log_event("ordner_entzogen", ordner=len(context.folders))
        return context

    def delete(self, project_id: str, confirm_name: str) -> dict[str, int]:
        """Delete the project folder for good (F7, A-08): no recycle bin, then a log entry
        outside the project with counts only. ``confirm_name`` must repeat the project name.

        The caller closes everything that holds the project's files open first.
        """
        info = self.info(project_id)
        if " ".join(confirm_name.split()) != info.name:
            raise DaengsError("Der eingegebene Name stimmt nicht mit dem Projektnamen überein")
        project_dir = self.data_dir / info.project_id
        files = size = 0
        for path in project_dir.rglob("*"):
            if path.is_file():
                files += 1
                size += path.stat().st_size
        _remove_tree(project_dir)
        if project_dir.exists():
            raise DaengsError("Projektordner konnte nicht vollständig gelöscht werden")
        log = self.data_dir / "_protokoll"
        log.mkdir(exist_ok=True)
        entry = {
            "zeit": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "ereignis": "projekt_geloescht",
            "dateien": files,
            "bytes": size,
        }
        with open(log / "loeschungen.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
        return {"dateien": files, "bytes": size}

    def _check_folder(self, folder: Path) -> Path:
        if not folder.is_absolute():
            raise DaengsError("Ordner muss als vollständiger Pfad angegeben werden")
        resolved = folder.resolve()
        if not resolved.is_dir():
            raise DaengsError("Ordner existiert nicht")
        # Daengs writes only into its data location and never into customer folders (09 §4).
        if is_within(resolved, self.data_dir) or is_within(self.data_dir, resolved):
            raise PathNotAllowedError(f"Ordner überschneidet sich mit dem Datenort von {PRODUCT}")
        return resolved


def _remove_tree(path: Path, attempts: int = 5) -> None:
    """rmtree that clears read-only flags and retries briefly (virus scanners hold files)."""

    def clear_and_retry(function, target, _exc) -> None:
        os.chmod(target, stat.S_IWRITE)
        function(target)

    for attempt in range(attempts):
        try:
            shutil.rmtree(path, onexc=clear_and_retry)
            return
        except FileNotFoundError:
            return
        except PermissionError:
            if attempt == attempts - 1:
                raise DaengsError("Projektordner ist noch in Benutzung") from None
            time.sleep(0.2 * (attempt + 1))


def _clean_name(name: str) -> str:
    name = " ".join(name.split())
    if not name or len(name) > MAX_NAME:
        raise DaengsError(f"Projektname muss 1 bis {MAX_NAME} Zeichen lang sein")
    return name


def _bring_up_to_date(context: ProjectContext, version: int) -> None:
    """Older projects are migrated in one transaction; a newer one is left untouched."""
    if version > SCHEMA_VERSION:
        raise ProjectTooNewError(
            "Dieses Projekt stammt aus einer neueren Fassung. Bitte aktualisiere das Programm."
        )
    if version == SCHEMA_VERSION:
        return
    with context.transaction() as con:
        con.execute("begin immediate")  # sqlite3 starts none for "create table" by itself
        row = con.execute("select value from meta where key = 'schema_version'").fetchone()
        for step in range(int(row[0]), SCHEMA_VERSION):  # another thread may have been first
            MIGRATIONS[step](con)
        con.execute(
            "update meta set value = ? where key = 'schema_version'", (str(SCHEMA_VERSION),)
        )
    context.log_event("projekt_migriert", von=version, nach=SCHEMA_VERSION)


def _read(db_path: Path) -> tuple[dict[str, str], tuple[Path, ...]]:
    with closing(sqlite3.connect(f"{db_path.as_uri()}?mode=ro", uri=True)) as con:
        meta = dict(con.execute("select key, value from meta"))
        folders = tuple(Path(p) for (p,) in con.execute("select path from folder order by id"))
    return meta, folders
