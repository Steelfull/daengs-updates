"""Takes over an installation under the earlier working name (D-023, M8).

The Daengs installer runs ``pythonw.exe -I -m daengs.migrate --config daengs.toml`` after copying
its files; setup has waited until the old program was closed (both mutexes). Steps, each skipped
when there is nothing to do, so a second run changes nothing:

1. Projects: the old data location is moved (not copied) to Daengs' one, if that is still empty.
2. Extension: the old language-model extension is moved into the new program folder, if Daengs
   has none yet, and gets a new "Apps" entry that points to Daengs' Python.
3. Old program folder, its shortcuts, "Apps" entries and window profile are removed.

Delivery folders are never touched.
"""

import argparse
import contextlib
import os
import shutil
import sys
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from daengs import PRODUCT
from daengs.config import ConfigError, load_settings

# The earlier working name; the only place in the program where it still appears.
LEGACY = "Lisa"
LEGACY_MUTEX = f"{LEGACY}-laeuft-8b1e6c2a"
UNINSTALL_ROOT = r"Software\Microsoft\Windows\CurrentVersion\Uninstall"
EXTENSION_DIR = Path("erweiterungen") / "sprachmodell"


class Registry:
    """HKCU uninstall entries; replaced by a dictionary in tests."""

    def read(self, key: str) -> dict[str, object] | None:
        import winreg

        try:
            handle = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key)
        except FileNotFoundError:
            return None
        values = {}
        with handle:
            for i in range(winreg.QueryInfoKey(handle)[1]):
                name, value, _ = winreg.EnumValue(handle, i)
                values[name] = value
        return values

    def write(self, key: str, values: dict[str, object]) -> None:
        import winreg

        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key) as handle:
            for name, value in values.items():
                kind = winreg.REG_DWORD if isinstance(value, int) else winreg.REG_SZ
                winreg.SetValueEx(handle, name, 0, kind, value)

    def delete(self, key: str) -> None:
        import winreg

        with contextlib.suppress(FileNotFoundError):
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, key)


@dataclass
class Places:
    install_dir: Path  # the new program folder
    data_dir: Path  # the new project location (from daengs.toml)
    local_appdata: Path
    shortcuts: list[Path] = field(default_factory=list)  # old shortcuts

    @classmethod
    def current(cls, data_dir: Path) -> "Places":
        start_menu = Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu"
        desktop = Path(os.environ["USERPROFILE"]) / "Desktop"
        return cls(
            install_dir=Path(sys.executable).resolve().parent.parent,
            data_dir=data_dir,
            local_appdata=Path(os.environ["LOCALAPPDATA"]),
            shortcuts=[start_menu / "Programs" / f"{LEGACY}.lnk", desktop / f"{LEGACY}.lnk"],
        )


def _is_old_install(folder: Path, new: Path) -> bool:
    return (
        folder.is_dir()
        and (folder / "python" / "pythonw.exe").is_file()
        and (folder / f"{LEGACY.lower()}.toml").is_file()
        and folder.resolve() != new.resolve()
    )


def _redirected(places: Places) -> bool:
    """True when AppData is redirected into a package folder (Daengs or setup was started by a
    packaged app): moved projects would land where a normal start of Daengs never looks."""
    packages = (places.local_appdata / "Packages").resolve()
    target = places.data_dir.resolve()
    return target == packages or packages in target.parents


def take_over_projects(
    places: Places,
    remove_tree: Callable[[Path], None] = lambda p: shutil.rmtree(p, ignore_errors=True),
) -> int:
    """Move the projects of the earlier installation, one by one, never over an existing one.

    Also called at every start of Daengs (``__main__``): setup may have run where Windows
    redirects AppData (a packaged app started it), then the first normal start finishes the
    move. Returns how many projects were moved."""
    old_program_data = places.local_appdata / LEGACY
    old_projects = old_program_data / "Projekte"
    if not old_projects.is_dir() or _redirected(places):
        return 0
    places.data_dir.mkdir(parents=True, exist_ok=True)
    moved = 0
    for entry in sorted(old_projects.iterdir()):
        target = places.data_dir / entry.name
        if entry.name == "_tmp":
            remove_tree(entry)
        elif entry.name == "_protokoll" and entry.is_dir():
            target.mkdir(exist_ok=True)
            for log in entry.iterdir():  # deletion records: append, never lose one
                with open(target / log.name, "ab") as out:
                    out.write(log.read_bytes())
                log.unlink()
            entry.rmdir()
        elif not target.exists():
            shutil.move(str(entry), str(target))
            moved += 1
    if old_projects.is_dir() and not any(old_projects.iterdir()):
        old_projects.rmdir()
        remove_tree(old_program_data)  # window profile and temporary files only
    return moved


def _rewrite(value: object, old_dir: Path, new_dir: Path) -> object:
    if not isinstance(value, str):
        return value
    value = value.replace(str(old_dir), str(new_dir))
    value = value.replace(f"-m {LEGACY.lower()}.", f"-m {PRODUCT.lower()}.")
    return value.replace(LEGACY, PRODUCT)


def migrate(
    places: Places,
    registry: Registry,
    remove_tree: Callable[[Path], None] = lambda p: shutil.rmtree(p, ignore_errors=True),
) -> dict[str, bool]:
    """Take over an old installation. Returns which steps did something."""
    done = {"projekte": False, "erweiterung": False, "programm": False}
    old_key = rf"{UNINSTALL_ROOT}\{LEGACY}"
    old_ext_key = rf"{UNINSTALL_ROOT}\{LEGACY}-Sprachmodell"
    entry = registry.read(old_key) or {}
    location = entry.get("InstallLocation")
    candidates = [Path(location)] if isinstance(location, str) and location else []
    candidates.append(places.local_appdata / "Programs" / LEGACY)
    old_install = next((c for c in candidates if _is_old_install(c, places.install_dir)), None)

    old_program_data = places.local_appdata / LEGACY
    old_projects = old_program_data / "Projekte"
    done["projekte"] = take_over_projects(places, remove_tree) > 0

    if old_install is not None:
        old_ext = old_install / EXTENSION_DIR
        new_ext = places.install_dir / EXTENSION_DIR
        if old_ext.is_dir() and not new_ext.exists():
            new_ext.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(old_ext), str(new_ext))
            ext_entry = registry.read(old_ext_key) or {}
            registry.write(
                rf"{UNINSTALL_ROOT}\{PRODUCT}-Sprachmodell",
                {k: _rewrite(v, old_install, places.install_dir) for k, v in ext_entry.items()}
                | {
                    "DisplayName": f"{PRODUCT}-Sprachmodell",
                    "InstallLocation": str(new_ext),
                    "UninstallString": f'"{places.install_dir}\\python\\pythonw.exe" -I -m '
                    f"{PRODUCT.lower()}.uninstall --erweiterung sprachmodell",
                    "QuietUninstallString": f'"{places.install_dir}\\python\\pythonw.exe" -I -m '
                    f"{PRODUCT.lower()}.uninstall --erweiterung sprachmodell --still",
                },
            )
            done["erweiterung"] = True
        remove_tree(old_install)
        done["programm"] = True

    if old_install is not None or done["projekte"] or entry:
        for shortcut in places.shortcuts:
            shortcut.unlink(missing_ok=True)
        registry.delete(old_ext_key)
        registry.delete(old_key)
        if old_program_data.is_dir() and not old_projects.exists():
            remove_tree(old_program_data)  # window profile and temporary files only
    return done


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog=f"{PRODUCT.lower()}.migrate")
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        settings = load_settings(args.config)
    except ConfigError:
        return 2
    if sys.platform != "win32":
        return 0
    migrate(Places.current(settings.data_dir), Registry())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
