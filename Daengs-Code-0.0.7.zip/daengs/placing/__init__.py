"""Copying files into a delivery folder (M12, D-038): the one place in Daengs that writes there."""

from daengs.placing.place import PlaceError, place_file

__all__ = ["PlaceError", "place_file"]
