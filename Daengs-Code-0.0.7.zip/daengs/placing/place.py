"""Copies one file the user dropped into a delivery folder. Only ever adds a file.

Never overwrites, moves or deletes anything of the user's: the original stays where it is, a name
already taken becomes "Name (2).pdf". The copy goes to a temporary file first, which neither the
explorer nor the ingest looks at; only the finished copy gets its name. os.rename does not replace
an existing file on Windows, so a file appearing in the meantime is not lost either.
"""

import contextlib
import os
import shutil
import threading
import time
import uuid
from collections.abc import Callable
from pathlib import Path

from daengs.core import DaengsError

CHUNK = 1024 * 1024
SPARE_BYTES = 50 * 2**20  # the disk is not filled to the last byte
TEMP_PREFIX = (
    "~$daengs-"  # "~$" is skipped by the explorer and the ingest, like Office's lock files
)
TEMP_SUFFIX = ".tmp"
STALE_SECONDS = 24 * 3600
MAX_TRIES = 1000


class PlaceError(DaengsError):
    """This file could not be placed; the message says why, for the user."""


def _free_name(directory: Path, name: str, skip: int = 0) -> str:
    stem, suffix = os.path.splitext(name)
    for number in range(1 + skip, MAX_TRIES):
        candidate = name if number == 1 else f"{stem} ({number}){suffix}"
        if not os.path.lexists(directory / candidate):
            return candidate
    raise PlaceError("Zu viele Dateien mit diesem Namen")


def _sweep(directory: Path) -> None:
    """Our own temporary files left by a crash, in this folder only."""
    with contextlib.suppress(OSError):
        for entry in directory.glob(f"{TEMP_PREFIX}*{TEMP_SUFFIX}"):
            if time.time() - entry.stat().st_mtime > STALE_SECONDS:
                entry.unlink(missing_ok=True)


def place_file(
    source: Path,
    directory: Path,
    progress: Callable[[int, int], None] = lambda done, size: None,
    stop: threading.Event | None = None,
) -> str:
    """Copy ``source`` into ``directory``; returns the name it got there."""
    if source.is_symlink() or source.is_dir():
        raise PlaceError("Ganze Ordner werden nicht kopiert. Bitte die Dateien selbst ablegen.")
    if not source.is_file():
        raise PlaceError("Die Datei ist nicht mehr da")
    if source.parent.resolve() == directory.resolve():
        raise PlaceError("Die Datei liegt schon in diesem Ordner")
    try:
        size = source.stat().st_size
        free = shutil.disk_usage(directory).free
    except OSError as exc:
        raise PlaceError("Der Lieferordner ist nicht erreichbar") from exc
    if free < size + SPARE_BYTES:
        raise PlaceError("Nicht genug Platz im Lieferordner")
    _sweep(directory)
    temporary = directory / f"{TEMP_PREFIX}{uuid.uuid4().hex}{TEMP_SUFFIX}"
    try:
        _copy(source, temporary, size, progress, stop)
        times = source.stat()
        os.utime(temporary, ns=(times.st_atime_ns, times.st_mtime_ns))
        return _give_name(temporary, directory, source.name)
    except PermissionError as exc:
        raise PlaceError("Die Datei ist gerade gesperrt oder der Ordner schreibgeschützt") from exc
    except OSError as exc:
        raise PlaceError("Die Datei konnte nicht kopiert werden") from exc
    finally:
        with contextlib.suppress(OSError):
            temporary.unlink(missing_ok=True)


def _copy(source: Path, temporary: Path, size: int, progress, stop) -> None:
    done = 0
    with source.open("rb") as reader, temporary.open("xb") as writer:
        while chunk := reader.read(CHUNK):
            if stop is not None and stop.is_set():
                raise PlaceError("Abgebrochen")
            writer.write(chunk)
            done += len(chunk)
            progress(done, size)
        writer.flush()
        os.fsync(writer.fileno())
    if temporary.stat().st_size != source.stat().st_size:
        raise PlaceError("Die Datei wurde beim Kopieren verändert. Bitte noch einmal ablegen.")


def _give_name(temporary: Path, directory: Path, name: str) -> str:
    for skip in range(MAX_TRIES):
        final = _free_name(directory, name, skip)
        try:
            os.rename(temporary, directory / final)
            return final
        except FileExistsError:  # someone was quicker
            continue
    raise PlaceError("Zu viele Dateien mit diesem Namen")
