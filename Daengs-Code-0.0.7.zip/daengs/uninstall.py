"""Uninstall Daengs (F9, D-021) with Daengs's own Python instead of a separate uninstaller program.

Why: Windows Smart App Control blocks unsigned programs it does not know, and the uninstaller that
Inno Setup writes at install time is unknown by definition (found in the M6 Probelauf). Daengs's
Python is allowed, so the "Apps > Daengs > Deinstallieren" entry runs:
    pythonw.exe -I -m daengs.uninstall            (asks)
    pythonw.exe -I -m daengs.uninstall --still    (no questions; projects are deleted)
"""

import argparse
import contextlib
import os
import shutil
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from daengs import GLOBAL_WIKI_FOLDER, PRODUCT
from daengs.core.settings import PREFERENCES_FILE
from daengs.core.updates import FOLDER as UPDATE_FOLDER

UNINSTALL_KEY = rf"Software\Microsoft\Windows\CurrentVersion\Uninstall\{PRODUCT}"
# Extensions have their own "Apps" entry (D-022); removing Daengs removes them too.
EXTENSIONS = {"sprachmodell": UNINSTALL_KEY + "-Sprachmodell"}
MB_YESNO, MB_ICONQUESTION, MB_ICONINFORMATION, MB_DEFBUTTON2 = 0x4, 0x20, 0x40, 0x100
IDYES = 6
SYSTEM_ROOT = os.environ.get("SYSTEMROOT", r"C:\Windows")

Ask = Callable[[str, bool], bool]  # (question, default yes) -> answer


@dataclass
class Places:
    install_dir: Path
    local_appdata: Path
    shortcuts: list[Path] = field(default_factory=list)

    @property
    def program_data(self) -> Path:
        return self.local_appdata / PRODUCT

    @property
    def global_wiki(self) -> Path:
        return self.program_data / GLOBAL_WIKI_FOLDER

    @classmethod
    def current(cls) -> "Places":
        install = Path(sys.executable).resolve().parent.parent  # <install>/python/pythonw.exe
        appdata = Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
        desktop = Path(os.environ["USERPROFILE"]) / "Desktop"
        return cls(
            install_dir=install,
            local_appdata=Path(os.environ["LOCALAPPDATA"]),
            shortcuts=[appdata / f"{PRODUCT}.lnk", desktop / f"{PRODUCT}.lnk"],
        )


def message_box(text: str, flags: int) -> int:
    import ctypes

    return ctypes.windll.user32.MessageBoxW(None, text, f"{PRODUCT} deinstallieren", flags)


def ask_with_box(question: str, default_yes: bool) -> bool:
    flags = MB_YESNO | MB_ICONQUESTION | (0 if default_yes else MB_DEFBUTTON2)
    return message_box(question, flags) == IDYES


def is_running() -> bool:
    if sys.platform != "win32":
        return False
    import ctypes

    from daengs import RUNNING_MUTEX

    synchronize = 0x00100000
    handle = ctypes.windll.kernel32.OpenMutexW(synchronize, False, RUNNING_MUTEX)
    if handle:
        ctypes.windll.kernel32.CloseHandle(handle)
        return True
    return False


def remove_registry_entry(*keys: str) -> None:
    if sys.platform != "win32":
        return
    import winreg

    for key in keys or (UNINSTALL_KEY, *EXTENSIONS.values()):
        with contextlib.suppress(FileNotFoundError):
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, key)


def remove_later(folder: Path) -> None:
    """The running Python lives in ``folder``: a detached cmd removes it once Python has exited."""
    cmd = os.path.join(SYSTEM_ROOT, "System32", "cmd.exe")
    # Passed verbatim: /s makes cmd strip only the outer quotes, the folder keeps its own.
    command = f'"{cmd}" /s /c "ping -n 4 127.0.0.1 >nul & rmdir /s /q "{folder}""'
    detached, no_window = 0x00000008, 0x08000000
    subprocess.Popen(  # noqa: S603 - fixed system program, path from our own installation
        command, creationflags=detached | no_window, close_fds=True, cwd=SYSTEM_ROOT
    )


def uninstall(
    places: Places,
    ask: Ask,
    remove_install_dir: Callable[[Path], None] = remove_later,
    remove_registry: Callable[[], None] = remove_registry_entry,
) -> dict[str, bool]:
    """Remove Daengs. Delivery folders are never touched. Returns what was removed."""
    if not ask(f"{PRODUCT} von diesem Rechner entfernen?", True):
        return {"entfernt": False, "projekte": False, "gesamtwiki": False}
    projects = ask(
        f"Auch alle Projekte von {PRODUCT} löschen?\n\n"
        "Gelöscht werden Suchindex, Übersicht und Wiki aller Projekte. "
        "Deine Lieferordner mit den Kundendateien bleiben unverändert.\n\n"
        f"Wähl „Nein“ nur, wenn du {PRODUCT} gleich wieder installieren möchtest.",
        True,
    )
    global_wiki = places.global_wiki.is_dir() and ask(
        "Auch das Gesamt-Wiki löschen?\n\n"
        "Es gilt für alle Projekte und enthält deine Regeln, dein Glossar und dein Vorgehen.\n\n"
        f"Wähl „Nein“, wenn du es bei einer neuen Installation von {PRODUCT} "
        "wieder nutzen möchtest.",
        projects,
    )
    for shortcut in places.shortcuts:
        shortcut.unlink(missing_ok=True)
    remove_registry()
    if global_wiki:
        _rmtree(places.global_wiki)
    if projects and not places.global_wiki.is_dir():
        _rmtree(places.program_data)
    elif projects:
        for entry in places.program_data.iterdir():
            if entry != places.global_wiki:
                _rmtree(entry) if entry.is_dir() else entry.unlink(missing_ok=True)
    else:
        _rmtree(places.program_data / "fenster")
        _rmtree(places.program_data / "Projekte" / "_tmp")
        _rmtree(places.program_data / UPDATE_FOLDER)
        (places.program_data / PREFERENCES_FILE).unlink(missing_ok=True)
    remove_install_dir(places.install_dir)
    return {"entfernt": True, "projekte": projects, "gesamtwiki": global_wiki}


def uninstall_extension(
    places: Places,
    name: str,
    ask: Ask,
    remove_registry: Callable[..., None] = remove_registry_entry,
) -> bool:
    """Remove one extension; Daengs and the projects stay. Chat histories stay in the projects."""
    if name not in EXTENSIONS:
        raise ValueError("unbekannte Erweiterung")
    if not ask(f"Die Erweiterung {PRODUCT}-Sprachmodell entfernen? {PRODUCT} selbst bleibt.", True):
        return False
    _rmtree(places.install_dir / "erweiterungen" / name)
    remove_registry(EXTENSIONS[name])
    return True


def _rmtree(path: Path) -> None:
    for attempt in range(5):
        try:
            shutil.rmtree(path)
            return
        except FileNotFoundError:
            return
        except PermissionError:
            time.sleep(0.3 * (attempt + 1))
    shutil.rmtree(path, ignore_errors=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="daengs.uninstall")
    parser.add_argument("--still", action="store_true", help="ohne Rückfragen, alles löschen")
    parser.add_argument("--erweiterung", choices=sorted(EXTENSIONS), help="nur diese Erweiterung")
    args = parser.parse_args(argv)
    if is_running():
        if not args.still:
            message_box(
                f"{PRODUCT} läuft noch. Bitte {PRODUCT} zuerst schließen.", MB_ICONINFORMATION
            )
        return 3
    ask = (lambda question, default_yes: default_yes) if args.still else ask_with_box
    if args.erweiterung:
        if uninstall_extension(Places.current(), args.erweiterung, ask) and not args.still:
            message_box("Die Erweiterung wurde entfernt.", MB_ICONINFORMATION)
        return 0
    result = uninstall(Places.current(), ask)
    if result["entfernt"] and not args.still:
        message_box(f"{PRODUCT} wurde entfernt.", MB_ICONINFORMATION)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
