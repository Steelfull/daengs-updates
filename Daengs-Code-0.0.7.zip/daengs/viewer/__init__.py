"""Viewer: page image with marked hit, open the original at the right page (F4)."""

from daengs.viewer.opener import open_at_page
from daengs.viewer.page import PageMarks, PageView

__all__ = ["PageMarks", "PageView", "open_at_page"]
