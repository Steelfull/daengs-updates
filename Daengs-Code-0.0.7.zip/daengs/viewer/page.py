"""Page view (F4): page image and marks for a hit, from the project's own files only.

Reads the ingest tables ``file``, ``page`` and ``chunk`` by SQL (see daengs.search.schema).
Boxes are fractions of the page (x0, y0, x1, y1 from the top left), so the UI can scale freely.
"""

import contextlib
import ctypes
import io
import json
import re
import uuid
from dataclasses import dataclass, field
from pathlib import Path

import pypdfium2 as pdfium
import pypdfium2.raw as raw

from daengs.core import PDFIUM_LOCK, DaengsError, ProjectContext

Box = tuple[float, float, float, float]

MIN_WIDTH, MAX_WIDTH, WIDTH_STEP = 400, 2400, 200
_DEVICE = 10000  # virtual device size for coordinate conversion
_WORD = re.compile(r"\S+")


@dataclass(frozen=True)
class PageMarks:
    file_id: int
    rel_path: str
    page_no: int
    page_count: int
    source: str
    aspect: float  # height / width of the page as displayed
    region: list[Box] = field(default_factory=list)  # the hit's chunk
    terms: list[Box] = field(default_factory=list)  # query terms on the page
    # Word and Excel (A-35): no page image; the UI shows the text lines or the cells, marks the
    # lines of the hit's chunk (region_lines) and the query terms itself.
    label: str = ""
    lines: list[str] | None = None
    cells: list | None = None
    region_lines: list[int] = field(default_factory=list)


class PageView:
    def __init__(self, context: ProjectContext) -> None:
        self.context = context
        self._preview = context.project_dir / "vorschau"

    def _file(self, file_id: int, page_no: int) -> tuple[Path, str, int, int]:
        with self.context.transaction() as con:
            row = con.execute(
                "select folder, rel_path, page_count, version from file"
                " where id = ? and status = 'ok'",
                (file_id,),
            ).fetchone()
        if row is None or not 1 <= page_no <= row[2]:
            raise DaengsError("Seite nicht gefunden")
        folder, rel_path, page_count, version = row
        # Only files inside the granted folders; a revoked folder is no longer readable.
        return self.context.readable(Path(folder) / rel_path), rel_path, page_count, version

    def _text_marks(
        self, file_id: int, rel_path: str, page_no: int, page_count: int, chunk_id: int | None
    ) -> PageMarks:
        with self.context.transaction() as con:
            text, label, cells = con.execute(
                "select text, label, cells from page where file_id = ? and page_no = ?",
                (file_id, page_no),
            ).fetchone()
            span = None
            if chunk_id is not None:
                span = con.execute(
                    "select word_start, word_end from chunk"
                    " where id = ? and file_id = ? and page_no = ? and word_start is not null",
                    (chunk_id, file_id, page_no),
                ).fetchone()
        lines = text.split("\n")
        region = []
        if span:
            position = 0
            for i, line in enumerate(lines):
                count = len(line.split())
                if count and position < span[1] and position + count > span[0]:
                    region.append(i)
                position += count
        kind = Path(rel_path).suffix.lower().lstrip(".")
        return PageMarks(
            file_id, rel_path, page_no, page_count, kind, 0.0, label=label or "",
            lines=None if cells else lines, cells=json.loads(cells) if cells else None,
            region_lines=region,
        )  # fmt: skip

    def original(self, file_id: int, page_no: int) -> Path:
        return self._file(file_id, page_no)[0]

    def image(self, file_id: int, page_no: int, width: int) -> bytes:
        """PNG of the page, ``width`` rounded to steps; cached in the project's preview folder."""
        if self._file(file_id, page_no)[0].suffix.lower() != ".pdf":
            raise DaengsError("Für diese Datei gibt es kein Seitenbild")
        path, _, _, version = self._file(file_id, page_no)
        width = max(MIN_WIDTH, min(MAX_WIDTH, round(width / WIDTH_STEP) * WIDTH_STEP))
        cached = self._preview / f"{file_id}_{version}_{page_no}_{width}.png"
        try:
            return cached.read_bytes()
        except OSError:
            pass  # not cached yet, or another request is just writing it
        with PDFIUM_LOCK:
            pdf = pdfium.PdfDocument(path)
            try:
                page = pdf[page_no - 1]
                bitmap = page.render(scale=width / page.get_width())
                image = bitmap.to_pil().copy()  # own pixels, independent of PDFium memory
                bitmap.close()
                page.close()
            finally:
                pdf.close()
        buffer = io.BytesIO()
        image.save(buffer, format="PNG", compress_level=1)
        data = buffer.getvalue()
        # The cache is best effort: parallel requests may race for the same file on Windows.
        tmp = cached.with_name(f"{cached.stem}.{uuid.uuid4().hex}.tmp")
        try:
            self._preview.mkdir(exist_ok=True)
            tmp.write_bytes(data)
            tmp.replace(cached)
        except OSError:
            # Deleting can fail the same way (folder going away, virus scanner): still answer.
            with contextlib.suppress(OSError):
                tmp.unlink(missing_ok=True)
        return data

    def marks(
        self, file_id: int, page_no: int, chunk_id: int | None = None, terms: list[str] = ()
    ) -> PageMarks:
        path, rel_path, page_count, _ = self._file(file_id, page_no)
        if path.suffix.lower() != ".pdf":
            return self._text_marks(file_id, rel_path, page_no, page_count, chunk_id)
        with self.context.transaction() as con:
            source, text, ocr_lines = con.execute(
                "select source, text, ocr_lines from page where file_id = ? and page_no = ?",
                (file_id, page_no),
            ).fetchone()
            span = None
            if chunk_id is not None:
                span = con.execute(
                    "select word_start, word_end from chunk"
                    " where id = ? and file_id = ? and page_no = ? and word_start is not null",
                    (chunk_id, file_id, page_no),
                ).fetchone()
        terms = [t for t in terms if len(t) >= 2]
        with PDFIUM_LOCK:
            pdf = pdfium.PdfDocument(path)
            try:
                page = pdf[page_no - 1]
                width, height = page.get_size()
                marks = PageMarks(file_id, rel_path, page_no, page_count, source, height / width)
                if source == "text_layer":
                    _text_layer_marks(page, text, span, terms, marks)
                page.close()
            finally:
                pdf.close()
        if source == "ocr" and ocr_lines:
            _ocr_marks(text, json.loads(ocr_lines), span, terms, marks)
        return marks


# Shorter terms are marked only as whole words: "ins" not inside "Instandsetzung" (M8); the same
# rule as markRanges in ui/static/logic.js.
WHOLE_WORD_BELOW = 4


def _term_pattern(term: str) -> re.Pattern:
    if len(term) < WHOLE_WORD_BELOW:
        return re.compile(rf"(?<!\w){re.escape(term)}(?!\w)", re.IGNORECASE)
    return re.compile(re.escape(term), re.IGNORECASE)


def _text_layer_marks(page, text: str, span, terms: list[str], marks: PageMarks) -> None:
    """Caller holds PDFIUM_LOCK; every PDFium object is closed before it is released."""
    textpage = page.get_textpage()
    try:
        if span:
            words = list(_WORD.finditer(text))
            start, end = span
            if 0 <= start < end <= len(words):
                first, last = words[start].start(), words[end - 1].end()
                marks.region.extend(_char_rects(page, textpage, first, last - first))
        for term in terms:
            whole = len(term) < WHOLE_WORD_BELOW
            searcher = textpage.search(term, match_case=False, match_whole_word=whole)
            try:
                while (found := searcher.get_next()) is not None and len(marks.terms) <= 200:
                    index, count = found
                    marks.terms.extend(_char_rects(page, textpage, index, count))
            finally:
                searcher.close()
    finally:
        textpage.close()


def _char_rects(page, textpage, index: int, count: int) -> list[Box]:
    result = []
    for k in range(textpage.count_rects(index, count)):
        left, bottom, right, top = textpage.get_rect(k)
        x0, y0 = _to_fraction(page, left, top)
        x1, y1 = _to_fraction(page, right, bottom)
        result.append((min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)))
    return result


def _to_fraction(page, x: float, y: float) -> tuple[float, float]:
    """PDF point to fraction of the displayed page; handles crop box and page rotation."""
    dx, dy = ctypes.c_int(), ctypes.c_int()
    raw.FPDF_PageToDevice(page.raw, 0, 0, _DEVICE, _DEVICE, 0, x, y, dx, dy)
    return dx.value / _DEVICE, dy.value / _DEVICE


def _ocr_marks(text: str, boxes: list, span, terms: list[str], marks: PageMarks) -> None:
    lines = text.split("\n")
    if len(lines) != len(boxes):
        return
    if span:
        start, end = span
        position = 0
        for line, box in zip(lines, boxes, strict=True):
            count = len(line.split())
            if count and position < end and position + count > start:
                marks.region.append(tuple(box))
            position += count
    patterns = [_term_pattern(t) for t in terms]
    for line, box in zip(lines, boxes, strict=True):
        if any(p.search(line) for p in patterns):
            marks.terms.append(tuple(box))
