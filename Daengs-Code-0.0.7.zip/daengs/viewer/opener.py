"""Open the original PDF in the user's own PDF program, at the right page if it can (F4)."""

import ctypes
import os
import subprocess
import sys
from collections.abc import Callable
from pathlib import Path

# Command line for programs that can jump to a page; {page}, {path}, {uri} are filled in.
PAGE_ARGS: dict[str, list[str]] = {
    "acrobat.exe": ["/A", "page={page}", "{path}"],
    "acrord32.exe": ["/A", "page={page}", "{path}"],
    "foxitpdfreader.exe": ["/A", "page={page}", "{path}"],
    "foxitreader.exe": ["/A", "page={page}", "{path}"],
    "foxitpdfeditor.exe": ["/A", "page={page}", "{path}"],
    "pdfxedit.exe": ["/A", "page={page}", "{path}"],
    "sumatrapdf.exe": ["-page", "{page}", "{path}"],
    "msedge.exe": ["{uri}#page={page}"],
    "chrome.exe": ["{uri}#page={page}"],
    "firefox.exe": ["{uri}#page={page}"],
}


def default_pdf_program() -> Path | None:
    """Executable registered for .pdf files (Windows), or None."""
    if sys.platform != "win32":
        return None
    size = ctypes.c_ulong(1024)
    buffer = ctypes.create_unicode_buffer(size.value)
    assoc_str_executable = 2
    result = ctypes.windll.shlwapi.AssocQueryStringW(
        0, assoc_str_executable, ".pdf", "open", buffer, ctypes.byref(size)
    )
    return Path(buffer.value) if result == 0 and buffer.value else None


def command_for(program: Path | None, path: Path, page: int) -> list[str] | None:
    """Arguments to open ``path`` at ``page`` with ``program``; None if it cannot jump to pages."""
    if program is None or program.name.lower() not in PAGE_ARGS:
        return None
    values = {"page": str(page), "path": str(path), "uri": path.as_uri()}
    return [str(program), *(arg.format(**values) for arg in PAGE_ARGS[program.name.lower()])]


def open_at_page(
    path: Path,
    page: int,
    program: Path | None = None,
    run: Callable[[list[str]], object] | None = None,
    start: Callable[[str], object] | None = None,
) -> bool:
    """Open the file; True if the program was told the page. Never through a shell.

    Word, Excel and every other file open in their own program, without a page (M8)."""
    if path.suffix.lower() != ".pdf":
        (start or _startfile)(str(path))
        return False
    command = command_for(program if program is not None else default_pdf_program(), path, page)
    if command is not None:
        (run or _popen)(command)
        return True
    (start or _startfile)(str(path))
    return False


def _popen(command: list[str]) -> None:
    subprocess.Popen(command, close_fds=True)  # noqa: S603 - fixed program, list arguments


def _startfile(path: str) -> None:
    os.startfile(path)  # noqa: S606 - opens the file with its registered program
