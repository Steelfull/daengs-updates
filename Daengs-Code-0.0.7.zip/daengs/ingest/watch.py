"""When a new or changed file in the delivery may be read in by itself (M12, A-42).

The app looks at the folder listing regularly. A file still being copied must not be read: it only
counts once its size and time held over two looks and it can be opened (Explorer holds a file open
while copying, even when it reserved the full size at once). A file somebody keeps locked does not
hold up the others; it comes in when it is free again.
"""

from collections.abc import Iterable
from pathlib import Path

from daengs.ingest.inventory import CHANGED, NEW, FileEntry

Key = tuple[str, str, int, int]


def _can_open(entry: FileEntry) -> bool:
    try:
        with (Path(entry.folder) / entry.rel_path).open("rb"):
            return True
    except OSError:
        return False


class FileWatch:
    """One per open project; remembers the last look and what was already started for."""

    def __init__(self) -> None:
        self._last: set[Key] = set()
        self._started: set[Key] = set()

    def should_start(self, files: Iterable[FileEntry]) -> bool:
        pending = {
            (f.folder, f.rel_path, f.size, f.mtime_ns): f
            for f in files
            if f.state in (NEW, CHANGED)
        }
        current = set(pending)
        unsettled = current - self._last
        self._last = current
        if not current or unsettled:
            return False
        # Files that are free now and were not started for yet; the failed ones are not retried
        # until they change, so nothing runs again and again.
        ready = {key for key in current - self._started if _can_open(pending[key])}
        self._started &= current
        if not ready:
            return False
        self._started |= ready
        return True
