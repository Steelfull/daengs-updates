"""Pure text helpers: chunks, document title, OCR line order (taken over from praxistest)."""

import re
from collections.abc import Sequence

Box = tuple[float, float, float, float]


def clean_hyphens(text: str) -> str:
    """PDFium marks hyphenation points with U+FFFE: "Steckverbin\ufffe der" is one word."""
    return text.replace("\ufffe ", "").replace("\ufffe", "")


def chunk_spans(text: str, words_per_chunk: int, overlap: int) -> list[tuple[int, int]]:
    """Word index ranges [start, end) of the chunks of one page; the page is a hard boundary."""
    count = len(text.split())
    if not count:
        return []
    step = words_per_chunk - overlap
    return [
        (start, min(start + words_per_chunk, count))
        for start in range(0, max(count - overlap, 1), step)
    ]


def chunk_page(text: str, words_per_chunk: int, overlap: int) -> list[str]:
    """Word windows with overlap inside one page (06 §2)."""
    words = text.split()
    return [" ".join(words[a:b]) for a, b in chunk_spans(text, words_per_chunk, overlap)]


# Bump when the way titles are built changes: older projects get new titles when they are opened.
TITLE_RULE = 3
USE_PDF_TITLE = True

_WORD = re.compile(r"[^\W\d_]{3,}")
_CONTACT = re.compile(r"@|https?://|www\.|\b(?:tel|fax|phone|telefon)\b|\+\d[\d /()-]{6,}", re.I)
_BAD_META = re.compile(
    r"^(microsoft (word|excel|powerpoint)\b.*|untitled.*|unbenannt.*|document\d*|dokument\d*)$",
    re.I,
)
_FILE_NAME = re.compile(r"\.(pdf|docx?|xlsx?|indd|pptx?|tmp|txt)$", re.I)


def has_words(line: str) -> bool:
    """A line that says something: a word of letters, not just digits, codes, phone or mail."""
    if _CONTACT.search(line) or not _WORD.search(line):
        return False
    letters = sum(c.isalpha() for c in line)
    return letters >= 0.5 * len(line.replace(" ", ""))


def meta_title_ok(meta: str, stem: str = "") -> str:
    """The PDF metadata title if it is a real title: not empty, not a file name, no Word default."""
    meta = " ".join(meta.split())
    if not meta or _BAD_META.match(meta) or _FILE_NAME.search(meta):
        return ""
    if stem and meta.lower().replace("_", " ") == stem.lower().replace("_", " "):
        return ""
    return meta


_STOP = frozenset(
    "this that with from have your into over under about nach oder eine einer eines einem einen "
    "dass sind sein wird werden auch noch nicht beim zum zur für fuer von dem den der die das "
    "und mit aber wenn sich dies diese dieser manual document dokument file datei".split()
)


def meta_fits(meta: str, text: str) -> bool:
    """Does a content word of the metadata title (4+ letters, no stop word, no number or code
    alone) stand in the text of the first pages? Else it is a template leftover."""
    present = {w.lower() for w in re.findall(r"[^\W\d_]{4,}", text)}
    return any(
        w.lower() in present and w.lower() not in _STOP for w in re.findall(r"[^\W\d_]{4,}", meta)
    )


def title_from(text: str, rich: bool = False, meta: str = "") -> str:
    """Document title from the first page with text.

    Plain (Word, Excel): first four non-empty lines, at most 150 characters.
    Rich (PDF): up to eight lines with words (codes, numbers, phone and address-like lines are
    skipped), at most 300 characters, the metadata title in front if there is one."""
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not rich:
        return " ".join(lines[:4])[:150]
    title = " ".join([line for line in lines if has_words(line)][:8])
    if meta and meta.lower() not in title.lower():
        title = f"{meta} · {title}" if title else meta
    return title[:300]


def group_lines(
    boxes: Sequence[Sequence[Sequence[float]]], texts: Sequence[str]
) -> list[tuple[str, Box]]:
    """Group OCR fields into lines (by height, tolerance half a field), then left to right.

    Returns each line's text and its bounding box (x0, y0, x1, y1) in image pixels.
    """
    fields = []
    for box, text in zip(boxes, texts, strict=True):
        ys = [p[1] for p in box]
        xs = [p[0] for p in box]
        bbox = (min(xs), min(ys), max(xs), max(ys))
        fields.append(((min(ys) + max(ys)) / 2, max(ys) - min(ys), min(xs), text, bbox))
    fields.sort(key=lambda f: f[:4])
    lines: list[list[tuple[float, str, Box]]] = []
    current: list[tuple[float, str, Box]] = []
    middle, height = 0.0, 0.0
    for y, h, x, text, bbox in fields:
        if current and abs(y - middle) > max(height, h) / 2:
            lines.append(current)
            current = []
        if not current:
            middle, height = y, h
        current.append((x, text, bbox))
    if current:
        lines.append(current)
    result = []
    for line in lines:
        line.sort(key=lambda f: f[:2])
        b = [f[2] for f in line]
        bbox = (
            min(x[0] for x in b),
            min(x[1] for x in b),
            max(x[2] for x in b),
            max(x[3] for x in b),
        )
        result.append((" ".join(f[1] for f in line), bbox))
    return result


def order_lines(boxes: Sequence[Sequence[Sequence[float]]], texts: Sequence[str]) -> str:
    """OCR fields as reading text, one line per row (same result as praxistest/schlank.py)."""
    return "\n".join(text for text, _ in group_lines(boxes, texts))
