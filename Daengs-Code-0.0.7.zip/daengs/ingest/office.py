"""Text of Word (DOCX) and Excel (XLSX) files for the search (A-35, D-024), standard library only.

Both formats are ZIP archives of XML parts. Read with zipfile and xml.etree, so no further
library (and no libxml2) comes into the package. Hardened against crafted files: a part with a
DTD is refused (OOXML never has one, entity tricks need it), unpacked sizes and cell counts are
capped. Macros, embedded objects, links and external data are never touched.

A Word file becomes one part per section (heading level 1-3), long sections split further;
an Excel file one part per block of rows of a sheet. Each part has a label for the hit list
("Abschnitt „Wartung“", "Blatt „Teile“, Zeilen 21-40"); Excel parts keep their cells for the
preview and the cell of a hit.
"""

import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET

MAX_PART_BYTES = 200 * 1024 * 1024  # one unpacked XML part
MAX_CELLS = 2_000_000
HEADING_LEVELS = 3  # headings up to this level start a new section

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PR = "{http://schemas.openxmlformats.org/package/2006/relationships}"


class OfficeError(Exception):
    """File cannot be read as DOCX or XLSX (damaged, encrypted, too large, not allowed)."""


@dataclass
class Part:
    label: str
    text: str
    cells: list[tuple[int, list[tuple[str, str]]]] | None = field(default=None)


def _xml(archive: zipfile.ZipFile, name: str) -> ET.Element | None:
    try:
        info = archive.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MAX_PART_BYTES:
        raise OfficeError("Teil zu groß")
    with archive.open(info) as f:
        data = f.read(MAX_PART_BYTES + 1)
    if len(data) > MAX_PART_BYTES:
        raise OfficeError("Teil zu groß")
    if b"<!DOCTYPE" in data[:4096] or b"<!ENTITY" in data:
        raise OfficeError("Dokumenttyp nicht erlaubt")
    try:
        return ET.fromstring(data)  # noqa: S314 - no DTD (checked above), size capped
    except ET.ParseError as exc:
        raise OfficeError("XML fehlerhaft") from exc


def _open(path: Path) -> zipfile.ZipFile:
    try:
        return zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as exc:
        # Encrypted Office files are not ZIP archives at all.
        raise OfficeError("kein lesbares Office-Dokument") from exc


def _split(label: str, lines: list[str], words: int) -> list[Part]:
    """Lines into parts of about ``words`` words; the label gets "(Teil n)" when split."""
    parts, current, count = [], [], 0
    for line in lines:
        n = len(line.split())
        if current and count + n > words:
            parts.append(current)
            current, count = [], 0
        current.append(line)
        count += n
    if current:
        parts.append(current)
    if len(parts) == 1:
        return [Part(label, "\n".join(parts[0]))]
    return [Part(f"{label} (Teil {i})", "\n".join(p)) for i, p in enumerate(parts, start=1)]


# -- Word ---------------------------------------------------------------------------------------


def _heading_styles(archive: zipfile.ZipFile) -> dict[str, int]:
    """styleId -> heading level, from the style name ("heading 2") or its outline level."""
    levels: dict[str, int] = {}
    root = _xml(archive, "word/styles.xml")
    if root is None:
        return levels
    for style in root.iter(f"{W}style"):
        style_id = style.get(f"{W}styleId")
        name = style.find(f"{W}name")
        outline = style.find(f"{W}pPr/{W}outlineLvl")
        level = None
        if name is not None:
            match = re.fullmatch(r"heading (\d)", (name.get(f"{W}val") or "").lower())
            if match:
                level = int(match.group(1))
        if level is None and outline is not None:
            level = int(outline.get(f"{W}val", "9")) + 1
        if style_id and level:
            levels[style_id] = level
    return levels


def _paragraph_text(p: ET.Element) -> str:
    out = []
    for node in p.iter():
        tag = node.tag
        if tag == f"{W}t":
            out.append(node.text or "")
        elif tag in (f"{W}tab", f"{W}br", f"{W}cr"):
            out.append(" ")
        elif tag == f"{W}noBreakHyphen":
            out.append("-")
    return "".join(out).strip()


def _inside_deleted(p: ET.Element) -> bool:
    return p.find(f".//{W}delText") is not None and p.find(f".//{W}t") is None


def _level(p: ET.Element, styles: dict[str, int]) -> int | None:
    own = p.find(f"{W}pPr/{W}outlineLvl")
    if own is not None:
        return int(own.get(f"{W}val", "9")) + 1
    style = p.find(f"{W}pPr/{W}pStyle")
    return styles.get(style.get(f"{W}val")) if style is not None else None


def read_docx(path: Path, words_per_part: int = 600) -> list[Part]:
    with _open(path) as archive:
        styles = _heading_styles(archive)
        root = _xml(archive, "word/document.xml")
    if root is None:
        raise OfficeError("kein Word-Dokument")
    body = root.find(f"{W}body")
    sections: list[tuple[str, list[str]]] = [("Anfang", [])]
    path_of_headings: list[str] = []  # e.g. ["Wartung", "Ölwechsel"]

    def walk(element: ET.Element) -> None:
        for child in element:
            if child.tag == f"{W}p":
                text = _paragraph_text(child)
                if not text or _inside_deleted(child):
                    continue
                level = _level(child, styles)
                if level is not None and level <= HEADING_LEVELS:
                    del path_of_headings[level - 1 :]
                    path_of_headings.append(text[:120])
                    # A heading with nothing below it before the next one is no section of its
                    # own; its text lives on in the path of the next ("Wartung › Ölwechsel").
                    if len(sections) > 1 and len(sections[-1][1]) == 1:
                        sections.pop()
                    heading = " › ".join(path_of_headings)
                    sections.append((heading, [heading]))
                else:
                    sections[-1][1].append(text)
            elif child.tag == f"{W}tbl":
                for row in child.iter(f"{W}tr"):
                    cells = [
                        " ".join(t for p in tc.iter(f"{W}p") if (t := _paragraph_text(p)))
                        for tc in row.iter(f"{W}tc")
                    ]
                    if any(cells):
                        sections[-1][1].append(" | ".join(c for c in cells if c))
            elif child.tag in (f"{W}sdt", f"{W}sdtContent", f"{W}customXml", f"{W}ins"):
                walk(child)

    if body is not None:
        walk(body)
    parts = []
    for heading, lines in sections:
        if lines:
            label = "Anfang" if heading == "Anfang" else f"Abschnitt „{heading}“"
            parts.extend(_split(label, lines, words_per_part))
    return parts


# -- Excel --------------------------------------------------------------------------------------

_CELL = re.compile(r"([A-Z]{1,3})(\d{1,7})")


def _shared_strings(archive: zipfile.ZipFile) -> list[str]:
    root = _xml(archive, "xl/sharedStrings.xml")
    if root is None:
        return []
    return ["".join(t.text or "" for t in si.iter(f"{S}t")) for si in root.iter(f"{S}si")]


def _sheets(archive: zipfile.ZipFile) -> list[tuple[str, str]]:
    """(sheet name, part name) in workbook order."""
    workbook = _xml(archive, "xl/workbook.xml")
    rels = _xml(archive, "xl/_rels/workbook.xml.rels")
    if workbook is None or rels is None:
        raise OfficeError("keine Excel-Mappe")
    targets = {r.get("Id"): r.get("Target", "") for r in rels.iter(f"{PR}Relationship")}
    sheets = []
    for sheet in workbook.iter(f"{S}sheet"):
        target = targets.get(sheet.get(f"{R}id"), "")
        if not target or "://" in target:
            continue  # external targets are never followed
        name = target.lstrip("/") if target.startswith("/") else f"xl/{target}"
        sheets.append((sheet.get("name") or "Blatt", name.replace("\\", "/")))
    return sheets


def _value(cell: ET.Element, strings: list[str]) -> str:
    kind = cell.get("t")
    if kind == "inlineStr":
        return "".join(t.text or "" for t in cell.iter(f"{S}t")).strip()
    v = cell.find(f"{S}v")
    if v is None or v.text is None:
        return ""
    if kind == "s":
        index = int(v.text)
        return strings[index].strip() if 0 <= index < len(strings) else ""
    if kind == "b":
        return "WAHR" if v.text == "1" else "FALSCH"
    text = v.text.strip()
    if kind in (None, "n") and re.fullmatch(r"-?\d+\.0+", text):
        text = text.split(".")[0]
    return text


def read_xlsx(path: Path, words_per_part: int = 200) -> list[Part]:
    parts: list[Part] = []
    cells_seen = 0
    with _open(path) as archive:
        strings = _shared_strings(archive)
        for sheet_name, part_name in _sheets(archive):
            root = _xml(archive, part_name)
            if root is None:
                continue
            rows: list[tuple[int, list[tuple[str, str]]]] = []
            for row in root.iter(f"{S}row"):
                values = []
                for cell in row.iter(f"{S}c"):
                    cells_seen += 1
                    if cells_seen > MAX_CELLS:
                        raise OfficeError("zu viele Zellen")
                    match = _CELL.fullmatch(cell.get("r") or "")
                    value = _value(cell, strings)
                    if match and value:
                        values.append((match.group(1), value))
                if values:
                    rows.append((int(row.get("r") or len(rows) + 1), values))
            parts.extend(_row_blocks(sheet_name, rows, words_per_part))
    return parts


def _row_blocks(
    sheet: str, rows: list[tuple[int, list[tuple[str, str]]]], words: int
) -> list[Part]:
    """Rows in blocks of about ``words`` words, one search chunk each; the header row of the
    sheet (its first row) is repeated at the top of every later block for context."""
    blocks, current, count = [], [], 0
    for row in rows:
        n = sum(len(v.split()) for _, v in row[1])
        if current and count + n > words:
            blocks.append(current)
            current, count = [], 0
        current.append(row)
        count += n
    if current:
        blocks.append(current)
    parts = []
    header = rows[0] if rows else None
    for block in blocks:
        first, last = block[0][0], block[-1][0]
        span = f"Zeile {first}" if first == last else f"Zeilen {first}–{last}"
        shown = block if block[0] is header else [header, *block]
        text = "\n".join(" | ".join(v for _, v in r[1]) for r in shown)
        parts.append(Part(f"Blatt „{sheet}“, {span}", text, cells=shown))
    return parts


def read_office(path: Path, words_per_part: int) -> list[Part]:
    suffix = path.suffix.lower()
    if suffix == ".docx":
        return read_docx(path, max(words_per_part * 3, 300))
    if suffix == ".xlsx":
        return read_xlsx(path, words_per_part)
    raise OfficeError("nicht unterstützt")
