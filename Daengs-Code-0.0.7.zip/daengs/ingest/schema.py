"""Tables owned by the ingest module inside the project database."""

import sqlite3

# Page sources. A page without a text layer waits for OCR in the background (F2).
TEXT_LAYER = "text_layer"
OCR = "ocr"
OCR_PENDING = "ocr_pending"
OCR_FAILED = "ocr_failed"

# File types that are read and searched (D-024); the explorer shows all others too.
SEARCHED = (".pdf", ".docx", ".xlsx")

FILE_OK = "ok"
FILE_FAILED = "failed"

_SCHEMA = f"""
create table if not exists file(
    id integer primary key autoincrement,
    folder text not null,
    rel_path text not null,
    size integer not null,
    mtime_ns integer not null,
    sha256 text not null,
    version integer not null default 1,
    status text not null check (status in ('{FILE_OK}', '{FILE_FAILED}')),
    error text,
    page_count integer not null default 0,
    title text not null default '',
    title_page integer,
    meta_title text,
    title_rule integer,
    unique(folder, rel_path)
);
create table if not exists page(
    file_id integer not null references file(id) on delete cascade,
    page_no integer not null,
    source text not null
        check (source in ('{TEXT_LAYER}', '{OCR}', '{OCR_PENDING}', '{OCR_FAILED}')),
    text text not null,
    -- OCR pages: JSON list of line boxes [x0, y0, x1, y1] as page fractions, one per text line
    ocr_lines text,
    -- Word and Excel (M8): where the part is ("Abschnitt ...", "Blatt ..., Zeilen ...");
    -- Excel parts also keep their cells as JSON [[row, [[column, value], ...]], ...]
    label text,
    cells text,
    primary key(file_id, page_no)
);
create index if not exists page_pending on page(source) where source = '{OCR_PENDING}';
create table if not exists chunk(
    id integer primary key autoincrement,
    file_id integer not null,
    page_no integer not null,
    text text not null,
    -- word index range [word_start, word_end) inside the page text, for marking in the viewer
    word_start integer,
    word_end integer,
    -- language of the chunk ("de", "en", ...; "" if unclear), for multilingual manuals (D-026)
    lang text,
    foreign key(file_id, page_no) references page(file_id, page_no) on delete cascade
);
create index if not exists chunk_page on chunk(file_id, page_no);
"""


# Columns added after the first schema (M4); older project databases get them on open.
_ADDED = {
    "page": [("ocr_lines", "text"), ("label", "text"), ("cells", "text")],
    "chunk": [("word_start", "integer"), ("word_end", "integer"), ("lang", "text")],
}


def ensure_schema(con: sqlite3.Connection) -> None:
    con.executescript(_SCHEMA)
    for table, columns in _ADDED.items():
        present = {row[1] for row in con.execute(f"pragma table_info({table})")}
        for name, kind in columns:
            if name not in present:
                try:
                    con.execute(f"alter table {table} add column {name} {kind}")
                except sqlite3.OperationalError as exc:
                    # Another thread added it in the meantime.
                    if "duplicate column" not in str(exc):
                        raise
