"""Text recognition for pages without a text layer: RapidOCR with fixed local models (D-013)."""

from dataclasses import dataclass
from typing import Protocol

import numpy as np

from daengs.core import DaengsError, OcrModels
from daengs.ingest.text import Box, group_lines


@dataclass(frozen=True)
class OcrText:
    """Recognized text, one line per row, and per line its box as fractions of the page
    (x0, y0, x1, y1 from the top left), so the viewer can mark it later."""

    text: str
    lines: tuple[Box, ...] = ()


class OcrEngine(Protocol):
    def __call__(self, image: np.ndarray) -> "OcrText | str": ...


class RapidOcrEngine:
    """RapidOCR with all model paths set, so it never falls back to downloading (R-23)."""

    def __init__(self, models: OcrModels, threads: int) -> None:
        missing = [p.name for p in models.files() if not p.is_file()]
        if missing:
            raise DaengsError(f"OCR-Modelldateien fehlen: {missing}")
        from rapidocr import RapidOCR

        self._engine = RapidOCR(
            params={
                "Global.text_score": 0.5,
                "Global.log_level": "warning",
                "EngineConfig.onnxruntime.intra_op_num_threads": threads,
                "Det.model_path": str(models.det),
                "Cls.model_path": str(models.cls),
                "Rec.model_path": str(models.rec),
                "Rec.rec_keys_path": str(models.rec_keys),
            }
        )

    def __call__(self, image: np.ndarray) -> OcrText:
        result = self._engine(image)
        if result.boxes is None:
            return OcrText("")
        lines = group_lines(result.boxes.tolist(), result.txts)
        height, width = image.shape[:2]
        boxes = tuple(
            (x0 / width, y0 / height, x1 / width, y1 / height) for _, (x0, y0, x1, y1) in lines
        )
        return OcrText("\n".join(text for text, _ in lines), boxes)
