"""All files of a project's delivery with their state, for the file explorer (A-33, A-34).

Only lists and compares (names, sizes, times against the project database); it reads no file
content and changes nothing. daengs.ingest.watch decides from this when reading starts by itself.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path

from daengs.core import PathNotAllowedError, ProjectContext, resolve_within
from daengs.ingest.schema import FILE_FAILED, OCR_PENDING, SEARCHED

NEW, CHANGED, DONE, FAILED = "neu", "geaendert", "eingelesen", "nicht_lesbar"
PENDING, REMOVED, OTHER = "texterkennung", "entfernt", "nicht_durchsucht"
UNREACHABLE = "nicht_erreichbar"
MAX_FILES = 20_000  # beyond that the explorer shows the first ones and says so

# File types that may be opened with their own program from the explorer. Programs, scripts,
# links and web pages in a delivery are never started by a click (they could run code).
OPENABLE = frozenset(
    """
.pdf .docx .doc .docm .dotx .xlsx .xls .xlsm .csv .pptx .ppt .odt .ods .odp .rtf .txt .md .xml
.json .png .jpg .jpeg .gif .bmp .tif .tiff .svg .dwg .dxf .step .stp .igs .iges .stl .zip .7z
.msg .eml
""".split()
)


@dataclass(frozen=True)
class FileEntry:
    folder: str
    rel_path: str
    size: int
    state: str
    file_id: int | None = None
    pages: int = 0
    openable: bool = False
    mtime_ns: int = 0


@dataclass(frozen=True)
class Inventory:
    files: list[FileEntry]
    truncated: bool
    unreachable: list[str] = field(default_factory=list)

    def counts(self) -> dict[str, int]:
        result: dict[str, int] = {}
        for f in self.files:
            result[f.state] = result.get(f.state, 0) + 1
        return result


def inventory(context: ProjectContext) -> Inventory:
    with context.transaction() as con:
        known = (
            {
                (folder, rel): (fid, size, mtime, status, pages)
                for fid, folder, rel, size, mtime, status, pages in con.execute(
                    "select id, folder, rel_path, size, mtime_ns, status, page_count from file"
                )
            }
            if con.execute("select 1 from sqlite_master where name = 'file'").fetchone()
            else {}
        )
        pending = (
            {
                fid
                for (fid,) in con.execute(
                    "select distinct file_id from page where source = ?", (OCR_PENDING,)
                )
            }
            if known
            else set()
        )
    files: list[FileEntry] = []
    seen: set[tuple[str, str]] = set()
    truncated = False
    unreachable = [str(f) for f in context.folders if not f.is_dir()]
    for folder in context.folders:
        if str(folder) in unreachable:
            continue
        for dirpath, dirnames, filenames in os.walk(folder, followlinks=False):
            dirnames.sort()
            for name in sorted(filenames):
                if name.startswith("~$"):
                    continue  # lock file of an open Word or Excel document
                if len(files) >= MAX_FILES:
                    truncated = True
                    break
                try:
                    path = resolve_within(folder, Path(dirpath) / name)
                    stat = path.stat()
                except (PathNotAllowedError, OSError):
                    continue
                rel = path.relative_to(folder).as_posix()
                key = (str(folder), rel)
                seen.add(key)
                files.append(_entry(key, path, stat, known.get(key), pending))
    for key, (fid, size, _, _, pages) in known.items():
        if key not in seen and not truncated:
            state = UNREACHABLE if key[0] in unreachable else REMOVED
            files.append(FileEntry(key[0], key[1], size, state, fid, pages))
    return Inventory(files, truncated, unreachable)


def _entry(key, path: Path, stat, row, pending: set[int]) -> FileEntry:
    suffix = path.suffix.lower()
    openable = suffix in OPENABLE
    if suffix not in SEARCHED:
        return FileEntry(*key, stat.st_size, OTHER, openable=openable)
    if row is None:
        return FileEntry(*key, stat.st_size, NEW, openable=openable, mtime_ns=stat.st_mtime_ns)
    fid, size, mtime, status, pages = row
    if (size, mtime) != (stat.st_size, stat.st_mtime_ns):
        state = CHANGED
    elif status == FILE_FAILED:
        state = FAILED
    elif fid in pending:
        state = PENDING
    else:
        state = DONE
    return FileEntry(*key, stat.st_size, state, fid, pages, openable, stat.st_mtime_ns)
