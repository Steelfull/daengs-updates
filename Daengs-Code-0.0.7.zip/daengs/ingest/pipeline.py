"""Ingest of granted folders: quick index first, OCR in the background, change detection (F2)."""

import contextlib
import hashlib
import json
import os
import sqlite3
import threading
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path

import pypdfium2 as pdfium

from daengs.core import (
    PDFIUM_LOCK,
    IngestSettings,
    PathNotAllowedError,
    ProjectContext,
    detect_language,
    resolve_within,
)
from daengs.ingest import text as titles
from daengs.ingest.ocr import OcrEngine, OcrText
from daengs.ingest.office import OfficeError, read_office
from daengs.ingest.schema import (
    FILE_FAILED,
    FILE_OK,
    OCR,
    OCR_FAILED,
    OCR_PENDING,
    SEARCHED,
    TEXT_LAYER,
    ensure_schema,
)
from daengs.ingest.text import chunk_spans, clean_hyphens, title_from

_HASH_BLOCK = 1 << 20


def _title_for(rel_path: str, text: str, meta: str) -> str:
    """PDF titles are built richly (D-063); Word and Excel keep the first four lines."""
    if rel_path.lower().endswith(".pdf"):
        return title_from(text, rich=True, meta=meta or "")
    return title_from(text)


# One page of a file: source, text, label (Word/Excel), cells as JSON (Excel).
Extracted = tuple[str, str, str | None, str | None]


@dataclass(frozen=True)
class ScanReport:
    new: int = 0
    changed: int = 0
    unchanged: int = 0
    removed: int = 0
    failed: int = 0
    rejected: int = 0
    locked: int = 0
    pages: int = 0
    ocr_pending: int = 0
    seconds: float = 0.0
    stopped: bool = False


@dataclass(frozen=True)
class OcrReport:
    pages: int = 0
    failed: int = 0
    seconds: float = 0.0


@dataclass(frozen=True)
class IngestStatus:
    files: int
    failed_files: int
    pages: int
    text_layer: int
    ocr: int
    ocr_pending: int
    ocr_failed: int
    chunks: int


class Ingestor:
    """Reads only the project's granted folders and writes only into the project's database."""

    def __init__(
        self,
        context: ProjectContext,
        settings: IngestSettings,
        ocr_engine: Callable[[], OcrEngine] | None = None,
    ) -> None:
        self.context = context
        self.settings = settings
        # Factory, so the OCR models are loaded only when a page needs them.
        self._ocr_factory = ocr_engine
        with context.transaction() as con:
            ensure_schema(con)

    # -- quick index -------------------------------------------------------------------------

    def scan(
        self,
        stop: threading.Event | None = None,
        on_file: Callable[[int, int, str, str], None] | None = None,
    ) -> ScanReport:
        """Index new and changed files: PDF from its text layer (pages without text wait for
        OCR), Word and Excel from their XML (A-35).

        ``on_file(i, total, folder, rel_path)`` is told before each file (progress, D-065).
        Setting ``stop`` ends the run after the current file; each file is committed on its own,
        and nothing is removed or retitled then, since not all files were looked at (D-066)."""
        start = time.perf_counter()
        counts = dict.fromkeys(
            ("new", "changed", "unchanged", "removed", "failed", "rejected", "locked"), 0
        )
        seen: set[tuple[str, str]] = set()
        unreachable = {str(f) for f in self.context.folders if not f.is_dir()}
        files = list(self._files(counts))
        for i, (folder, path) in enumerate(files):
            if stop is not None and stop.is_set():
                status = self.status()
                return ScanReport(
                    **counts,
                    pages=status.pages,
                    ocr_pending=status.ocr_pending,
                    seconds=time.perf_counter() - start,
                    stopped=True,
                )
            key = (str(folder), path.relative_to(folder).as_posix())
            if on_file is not None:
                on_file(i, len(files), *key)
            seen.add(key)
            counts[self._index_file(path, key)] += 1
        with self.context.transaction() as con:
            for file_id, folder, rel in con.execute(
                "select id, folder, rel_path from file"
            ).fetchall():
                # A folder that is not there right now (external disk) says nothing about its files.
                if (folder, rel) not in seen and folder not in unreachable:
                    con.execute("delete from file where id = ?", (file_id,))
                    counts["removed"] += 1
        self._retitle()
        status = self.status()
        report = ScanReport(
            **counts,
            pages=status.pages,
            ocr_pending=status.ocr_pending,
            seconds=time.perf_counter() - start,
        )
        self.context.log_event(
            "einlesen",
            neu=report.new,
            geaendert=report.changed,
            entfernt=report.removed,
            fehler=report.failed,
            abgewiesen=report.rejected,
            seiten=report.pages,
            ocr_offen=report.ocr_pending,
            sekunden=round(report.seconds, 1),
        )
        return report

    def _files(self, counts: dict[str, int]) -> Iterator[tuple[Path, Path]]:
        for folder in self.context.folders:
            if not folder.is_dir():
                continue
            for dirpath, dirnames, filenames in os.walk(folder, followlinks=False):
                dirnames.sort()
                for name in sorted(filenames):
                    # "~$name.docx" is the lock file Word and Excel keep while a file is open.
                    if not name.lower().endswith(SEARCHED) or name.startswith("~$"):
                        continue
                    try:
                        # Links and junctions are resolved; paths out of this folder are refused.
                        path = resolve_within(folder, Path(dirpath) / name)
                    except PathNotAllowedError:
                        counts["rejected"] += 1
                        continue
                    if path.is_file():
                        yield folder, path

    def _index_file(self, path: Path, key: tuple[str, str]) -> str:
        stat = path.stat()
        with self.context.transaction() as con:
            row = con.execute(
                "select id, size, mtime_ns, sha256 from file where folder = ? and rel_path = ?",
                key,
            ).fetchone()
        if row and (row[1], row[2]) == (stat.st_size, stat.st_mtime_ns):
            return "unchanged"
        try:
            digest = _sha256(path)
        except OSError:  # locked or just being written: not an error, it comes in later
            return "locked"
        if row and row[3] == digest:
            with self.context.transaction() as con:
                con.execute(
                    "update file set size = ?, mtime_ns = ? where id = ?",
                    (stat.st_size, stat.st_mtime_ns, row[0]),
                )
            return "unchanged"
        pages, error = self._extract(path)
        meta = self._pdf_meta(path) if path.suffix.lower() == ".pdf" else ""
        with self.context.transaction() as con:
            if row:
                file_id = row[0]
                con.execute("delete from page where file_id = ?", (file_id,))
                con.execute(
                    "update file set size = ?, mtime_ns = ?, sha256 = ?, version = version + 1,"
                    " status = ?, error = ?, page_count = ?, title = '', title_page = null"
                    " where id = ?",
                    (stat.st_size, stat.st_mtime_ns, digest, *_file_state(pages, error), file_id),
                )
            else:
                file_id = con.execute(
                    "insert into file(folder, rel_path, size, mtime_ns, sha256, status, error,"
                    " page_count) values (?, ?, ?, ?, ?, ?, ?, ?)",
                    (*key, stat.st_size, stat.st_mtime_ns, digest, *_file_state(pages, error)),
                ).lastrowid
            con.execute(
                "update file set meta_title = ?, title_rule = ? where id = ?",
                (meta, titles.TITLE_RULE, file_id),
            )
            for page_no, (source, text, label, cells) in enumerate(pages, start=1):
                con.execute(
                    "insert into page(file_id, page_no, source, text, label, cells)"
                    " values (?, ?, ?, ?, ?, ?)",
                    (file_id, page_no, source, text, label, cells),
                )
                if source == TEXT_LAYER:
                    context = _office_context(path, pages, page_no, label)
                    self._store_page_text(con, file_id, page_no, text, context)
            self._set_title(con, file_id)
        if error:
            return "failed"
        return "changed" if row else "new"

    def _extract(self, path: Path) -> tuple[list[Extracted], str | None]:
        if path.suffix.lower() != ".pdf":
            try:
                parts = read_office(path, self.settings.chunk_words)
            except (OfficeError, OSError, ValueError, KeyError, EOFError) as exc:
                return [], type(exc).__name__
            return [
                (
                    TEXT_LAYER,
                    p.text,
                    p.label,
                    json.dumps(p.cells, ensure_ascii=False) if p.cells else None,
                )
                for p in parts
            ], None
        with PDFIUM_LOCK:
            try:
                pdf = pdfium.PdfDocument(path)
            except pdfium.PdfiumError as exc:
                # Only the error class: the message may quote the file name.
                return [], type(exc).__name__
            try:
                pages = []
                for i in range(len(pdf)):
                    page = pdf[i]
                    textpage = page.get_textpage()
                    text = textpage.get_text_range()
                    textpage.close()
                    page.close()
                    if len(text.strip()) < self.settings.min_text_chars:
                        pages.append((OCR_PENDING, "", None, None))
                    else:
                        pages.append((TEXT_LAYER, text, None, None))
                return pages, None
            except pdfium.PdfiumError as exc:
                return [], type(exc).__name__
            finally:
                pdf.close()

    def _store_page_text(
        self, con: sqlite3.Connection, file_id: int, page_no: int, text: str, context: str = ""
    ) -> None:
        words = text.split()
        spans = chunk_spans(text, self.settings.chunk_words, self.settings.chunk_overlap)
        # The context goes in front of the chunk text only; word spans still count page words.
        prefix = f"{context} · " if context else ""
        rows = []
        for a, b in spans:
            body = clean_hyphens(" ".join(words[a:b]))
            rows.append((file_id, page_no, prefix + body, a, b, detect_language(body)))
        con.executemany(
            "insert into chunk(file_id, page_no, text, word_start, word_end, lang)"
            " values (?, ?, ?, ?, ?, ?)",
            rows,
        )
        if text.strip():
            self._set_title(con, file_id)

    @staticmethod
    def _set_title(con: sqlite3.Connection, file_id: int) -> None:
        """Title from the first page with text; the PDF metadata title only if it fits the
        document (a word of it stands in the first three pages), else it is a template leftover."""
        rel, meta = con.execute(
            "select rel_path, meta_title from file where id = ?", (file_id,)
        ).fetchone()
        pages = con.execute(
            "select page_no, text from page where file_id = ? and page_no <= 3 order by page_no",
            (file_id,),
        ).fetchall()
        first = con.execute(
            "select page_no, text from page where file_id = ? and trim(text) != ''"
            " order by page_no limit 1",
            (file_id,),
        ).fetchone()
        if first is None:
            con.execute(
                "update file set title = '', title_page = null, title_rule = ? where id = ?",
                (titles.TITLE_RULE, file_id),
            )
            return
        if meta and not titles.meta_fits(meta, " ".join(t for _, t in pages)):
            meta = ""
        con.execute(
            "update file set title = ?, title_page = ?, title_rule = ? where id = ?",
            (_title_for(rel, first[1], meta or ""), first[0], titles.TITLE_RULE, file_id),
        )

    def _retitle(self) -> None:
        """Projects made with an older title rule get their titles rebuilt from the stored pages;
        the search index then re-embeds the changed ones (SearchIndex.update compares titles)."""
        with self.context.transaction() as con:
            old = con.execute(
                "select id, folder, rel_path from file where status = ?"
                " and (title_rule is null or title_rule != ?)",
                (FILE_OK, titles.TITLE_RULE),
            ).fetchall()
        for file_id, folder, rel in old:
            meta = ""
            if rel.lower().endswith(".pdf") and titles.USE_PDF_TITLE:
                with contextlib.suppress(PathNotAllowedError, OSError):
                    meta = self._pdf_meta(self.context.readable(Path(folder) / rel))
            with self.context.transaction() as con:
                con.execute("update file set meta_title = ? where id = ?", (meta, file_id))
                self._set_title(con, file_id)

    @staticmethod
    def _pdf_meta(path: Path) -> str:
        if not titles.USE_PDF_TITLE:
            return ""
        with PDFIUM_LOCK:
            try:
                pdf = pdfium.PdfDocument(path)
            except pdfium.PdfiumError:
                return ""
            try:
                return titles.meta_title_ok(pdf.get_metadata_dict().get("Title") or "", path.stem)
            except pdfium.PdfiumError:
                return ""
            finally:
                pdf.close()

    # -- OCR in the background ---------------------------------------------------------------

    def run_ocr(self, stop: threading.Event | None = None, limit: int | None = None) -> OcrReport:
        """Recognize queued pages one by one; each page is committed on its own."""
        start = time.perf_counter()
        with self.context.transaction() as con:
            queue = con.execute(
                "select p.file_id, p.page_no, f.folder, f.rel_path, f.version from page p"
                " join file f on f.id = p.file_id where p.source = ?"
                " order by p.file_id, p.page_no",
                (OCR_PENDING,),
            ).fetchall()
        if limit is not None:
            queue = queue[:limit]
        done = failed = 0
        engine: OcrEngine | None = None
        open_pdf: tuple[int, pdfium.PdfDocument] | None = None
        try:
            for file_id, page_no, folder, rel, version in queue:
                if stop is not None and stop.is_set():
                    break
                if engine is None:
                    if self._ocr_factory is None:
                        break
                    engine = self._ocr_factory()
                if open_pdf is None or open_pdf[0] != file_id:
                    with PDFIUM_LOCK:
                        if open_pdf is not None:
                            open_pdf[1].close()
                        open_pdf = None
                        try:
                            path = self.context.readable(Path(folder) / rel)
                            open_pdf = (file_id, pdfium.PdfDocument(path))
                        except (PathNotAllowedError, OSError, pdfium.PdfiumError):
                            continue
                try:
                    with PDFIUM_LOCK:
                        page = open_pdf[1][page_no - 1]
                        bitmap = page.render(scale=self.settings.ocr_scale)
                        image = bitmap.to_numpy().copy()
                        bitmap.close()
                        page.close()
                    # Recognition runs outside the lock: the viewer stays responsive meanwhile.
                    result = engine(image)
                    if not isinstance(result, OcrText):
                        result = OcrText(result)
                    text, source = result.text, OCR
                    boxes = json.dumps([[round(v, 5) for v in b] for b in result.lines])
                except Exception:  # one unreadable page must not stop the queue
                    text, source, boxes = "", OCR_FAILED, None
                with self.context.transaction() as con:
                    updated = con.execute(
                        "update page set source = ?, text = ?, ocr_lines = ?"
                        " where file_id = ? and page_no = ? and source = ?"
                        " and exists(select 1 from file where id = ? and version = ?)",
                        (source, text, boxes, file_id, page_no, OCR_PENDING, file_id, version),
                    ).rowcount
                    if updated and source == OCR:
                        self._store_page_text(con, file_id, page_no, text)
                if updated:
                    done += source == OCR
                    failed += source == OCR_FAILED
        finally:
            if open_pdf is not None:
                with PDFIUM_LOCK:
                    open_pdf[1].close()
        report = OcrReport(done, failed, time.perf_counter() - start)
        if done or failed:
            self.context.log_event(
                "texterkennung", seiten=done, fehler=failed, sekunden=round(report.seconds, 1)
            )
        return report

    def start_background_ocr(self) -> tuple[threading.Thread, threading.Event]:
        """Run the OCR queue in a thread; setting the event stops it after the current page."""
        stop = threading.Event()
        thread = threading.Thread(target=self.run_ocr, args=(stop,), name="daengs-ocr", daemon=True)
        thread.start()
        return thread, stop

    # -- status ------------------------------------------------------------------------------

    def status(self) -> IngestStatus:
        with self.context.transaction() as con:
            files, failed_files = con.execute(
                "select count(*), coalesce(sum(status = ?), 0) from file", (FILE_FAILED,)
            ).fetchone()
            by_source = dict(con.execute("select source, count(*) from page group by source"))
            (chunks,) = con.execute("select count(*) from chunk").fetchone()
        return IngestStatus(
            files=files,
            failed_files=failed_files,
            pages=sum(by_source.values()),
            text_layer=by_source.get(TEXT_LAYER, 0),
            ocr=by_source.get(OCR, 0),
            ocr_pending=by_source.get(OCR_PENDING, 0),
            ocr_failed=by_source.get(OCR_FAILED, 0),
            chunks=chunks,
        )

    def ocr_queue(self) -> list[tuple[str, str, int]]:
        """Files with pages waiting for OCR, in the order ``run_ocr`` takes them: folder,
        rel_path, open pages (progress, D-065)."""
        with self.context.transaction() as con:
            return con.execute(
                "select f.folder, f.rel_path, count(*) from page p join file f on f.id = p.file_id"
                " where p.source = ? group by p.file_id order by p.file_id",
                (OCR_PENDING,),
            ).fetchall()


def _office_context(path: Path, pages: list[Extracted], page_no: int, label: str | None) -> str:
    """What a Word section or Excel block lacks on its own: which document it belongs to.

    In a PDF, headers and footers usually carry the machine or document name on every page; a
    Word section ("Ölwechsel") or a block of rows does not. The search therefore gets the
    document title (Word) or file and sheet (Excel) in front of every chunk (M8)."""
    suffix = path.suffix.lower()
    if suffix == ".docx" and page_no > 1 and pages:
        return title_from(pages[0][1])
    if suffix == ".xlsx":
        return f"{path.stem.replace('_', ' ')} · {label or ''}".strip(" ·")
    return ""


def _file_state(pages: list[Extracted], error: str | None) -> tuple[str, str | None, int]:
    return (FILE_FAILED if error else FILE_OK), error, len(pages)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        while block := f.read(_HASH_BLOCK):
            digest.update(block)
    return digest.hexdigest()
