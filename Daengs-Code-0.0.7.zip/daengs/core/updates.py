"""What the app and the update program share (13, D-030, D-037): files in one folder, no network.

The app holds customer data and has no network; the update program has network and sees no project.
They talk through small files in ``Updates`` next to the projects. The user's choice lies there too,
not in daengs.toml: every update replaces that file and would switch updates back on.
"""

import contextlib
import json
import re
import time
from pathlib import Path
from typing import Any

FOLDER = "Updates"
# Fixed in the program, not a setting (13 §5): GitHub Pages of the release repository (D-074).
# Only the installed package asks, through daengs-update.exe; a development run never does.
UPDATE_URL = "https://steelfull.github.io/daengs-updates/latest.json"

_VERSION = re.compile(r"^\d{1,4}(\.\d{1,4}){1,3}$")


def version_key(version: str) -> tuple[int, ...]:
    if not isinstance(version, str) or not _VERSION.fullmatch(version):
        raise ValueError("ungültige Version")
    return tuple(int(part) for part in version.split("."))


def is_newer(version: str, than: str) -> bool:
    return version_key(version) > version_key(than)


class UpdateFiles:
    """The folder both programs use. Every write is atomic, so a reader never sees half a file."""

    def __init__(self, folder: Path) -> None:
        self.folder = folder

    @property
    def download_dir(self) -> Path:
        return self.folder / "download"

    @property
    def cancel_file(self) -> Path:
        return self.folder / "abbrechen"

    def read(self, name: str) -> dict[str, Any]:
        with contextlib.suppress(OSError, ValueError):
            value = json.loads((self.folder / f"{name}.json").read_text(encoding="utf-8"))
            if isinstance(value, dict):
                return value
        return {}

    def write(self, name: str, value: dict[str, Any]) -> None:
        self.folder.mkdir(parents=True, exist_ok=True)
        target = self.folder / f"{name}.json"
        temporary = target.with_suffix(f".{time.monotonic_ns()}.tmp")
        temporary.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
        for attempt in range(5):
            try:
                temporary.replace(target)
                return
            except PermissionError:  # the other program is reading it just now
                time.sleep(0.05 * (attempt + 1))
        temporary.unlink(missing_ok=True)

    def update(self, name: str, **fields: Any) -> None:
        self.write(name, {**self.read(name), **fields})

    def remove(self, name: str) -> None:
        (self.folder / f"{name}.json").unlink(missing_ok=True)
