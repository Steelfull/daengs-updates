"""Error types shared across modules. Messages never contain document content."""


class DaengsError(Exception):
    """Base class for expected, user-facing errors."""


class PathNotAllowedError(DaengsError):
    """A path lies outside the folders a project may read or write."""


class ProjectNotFoundError(DaengsError):
    """No project with this ID exists in the data location."""


class ProjectTooNewError(DaengsError):
    """The project was last used by a newer Daengs; this one must not touch it."""
