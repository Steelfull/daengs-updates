"""Shared core: types and contracts every module may depend on.

Modules depend only on ``daengs.core``, never on each other (07 §3).
"""

from daengs.core.errors import (
    DaengsError,
    PathNotAllowedError,
    ProjectNotFoundError,
    ProjectTooNewError,
)
from daengs.core.language import detect_language
from daengs.core.paths import is_within, resolve_within
from daengs.core.pdf import PDFIUM_LOCK
from daengs.core.project import (
    DataZone,
    ProjectContext,
    ProjectId,
    new_project_id,
    validate_project_id,
)
from daengs.core.settings import (
    PREFERENCES_FILE,
    EmbeddingModel,
    IngestSettings,
    LlmModel,
    OcrModels,
    Preferences,
    SearchSettings,
    Settings,
)

__all__ = [
    "PDFIUM_LOCK",
    "PREFERENCES_FILE",
    "DaengsError",
    "DataZone",
    "EmbeddingModel",
    "IngestSettings",
    "LlmModel",
    "OcrModels",
    "PathNotAllowedError",
    "Preferences",
    "ProjectContext",
    "ProjectId",
    "ProjectNotFoundError",
    "ProjectTooNewError",
    "SearchSettings",
    "Settings",
    "detect_language",
    "is_within",
    "new_project_id",
    "resolve_within",
    "validate_project_id",
]
