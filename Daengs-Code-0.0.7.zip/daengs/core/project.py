"""Project identity and the context handed to modules working on one project."""

import json
import re
import sqlite3
import time
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import NewType

from daengs.core.errors import PathNotAllowedError
from daengs.core.paths import resolve_within

ProjectId = NewType("ProjectId", str)

_ID = re.compile(r"^[0-9a-f]{32}$")
_EVENT = re.compile(r"^[a-z_]{1,40}$")

DB_NAME = "projekt.sqlite"
SCHEMA_VERSION = 2


class DataZone(StrEnum):
    """Data zone of a storage location (09 §3, H-16)."""

    CUSTOMER = "kundendaten"
    CUSTOMER_FREE = "kundenfrei"


def new_project_id() -> ProjectId:
    return ProjectId(uuid.uuid4().hex)


def validate_project_id(value: str) -> ProjectId:
    """Accept only generated IDs, so an ID can never address another folder."""
    if not _ID.fullmatch(value):
        raise ValueError("ungültige Projekt-ID")
    return ProjectId(value)


@dataclass(frozen=True)
class ProjectContext:
    """Everything a module may touch for one project: its own folder and its granted folders."""

    project_id: ProjectId
    project_dir: Path
    folders: tuple[Path, ...]
    zone: DataZone = DataZone.CUSTOMER

    @property
    def db_path(self) -> Path:
        return self.project_dir / DB_NAME

    @property
    def tmp_dir(self) -> Path:
        return self.project_dir / "tmp"

    @property
    def log_dir(self) -> Path:
        return self.project_dir / "protokoll"

    def connect(self) -> sqlite3.Connection:
        """Open this project's own database; every connection is bound to this project only."""
        con = sqlite3.connect(self.db_path, timeout=30)
        con.execute("pragma foreign_keys = on")
        # Deleted chats, wiki pages and changed files are overwritten, not only released: no
        # customer text stays behind in free pages of the database (F7; found in M9a).
        con.execute("pragma secure_delete = on")
        con.execute("pragma journal_mode = wal")
        con.execute("pragma busy_timeout = 30000")
        return con

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Connection that commits on success, rolls back on error and is always closed."""
        con = self.connect()
        try:
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    def readable(self, path: Path) -> Path:
        """Resolve ``path`` and require it to lie inside one of the granted folders."""
        for folder in self.folders:
            try:
                return resolve_within(folder, path)
            except PathNotAllowedError:
                continue
        raise PathNotAllowedError("Pfad liegt außerhalb der freigegebenen Ordner")

    def place_dir(self, folder: str, subfolder: str = "") -> Path:
        """The folder a dropped file may go to: a granted folder or a folder inside it (D-038)."""
        for granted in self.folders:
            if str(granted) == folder:
                directory = resolve_within(granted, Path(subfolder))
                if not directory.is_dir():
                    raise PathNotAllowedError("Ordner ist nicht erreichbar")
                return directory
        raise PathNotAllowedError("Ordner ist nicht freigegeben")

    def log_event(self, event: str, **counts: int | float) -> None:
        """Append to the project log. Only an event name and numbers: no content, no names."""
        if not _EVENT.fullmatch(event):
            raise ValueError("ungültiger Ereignisname")
        if any(isinstance(v, bool) or not isinstance(v, int | float) for v in counts.values()):
            raise TypeError("Protokoll nimmt nur Zahlen auf")
        self.log_dir.mkdir(exist_ok=True)
        entry = {"zeit": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "ereignis": event, **counts}
        with open(self.log_dir / "ereignisse.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
