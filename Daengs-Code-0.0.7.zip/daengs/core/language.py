"""Language of a passage or a question, for multilingual manuals (M8, D-026).

Small and offline: frequent function words and distinctive letters per language. Good enough to
tell the language sections of a manual apart (a chain saw manual in 20 languages); not meant for
mixed sentences. Returns "" when it cannot tell.
"""

import re

_WORDS = {
    "de": "der die das und ist nicht mit den dem des ein eine einer eines sich auf für von zu "
    "bei wird werden sind wie oder auch nach aus nur muss kann dass wenn sie ich welche welcher "
    "welches wo was warum zum zur im vom",
    "en": "the and is are of to with for this that be not or by from on can must if when your "
    "you should do how what which where why does it",
    "fr": "le les et est des du un une pour dans avec ne pas sur qui au aux ce cette sont être "
    "vous votre peut doit comment quel quelle où",
    "es": "el los las y es del una para con por se su sus al este esta puede debe cómo qué "
    "cuál dónde",
    "it": "il lo gli è della delle dei per con che sono essere può deve nel questo questa come "
    "quale dove",
    "nl": "het een en van met voor niet op te dat zijn bij als ook door om kan moet worden wordt "
    "hoe wat welke waar",
    "cs": "je se na ve s z do pro že jsou nebo jako které který při po k aby být lze musí jak "
    "co kde",
    "pl": "w z na się do jest nie że od dla jak są przez może należy jest co gdzie",
    "sv": "och är att det ett som på för med inte av till kan ska eller hur vad var",
    "da": "og er at det et som på for med ikke af til kan skal eller hvordan hvad hvor",
    "pt": "o os as e é do da dos das um uma para com não por que se seu sua pode deve como",
    "hu": "a az és egy hogy nem van meg ez az vagy kell lehet csak mint",
}
COMMON_WORDS = frozenset(word for words in _WORDS.values() for word in words.split())
_LETTERS = {
    "de": "ßäöü",
    "cs": "řěůčšžý",
    "pl": "łąęśźżń",
    "fr": "éèêçàù",
    "es": "ñ¿¡",
    "sv": "å",
    "pt": "ãõç",
    "hu": "őű",
}
_LEXICON = {lang: frozenset(words.split()) for lang, words in _WORDS.items()}
_TOKEN = re.compile(r"[^\W\d_]+", re.UNICODE)


def detect_language(text: str, min_score: float = 3.0, min_share: float = 0.12) -> str:
    """ISO code of the most likely language, or "" if no language clearly wins.

    Prose is full of function words and typical letters, parts lists and tables have almost none:
    below ``min_share`` there is no language, so a list with "Tél." on it is not French (D-029)."""
    lowered = text.lower()
    if re.search(r"[Ѐ-ӿ]", lowered):
        return "ru" if len(re.findall(r"[Ѐ-ӿ]", lowered)) > 10 else ""
    tokens = _TOKEN.findall(lowered)
    if not tokens:
        return ""
    scores = dict.fromkeys(_LEXICON, 0.0)
    for token in tokens:
        for lang, words in _LEXICON.items():
            if token in words:
                scores[lang] += 1
    for lang, letters in _LETTERS.items():
        scores[lang] += 0.5 * sum(lowered.count(c) for c in letters)
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    (best, top), (_, second) = ranked[0], ranked[1]
    if top < min_score or top < second * 1.3 or top / len(tokens) < min_share:
        return ""
    return best
