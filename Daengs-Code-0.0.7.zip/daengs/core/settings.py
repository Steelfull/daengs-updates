"""Runtime settings as typed values; the config module fills them from the customer file."""

import contextlib
import json
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path

# Next to the projects, not in daengs.toml: every update replaces that file (like core.updates).
PREFERENCES_FILE = "oberflaeche.json"
# Every choice with its allowed values; the first one is the default. Nothing else can get in.
PREFERENCE_CHOICES = {
    "motion": ("dezent", "aus", "lebhaft"),
    "density": ("ausfuehrlich", "kompakt"),
    "file_filter": ("alle", "pdf", "word", "excel"),
}
# The random ID of the last opened project (D-050), or empty; never a name.
_PROJECT_ID = re.compile(r"[0-9a-f]{32}")


_preferences_lock = threading.Lock()


def allowed_preference(key: str, value: object) -> bool:
    if key == "last_project":
        return value == "" or (isinstance(value, str) and bool(_PROJECT_ID.fullmatch(value)))
    return value in PREFERENCE_CHOICES.get(key, ())


class Preferences:
    """The user's choices for the interface on this computer; never holds customer data."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def read(self) -> dict[str, str]:
        stored: object = {}
        with contextlib.suppress(OSError, ValueError):
            stored = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(stored, dict):
            stored = {}
        choices = {
            key: stored[key] if stored.get(key) in allowed else allowed[0]
            for key, allowed in PREFERENCE_CHOICES.items()
        }
        last = stored.get("last_project", "")
        return {**choices, "last_project": last if allowed_preference("last_project", last) else ""}

    def write(self, **changes: str) -> dict[str, str]:
        for key, value in changes.items():
            if not allowed_preference(key, value):
                raise ValueError(f"unbekannte Einstellung: {key}")
        # Read, merge and replace as one step: the page sends choices right after one another.
        with _preferences_lock:
            choices = {**self.read(), **changes}
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix(".tmp")
            temporary.write_text(json.dumps(choices), encoding="utf-8")
            temporary.replace(self.path)
        return choices

    def forget_project(self, project_id: str) -> None:
        """A deleted project leaves no trace here (D-050, A-08)."""
        if self.read()["last_project"] == project_id:
            self.write(last_project="")


@dataclass(frozen=True)
class OcrModels:
    """Fixed model files for RapidOCR (PP-OCRv6 small, docs/lizenzliste.md §2). Never downloaded."""

    det: Path
    cls: Path
    rec: Path
    rec_keys: Path

    def files(self) -> tuple[Path, ...]:
        return (self.det, self.cls, self.rec, self.rec_keys)


@dataclass(frozen=True)
class IngestSettings:
    # A page with fewer non-space characters goes to OCR (praxistest: 50).
    min_text_chars: int = 50
    # Render scale for OCR; 3 = 216 dpi as measured in 08.
    ocr_scale: float = 3.0
    ocr_threads: int = 4
    # Chunk = word window inside one page; the page is a hard boundary (06 §2).
    chunk_words: int = 180
    chunk_overlap: int = 40


@dataclass(frozen=True)
class EmbeddingModel:
    """Fixed ONNX embedding model with its tokenizer (Granite-311M fp32, D-013). Never downloaded.

    ``model_id`` is stored with the vectors; a different ID means all vectors are recomputed.
    """

    onnx: Path
    tokenizer: Path
    model_id: str
    dim: int = 768
    max_tokens: int = 512

    def files(self) -> tuple[Path, ...]:
        return (self.onnx, self.tokenizer)


@dataclass(frozen=True)
class LlmModel:
    """Optional answer model (F10, D-022): llama.cpp llama-server and a GGUF file. Never downloaded.

    Comes from the extension "Daengs-Sprachmodell" (erweiterungen/sprachmodell/erweiterung.toml) or,
    for development, from [models.llm] in the settings file.
    """

    server: Path
    model: Path
    model_id: str
    context: int = 8192
    threads: int = 4
    # "none" = CPU only (as measured); e.g. "Vulkan0" to use a graphics chip.
    device: str = "none"
    # The model is loaded on the first question and unloaded after this idle time (RAM, R-14).
    idle_seconds: int = 300
    max_tokens: int = 500
    # 4 sources of about 60 words: first word after 5-6 s, gold pages 29/30 (D-028, M9a;
    # praxistest/ergebnisse/m9a_fundstellen_vergleich_2.md).
    sources: int = 4

    def files(self) -> tuple[Path, ...]:
        return (self.server, self.model)


@dataclass(frozen=True)
class SearchSettings:
    embedding_threads: int = 4
    # Chunks taken from each ranking before fusion (praxistest: 100).
    candidates: int = 100
    # Reciprocal rank fusion constant (praxistest: 60).
    rrf_k: int = 60
    # Share of the word search next to the meaning search for plain questions (D-029): small, as
    # equal weight pushes English documents out of German questions (06 §3); see
    # praxistest/ergebnisse/m10_suche_varianten.md.
    word_weight: float = 0.15
    # Language assumed for a question whose language cannot be told, e.g. a single noun (D-026).
    language: str = "de"
    # From this similarity a passage counts as sure even without the question's words (D-040).
    # Holds for this embedding model only; praxistest/ergebnisse/m14_relevanz.md.
    sure_similarity: float = 0.83


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    ocr_models: OcrModels | None = None
    embedding: EmbeddingModel | None = None
    llm: LlmModel | None = None
    ingest: IngestSettings = field(default_factory=IngestSettings)
    search: SearchSettings = field(default_factory=SearchSettings)
