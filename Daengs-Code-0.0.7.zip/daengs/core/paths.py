"""Path checks that enforce the project boundary (09 §4)."""

import os
from pathlib import Path

from daengs.core.errors import PathNotAllowedError


def is_within(path: Path, root: Path) -> bool:
    """True if the resolved ``path`` is ``root`` or lies below it (links and ``..`` resolved)."""
    p = os.path.normcase(str(path.resolve()))
    r = os.path.normcase(str(root.resolve()))
    return p == r or p.startswith(r.rstrip(os.sep) + os.sep)


def resolve_within(root: Path, candidate: Path) -> Path:
    """Resolve ``candidate`` relative to ``root`` and require the result to stay inside ``root``."""
    resolved = (root / candidate).resolve()
    if not is_within(resolved, root):
        raise PathNotAllowedError("Pfad liegt außerhalb des freigegebenen Ordners")
    return resolved
