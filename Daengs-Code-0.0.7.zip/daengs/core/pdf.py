"""PDFium is not thread-safe (pypdfium2 docs): every call into it, including opening and closing
documents, runs under this one process-wide lock. Slow work on the results (OCR, PNG encoding of
a finished bitmap copy) may run outside it."""

import threading

PDFIUM_LOCK = threading.RLock()
