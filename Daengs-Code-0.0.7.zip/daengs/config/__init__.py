"""Config: per-customer settings from one file (modules, model paths, language)."""

from daengs.config.loader import ConfigError, load_settings

__all__ = ["ConfigError", "load_settings"]
