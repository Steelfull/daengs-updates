"""Read the customer settings file (TOML). Relative paths are relative to the file;
``%LOCALAPPDATA%`` and other environment variables are expanded (installed package)."""

import os
import tomllib
from dataclasses import fields
from pathlib import Path
from typing import Any

from daengs.core import (
    DaengsError,
    EmbeddingModel,
    IngestSettings,
    LlmModel,
    OcrModels,
    SearchSettings,
    Settings,
)

_TOP_KEYS = {"data_dir", "models", "ingest", "search"}
_OCR_KEYS = {"det", "cls", "rec", "rec_keys"}
_EMBEDDING_PATHS = {"onnx", "tokenizer"}
_LLM_PATHS = {"server", "model"}
# Installed next to the settings file by the "Daengs-Sprachmodell" setup (D-022).
EXTENSION_MANIFEST = Path("erweiterungen") / "sprachmodell" / "erweiterung.toml"


class ConfigError(DaengsError):
    """The settings file is missing, malformed or names missing model files."""


def load_settings(path: Path) -> Settings:
    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise ConfigError(f"Einstellungsdatei nicht lesbar: {exc}") from exc
    base = path.resolve().parent
    _reject_unknown(raw, _TOP_KEYS, "")
    if "data_dir" not in raw:
        raise ConfigError("data_dir fehlt")
    models = raw.get("models", {})
    _reject_unknown(models, {"ocr", "embedding", "llm"}, "models.")
    ingest = _numbers(IngestSettings, raw.get("ingest", {}), "ingest.")
    if not 0 <= ingest.chunk_overlap < ingest.chunk_words or ingest.ocr_threads < 1:
        raise ConfigError("ingest: ungültige Werte")
    search = _numbers(SearchSettings, raw.get("search", {}), "search.")
    if search.embedding_threads < 1 or search.candidates < 10 or search.rrf_k < 1:
        raise ConfigError("search: ungültige Werte")
    return Settings(
        data_dir=_path(base, raw["data_dir"]),
        ocr_models=_ocr_models(base, models.get("ocr")),
        embedding=_embedding(base, models.get("embedding")),
        llm=_llm(base, models.get("llm")) or load_extension(base / EXTENSION_MANIFEST),
        ingest=ingest,
        search=search,
    )


def _ocr_models(base: Path, ocr: dict[str, Any] | None) -> OcrModels | None:
    if ocr is None:
        return None
    _reject_unknown(ocr, _OCR_KEYS, "models.ocr.")
    _require(ocr, _OCR_KEYS, "models.ocr")
    return _existing(OcrModels(**{k: _path(base, ocr[k]) for k in _OCR_KEYS}))


def _embedding(base: Path, emb: dict[str, Any] | None) -> EmbeddingModel | None:
    if emb is None:
        return None
    _reject_unknown(emb, _EMBEDDING_PATHS | {"model_id", "dim", "max_tokens"}, "models.embedding.")
    _require(emb, _EMBEDDING_PATHS | {"model_id"}, "models.embedding")
    if not isinstance(emb["model_id"], str) or not emb["model_id"]:
        raise ConfigError("models.embedding.model_id muss ein nicht leerer Text sein")
    numbers = {k: emb[k] for k in ("dim", "max_tokens") if k in emb}
    if any(isinstance(v, bool) or not isinstance(v, int) or v < 1 for v in numbers.values()):
        raise ConfigError("models.embedding: dim und max_tokens müssen positive Zahlen sein")
    paths = {k: _path(base, emb[k]) for k in _EMBEDDING_PATHS}
    return _existing(EmbeddingModel(**paths, model_id=emb["model_id"], **numbers))


def _llm(base: Path, llm: dict[str, Any] | None) -> LlmModel | None:
    if llm is None:
        return None
    allowed = {f.name for f in fields(LlmModel)}
    _reject_unknown(llm, allowed, "models.llm.")
    _require(llm, _LLM_PATHS | {"model_id"}, "models.llm")
    if not isinstance(llm["model_id"], str) or not llm["model_id"]:
        raise ConfigError("models.llm.model_id muss ein nicht leerer Text sein")
    device = llm.get("device", "none")
    if not isinstance(device, str) or not device.replace("_", "").isalnum():
        raise ConfigError("models.llm.device ist ungültig")
    numbers = {k: v for k, v in llm.items() if k not in _LLM_PATHS | {"model_id", "device"}}
    if any(isinstance(v, bool) or not isinstance(v, int) or v < 1 for v in numbers.values()):
        raise ConfigError("models.llm: Zahlenwerte müssen positiv sein")
    paths = {k: _path(base, llm[k]) for k in _LLM_PATHS}
    return _existing(LlmModel(**paths, model_id=llm["model_id"], device=device, **numbers))


def load_extension(manifest: Path) -> LlmModel | None:
    """The language model extension, if installed. A broken extension is ignored (Daengs still
    starts without answers); it is not an error of the main settings file."""
    if not manifest.is_file():
        return None
    try:
        raw = tomllib.loads(manifest.read_text(encoding="utf-8"))
        _reject_unknown(raw, {"name", "version", "llm"}, "")
        return _llm(manifest.parent, raw.get("llm"))
    except (OSError, tomllib.TOMLDecodeError, ConfigError):
        return None


def _numbers[T](cls: type[T], values: dict[str, Any], prefix: str) -> T:
    allowed = {f.name: f.type for f in fields(cls)}  # type: ignore[arg-type]
    _reject_unknown(values, set(allowed), prefix)
    for key, value in values.items():
        expected = float if allowed[key] in (float, "float") else int
        if isinstance(value, bool) or not isinstance(value, expected | int):
            raise ConfigError(f"{prefix}{key} muss eine Zahl sein")
    return cls(**values)


def _existing[M: (OcrModels, EmbeddingModel, LlmModel)](models: M) -> M:
    missing = [str(p) for p in models.files() if not p.is_file()]
    if missing:
        # Fail early: libraries would otherwise try to download replacements (R-23).
        raise ConfigError(f"Modelldateien fehlen: {missing}")
    return models


def _path(base: Path, value: Any) -> Path:
    if not isinstance(value, str) or not value:
        raise ConfigError("Pfadangabe muss ein nicht leerer Text sein")
    expanded = os.path.expandvars(value)
    if "%" in expanded or "$" in expanded:
        raise ConfigError("Umgebungsvariable in einer Pfadangabe ist nicht gesetzt")
    return (base / Path(expanded)).resolve()


def _require(values: dict[str, Any], keys: set[str], prefix: str) -> None:
    missing = keys - set(values)
    if missing:
        raise ConfigError(f"{prefix} unvollständig: {sorted(missing)}")


def _reject_unknown(values: dict[str, Any], allowed: set[str], prefix: str) -> None:
    unknown = set(values) - allowed
    if unknown:
        raise ConfigError(f"unbekannte Einstellungen: {sorted(prefix + k for k in unknown)}")
