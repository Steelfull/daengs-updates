"""Overview as a table: components x chapters of a manual (D-067, D-069, D-070, D-071).

Way A of D-069: one search per cell ("component: words of the chapter") with the project's own
search, no language model, no change to reading. A passage fills a cell only when it is *direct*
(rule approved by Tim, 2026-11-07): the search marks it sure (rule unchanged), the component
stands in the passage, and a word of the chapter stands in the passage, in its heading path or in
the file name / document title (document kind words removed there). A passage that names the
component but is not direct is a hint and never fills a cell (D-069 (2)); passages that do not
name it are left out. How a cell got filled is kept per passage, for m20.

The user's work (rows, chapters, status and note per cell, fits / does not fit per passage, state
per document) lives in its own file ``uebersicht.sqlite`` in the project folder, with its own
schema version. It never refers to row ids of the project database, which change when files are
read again: passages are kept by folder, path, page and a hash of the page text, and moved to
where that text is found again (renamed file, shifted pages); a passage not found any more stays
and is shown as "Stelle nicht mehr gefunden".

Reads the project database by SQL only (contracts of daengs.ingest and daengs.search).
"""

import base64
import csv
import hashlib
import io
import json
import re
import sqlite3
import time
import uuid
import zipfile
from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape

from daengs import __version__
from daengs.core import DaengsError, ProjectContext

TABLE_DB = "uebersicht.sqlite"
TABLE_VERSION = 1
# Raised when the cell rule or what a cell result holds changes: every cached cell is then stale.
RULE_VERSION = (
    3  # 2: name parts only at a word start or compound end; 3: weak words, contents pages
)

SearchFn = Callable[[str, int], list[Mapping[str, Any]]]

OPEN, OK, ASK, NOT_RELEVANT = "offen", "ok", "rueckfrage", "nicht_relevant"
STATUSES = (OPEN, OK, ASK, NOT_RELEVANT)
FITS, FITS_NOT = "passt", "passt_nicht"
DOC_STATUSES = ("offen", "gesichtet", "nicht_relevant")
WAY_PASSAGE, WAY_HEADING, WAY_TITLE = "stelle", "ueberschrift", "dateiname_titel"

CANDIDATES = 40  # search hits per cell and language
HINTS = 15  # hints kept per cell, spread over documents
PER_FILE_FIRST = 4
SIMILAR = 0.8  # Jaccard of page vocabularies: the same page twice (parts lists)
ENGLISH_SHARE = 0.02  # a second search with English words from this share of English passages
QUERY_WORDS = 5  # own words of a chapter that go into the search question
MAX_COMPONENTS = 300
MAX_OWN_CHAPTERS = 20
MAX_NAME = 100
MAX_NOTE = 2000
MAX_WORDS = 40
MAX_SUGGESTIONS = 400
PRESELECT = 30  # suggestions ticked in advance at most (Tim, 2026-11-07)

_DATA = Path(__file__).parent
_WORD = re.compile(r"[\wäöüÄÖÜß]{3,}")
_TOKEN = re.compile(r"[\wäöüÄÖÜß]+(?:-[\wäöüÄÖÜß]+)*")
_LETTERS = re.compile(r"[a-zäöüß]")

_SCHEMA = f"""
create table if not exists meta(
    key text primary key,
    value text not null
);
create table if not exists component(
    key text primary key,
    name text not null,
    aliases text not null default '[]',
    terms text not null default '',
    hidden integer not null default 0,
    position integer not null
);
create table if not exists chapter(
    key text primary key,
    name text,
    extra_de text not null default '[]',
    extra_en text not null default '[]',
    own integer not null default 0,
    visible integer not null default 1,
    position integer not null
);
create table if not exists cell(
    component_key text not null references component(key) on delete cascade,
    chapter_key text not null references chapter(key) on delete cascade,
    status text not null check (status in ('{OPEN}', '{OK}', '{ASK}', '{NOT_RELEVANT}')),
    note text not null default '',
    updated text not null,
    primary key(component_key, chapter_key)
);
create table if not exists hit_decision(
    component_key text not null references component(key) on delete cascade,
    chapter_key text not null references chapter(key) on delete cascade,
    folder text not null,
    rel_path text not null,
    page_no integer not null,
    text_hash text not null,
    file_sha256 text not null,
    decision text not null check (decision in ('{FITS}', '{FITS_NOT}')),
    place text not null default '',
    snippet text not null default '',
    lost integer not null default 0,
    decided text not null,
    primary key(component_key, chapter_key, folder, rel_path, page_no)
);
create table if not exists doc_state(
    folder text not null,
    rel_path text not null,
    status text not null check (status in ('offen', 'gesichtet', 'nicht_relevant')),
    stand text not null default '',
    file_sha256 text not null default '',
    primary key(folder, rel_path)
);
create table if not exists cell_result(
    component_key text not null references component(key) on delete cascade,
    chapter_key text not null references chapter(key) on delete cascade,
    stamp text not null,
    hits text not null,
    primary key(component_key, chapter_key)
);
"""


# -- word lists ---------------------------------------------------------------------------------


def _load(name: str) -> dict[str, Any]:
    return json.loads((_DATA / name).read_text(encoding="utf-8"))


CHAPTERS: dict[str, Any] = _load("spalten.json")
NEGATIVE: dict[str, Any] = _load("negativ.json")
STANDARD = {c["key"]: c for c in CHAPTERS["spalten"]}
TEMPLATES: dict[str, list[str]] = CHAPTERS["vorlagen"]


def lists_hash() -> str:
    """Fingerprint of the shipped word lists, frozen in a test (D-069 (3))."""
    canonical = json.dumps([CHAPTERS, NEGATIVE], ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def norm(text: str) -> str:
    """Lower case, PDFium hyphen marks and soft hyphens gone, one space between words."""
    text = text.replace("￾ ", "").replace("￾", "").replace("­", "")
    return " ".join(text.split()).lower()


def word_in(word: str, text: str, whole_below: int = 4) -> bool:
    """A word of a list in normalized text: also as part of a longer word (Wartungsintervall,
    Schmierstoff); words shorter than ``whole_below`` only as a whole word ("CE" not in
    "Fläche")."""
    word = norm(word)
    if not word:
        return False
    if len(word) >= whole_below:
        return word in text
    return re.search(rf"(?<![\wäöüß]){re.escape(word)}(?![\wäöüß])", text) is not None


_ENDINGS = "(?:e|en|n|s|es|er|ern|ns)?"  # inflection after a compound head (Motoren)


def part_in(part: str, text: str) -> bool:
    """A part of a component name at the start of a word (Getriebemotor) or as the end of a
    compound with its inflection (Stirnradgetriebe, Elektromotoren), not in the middle of an
    unrelated word ("getriebe" in "angetriebene", found in the hand check, AP-9.30)."""
    p = re.escape(part)
    edge = r"[\wäöüß]"
    return re.search(rf"(?<!{edge}){p}|{p}{_ENDINGS}(?!{edge})", text) is not None


def component_in(names: list[str], text: str) -> bool:
    """The component stands in normalized text: one of its names as a whole, or every part of
    a name with at least 4 letters, also as part of a compound (Getriebemotoren)."""
    for name in names:
        name = norm(name)
        if not name:
            continue
        if part_in(name, text):
            return True
        parts = [t for t in _TOKEN.findall(name) if len(_LETTERS.findall(t)) >= 4]
        if parts and all(part_in(p, text) for p in parts):
            return True
    return False


def strip_document_kind(text: str) -> str:
    """File name or title without words that only name the kind of document (Betriebsanleitung,
    Handbuch, Operating instructions ...), also as the end of a compound ("Betriebs- und
    Wartungsanleitung", "Betriebs-/Montageanleitung": a whole manual, not one chapter)."""
    text = norm(re.sub(r"[_.]+", " ", text))
    for phrase in NEGATIVE["dokumentart_phrasen"]:
        text = text.replace(phrase, " ")
    kinds = NEGATIVE["dokumentart"]
    endings = tuple(NEGATIVE["dokumentart_endungen"])

    def is_kind(token: str) -> bool:
        token = token.strip("-,;:()/")
        return token in kinds or token.endswith(endings)

    return " ".join(t for t in text.split() if not is_kind(t))


@dataclass(frozen=True)
class Chapter:
    key: str
    name: str
    short: str
    words_de: list[str]
    words_en: list[str]
    question_de: str
    question_en: str
    own: bool
    visible: bool
    position: int
    weak: tuple[str, ...] = ()  # ambiguous words (Demontage, Funktion): no cell on their own

    @property
    def words(self) -> list[str]:
        return self.words_de + self.words_en

    @property
    def strong(self) -> list[str]:
        """The words that can make a passage direct. A weak word counts only together with a
        strong word of the chapter in the same passage or its heading path; there that strong
        word already decides, so a weak word adds nothing to the decision (AP-9.32)."""
        return [w for w in self.words if w not in self.weak]


def way_of(
    names: list[str], chapter: Chapter, passage: str, heading: str, title: str
) -> str | None:
    """How a sure passage is direct for a cell, or None (then it is only a hint).

    The component must stand in the passage itself; the chapter word may stand in the passage,
    in its heading path (Word) or in the file name / document title. In the title, document kind
    words are removed first and chapter words shorter than 6 letters count only as whole words
    (Freigabe Tim, 2026-11-07)."""
    passage = norm(passage)
    if not component_in(names, passage):
        return None
    strong = chapter.strong
    if any(word_in(w, passage) for w in strong):
        return WAY_PASSAGE
    heading = norm(heading)
    if heading and any(word_in(w, heading) for w in strong):
        return WAY_HEADING
    title = strip_document_kind(title)
    if title and any(word_in(w, title, whole_below=6) for w in strong):
        return WAY_TITLE
    return None


# -- contents and index pages ---------------------------------------------------------------------

_CONTENTS_HEADS = re.compile(
    r"(?:\d+[.)]?\s*)?(?:inhalt|inhaltsverzeichnis|stichwortverzeichnis|stichwörter|sachverzeichnis"
    r"|abbildungsverzeichnis|tabellenverzeichnis|index|key ?word index|contents|table of contents"
    r"|list of (?:tables|figures))(?:\s+(?:seite|page))?",
)
# A line that ends in a dot leader and a page number: "9.5 Entsorgung ....... 270", "Vent .... 40",
# also a list of numbers ("Transport ..... 11, 16"). Garbled characters before the number occur.
_LEADER_LINE = re.compile(
    r"(?:\.\s?){3,}[\s\ufffd]*\d{1,4}(?:\s*[,\u2013-]\s*\d{1,4})*\s*$|…+\s*\d{1,4}\s*$"
)
_SOFT_LINE = re.compile(r"[A-Za-zÄÖÜäöüß)]\.{1,2}\s+\d{1,3}\s*$")  # OCR: dots shrunk to one
# A numbered entry without leader: "4.6 Demontage der Naben 12" (contents list of a short manual)
_NUMBERED_LINE = re.compile(r"\d{1,2}(?:\.\d{1,2}){0,3}\.?\s+[^\d\s].*[^\d\s]\s+\d{1,3}")
CONTENTS_SHARE = 0.5  # share of leader lines from which a page is a contents/index page
CONTENTS_SOFT_SHARE = 0.8  # the same for OCR lines whose leader shrank to one or two dots
CONTENTS_NUMBERED_SHARE = 0.6  # the same for numbered entries without any leader
CONTENTS_MIN_LINES = 3
CONTENTS_MIN_SOFT_LINES = 8  # also the minimum for the numbered rule
_HEAD_LINES = 6


def is_contents_page(text: str) -> bool:
    """A table of contents, index or list of tables: a heading in the first lines ("Inhalt",
    "Stichwortverzeichnis", "Index", "Contents" ...) together with at least one line that ends
    in a dot leader and a page number, or most lines of the page end that way. Such a page names
    every component and every chapter without saying anything about either (AP-9.32).

    Thresholds measured on the 1,056 pages of the delivery corpus: of its 28 contents and index
    pages, 24 have a leader share of 0.59 to 0.98; the other three (the end of a contents list,
    two OCR scans whose dots are broken) are found by the heading or the soft rule (80 % of at
    least 8 lines). One more contents list has no leaders at all ("4.6 Demontage der Naben 12"):
    numbered entries make up 67 % of its lines, against at most 34 % on any other page, so the
    numbered rule starts at 60 % of at least 8 lines. Every other page has a leader share of 0
    and no such heading."""
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if len(lines) < 2:
        return False
    leaders = sum(1 for ln in lines if _LEADER_LINE.search(ln))
    if len(lines) >= CONTENTS_MIN_LINES and leaders / len(lines) >= CONTENTS_SHARE:
        return True
    heading = any(
        _CONTENTS_HEADS.fullmatch(ln.strip(" .:-_*#|\u2013").lower()) for ln in lines[:_HEAD_LINES]
    )
    if heading and leaders >= 1:
        return True
    if len(lines) >= CONTENTS_MIN_SOFT_LINES:
        soft = sum(1 for ln in lines if _LEADER_LINE.search(ln) or _SOFT_LINE.search(ln))
        if soft / len(lines) >= CONTENTS_SOFT_SHARE:
            return True
        numbered = sum(1 for ln in lines if _NUMBERED_LINE.fullmatch(ln))
        return numbered / len(lines) >= CONTENTS_NUMBERED_SHARE
    return False


# -- suggestions --------------------------------------------------------------------------------

NAME_HEADERS = {
    "benennung", "bezeichnung", "beschreibung", "teilebezeichnung", "artikelbezeichnung",
    "komponente", "description", "designation", "part name", "item description", "name",
}  # fmt: skip
GROUP_HEADERS = {
    "baugruppe", "gruppe", "unterbaugruppe", "hauptbaugruppe", "assembly", "sub-assembly",
    "subassembly", "group", "module",
}  # fmt: skip


def kind_of(value: str) -> str | None:
    """'normteil' or 'betriebsstoff' when a suggestion names a standard part or a consumable."""
    text = norm(value)
    tokens = [t.strip("-") for t in re.findall(r"[\wäöüß-]+", text)]
    for kind in ("normteil", "betriebsstoff"):
        for word in NEGATIVE[kind]:
            if any(t == word or (len(t) > len(word) and t.endswith(word)) for t in tokens):
                return kind
    if any(re.search(p, text) for p in NEGATIVE["normteil_muster"]):
        return "normteil"
    return None


def _header_key(value: str) -> str:
    return " ".join(re.sub(r"[^\wäöüß\- ]", " ", norm(value)).split())


# -- XLSX without a library ---------------------------------------------------------------------


def _col(n: int) -> str:
    letters = ""
    while n:
        n, r = divmod(n - 1, 26)
        letters = chr(65 + r) + letters
    return letters


def xlsx_bytes(sheet: str, rows: list[list[str]]) -> bytes:
    """A minimal workbook: one sheet, text cells only (inline strings, never a formula)."""
    body = []
    for r, row in enumerate(rows, start=1):
        cells = "".join(
            f'<c r="{_col(c)}{r}" t="inlineStr"><is><t xml:space="preserve">'
            f"{escape(_xml_text(str(v)))}</t></is></c>"
            for c, v in enumerate(row, start=1)
        )
        body.append(f'<row r="{r}">{cells}</row>')
    main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    pkg = "http://schemas.openxmlformats.org/package/2006/relationships"
    types = "http://schemas.openxmlformats.org/package/2006/content-types"
    xml_type = "application/vnd.openxmlformats-"
    sheet_type = xml_type + "officedocument.spreadsheetml"
    parts = {
        "[Content_Types].xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<Types xmlns="{types}">'
            f'<Default Extension="rels" ContentType="{xml_type}package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            f'<Override PartName="/xl/workbook.xml" ContentType="{sheet_type}.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml"'
            f' ContentType="{sheet_type}.worksheet+xml"/>'
            "</Types>"
        ),
        "_rels/.rels": (
            f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{pkg}">'
            f'<Relationship Id="rId1" Type="{rel}/officeDocument" Target="xl/workbook.xml"/>'
            "</Relationships>"
        ),
        "xl/workbook.xml": (
            f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<workbook xmlns="{main}" xmlns:r="{rel}"><sheets>'
            f'<sheet name="{escape(sheet[:31])}" sheetId="1" r:id="rId1"/></sheets></workbook>'
        ),
        "xl/_rels/workbook.xml.rels": (
            f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{pkg}">'
            f'<Relationship Id="rId1" Type="{rel}/worksheet" Target="worksheets/sheet1.xml"/>'
            "</Relationships>"
        ),
        "xl/worksheets/sheet1.xml": (
            f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<worksheet xmlns="{main}"><sheetData>{"".join(body)}</sheetData></worksheet>'
        ),
    }
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, text in parts.items():
            archive.writestr(name, text)
    return out.getvalue()


def _xml_text(value: str) -> str:
    # Characters XML 1.0 does not allow (control characters from PDFs) are dropped.
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]", "", value)


def _csv_cell(value: str) -> str:
    value = " ".join(str(value).replace("￾", "").split())
    return "'" + value if value[:1] in ("=", "+", "-", "@", "\t", "\r") else value


def csv_text(rows: list[list[str]]) -> str:
    """For Excel: BOM, semicolons; a cell never starts a formula (CSV injection)."""
    out = io.StringIO()
    out.write("﻿")
    writer = csv.writer(out, delimiter=";", lineterminator="\r\n")
    for row in rows:
        writer.writerow([_csv_cell(v) for v in row])
    return out.getvalue()


# -- the store ----------------------------------------------------------------------------------


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def page_hash(text: str) -> str:
    return _hash(norm(text))[:32]


def _jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0


class Table:
    """The table of one project: its own store next to the project database."""

    def __init__(self, context: ProjectContext) -> None:
        self.context = context
        self.path = context.project_dir / TABLE_DB
        with self.context.transaction() as con:
            if not con.execute("select 1 from sqlite_master where name = 'file'").fetchone():
                raise DaengsError("Projekt ist noch nicht eingelesen")
        with self._store() as con:
            version = con.execute("pragma user_version").fetchone()[0]
            if version > TABLE_VERSION:
                raise DaengsError("Die Übersicht stammt aus einer neueren Fassung von Daengs")
            con.executescript(_SCHEMA)
            con.execute(f"pragma user_version = {TABLE_VERSION}")
            row = con.execute("select value from meta where key = 'project_id'").fetchone()
            if row is None:
                con.execute(
                    "insert into meta(key, value) values ('project_id', ?)",
                    (context.project_id,),
                )
            elif row[0] != context.project_id:
                raise DaengsError("Die Übersicht gehört zu einem anderen Projekt")
            if not con.execute("select 1 from chapter").fetchone():
                for position, key in enumerate(TEMPLATES["standard"]):
                    con.execute("insert into chapter(key, position) values (?, ?)", (key, position))
                self._set_meta(con, "template", "standard")
            if self._meta(con, "assemblies_taken") is None:
                self._take_assemblies(con)

    # -- connections ----------------------------------------------------------------------------

    @contextmanager
    def _store(self) -> Iterator[sqlite3.Connection]:
        """Only this project's own overview file (same pragmas as the project database)."""
        if self.path.parent != self.context.project_dir:
            raise DaengsError("Übersicht liegt außerhalb des Projekts")
        con = sqlite3.connect(self.path, timeout=30)
        con.execute("pragma foreign_keys = on")
        con.execute("pragma secure_delete = on")
        con.execute("pragma journal_mode = wal")
        con.execute("pragma busy_timeout = 30000")
        try:
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    @staticmethod
    def _meta(con: sqlite3.Connection, key: str) -> str | None:
        row = con.execute("select value from meta where key = ?", (key,)).fetchone()
        return row[0] if row else None

    @staticmethod
    def _set_meta(con: sqlite3.Connection, key: str, value: str) -> None:
        con.execute("insert or replace into meta(key, value) values (?, ?)", (key, value))

    def _take_assemblies(self, con: sqlite3.Connection) -> None:
        """Assemblies of the old overview (AP-9.5) become rows, once; their decisions stay in
        the project database (no chapter, tied to row ids)."""
        with self.context.transaction() as project:
            rows = []
            if project.execute("select 1 from sqlite_master where name = 'assembly'").fetchone():
                rows = project.execute(
                    "select name, terms from assembly order by position, id"
                ).fetchall()
        start = con.execute("select coalesce(max(position) + 1, 0) from component").fetchone()[0]
        known = {n.lower() for (n,) in con.execute("select name from component")}
        for i, (name, terms) in enumerate(rows):
            if name.lower() not in known:
                con.execute(
                    "insert into component(key, name, terms, position) values (?, ?, ?, ?)",
                    (uuid.uuid4().hex, name[:MAX_NAME], terms[:500], start + i),
                )
        self._set_meta(con, "assemblies_taken", str(len(rows)))

    # -- settings of the view -------------------------------------------------------------------

    def view_settings(self) -> dict[str, Any]:
        with self._store() as con:
            view = self._meta(con, "view")
            return {
                "intro_seen": self._meta(con, "intro_seen") == "1",
                "template": self._meta(con, "template") or "standard",
                "view": json.loads(view) if view else {},
            }

    def set_view(self, intro_seen: bool | None, view: dict[str, Any] | None) -> None:
        with self._store() as con:
            if intro_seen is not None:
                self._set_meta(con, "intro_seen", "1" if intro_seen else "0")
            if view is not None:
                self._set_meta(con, "view", json.dumps(view, ensure_ascii=False))

    # -- rows -----------------------------------------------------------------------------------

    def components(self, con: sqlite3.Connection | None = None) -> list[dict[str, Any]]:
        if con is None:
            with self._store() as c:
                return self.components(c)
        rows = con.execute(
            "select key, name, aliases, terms, hidden, position from component"
            " order by position, name"
        )
        return [
            {
                "key": k,
                "name": n,
                "aliases": json.loads(a),
                "terms": t,
                "hidden": bool(h),
                "position": p,
            }
            for k, n, a, t, h, p in rows
        ]

    @staticmethod
    def _clean_name(name: str) -> str:
        name = " ".join(str(name).split())
        if not name or len(name) > MAX_NAME:
            raise DaengsError(f"Name fehlt oder ist länger als {MAX_NAME} Zeichen")
        return name

    def add_components(self, names: list[str]) -> list[dict[str, Any]]:
        with self._store() as con:
            known = {n.lower() for (n,) in con.execute("select name from component")}
            count = len(known)
            position = con.execute(
                "select coalesce(max(position) + 1, 0) from component"
            ).fetchone()[0]
            for raw in names:
                name = self._clean_name(raw)
                if name.lower() in known:
                    continue
                if count >= MAX_COMPONENTS:
                    raise DaengsError(f"Höchstens {MAX_COMPONENTS} Komponenten")
                con.execute(
                    "insert into component(key, name, position) values (?, ?, ?)",
                    (uuid.uuid4().hex, name, position),
                )
                known.add(name.lower())
                count += 1
                position += 1
            return self.components(con)

    def update_component(
        self,
        key: str,
        name: str | None = None,
        hidden: bool | None = None,
        aliases: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        with self._store() as con:
            if not con.execute("select 1 from component where key = ?", (key,)).fetchone():
                raise DaengsError("Komponente nicht gefunden")
            if name is not None:
                name = self._clean_name(name)
                other = con.execute(
                    "select 1 from component where lower(name) = lower(?) and key != ?",
                    (name, key),
                ).fetchone()
                if other:
                    raise DaengsError("Diese Komponente gibt es schon")
                con.execute("update component set name = ? where key = ?", (name, key))
            if hidden is not None:
                con.execute("update component set hidden = ? where key = ?", (int(hidden), key))
            if aliases is not None:
                clean = [self._clean_name(a) for a in aliases][:20]
                con.execute(
                    "update component set aliases = ? where key = ?",
                    (json.dumps(clean, ensure_ascii=False), key),
                )
            return self.components(con)

    def merge_components(self, keep: str, others: list[str]) -> list[dict[str, Any]]:
        """Several names of one thing (Getriebemotor = GM 45): one row, the others become
        names it is also found by. Status and notes of the kept row win; decisions move over."""
        with self._store() as con:
            row = con.execute("select name, aliases from component where key = ?", (keep,))
            found = row.fetchone()
            if found is None:
                raise DaengsError("Komponente nicht gefunden")
            aliases = json.loads(found[1])
            for other in others:
                if other == keep:
                    continue
                o = con.execute(
                    "select name, aliases from component where key = ?", (other,)
                ).fetchone()
                if o is None:
                    raise DaengsError("Komponente nicht gefunden")
                aliases += [o[0], *json.loads(o[1])]
                con.execute(
                    "insert or ignore into cell(component_key, chapter_key, status, note,"
                    " updated) select ?, chapter_key, status, note, updated from cell"
                    " where component_key = ?",
                    (keep, other),
                )
                con.execute(
                    "insert or ignore into hit_decision select ?, chapter_key, folder, rel_path,"
                    " page_no, text_hash, file_sha256, decision, place, snippet, lost, decided"
                    " from hit_decision where component_key = ?",
                    (keep, other),
                )
                con.execute("delete from component where key = ?", (other,))
            unique = []
            for a in aliases:
                if a.lower() != found[0].lower() and a.lower() not in {u.lower() for u in unique}:
                    unique.append(a)
            con.execute(
                "update component set aliases = ? where key = ?",
                (json.dumps(unique[:20], ensure_ascii=False), keep),
            )
            con.execute("delete from cell_result where component_key = ?", (keep,))
            return self.components(con)

    def remove_component(self, key: str) -> list[dict[str, Any]]:
        with self._store() as con:
            con.execute("delete from component where key = ?", (key,))
            return self.components(con)

    def move_component(self, key: str, position: int) -> list[dict[str, Any]]:
        with self._store() as con:
            keys = [k for (k,) in con.execute("select key from component order by position, name")]
            if key not in keys:
                raise DaengsError("Komponente nicht gefunden")
            keys.remove(key)
            keys.insert(max(0, min(position, len(keys))), key)
            for i, k in enumerate(keys):
                con.execute("update component set position = ? where key = ?", (i, k))
            return self.components(con)

    # -- chapters -------------------------------------------------------------------------------

    def chapters(self, con: sqlite3.Connection | None = None) -> list[Chapter]:
        if con is None:
            with self._store() as c:
                return self.chapters(c)
        result = []
        for key, name, extra_de, extra_en, own, visible, position in con.execute(
            "select key, name, extra_de, extra_en, own, visible, position from chapter"
            " order by position"
        ):
            extra_de, extra_en = json.loads(extra_de), json.loads(extra_en)
            if own:
                question = " ".join([name or "", *extra_de[:QUERY_WORDS]])
                result.append(
                    Chapter(key, name or "", name or "", extra_de, extra_en, question,
                            " ".join(extra_en[:QUERY_WORDS]), True, bool(visible), position)
                )  # fmt: skip
                continue
            std = STANDARD.get(key)
            if std is None:
                continue  # a chapter of a newer list version
            result.append(
                Chapter(
                    key,
                    name or std["name"],
                    name or std["kurz"],
                    [*std["de"], *extra_de],
                    [*std["en"], *extra_en],
                    " ".join([std["frage_de"], *extra_de[:QUERY_WORDS]]),
                    " ".join([std["frage_en"], *extra_en[:QUERY_WORDS]]),
                    False,
                    bool(visible),
                    position,
                    tuple(
                        w
                        for w in [*std.get("schwach_de", []), *std.get("schwach_en", [])]
                        if w not in extra_de and w not in extra_en  # an own word is a strong one
                    ),
                )
            )
        return result

    @staticmethod
    def _clean_words(words: list[str]) -> list[str]:
        clean: list[str] = []
        for w in words:
            w = " ".join(str(w).split()).lower()
            if w and len(w) <= 60 and w not in clean:
                clean.append(w)
        if len(clean) > MAX_WORDS:
            raise DaengsError(f"Höchstens {MAX_WORDS} Suchwörter je Spalte")
        return clean

    def add_chapter(self, name: str, words_de: list[str], words_en: list[str]) -> str:
        name = self._clean_name(name)
        words_de, words_en = self._clean_words(words_de), self._clean_words(words_en)
        if not words_de and not words_en:
            raise DaengsError("Eine eigene Spalte braucht mindestens ein Suchwort")
        with self._store() as con:
            if con.execute("select count(*) from chapter where own = 1").fetchone()[0] >= (
                MAX_OWN_CHAPTERS
            ):
                raise DaengsError(f"Höchstens {MAX_OWN_CHAPTERS} eigene Spalten")
            key = "eigen_" + uuid.uuid4().hex[:12]
            position = con.execute("select coalesce(max(position) + 1, 0) from chapter").fetchone()
            con.execute(
                "insert into chapter(key, name, extra_de, extra_en, own, position)"
                " values (?, ?, ?, ?, 1, ?)",
                (key, name, json.dumps(words_de, ensure_ascii=False),
                 json.dumps(words_en, ensure_ascii=False), position[0]),
            )  # fmt: skip
            self._set_meta(con, "template", "eigen")
            return key

    def update_chapter(
        self,
        key: str,
        name: str | None = None,
        words_de: list[str] | None = None,
        words_en: list[str] | None = None,
        visible: bool | None = None,
        reset: bool = False,
    ) -> None:
        """Own chapters: name and words. Standard chapters: own name and extra words on top of
        the shipped list; ``reset`` brings back the shipped state."""
        with self._store() as con:
            row = con.execute("select own from chapter where key = ?", (key,)).fetchone()
            if row is None:
                raise DaengsError("Spalte nicht gefunden")
            if reset and not row[0]:
                con.execute(
                    "update chapter set name = null, extra_de = '[]', extra_en = '[]'"
                    " where key = ?",
                    (key,),
                )
            if name is not None:
                con.execute(
                    "update chapter set name = ? where key = ?", (self._clean_name(name), key)
                )
            for column, words in (("extra_de", words_de), ("extra_en", words_en)):
                if words is not None:
                    con.execute(
                        f"update chapter set {column} = ? where key = ?",  # noqa: S608 (fixed)
                        (json.dumps(self._clean_words(words), ensure_ascii=False), key),
                    )
            if visible is not None:
                con.execute("update chapter set visible = ? where key = ?", (int(visible), key))
                self._set_meta(con, "template", "eigen")

    def remove_chapter(self, key: str) -> None:
        with self._store() as con:
            row = con.execute("select own from chapter where key = ?", (key,)).fetchone()
            if row is None:
                raise DaengsError("Spalte nicht gefunden")
            if not row[0]:
                raise DaengsError("Standardspalten lassen sich nur ausblenden")
            con.execute("delete from chapter where key = ?", (key,))

    def use_template(self, template: str) -> None:
        if template not in TEMPLATES:
            raise DaengsError("Unbekannte Vorlage")
        shown = set(TEMPLATES[template])
        with self._store() as con:
            for (key,) in con.execute("select key from chapter where own = 0").fetchall():
                con.execute(
                    "update chapter set visible = ? where key = ?", (int(key in shown), key)
                )
            self._set_meta(con, "template", template)

    # -- status, notes, decisions ---------------------------------------------------------------

    def _check_cell(self, con: sqlite3.Connection, component: str, chapter: str) -> None:
        if not con.execute("select 1 from component where key = ?", (component,)).fetchone():
            raise DaengsError("Komponente nicht gefunden")
        if not con.execute("select 1 from chapter where key = ?", (chapter,)).fetchone():
            raise DaengsError("Spalte nicht gefunden")

    def set_cell(
        self, component: str, chapter: str, status: str | None, note: str | None
    ) -> dict[str, str]:
        if status is not None and status not in STATUSES:
            raise DaengsError("Unbekannter Status")
        if note is not None and len(note) > MAX_NOTE:
            raise DaengsError(f"Notiz länger als {MAX_NOTE} Zeichen")
        with self._store() as con:
            self._check_cell(con, component, chapter)
            row = con.execute(
                "select status, note from cell where component_key = ? and chapter_key = ?",
                (component, chapter),
            ).fetchone()
            status = status if status is not None else (row[0] if row else OPEN)
            note = note if note is not None else (row[1] if row else "")
            if status == OPEN and not note.strip():
                con.execute(
                    "delete from cell where component_key = ? and chapter_key = ?",
                    (component, chapter),
                )
            else:
                con.execute(
                    "insert or replace into cell(component_key, chapter_key, status, note,"
                    " updated) values (?, ?, ?, ?, ?)",
                    (component, chapter, status, note, _now()),
                )
            return {"status": status, "note": note}

    def decide(
        self,
        component: str,
        chapter: str,
        folder: str,
        rel_path: str,
        page_no: int,
        decision: str | None,
    ) -> None:
        """Fits / does not fit for one passage of a cell, kept by place and page text."""
        if decision not in (FITS, FITS_NOT, None):
            raise DaengsError("Entscheidung muss passt, passt nicht oder leer sein")
        with self._store() as con:
            self._check_cell(con, component, chapter)
            key = (component, chapter, folder, rel_path, page_no)
            if decision is None:
                con.execute(
                    "delete from hit_decision where component_key = ? and chapter_key = ?"
                    " and folder = ? and rel_path = ? and page_no = ?",
                    key,
                )
                return
            with self.context.transaction() as project:
                row = project.execute(
                    "select p.text, f.sha256, coalesce(p.label, '') from page p"
                    " join file f on f.id = p.file_id"
                    " where f.folder = ? and f.rel_path = ? and p.page_no = ?",
                    (folder, rel_path, page_no),
                ).fetchone()
            if row is None:
                raise DaengsError("Seite nicht gefunden")
            text, sha, label = row
            con.execute(
                "insert or replace into hit_decision(component_key, chapter_key, folder,"
                " rel_path, page_no, text_hash, file_sha256, decision, place, snippet, lost,"
                " decided) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)",
                (*key, page_hash(text), sha, decision, label, " ".join(text.split())[:240], _now()),
            )

    def set_document(
        self, folder: str, rel_path: str, status: str | None, stand: str | None
    ) -> None:
        if status is not None and status not in DOC_STATUSES:
            raise DaengsError("Unbekannter Status")
        if stand is not None and len(stand) > 200:
            raise DaengsError("Stand ist zu lang")
        with self.context.transaction() as project:
            row = project.execute(
                "select sha256 from file where folder = ? and rel_path = ?", (folder, rel_path)
            ).fetchone()
        if row is None:
            raise DaengsError("Datei nicht gefunden")
        with self._store() as con:
            old = con.execute(
                "select status, stand from doc_state where folder = ? and rel_path = ?",
                (folder, rel_path),
            ).fetchone()
            con.execute(
                "insert or replace into doc_state(folder, rel_path, status, stand, file_sha256)"
                " values (?, ?, ?, ?, ?)",
                (
                    folder,
                    rel_path,
                    status if status is not None else (old[0] if old else "offen"),
                    stand if stand is not None else (old[1] if old else ""),
                    row[0],
                ),
            )

    # -- reconciling decisions after reading again ----------------------------------------------

    def reconcile(self) -> int:
        """Moves decisions to where their page text is now (shifted pages, renamed file) and
        marks those not found any more. Returns how many are lost."""
        with self._store() as con:
            decisions = con.execute(
                "select rowid, folder, rel_path, page_no, text_hash from hit_decision"
            ).fetchall()
            if not decisions:
                return 0
            with self.context.transaction() as project:
                pages = project.execute(
                    "select f.folder, f.rel_path, p.page_no, p.text, f.sha256 from page p"
                    " join file f on f.id = p.file_id where p.text != ''"
                ).fetchall()
            here = {(f, r, n): (page_hash(t), s) for f, r, n, t, s in pages}
            by_hash: dict[str, list[tuple[str, str, int]]] = {}
            for place, (h, _) in here.items():
                by_hash.setdefault(h, []).append(place)
            lost = 0
            for rowid, folder, rel, page_no, text_hash in decisions:
                now = here.get((folder, rel, page_no))
                if now and now[0] == text_hash:
                    con.execute(
                        "update hit_decision set lost = 0, file_sha256 = ? where rowid = ?",
                        (now[1], rowid),
                    )
                    continue
                places = by_hash.get(text_hash, [])
                target = next((p for p in places if p[:2] == (folder, rel)), None) or (
                    places[0] if places else None
                )
                if target is None:
                    con.execute("update hit_decision set lost = 1 where rowid = ?", (rowid,))
                    lost += 1
                    continue
                try:
                    con.execute(
                        "update hit_decision set folder = ?, rel_path = ?, page_no = ?,"
                        " file_sha256 = ?, lost = 0 where rowid = ?",
                        (*target, here[target][1], rowid),
                    )
                except sqlite3.IntegrityError:
                    # The same cell already decides that page: the newer decision stays.
                    con.execute("delete from hit_decision where rowid = ?", (rowid,))
            return lost

    # -- computing cells ------------------------------------------------------------------------

    def index_stamp(self) -> str:
        """Changes whenever a search result could change: files, titles, OCR, embeddings."""
        with self.context.transaction() as con:
            files = con.execute(
                "select id, sha256, version, title, status from file order by id"
            ).fetchall()
            pending = con.execute(
                "select count(*) from page where source = 'ocr_pending'"
            ).fetchone()[0]
            meta, vectors = [], 0
            if con.execute("select 1 from sqlite_master where name = 'search_meta'").fetchone():
                # language_rule is written by the first search itself; a new rule comes with an
                # update, and every update recomputes the table once (version below).
                meta = con.execute(
                    "select key, value from search_meta where key != 'language_rule' order by key"
                ).fetchall()
                vectors = con.execute("select count(*) from chunk_vector").fetchone()[0]
        parts = [RULE_VERSION, __version__, files, pending, meta, vectors]
        return _hash(json.dumps(parts, ensure_ascii=False))

    def english(self) -> bool:
        with self.context.transaction() as con:
            total, en = con.execute(
                "select count(*), sum(case when lang = 'en' then 1 else 0 end) from chunk"
            ).fetchone()
        return bool(total) and (en or 0) / total >= ENGLISH_SHARE

    @staticmethod
    def cell_stamp(index_stamp: str, component: Mapping[str, Any], chapter: Chapter, en: bool):
        parts = [
            index_stamp,
            component["name"],
            component["aliases"],
            component["terms"],
            chapter.words,
            chapter.question_de,
            chapter.question_en,
            en,
        ]
        return _hash(json.dumps(parts, ensure_ascii=False))

    def pending_cells(self) -> tuple[int, int]:
        """(cells still to compute, cells shown): what the table waits for."""
        stamp, en = self.index_stamp(), self.english()
        with self._store() as con:
            comps = [c for c in self.components(con) if not c["hidden"]]
            chapters = [c for c in self.chapters(con) if c.visible]
            have = dict(
                ((c, ch), s)
                for c, ch, s in con.execute(
                    "select component_key, chapter_key, stamp from cell_result"
                )
            )
        todo = sum(
            1
            for c in comps
            for ch in chapters
            if have.get((c["key"], ch.key)) != self.cell_stamp(stamp, c, ch, en)
        )
        return todo, len(comps) * len(chapters)

    def compute(
        self,
        search: SearchFn,
        stop: Any = None,
        on_cell: Callable[[int, int], None] | None = None,
    ) -> bool:
        """Searches every shown cell whose result is stale; False when stopped early. A cell
        that is done stays done, so a stopped run goes on where it was."""
        stamp, en = self.index_stamp(), self.english()
        self.reconcile()
        with self._store() as con:
            comps = [c for c in self.components(con) if not c["hidden"]]
            chapters = [c for c in self.chapters(con) if c.visible]
            have = dict(
                ((c, ch), s)
                for c, ch, s in con.execute(
                    "select component_key, chapter_key, stamp from cell_result"
                )
            )
        todo = [
            (c, ch, self.cell_stamp(stamp, c, ch, en))
            for c in comps
            for ch in chapters
            if have.get((c["key"], ch.key)) != self.cell_stamp(stamp, c, ch, en)
        ]
        pages = _PageCache(self.context)
        started, done = time.perf_counter(), 0
        try:
            for i, (component, chapter, cell_stamp) in enumerate(todo):
                if stop is not None and stop.is_set():
                    return False
                hits = self._cell(search, pages, component, chapter, en)
                with self._store() as con:
                    con.execute(
                        "insert or replace into cell_result(component_key, chapter_key, stamp,"
                        " hits) values (?, ?, ?, ?)",
                        (component["key"], chapter.key, cell_stamp,
                         json.dumps(hits, ensure_ascii=False)),
                    )  # fmt: skip
                done += 1
                if on_cell is not None:
                    on_cell(i + 1, len(todo))
        finally:
            pages.close()
            if done:
                with self._store() as con:
                    per_cell = (time.perf_counter() - started) * 1000 / done
                    self._set_meta(con, "ms_per_cell", f"{per_cell:.1f}")
        return True

    def _cell(
        self,
        search: SearchFn,
        pages: "_PageCache",
        component: Mapping[str, Any],
        chapter: Chapter,
        en: bool,
    ) -> list[dict[str, Any]]:
        names = [component["name"], *component["aliases"]]
        subject = " ".join([component["name"], component["terms"]]).strip()
        questions = [f"{subject}: {chapter.question_de}"]
        if en and chapter.question_en.strip():
            questions.append(f"{subject}: {chapter.question_en}")
        seen: set[tuple[str, str, int]] = set()
        entries: list[dict[str, Any]] = []
        for question in questions:
            for hit in search(question, CANDIDATES):
                place = (str(hit["folder"]), hit["rel_path"], hit["page_no"])
                if place in seen:
                    continue
                seen.add(place)
                info = pages.passage(hit["chunk_id"], hit["file_id"], hit["page_no"])
                # a contents or index page gives neither a direct passage nor a hint
                if info is None or info["contents"]:
                    continue
                # A hint names the component at least; hits without it are left out, or every
                # cell would carry a hint (the search always returns its best pages).
                if not component_in(names, norm(info["passage"])):
                    continue
                way = None
                if hit.get("sure", True):
                    way = way_of(
                        names,
                        chapter,
                        info["passage"],
                        info["heading"],
                        f"{Path(hit['rel_path']).stem} {info['title']}",
                    )
                entries.append(
                    {
                        "folder": place[0],
                        "rel_path": place[1],
                        "page_no": place[2],
                        "file_id": hit["file_id"],
                        "chunk_id": hit["chunk_id"],
                        "place": hit.get("place", ""),
                        "kind": hit.get("kind", "pdf"),
                        "snippet": hit.get("snippet", ""),
                        "sure": bool(hit.get("sure", True)),
                        "direct": way is not None,
                        "way": way,
                        "hash": info["hash"],
                        "lang": info["lang"],
                        "similar": [],
                    }
                )
        merged = _merge_similar(entries, pages)
        direct = [e for e in merged if e["direct"]]
        hints = _spread([e for e in merged if not e["direct"]], HINTS)
        return direct + hints

    # -- reading the table ----------------------------------------------------------------------

    def files(self) -> list[dict[str, Any]]:
        with self.context.transaction() as con:
            rows = con.execute(
                "select f.folder, f.rel_path, f.title, f.sha256, f.mtime_ns, f.status,"
                " (select group_concat(distinct c.lang) from chunk c where c.file_id = f.id)"
                " from file f order by f.folder, f.rel_path"
            ).fetchall()
        with self._store() as con:
            docs = {
                (f, r): (s, st, h)
                for f, r, s, st, h in con.execute(
                    "select folder, rel_path, status, stand, file_sha256 from doc_state"
                )
            }
        result = []
        for folder, rel, title, sha, mtime, status, langs in rows:
            state = docs.get((folder, rel))
            result.append(
                {
                    "folder": folder,
                    "rel_path": rel,
                    "title": title,
                    "kind": Path(rel).suffix.lower().lstrip(".") or "pdf",
                    "date": time.strftime("%d.%m.%Y", time.localtime(mtime / 1e9)),
                    "readable": status == "ok",
                    "langs": sorted(x for x in (langs or "").split(",") if x),
                    "status": state[0] if state else "offen",
                    "stand": state[1] if state else "",
                    "changed": bool(state and state[2] and state[2] != sha),
                }
            )
        return result

    def table(self) -> dict[str, Any]:
        """Everything the view needs, from the store only (no search): rows, chapters, files
        and per cell its status, note, direct passages (file, page, language) and hints."""
        files = self.files()
        index = {(f["folder"], f["rel_path"]): i for i, f in enumerate(files)}
        with self._store() as con:
            comps = self.components(con)
            chapters = self.chapters(con)
            cells = {
                (c, ch): (s, n)
                for c, ch, s, n in con.execute(
                    "select component_key, chapter_key, status, note from cell"
                )
            }
            results = {
                (c, ch): json.loads(h)
                for c, ch, h in con.execute(
                    "select component_key, chapter_key, hits from cell_result"
                )
            }
            decisions = self._decisions(con)
            ms_per_cell = self._meta(con, "ms_per_cell")
            settings = {
                "ms_per_cell": float(ms_per_cell) if ms_per_cell else None,
                "intro_seen": self._meta(con, "intro_seen") == "1",
                "template": self._meta(con, "template") or "standard",
                "view": json.loads(self._meta(con, "view") or "{}"),
            }
        out_cells: dict[str, Any] = {}
        for c in comps:
            for ch in chapters:
                key = (c["key"], ch.key)
                status, note = cells.get(key, (OPEN, ""))
                shown = _apply(results.get(key), decisions.get(key, {}))
                cell: dict[str, Any] = {"st": status}
                if note:
                    cell["n"] = note
                d = [[index[(e["folder"], e["rel_path"])], e["page_no"], e.get("lang") or ""]
                     for e in shown["direct"] if (e["folder"], e["rel_path"]) in index]  # fmt: skip
                if d:
                    cell["d"] = d
                if shown["hints"]:
                    cell["h"] = len(shown["hints"])
                    cell["hf"] = sorted(
                        {index[(e["folder"], e["rel_path"])] for e in shown["hints"]
                         if (e["folder"], e["rel_path"]) in index}
                    )  # fmt: skip
                if shown["lost"]:
                    cell["lost"] = len(shown["lost"])
                if key not in results:
                    cell["wait"] = 1
                out_cells[f"{c['key']}|{ch.key}"] = cell
        return {
            "components": comps,
            "chapters": [_chapter_out(ch) for ch in chapters],
            "files": files,
            "cells": out_cells,
            **settings,
        }

    def _decisions(self, con: sqlite3.Connection) -> dict[tuple[str, str], dict]:
        out: dict[tuple[str, str], dict] = {}
        for row in con.execute(
            "select component_key, chapter_key, folder, rel_path, page_no, decision, place,"
            " snippet, lost, decided from hit_decision"
        ):
            c, ch, folder, rel, page, decision, place, snippet, lost, decided = row
            out.setdefault((c, ch), {})[(folder, rel, page)] = {
                "decision": decision,
                "place": place,
                "snippet": snippet,
                "lost": bool(lost),
                "decided": decided,
            }
        return out

    def cell(self, component: str, chapter: str) -> dict[str, Any]:
        """One cell in full, for the panel: passages, hints, lost decisions, how it searched."""
        with self._store() as con:
            self._check_cell(con, component, chapter)
            comp = next(c for c in self.components(con) if c["key"] == component)
            ch = next(c for c in self.chapters(con) if c.key == chapter)
            row = con.execute(
                "select hits from cell_result where component_key = ? and chapter_key = ?",
                (component, chapter),
            ).fetchone()
            state = con.execute(
                "select status, note from cell where component_key = ? and chapter_key = ?",
                (component, chapter),
            ).fetchone()
            decisions = self._decisions(con).get((component, chapter), {})
        shown = _apply(json.loads(row[0]) if row else None, decisions)
        # Passages kept only by a decision carry no row id: the viewer needs the current one.
        with self.context.transaction() as con:
            ids = {(f, r): i for i, f, r in con.execute("select id, folder, rel_path from file")}
        for group in shown.values():
            for e in group:
                e["file_id"] = ids.get((e["folder"], e["rel_path"]), e.get("file_id"))
        subject = " ".join([comp["name"], comp["terms"]]).strip()
        return {
            "component": comp,
            "chapter": _chapter_out(ch),
            "status": state[0] if state else OPEN,
            "note": state[1] if state else "",
            "computed": row is not None,
            **shown,
            "searched": {
                "questions": [f"{subject}: {ch.question_de}"]
                + ([f"{subject}: {ch.question_en}"] if self.english() else []),
                "names": [comp["name"], *comp["aliases"]],
                "words": ch.words,
            },
        }

    # -- lists for the customer -----------------------------------------------------------------

    def questions(self) -> list[dict[str, Any]]:
        """Cells with status 'Rückfrage', in table order, with their note (the request list)."""
        data = self.table()
        names = {c.get("key"): c for c in data["chapters"]}
        out = []
        for comp in data["components"]:
            for ch in data["chapters"]:
                cell = data["cells"].get(f"{comp['key']}|{ch['key']}", {})
                if cell.get("st") == ASK:
                    out.append(
                        {
                            "component": comp["key"],
                            "component_name": comp["name"],
                            "chapter": ch["key"],
                            "chapter_name": names[ch["key"]]["name"],
                            "note": cell.get("n", ""),
                            "direct": len(cell.get("d", [])),
                            "hints": cell.get("h", 0),
                        }
                    )
        return out

    def questions_text(self) -> str:
        items = self.questions()
        lines = ["Zu folgenden Punkten fehlen uns Informationen:", ""]
        for i, q in enumerate(items, start=1):
            text = q["note"].strip() or "Bitte Unterlagen nachreichen."
            lines.append(f"{i}. {q['component_name']} ({q['chapter_name']}): {text}")
        return "\n".join(lines) + "\n"

    def questions_rows(self) -> list[list[str]]:
        rows = [["Nr.", "Komponente", "Kapitel", "Rückfrage"]]
        for i, q in enumerate(self.questions(), start=1):
            rows.append([str(i), q["component_name"], q["chapter_name"], q["note"]])
        return rows

    def table_rows(self) -> list[list[str]]:
        data = self.table()
        files = data["files"]
        labels = {OPEN: "offen", OK: "ok", ASK: "Rückfrage", NOT_RELEVANT: "nicht relevant"}
        rows = [["Komponente", "Kapitel", "Status", "Notiz", "Fundstellen", "Hinweise"]]
        for comp in data["components"]:
            if comp["hidden"]:
                continue
            for ch in data["chapters"]:
                if not ch["visible"]:
                    continue
                cell = data["cells"].get(f"{comp['key']}|{ch['key']}", {})
                places = [f"{files[f]['rel_path']} S. {p}" for f, p, _ in cell.get("d", [])]
                rows.append(
                    [
                        comp["name"],
                        ch["name"],
                        labels[cell.get("st", OPEN)],
                        cell.get("n", ""),
                        "; ".join(places) or "keine direkte Fundstelle",
                        str(cell.get("h", 0)),
                    ]
                )
        return rows

    def export(self, what: str, fmt: str) -> dict[str, str]:
        """Table or request list as CSV text or XLSX (base64) for the save dialog."""
        rows = self.questions_rows() if what == "rueckfragen" else self.table_rows()
        base = "Rueckfrageliste" if what == "rueckfragen" else "Uebersicht"
        if fmt == "xlsx":
            data = xlsx_bytes("Rückfragen" if what == "rueckfragen" else "Übersicht", rows)
            return {"filename": f"{base}.xlsx", "base64": base64.b64encode(data).decode("ascii")}
        return {"filename": f"{base}.csv", "text": csv_text(rows)}

    # -- suggestions ----------------------------------------------------------------------------

    def suggestions(self) -> dict[str, Any]:
        """Candidate rows from structured places only (a): name and assembly columns of Excel
        sheets and document titles. Ticked in advance: assembly column entries and names found
        in at least one more document, at most 30. Standard parts and consumables hidden."""
        with self.context.transaction() as con:
            sheets = con.execute(
                "select f.id, f.rel_path, p.cells from page p join file f on f.id = p.file_id"
                " where p.cells is not null order by f.id, p.page_no"
            ).fetchall()
            titles = con.execute(
                "select id, rel_path, title from file where status = 'ok' order by rel_path"
            ).fetchall()
            texts: dict[int, list[str]] = {}
            for fid, text in con.execute("select file_id, text from page where text != ''"):
                texts.setdefault(fid, []).append(norm(text))
        with self._store() as con:
            known = {n.lower() for (n,) in con.execute("select name from component")}
            for (aliases,) in con.execute("select aliases from component"):
                known |= {a.lower() for a in json.loads(aliases)}
        found: dict[str, dict[str, Any]] = {}

        def add(name: str, source: str, where: str, file_id: int, group: bool) -> None:
            name = " ".join(name.split())
            if not 3 <= len(name) <= MAX_NAME or not _LETTERS.search(name.lower()):
                return
            if name.lower() in known:
                return
            entry = found.setdefault(
                name.lower(),
                {"name": name, "sources": [], "files": set(), "group": False},
            )
            if len(entry["sources"]) < 3:
                entry["sources"].append({"source": source, "where": where})
            entry["files"].add(file_id)
            entry["group"] = entry["group"] or group

        for fid, rel, cells_json in sheets:
            try:
                rows = json.loads(cells_json)
            except ValueError:
                continue
            if not rows:
                continue
            header = {col: _header_key(v) for col, v in rows[0][1]}
            names = [c for c, h in header.items() if h in NAME_HEADERS]
            groups = [c for c, h in header.items() if h in GROUP_HEADERS]
            if not names and not groups:
                continue
            stem = Path(rel).stem.replace("_", " ")
            for row_no, values in rows[1:]:
                for col, value in values:
                    if col in groups:
                        add(value, "Baugruppe", f"{stem} · Z. {row_no}", fid, True)
                    elif col in names:
                        add(value, "Stückliste", f"{stem} · Z. {row_no}", fid, False)
        for fid, rel, title in titles:
            if Path(rel).suffix.lower() == ".xlsx":
                continue
            cleaned = strip_document_kind(title or "")
            words = [w for w in cleaned.split() if _LETTERS.search(w)][:6]
            if words:
                add(
                    " ".join(_restore_case(w, title) for w in words),
                    "Dokumenttitel",
                    Path(rel).name,
                    fid,
                    False,
                )
        out = []
        for entry in found.values():
            name = norm(entry["name"])
            elsewhere = any(
                any(name in t for t in pages)
                for fid, pages in texts.items()
                if fid not in entry["files"]
            )
            kind = kind_of(entry["name"])
            source = entry["sources"][0]["source"]
            out.append(
                {
                    "name": entry["name"],
                    "sources": entry["sources"],
                    "kind": kind,
                    "group": entry["group"],
                    "elsewhere": elsewhere,
                    "title_only": all(s["source"] == "Dokumenttitel" for s in entry["sources"]),
                    "rank": (
                        0 if entry["group"] else 1 if elsewhere else 2,
                        source == "Dokumenttitel",
                    ),
                }
            )
        out.sort(key=lambda e: (e["rank"], e["name"].lower()))
        ticked = 0
        for e in out:
            ok = (
                e["kind"] is None
                and not e["title_only"]
                and (e["group"] or e["elsewhere"])
                and ticked < PRESELECT
            )
            e["ticked"] = ok
            ticked += ok
            del e["rank"]
        return {"suggestions": out[:MAX_SUGGESTIONS], "total": len(out)}


def _restore_case(word: str, original: str) -> str:
    match = re.search(re.escape(word), original, re.IGNORECASE)
    return match.group(0) if match else word


def _chapter_out(ch: Chapter) -> dict[str, Any]:
    return {
        "key": ch.key,
        "name": ch.name,
        "short": ch.short,
        "own": ch.own,
        "visible": ch.visible,
        "words_de": ch.words_de,
        "words_en": ch.words_en,
        "standard": not ch.own,
    }


def _apply(entries: list[dict[str, Any]] | None, decisions: dict) -> dict[str, list]:
    """Decisions over a cell result: fits fills the cell, does not fit hides; lost ones apart."""
    direct, hints, rejected = [], [], []
    taken = set()
    for e in entries or []:
        place = (e["folder"], e["rel_path"], e["page_no"])
        d = decisions.get(place)
        if d and not d["lost"]:
            taken.add(place)
            e = {**e, "decision": d["decision"]}
            if d["decision"] == FITS_NOT:
                rejected.append(e)
                continue
            direct.append(e)
            continue
        (direct if e["direct"] else hints).append(e)
    lost = []
    for place, d in decisions.items():
        if place in taken:
            continue
        item = {
            "folder": place[0],
            "rel_path": place[1],
            "page_no": place[2],
            "place": d["place"],
            "snippet": d["snippet"],
            "decision": d["decision"],
            "direct": d["decision"] == FITS,
            "way": "bestaetigt",
            "lost": d["lost"],
        }
        if d["lost"]:
            lost.append(item)
        elif d["decision"] == FITS:
            direct.append(item)  # confirmed earlier, not among the search hits now
        else:
            rejected.append(item)
    return {"direct": direct, "hints": hints, "rejected": rejected, "lost": lost}


class _PageCache:
    """Passage text without the context in front (title, sheet), heading path, title, page
    vocabulary: read once per computation from the project database."""

    def __init__(self, context: ProjectContext) -> None:
        self._con = context.connect()
        self._pages: dict[tuple[int, int], dict[str, Any] | None] = {}
        self._words: dict[tuple[int, int], set[str]] = {}

    def close(self) -> None:
        self._con.close()

    def page(self, file_id: int, page_no: int) -> dict[str, Any] | None:
        key = (file_id, page_no)
        if key not in self._pages:
            row = self._con.execute(
                "select p.text, coalesce(p.label, ''), f.title from page p"
                " join file f on f.id = p.file_id where p.file_id = ? and p.page_no = ?",
                key,
            ).fetchone()
            if row is None:
                self._pages[key] = None
            else:
                text, label, title = row
                heading = ""
                heading_words = 0
                match = re.fullmatch(r"Abschnitt „(.*)“(?: \(Teil \d+\))?", label)
                if match:
                    heading = match.group(1)
                    first = text.split("\n", 1)[0]
                    if norm(first) == norm(heading):
                        heading_words = len(first.split())
                self._pages[key] = {
                    "words": text.split(),
                    "heading": heading,
                    "heading_words": heading_words,
                    "title": title or "",
                    "hash": page_hash(text),
                    "contents": is_contents_page(text),
                }
                self._words[key] = set(_WORD.findall(text.lower()))
        return self._pages[key]

    def passage(self, chunk_id: int, file_id: int, page_no: int) -> dict[str, Any] | None:
        page = self.page(file_id, page_no)
        if page is None:
            return None
        row = self._con.execute(
            "select word_start, word_end, coalesce(lang, '') from chunk where id = ?",
            (chunk_id,),
        ).fetchone()
        if row is None or row[0] is None:
            start, end, lang = 0, len(page["words"]), (row[2] if row else "")
        else:
            start, end, lang = row
        start = max(start, page["heading_words"])  # the heading line counts as heading
        return {
            "passage": " ".join(page["words"][start:end]),
            "heading": page["heading"],
            "title": page["title"],
            "hash": page["hash"],
            "contents": page["contents"],
            "lang": lang,
        }

    def vocabulary(self, file_id: int, page_no: int) -> set[str]:
        self.page(file_id, page_no)
        return self._words.get((file_id, page_no), set())


def _merge_similar(entries: list[dict[str, Any]], pages: _PageCache) -> list[dict[str, Any]]:
    """Pages of the same file with nearly the same words become one entry (parts lists, 06 §4).
    A direct page is never merged into a hint."""
    kept: list[dict[str, Any]] = []
    for e in entries:
        words = pages.vocabulary(e["file_id"], e["page_no"])
        twin = next(
            (
                k
                for k in kept
                if k["file_id"] == e["file_id"]
                and k["direct"] >= e["direct"]
                and _jaccard(pages.vocabulary(k["file_id"], k["page_no"]), words) >= SIMILAR
            ),
            None,
        )
        if twin is None:
            kept.append(e)
        else:
            twin["similar"].append(e["page_no"])
    return kept


def _spread(entries: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    first, rest, per_file = [], [], {}
    for e in entries:
        n = per_file.get(e["file_id"], 0)
        (first if n < PER_FILE_FIRST else rest).append(e)
        per_file[e["file_id"]] = n + 1
    return (first + rest)[:limit]
