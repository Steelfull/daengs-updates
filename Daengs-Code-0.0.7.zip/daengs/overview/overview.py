"""Overview by assembly (F5): where is what, across all documents, without a language model.

Per assembly one search (name and terms), spread over documents, similar pages merged into one
entry (06 §4). The user confirms or rejects entries; rejected ones stay hidden, confirmed ones
stay even when the search changes. Reads the ingest tables by SQL (contract, daengs.search.schema).
"""

import csv
import io
import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Any

from daengs.core import DaengsError, ProjectContext

SearchFn = Callable[[str, int], list[Mapping[str, Any]]]

CONFIRMED, REJECTED = "bestaetigt", "verworfen"
CANDIDATES = 40
ENTRIES = 15
PER_FILE_FIRST = 4  # per document in the first pass, so one long manual cannot fill the list
SIMILAR = 0.8  # Jaccard of the page vocabularies above which two pages count as the same
MAX_ASSEMBLIES = 200

_SCHEMA = f"""
create table if not exists assembly(
    id integer primary key autoincrement,
    name text not null unique,
    terms text not null default '',
    position integer not null
);
create table if not exists assembly_decision(
    assembly_id integer not null references assembly(id) on delete cascade,
    file_id integer not null references file(id) on delete cascade,
    page_no integer not null,
    decision text not null check (decision in ('{CONFIRMED}', '{REJECTED}')),
    primary key(assembly_id, file_id, page_no)
);
"""
_WORD = re.compile(r"[\wäöüÄÖÜß]{3,}")


@dataclass
class Entry:
    file_id: int
    rel_path: str
    page_no: int
    snippet: str
    chunk_id: int | None
    status: str | None = None
    similar: list[int] = field(default_factory=list)  # further pages of the same file, merged
    place: str = ""  # Word and Excel: section or sheet and rows instead of a page (A-35)


@dataclass
class AssemblyResult:
    id: int
    name: str
    terms: str
    entries: list[Entry]

    @property
    def files(self) -> int:
        return len({e.file_id for e in self.entries})


class Overview:
    def __init__(self, context: ProjectContext, search: SearchFn) -> None:
        self.context = context
        self._search = search
        with context.transaction() as con:
            if not con.execute("select 1 from sqlite_master where name = 'file'").fetchone():
                raise DaengsError("Projekt ist noch nicht eingelesen")
            con.executescript(_SCHEMA)

    # -- assembly list -----------------------------------------------------------------------

    def assemblies(self) -> list[dict[str, Any]]:
        with self.context.transaction() as con:
            rows = con.execute("select id, name, terms from assembly order by position, id")
            return [{"id": i, "name": n, "terms": t} for i, n, t in rows]

    def set_assemblies(self, text: str) -> list[dict[str, Any]]:
        """Replace the list from text: one assembly per line, optionally ``Name: term, term``.

        Existing assemblies keep their decisions; removed ones lose them.
        """
        wanted: list[tuple[str, str]] = []
        for line in text.splitlines():
            name, _, terms = line.partition(":")
            name, terms = " ".join(name.split()), " ".join(terms.split())
            if name and name.lower() not in {w[0].lower() for w in wanted}:
                if len(name) > 100 or len(terms) > 500:
                    raise DaengsError("Baugruppe oder Begriffe zu lang")
                wanted.append((name, terms))
        if len(wanted) > MAX_ASSEMBLIES:
            raise DaengsError(f"Höchstens {MAX_ASSEMBLIES} Baugruppen")
        with self.context.transaction() as con:
            existing = {n.lower(): i for i, n in con.execute("select id, name from assembly")}
            keep = set()
            for position, (name, terms) in enumerate(wanted):
                if name.lower() in existing:
                    aid = existing[name.lower()]
                    con.execute(
                        "update assembly set name = ?, terms = ?, position = ? where id = ?",
                        (name, terms, position, aid),
                    )
                else:
                    aid = con.execute(
                        "insert into assembly(name, terms, position) values (?, ?, ?)",
                        (name, terms, position),
                    ).lastrowid
                keep.add(aid)
            for aid in set(existing.values()) - keep:
                con.execute("delete from assembly where id = ?", (aid,))
        self.context.log_event("baugruppen", anzahl=len(wanted))
        return self.assemblies()

    def decide(self, assembly_id: int, file_id: int, page_no: int, decision: str | None) -> None:
        if decision not in (CONFIRMED, REJECTED, None):
            raise DaengsError("Entscheidung muss bestätigt, verworfen oder leer sein")
        with self.context.transaction() as con:
            if not con.execute("select 1 from assembly where id = ?", (assembly_id,)).fetchone():
                raise DaengsError("Baugruppe nicht gefunden")
            if decision is None:
                con.execute(
                    "delete from assembly_decision"
                    " where assembly_id = ? and file_id = ? and page_no = ?",
                    (assembly_id, file_id, page_no),
                )
                return
            if not con.execute(
                "select 1 from page where file_id = ? and page_no = ?", (file_id, page_no)
            ).fetchone():
                raise DaengsError("Seite nicht gefunden")
            con.execute(
                "insert or replace into assembly_decision(assembly_id, file_id, page_no, decision)"
                " values (?, ?, ?, ?)",
                (assembly_id, file_id, page_no, decision),
            )

    # -- result ------------------------------------------------------------------------------

    def compute(self) -> list[AssemblyResult]:
        return [self._compute(a) for a in self.assemblies()]

    def _compute(self, assembly: dict[str, Any]) -> AssemblyResult:
        query = (
            f"{assembly['name']}: {assembly['terms']}" if assembly["terms"] else assembly["name"]
        )
        hits = self._search(query, CANDIDATES)
        with self.context.transaction() as con:
            decisions = {
                (f, p): d
                for f, p, d in con.execute(
                    "select file_id, page_no, decision from assembly_decision"
                    " where assembly_id = ?",
                    (assembly["id"],),
                )
            }
            confirmed = [
                Entry(f, r, p, "", None, CONFIRMED, place=label or "")
                for (f, p), d in decisions.items()
                if d == CONFIRMED
                for r, label in con.execute(
                    "select f.rel_path, p.label from file f"
                    " left join page p on p.file_id = f.id and p.page_no = ? where f.id = ?",
                    (p, f),
                )
            ]
            words = self._vocabularies(con, hits, confirmed)
        candidates = [
            Entry(
                h["file_id"],
                h["rel_path"],
                h["page_no"],
                h["snippet"],
                h["chunk_id"],
                place=h.get("place", ""),
            )
            for h in hits
            if decisions.get((h["file_id"], h["page_no"])) != REJECTED
        ]
        known = {(e.file_id, e.page_no) for e in confirmed}
        for e in candidates:
            if (e.file_id, e.page_no) in known:
                # Confirmed and found again: keep the search snippet for the confirmed entry.
                for c in confirmed:
                    if (c.file_id, c.page_no) == (e.file_id, e.page_no):
                        c.snippet, c.chunk_id = e.snippet, e.chunk_id
        candidates = [e for e in candidates if (e.file_id, e.page_no) not in known]
        merged = _merge_similar(confirmed + candidates, words)
        entries = [e for e in merged if e.status == CONFIRMED] + _spread(
            [e for e in merged if e.status != CONFIRMED], ENTRIES
        )
        return AssemblyResult(assembly["id"], assembly["name"], assembly["terms"], entries)

    def _vocabularies(self, con, hits, confirmed) -> dict[tuple[int, int], set[str]]:
        keys = {(h["file_id"], h["page_no"]) for h in hits} | {
            (e.file_id, e.page_no) for e in confirmed
        }
        result = {}
        for file_id, page_no in keys:
            row = con.execute(
                "select text from page where file_id = ? and page_no = ?", (file_id, page_no)
            ).fetchone()
            result[(file_id, page_no)] = set(_WORD.findall(row[0].lower())) if row else set()
        return result

    def export_csv(self) -> str:
        """Table for Excel: semicolons, BOM; cells cannot start a formula (CSV injection)."""
        out = io.StringIO()
        out.write("﻿")
        writer = csv.writer(out, delimiter=";", lineterminator="\r\n")
        writer.writerow(["Baugruppe", "Datei", "Seite", "Status", "Ähnliche Seiten", "Ausschnitt"])
        for result in self.compute():
            for e in result.entries:
                writer.writerow(
                    [
                        _cell(result.name),
                        _cell(e.rel_path),
                        e.place or e.page_no,
                        "bestätigt" if e.status == CONFIRMED else "",
                        ", ".join(str(p) for p in e.similar),
                        _cell(e.snippet),
                    ]
                )
        return out.getvalue()


def _jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0


def _merge_similar(entries: list[Entry], words: dict[tuple[int, int], set[str]]) -> list[Entry]:
    """Pages of the same file with nearly the same words become one entry (e.g. parts lists)."""
    kept: list[Entry] = []
    for e in entries:
        twin = next(
            (
                k
                for k in kept
                if k.file_id == e.file_id
                and _jaccard(words[(k.file_id, k.page_no)], words[(e.file_id, e.page_no)])
                >= SIMILAR
            ),
            None,
        )
        if twin is None or e.status == CONFIRMED:
            kept.append(e)
        else:
            twin.similar.append(e.page_no)
    return kept


def _spread(entries: list[Entry], limit: int) -> list[Entry]:
    """Best first, at most PER_FILE_FIRST per file; then fill up with the rest in rank order."""
    first, rest, per_file = [], [], {}
    for e in entries:
        n = per_file.get(e.file_id, 0)
        (first if n < PER_FILE_FIRST else rest).append(e)
        per_file[e.file_id] = n + 1
    return (first + rest)[:limit]


def _cell(value: str) -> str:
    value = " ".join(value.replace("￾", "").split())
    return "'" + value if value[:1] in ("=", "+", "-", "@", "\t", "\r") else value
