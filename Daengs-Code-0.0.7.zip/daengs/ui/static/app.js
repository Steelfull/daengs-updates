// Daengs UI. Document content is untrusted data: it is only ever set via textContent, never as HTML.
"use strict";

const $ = (id) => document.getElementById(id);
const state = { token: null, project: null, hits: [], terms: [], active: null, view: null, question: "", poll: null, imageUrl: null, tab: "search", wikiPage: null, llm: null, chats: [], answerDone: null, shownQuestion: "", answering: false, product: "", projects: [], files: null, fileAlert: 0, filesTimer: null, order: [], kindFilter: "alle", density: "ausfuehrlich", ingest: null, fresh: false, searchRun: 0, pageQuestion: "", lastProject: "", thread: { chatId: null, fromHistory: false, turns: [] }, ref: null, listOpen: false, commands: null, cmdIndex: 0, sideWanted: true, sideTab: "page", layout: null, updates: null, locked: false, view_: null, eta: [], live: null, miniLensOnly: true, firstSeen: null, focusOnReturn: false, filesAt: 0 };

// -- session token: from the pywebview window, or (development) from the URL fragment ----------

function tokenFromFragment() {
  const match = /(?:^|&)token=([^&]+)/.exec(location.hash.slice(1));
  if (match) history.replaceState(null, "", location.pathname);
  return match ? decodeURIComponent(match[1]) : null;
}

async function obtainToken() {
  const fromFragment = tokenFromFragment();
  if (fromFragment) return fromFragment;
  if (window.pywebview && window.pywebview.api) return window.pywebview.api.token();
  return new Promise((resolve) => {
    window.addEventListener("pywebviewready", () => resolve(window.pywebview.api.token()), { once: true });
  });
}

const hasDialogs = () => window.pywebview && window.pywebview.api && window.pywebview.api.choose_folder;

// -- API ----------------------------------------------------------------------------------------

async function api(method, path, body) {
  const options = { method, headers: { Authorization: `Bearer ${state.token}` } };
  if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const response = await fetch(path, options);
  if (response.headers.get("Content-Type")?.startsWith("image/")) return response.blob();
  const data = await response.json();
  if (!response.ok) throw new Error(data && data.fehler ? data.fehler : "Unbekannter Fehler");
  return data;
}

const projectPath = (suffix = "") => `/api/projects/${encodeURIComponent(state.project.id)}${suffix}`;

// -- projects -----------------------------------------------------------------------------------

async function loadProjects(selectId) {
  const projects = await api("GET", "/api/projects");
  state.projects = projects;
  $("welcome").hidden = projects.length > 0;
  const wanted = selectId || state.lastProject;
  const usable = projects.filter((p) => !p.too_new);
  const chosen = usable.find((p) => p.id === wanted) || usable[0];
  if (chosen) {
    await openProject(chosen);
  } else {
    state.project = null;
    resetProjectView();
    setSearchEnabled(false);
    showTab("search");
  }
  return projects;
}

// Nothing of the previous project stays visible: on switching, and after it was deleted (M8).
function resetProjectView() {
  clearTimeout(state.poll);
  clearTimeout(state.ov.timer);
  state.ov.data = null;
  state.ov.cell = null;
  state.ov.sel = null;
  state.ov.sub = null;
  $("ov-wrap").replaceChildren();
  $("side-cell").replaceChildren();
  state.question = "";
  state.terms = [];
  state.ingest = null;
  state.view_ = null;
  state.eta = [];
  state.firstSeen = null;
  state.focusOnReturn = false;
  state.chats = [];
  state.wikiPage = null;
  state.ref = null;
  clearResults();
  clearView();
  setInput("");
  renderComposer();
  $("saved-count").textContent = "";
  clearTimeout(state.filesTimer);
  state.files = null;
  state.fileAlert = 0;
  $("file-list").replaceChildren();
  setNote("files-status", "");
  clearTimeout(state.placeTimer);
  $("place-list").replaceChildren();
  $("wiki-select").replaceChildren();
  setNote("wiki-status", "");
  $("wiki-page").hidden = true;
  $("wiki-refs").replaceChildren();
}

async function openProject(project) {
  state.project = project;
  state.lastProject = project.id;
  savePreferences({ last_project: project.id });
  resetProjectView();
  setSearchEnabled(true);
  renderSidebar();
  // Opening a project picks up new or changed files (F2).
  await api("POST", projectPath("/ingest"), {});
  watchIngest();
  watchFiles();
  await loadChats();
  loadSaved();
  showTab(state.tab);
}

// -- left column (c4, A-36): projects; under the open one its areas and, with the extension, the history

const AREAS = [["search", "Suche", "search"], ["files", "Dateien", "folder"], ["overview", "Übersicht", "list"], ["wiki", "Wiki", "book"]];

function renderSidebar() {
  $("side-global").setAttribute("aria-current", String(state.tab === "global"));
  const list = $("side-projects");
  list.replaceChildren();
  for (const project of state.projects) {
    const open = state.project && state.project.id === project.id;
    const li = el("li", open ? "open" : "");
    const row = el("div", "project-row");
    const name = sideButton(project.too_new ? `${project.name} (neuere Fassung nötig)` : project.name, () => switchProject(project), "project-name", project.name, open ? "chevD" : "chevR");
    name.disabled = Boolean(project.too_new);
    name.setAttribute("aria-expanded", String(Boolean(open)));
    row.append(name);
    if (open) {
      const more = button("", (e) => openProjectMenu(e.currentTarget), "quiet small icon more", `Projekt „${project.name}“: Ordner, Löschen`);
      more.append(icon("more"));
      more.setAttribute("aria-haspopup", "menu");
      more.setAttribute("aria-expanded", "false");
      more.id = "btn-project-menu";
      row.append(more);
    }
    li.append(row);
    if (open) li.append(projectAreas());
    list.append(li);
  }
}

function projectAreas() {
  const ul = el("ul", "side-areas");
  for (const [tab, label, symbol] of AREAS) {
    const b = sideButton(label, () => showTab(tab), "", label, symbol);
    b.setAttribute("aria-current", String(state.tab === tab && !(tab === "search" && state.thread.chatId)));
    if (tab === "files" && state.fileAlert) {
      const badge = el("span", "badge", String(state.fileAlert));
      badge.title = "neue oder geänderte Dateien";
      b.append(badge);
    }
    ul.append(el("li", ""));
    ul.lastChild.append(b);
  }
  if (hasExtension()) {
    ul.append(el("li", "side-label", "Verlauf"));
    const chats = el("ul", "side-chats");
    if (!state.chats.length) chats.append(el("li", "side-label quiet-label", "Noch keine Antworten"));
    for (const chat of [...state.chats].reverse()) {
      const b = sideButton(chat.title, () => openHistory(chat.id), "", `${chat.title} (${chat.messages} ${chat.messages === 1 ? "Antwort" : "Antworten"})`, "chat");
      b.setAttribute("aria-current", String(state.tab === "search" && chat.id === state.thread.chatId));
      chats.append(el("li", ""));
      chats.lastChild.append(b);
    }
    ul.append(chats);
  }
  return ul;
}

function sideButton(label, onClick, className, title = "", symbol = "") {
  const b = button("", onClick, className, title || label);
  if (symbol) b.append(icon(symbol));
  b.append(el("span", "lbl", label));
  return b;
}

// Project menu (c4): what there is for the open project, as a menu at its "…" button.
function openProjectMenu(anchor) {
  const menu = $("project-menu");
  if (!menu.hidden) return closeProjectMenu();
  const at = anchor.getBoundingClientRect();
  menu.style.position = "fixed";
  menu.style.left = `${Math.round(at.left)}px`;
  menu.style.top = `${Math.round(at.bottom + 4)}px`;
  menu.style.right = "auto";
  menu.hidden = false;
  anchor.setAttribute("aria-expanded", "true");
  menu.querySelector("button").focus();
}

function closeProjectMenu(backToButton = true) {
  const menu = $("project-menu");
  if (menu.hidden) return;
  menu.hidden = true;
  const anchor = $("btn-project-menu");
  if (anchor) {
    anchor.setAttribute("aria-expanded", "false");
    if (backToButton) anchor.focus();
  }
}

function bindProjectMenu() {
  const menu = $("project-menu");
  const items = [...menu.querySelectorAll("button")];
  for (const item of items) {
    item.addEventListener("click", () => {
      closeProjectMenu(false);
      if (item.dataset.act === "folders") openFolders();
      if (item.dataset.act === "delete") openDelete();
    });
  }
  menu.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { e.stopPropagation(); return closeProjectMenu(); }
    if (e.key === "Tab") return closeProjectMenu(false);
    const next = menuStep(items.indexOf(document.activeElement), e.key, items.length);
    if (next !== null) {
      e.preventDefault();
      items[next].focus();
    }
  });
  document.addEventListener("click", (e) => {
    if (!menu.hidden && !e.target.closest("#project-menu, #btn-project-menu")) closeProjectMenu(false);
  });
}

async function switchProject(project) {
  if (state.project && state.project.id === project.id) return showTab("search");
  await openProject(project);
}

// -- layout c4: the panel stands beside the middle and makes it narrower, never over it -------------

function applyLayout() {
  const layout = $("layout");
  const open = !$("page-panel").hidden;
  const l = layoutFor(layout.clientWidth, open, state.sideWanted);
  layout.classList.toggle("rail", l.side === "rail");
  layout.style.setProperty("--side-w", `${l.side === "full" ? SIDE_FULL : SIDE_RAIL}px`);
  layout.style.setProperty("--panel-w", `${l.panel}px`);
  $("btn-side").setAttribute("aria-expanded", String(l.side === "full"));
  $("btn-side").title = l.forced ? "Für die linke Spalte fehlt neben dem Panel der Platz; ein Klick schließt das Panel" : "Linke Spalte ein- oder ausklappen";
  $("btn-panel").setAttribute("aria-expanded", String(open));
  state.layout = l;
}

function toggleSide() {
  if (state.layout && state.layout.forced) {
    state.sideWanted = true;
    return closePanel();
  }
  state.sideWanted = !state.sideWanted;
  transition(applyLayout);
}

function openPanel(tab = state.sideTab) {
  const panel = $("page-panel");
  showSide(tab);
  if (!panel.hidden) return Promise.resolve();
  return transition(() => {
    panel.hidden = false;
    applyLayout();
  });
}

function togglePanel() {
  if ($("page-panel").hidden) openPanel();
  else closePanel();
}

function showSide(tab) {
  state.sideTab = tab;
  for (const b of document.querySelectorAll(".ptabs [role=tab]")) b.setAttribute("aria-selected", String(b.dataset.side === tab));
  $("side-page").hidden = tab !== "page";
  $("side-cell").hidden = tab !== "cell";
  $("side-activity").hidden = tab !== "activity";
  $("side-saved").hidden = tab !== "saved";
  if (tab === "activity") renderActivity();
  if (tab === "saved") loadSaved();
}

function bindPanel() {
  const tabs = [...document.querySelectorAll(".ptabs [role=tab]")];
  for (const b of tabs) {
    b.addEventListener("click", () => openPanel(b.dataset.side));
    b.addEventListener("keydown", (e) => {
      const next = e.key === "ArrowRight" ? "ArrowDown" : e.key === "ArrowLeft" ? "ArrowUp" : e.key;
      const at = menuStep(tabs.indexOf(b), next, tabs.length);
      if (at !== null && (e.key === "ArrowRight" || e.key === "ArrowLeft" || e.key === "Home" || e.key === "End")) {
        e.preventDefault();
        tabs[at].focus();
        openPanel(tabs[at].dataset.side);
      }
    });
  }
  $("btn-side").addEventListener("click", toggleSide);
  $("btn-panel").addEventListener("click", togglePanel);
  new ResizeObserver(() => applyLayout()).observe($("layout"));
}

// Activity (c4): what runs in the background, the model, updates; all from calls that exist.
function renderActivity() {
  const s = state.ingest;
  const v = state.view_ || ingestView(s);
  const running = v.running || v.mode === "ordner";
  $("activity-dot").hidden = !running;
  const root = $("side-activity");
  if (root.hidden) return;
  const card = (title, symbol, lines, extra) => {
    const box = el("div", "pcard");
    const head = el("div", "pc-head");
    head.append(symbol === "stack" ? stackNode(true, v.running && !v.waiting) : icon(symbol, symbol === "spinner" ? "spin" : ""), el("b", "", title));
    box.append(head, ...lines.map((line) => el("div", "note", line)));
    if (extra) box.append(extra);
    return box;
  };
  const nodes = [el("h3", "", "Läuft")];
  if (running) {
    // The hint that searching goes on stands in the status line only (D-065 (2)), not here.
    const name = state.project ? state.project.name : "";
    const title = { erst: `Erstes Einlesen · ${name}`, ordner: `Angehalten · ${name}`, ocr: `Texterkennung · ${name}`, lesen: `Einlesen · ${name}` }[v.mode];
    const lines = [];
    if (v.mode === "ordner") lines.push(v.line, ...v.folders);
    else if (v.mode === "ocr") lines.push(s.ocr_pending ? `Noch ${count(s.ocr_pending, "gescannte Seite", "gescannte Seiten")}` : "Gescannte Seiten werden gelesen");
    else if (v.waiting) lines.push(`Wartet, bis ${s.ahead} eingelesen ist`);
    else if (v.total) lines.push(`${v.done} von ${count(v.total, "Datei", "Dateien")} · ${etaText(state.eta, Date.now())}`);
    else lines.push("Dateien werden gezählt …");
    let bar = null;
    if (v.mode !== "ordner" && v.mode !== "ocr" && v.total) {
      bar = el("div", "ing-bar");
      const fill = el("i", "");
      fill.style.setProperty("--p", String(v.fraction));
      bar.append(fill);
    }
    nodes.push(card(title, v.mode === "ordner" ? "warn" : "stack", lines, bar));
    const { rows, more, read } = activityRows(state.files);
    if (rows.length || read) {
      nodes.push(el("h3", "", "Dateien dieser Lieferung"));
      const list = el("ul", "rows");
      for (const f of rows) {
        const li = el("li", "arow");
        const name = el("span", "a-name", f.rel_path.split("/").pop());
        name.title = f.rel_path;
        // A scan whose OCR comes only later is waiting, not working: no movement then.
        const ocrWaits = f.state === "texterkennung" && v.mode !== "ocr";
        const label = el("span", `a-state ${ocrWaits ? "wartet" : f.state}`, ocrWaits ? "Texterkennung folgt" : ACTIVITY_LABELS[f.state] || f.state);
        if (f.state === "laeuft" || (f.state === "texterkennung" && !ocrWaits)) label.prepend(stackNode(true, true));
        else label.prepend(icon(ocrWaits ? "clock" : stateLook(f.state).symbol));
        li.append(icon(KIND_SYMBOLS[fileKind(f.rel_path)] || "file"), name, label);
        list.append(li);
      }
      nodes.push(list);
      const tail = [];
      if (more) tail.push(`${count(more, "weitere Datei", "weitere Dateien")} offen`);
      if (read) tail.push(`${count(read, "Datei", "Dateien")} eingelesen`);
      if (tail.length) nodes.push(el("p", "note", tail.join(" · ")));
    }
  } else {
    nodes.push(el("div", "pcard note", state.project ? "Zurzeit läuft nichts im Hintergrund." : "Kein Projekt offen."));
    if (s && state.project) nodes.push(card("Eingelesen", "check", [`${count(s.files, "Datei", "Dateien")}, ${count(s.pages, "Seite", "Seiten")}${s.failed_files ? ` · ${count(s.failed_files, "Datei", "Dateien")} nicht lesbar` : ""}`]));
  }
  nodes.push(el("h3", "", "Sprachmodell"));
  if (hasExtension()) {
    const running_ = state.llm.running;
    nodes.push(card(`${modelName(state.llm.model_id)} · lokal`, running_ ? "check" : "info", [running_ ? "Geladen. Rechnet auf diesem Rechner mit dem Prozessor." : "Bereit, lädt beim ersten Antworten. Nichts verlässt den Rechner."]));
  } else {
    nodes.push(el("div", "pcard note", "Die Sprachmodell-Erweiterung ist nicht installiert: Suchen geht, Antworten nicht."));
  }
  nodes.push(el("h3", "", "Updates"));
  const u = state.updates;
  if (u && u.available) {
    nodes.push(card(`${state.product} ${u.available.version} ist verfügbar`, "refresh", ["Das Update-Programm hat keinen Zugriff auf Kundendaten."], button("Ansehen …", openUpdates, "small")));
  } else {
    nodes.push(el("div", "pcard note", u && u.offered ? `Deine Fassung: ${u.version}. Kein Update offen.` : "Keine Abfrage nach Updates."));
  }
  root.replaceChildren(...nodes);
}

// Remembered passages of the open project (c4 "Gemerkt"), from its wiki pages.
async function loadSaved() {
  if (!state.project) {
    $("saved-count").textContent = "";
    return;
  }
  const project = state.project;
  try {
    const pages = await api("GET", projectPath("/wiki"));
    if (state.project !== project) return;
    const total = pages.reduce((n, p) => n + (p.refs || 0), 0);
    $("saved-count").textContent = total ? String(total) : "";
    const root = $("side-saved");
    if (root.hidden) return;
    const nodes = [el("h3", "", `Gemerkt in ${project.name}`)];
    const full = await Promise.all(pages.filter((p) => p.refs).map((p) => api("GET", projectPath(`/wiki/${p.id}`))));
    if (state.project !== project) return;
    for (const page of full) {
      for (const ref of page.refs) {
        const b = button("", () => (ref.file_id === null ? null : openPage(ref.file_id, ref.page_no, ref.chunk_id, ref.rel_path)), "saved");
        b.disabled = ref.file_id === null;
        const top = el("span", "c-file");
        top.append(icon(KIND_SYMBOLS[fileKind(ref.rel_path)] || "file"), el("span", "c-name", ref.rel_path.split("/").pop()));
        b.append(top, el("span", "c-loc", placeLabel(ref)));
        if (ref.note) b.append(el("span", "c-text", ref.note));
        const wiki = el("span", "note");
        wiki.append(icon("book"), ` Wiki: ${page.title}`);
        b.append(wiki);
        if (ref.file_id === null) b.append(el("span", "gone", "Datei nicht mehr im Projekt"));
        nodes.push(b);
      }
    }
    if (!total) nodes.push(el("div", "pcard note", "Noch nichts gemerkt. In der Seitenansicht mit „Merken …“ hinzufügen."));
    root.replaceChildren(...nodes);
  } catch (error) {
    $("side-saved").replaceChildren(el("p", "error", error.message));
  }
}

// -- file explorer (A-33, A-34) ------------------------------------------------------------------

const ACTIVITY_LABELS = { laeuft: "Wird gelesen", wartet: "Wartet", texterkennung: "Texterkennung", nicht_lesbar: "Nicht lesbar" };
const FILE_STATES = {
  neu: "neu", geaendert: "geändert", laeuft: "wird eingelesen", wartet: "wartet", texterkennung: "Texterkennung läuft",
  eingelesen: "eingelesen", nicht_lesbar: "nicht lesbar", entfernt: "entfernt", nicht_durchsucht: "nicht durchsucht",
  nicht_erreichbar: "nicht erreichbar",
};
const FILES_EVERY_MS = 15000;

// While the project is open, on every tab, the folder listing is looked at regularly (no network);
// new or changed files are read in by themselves once they have settled (A-42). A slow folder is
// looked at less often, so that the look itself does not keep the disk busy.
function watchFiles() {
  clearTimeout(state.filesTimer);
  const project = state.project;
  const tick = async () => {
    if (state.project !== project) return;
    const seconds = await loadFiles();
    state.filesTimer = setTimeout(tick, Math.max(FILES_EVERY_MS, Math.min(seconds * 30000, 300000)));
  };
  state.filesTimer = setTimeout(tick, 1500);
}

async function loadFiles() {
  if (!state.project) return 0;
  try {
    const data = await api("POST", projectPath("/files/watch"), {});
    state.files = data;
    if (data.started) watchIngest();
    else if (state.ingest && state.ingest.first === "laeuft" && !isBusy(state.ingest)) watchIngest();
    const alert = data.files.filter((f) => f.state === "neu" || f.state === "geaendert").length;
    const changed = alert !== state.fileAlert;
    state.fileAlert = alert;
    renderSummary();
    if (changed) renderSidebar();
    if (state.tab === "files") renderFiles();
    return data.seconds || 0;
  } catch (error) {
    setNote("files-status", error.message, "err");
    return 0;
  }
}

function renderFiles() {
  const data = state.files;
  const list = $("file-list");
  list.replaceChildren();
  if (!data) return;
  const counts = {};
  for (const f of data.files) counts[f.state] = (counts[f.state] || 0) + 1;
  const parts = Object.entries(counts).map(([k, n]) => `${n} ${FILE_STATES[k] || k}`);
  const away = data.unreachable.length ? ` ${data.unreachable.length === 1 ? "Ein Lieferordner ist" : "Lieferordner sind"} gerade nicht erreichbar; es wird nichts eingelesen.` : "";
  setNote("files-status", `${count(data.files.length, "Datei", "Dateien")}${parts.length ? ": " + parts.join(", ") : ""}${data.truncated ? " (gekürzt)" : ""}.${away}`);
  $("drop-zone").hidden = !window.pywebview;
  let folder = null;
  for (const f of data.files) {
    if (f.folder !== folder && data.folders.length > 1) {
      const head = el("li", "folder", f.folder);
      head.dataset.folder = f.folder;
      list.append(head);
    }
    folder = f.folder;
    const li = el("li", "file");
    li.dataset.folder = f.folder;
    li.dataset.subfolder = f.rel_path.split("/").slice(0, -1).join("/");
    const name = el("div", "name");
    const parts = f.rel_path.split("/");
    const file = parts.pop();
    if (f.openable && f.state !== "entfernt") {
      name.append(button(file, () => openFile(f), "", "Im zugehörigen Programm öffnen"));
    } else {
      name.append(el("span", "", file));
    }
    if (parts.length) name.append(el("span", "", `  ${parts.join(" / ")}`));
    const look = stateLook(f.state);
    li.append(name, withIcon(el("span", `state ${f.state} ${look.kind}`, FILE_STATES[f.state] || f.state), look.symbol, look.spin ? "spin" : ""));
    if (f.file_id && (f.state === "eingelesen" || f.state === "texterkennung") && f.pages) {
      li.append(button("Ansehen", () => openPage(f.file_id, 1, null, f.rel_path), "quiet small", "Hier rechts ansehen"));
    }
    list.append(li);
  }
}

async function openFile(f) {
  try {
    await api("POST", projectPath("/files/open"), { folder: f.folder, path: f.rel_path });
    setNote("files-status", `${f.rel_path.split("/").pop()} geöffnet.`);
  } catch (error) {
    setNote("files-status", error.message, "err");
  }
}

// -- dropping files from the Explorer (M12, D-038) -------------------------------------------------
// The window hands over the paths on its own side; the page gets the names and a number for them.

function dropTargetOf(event) {
  const row = event.target.closest ? event.target.closest("#file-list [data-folder]") : null;
  return row ? { folder: row.dataset.folder, subfolder: row.dataset.subfolder || "", row } : null;
}

function bindDrop() {
  const panel = $("panel-files");
  const hasFiles = (e) => e.dataTransfer && Array.from(e.dataTransfer.types).includes("Files");
  let marked = null;
  let over = null;
  const mark = (row) => {
    if (marked) marked.classList.remove("drop-here");
    marked = row;
    if (marked && state.files && state.files.folders.length > 1) marked.classList.add("drop-here");
  };
  // Everywhere else in the window a dropped file does nothing (it would replace the page).
  document.addEventListener("dragover", (e) => {
    e.preventDefault();
    const inside = state.tab === "files" && state.project && panel.contains(e.target);
    if (e.dataTransfer) e.dataTransfer.dropEffect = inside && hasFiles(e) ? "copy" : "none";
    panel.classList.toggle("dragging", Boolean(inside && hasFiles(e)));
    mark(inside ? (dropTargetOf(e) || {}).row : null);
    // dragover keeps coming while the mouse is over the window; dragleave also fires between child
    // elements and would make the area flicker, so its end is when dragover stops.
    clearTimeout(over);
    over = setTimeout(() => { panel.classList.remove("dragging"); mark(null); }, 600);
  });
  document.addEventListener("drop", (e) => {
    e.preventDefault();
    const inside = state.tab === "files" && state.project && panel.contains(e.target);
    state.dropAt = inside ? { project: state.project, ...(dropTargetOf(e) || {}) } : null;
    panel.classList.remove("dragging");
    mark(null);
  });
}

window.daengsDropped = async (drop) => {
  const at = state.dropAt;
  state.dropAt = null;
  if (!at || at.project !== state.project) return;
  state.drop = drop;
  await placeDrop(at.folder || null, at.subfolder || "");
};

async function placeDrop(folder, subfolder) {
  setNote("files-status", state.drop.too_many ? "Es werden nur die ersten 500 Dateien kopiert." : "");
  try {
    const answer = await api("POST", projectPath("/files/place"), { drop: state.drop.id, folder, subfolder });
    if (answer.choose) return askPlaceFolder(answer.choose);
    renderPlacing(answer.items);
    watchPlacing();
  } catch (error) {
    setNote("files-status", error.message, "err");
  }
}

function askPlaceFolder(folders) {
  const list = $("place-folders");
  list.replaceChildren();
  for (const folder of folders) {
    const li = el("li");
    li.append(button(folder, () => { $("dlg-place").close(); placeDrop(folder, ""); }, ""));
    list.append(li);
  }
  $("dlg-place").showModal();
}

const PLACE_STATES = { wartet: "wartet", kopiert: "wird kopiert" };

function renderPlacing(items) {
  const list = $("place-list");
  list.replaceChildren();
  for (const item of items) {
    const percent = item.size ? ` ${Math.floor((100 * item.done) / item.size)} %` : "";
    const text = item.state === "fehler" ? item.error
      : item.state === "fertig" ? (item.placed === item.name ? "abgelegt" : `abgelegt als ${item.placed}, der Name war schon vergeben`)
      : `${PLACE_STATES[item.state]}${item.state === "kopiert" ? percent : ""}`;
    const li = el("li");
    li.append(el("span", "name", item.name), el("span", `place-state ${item.state}`, text));
    if (item.state === "kopiert" && item.size) {
      const bar = el("div", "progress");
      const fill = el("i", "");
      fill.style.width = `${Math.floor((100 * item.done) / item.size)}%`;
      bar.append(fill);
      li.append(bar);
    }
    list.append(li);
  }
}

function watchPlacing() {
  clearTimeout(state.placeTimer);
  const project = state.project;
  const tick = async () => {
    if (state.project !== project) return;
    try {
      const { items } = await api("GET", projectPath("/files/place"));
      renderPlacing(items);
      if (items.some((i) => i.state === "wartet" || i.state === "kopiert")) {
        state.placeTimer = setTimeout(tick, 300);
      } else {
        watchIngest();
        await loadFiles();
      }
    } catch (error) {
      setNote("files-status", error.message, "err");
    }
  };
  state.placeTimer = setTimeout(tick, 100);
}

const isBusy = (s) => Boolean(s && (s.job === "wartet" || s.job === "laeuft"));

function watchIngest() {
  clearTimeout(state.poll);
  const project = state.project;
  const tick = async () => {
    if (state.project !== project) return;
    try {
      const s = await api("GET", projectPath("/ingest"));
      if (state.project !== project) return;
      // While reading, the activity tab shows each file: its listing is fetched now and then.
      if (isBusy(s) && !$("side-activity").hidden && Date.now() - state.filesAt > 5000) {
        state.filesAt = Date.now();
        state.files = await api("GET", projectPath("/files"));
      }
      showIngest(s);
      if (isBusy(s)) state.poll = setTimeout(tick, 1500);
      else loadFiles();
    } catch (error) {
      showStatus(error.message, "err");
    }
  };
  tick();
}

function count(n, one, many) {
  return `${n.toLocaleString("de-DE")} ${n === 1 ? one : many}`;
}

// The reading of the open project on screen (D-065): the middle during the first reading, else the
// status line and the activity tab; one live region, read at most every few seconds.
function showIngest(s) {
  const now = Date.now();
  const justDone = state.firstSeen === "laeuft" && s.first === "fertig";
  state.firstSeen = s.first;
  state.ingest = s;
  state.eta = etaSample(state.eta, now, s.phase === "suchindex" ? s.vectors_pending : null);
  const v = ingestView(s, state.project ? state.project.name : "", state.product);
  state.view_ = v;
  setLocked(v.locked);
  renderSummary();
  renderIngestHero(v, now);
  renderIngestStat(v);
  renderIngestAlert(v);
  renderActivity();
  const eta = v.mode === "erst" && !v.waiting && v.total ? `, ${etaText(state.eta, now)}` : "";
  announce(justDone ? "Fertig eingelesen. Du kannst jetzt suchen." : v.running || v.mode === "ordner" ? `${v.live}${eta}` : "", justDone ? "fertig" : v.mode, now);
  if (s.job === "fehler") return showStatus("Einlesen ist fehlgeschlagen. Bitte das Projekt erneut öffnen.", "err");
  if (justDone) return finishFirst();
  if (!isBusy(s) && s.first === "fertig" && s.files === 0) {
    return showStatus("Im freigegebenen Ordner wurden keine PDF-, Word- oder Excel-Dateien gefunden.", "warn");
  }
  if (!state.statusHold) showStatus("");
}

// Done with the first reading: a short message and the cursor in the input (D-065 (1)).
function finishFirst() {
  showStatus("Fertig eingelesen – du kannst jetzt suchen", "ok");
  state.statusHold = true;
  clearTimeout(state.doneTimer);
  state.doneTimer = setTimeout(() => {
    state.statusHold = false;
    if ($("status").textContent.startsWith("Fertig eingelesen")) showStatus("");
  }, 6000);
  if (state.tab === "search" && !document.querySelector("dialog[open]")) $("search-input").focus();
  else state.focusOnReturn = true;
}

function announce(text, kind, now) {
  if (!liveDue(state.live, now, text, kind)) return;
  state.live = { t: now, text, kind };
  $("ing-live").textContent = text;
}

// One drawing for the middle, the status line and the activity tab (c7 variant C).
function stackNode(mini = false, running = true) {
  const svg = $("tpl-stack").content.firstElementChild.cloneNode(true);
  if (mini) {
    svg.classList.add("mini");
    svg.setAttribute("width", "22");
    svg.setAttribute("height", "18");
    svg.setAttribute("viewBox", "20 8 124 100");
    if (state.miniLensOnly) svg.classList.add("lens-only");
  }
  const box = el("span", `stack-box${running ? " running" : ""}`);
  box.append(svg);
  return box;
}

function renderIngestHero(v, now) {
  const hero = $("ing-hero");
  const show = Boolean(state.project) && (v.mode === "erst" || v.mode === "ordner");
  hero.hidden = !show;
  if (!show) return;
  if (!$("ing-anim").firstChild) $("ing-anim").append(stackNode(false));
  const moving = v.mode === "erst" && !v.waiting;
  $("ing-anim").firstChild.classList.toggle("running", moving);
  hero.classList.toggle("stopped", v.mode === "ordner");
  $("ing-title").textContent = v.title;
  $("ing-sub").textContent = v.mode === "ordner" ? "Bis dahin bleibt die Suche gesperrt, damit sie nicht nur einen Teil findet." : `${state.product} liest jede Datei einmal, damit du danach in allem suchen kannst.`;
  $("ing-line").textContent = v.mode === "erst" && !v.waiting && v.total ? `${v.line} · ${etaText(state.eta, now)}` : v.line;
  const folders = $("ing-folders");
  folders.hidden = v.mode !== "ordner";
  folders.replaceChildren(...(v.folders || []).map((f) => el("li", "", f)));
  $("ing-bar").firstElementChild.style.setProperty("--p", String(v.fraction));
  const file = $("ing-file");
  file.replaceChildren();
  if (moving && v.fileName) file.append(icon(KIND_SYMBOLS[fileKind(v.fileName)] || "file"), v.fileName);
  const note = $("ing-note");
  note.replaceChildren(v.note);
  if (v.mode === "erst") note.append(" Schau dir in der Zwischenzeit die ", button("Dateien", () => showTab("files"), "link"), " an.");
  if (v.mode === "ordner") {
    // Nacharbeit 3c (b): without the folder the search would stay locked for good.
    const way = el("div", "actions start ing-way");
    way.append(
      button("Ordner aus dem Projekt entfernen …", openFolders, "", "Freigegebene Ordner: den fehlenden entfernen, dann geht das Einlesen ohne ihn zu Ende"),
      button("Zu den Dateien", () => showTab("files"), "quiet"),
    );
    note.append(el("span", "", " Kommt er nicht wieder, entfern ihn aus dem Projekt; du kannst ihn später wieder hinzufügen."), way);
  }
}

function renderIngestStat(v) {
  const stat = $("ing-stat");
  const show = Boolean(state.project) && (v.running || v.mode === "ordner");
  stat.hidden = !show;
  $("sum-open").hidden = show || !state.project;
  if (!show) return;
  const anim = $("ing-stat-anim");
  if (v.mode === "ordner") anim.replaceChildren(icon("warn"));
  else if (!anim.querySelector(".stack")) anim.replaceChildren(stackNode(true));
  const box = anim.querySelector(".stack-box");
  if (box) box.classList.toggle("running", v.running && !v.waiting);
  $("ing-stat-text").textContent = v.status;
}

// A file that could not be read: a calm bar with the way to the files; the input stays free.
function renderIngestAlert(v) {
  const bar = $("ing-alert");
  const failed = v.locked ? 0 : v.failed;
  bar.hidden = !failed;
  if (!failed) return bar.replaceChildren();
  bar.dataset.kind = "warn";
  const names = state.files ? state.files.files.filter((f) => f.state === "nicht_lesbar").map((f) => f.rel_path.split("/").pop()) : [];
  const what = failed === 1 ? `Eine Datei konnte nicht gelesen werden${names.length ? `: ${names[0]}` : ""}. Sie fehlt in der Suche.` : `${failed} Dateien konnten nicht gelesen werden${names.length ? `: ${namesLine(names)}` : ""}. Sie fehlen in der Suche.`;
  bar.replaceChildren(icon("warn"), el("span", "grow", what), button("Zu den Dateien", () => showTab("files"), "link"));
}

// The input during the first reading: visible and reachable, but it takes nothing (D-065 (1)).
function setLocked(on) {
  if (state.locked === on) return;
  state.locked = on;
  if (on) hideCommands();
  renderComposer();
}

function showStatus(text, kind = "", working = false) {
  setNote("status", text, kind, working);
}

// A status line; with a kind it becomes a hint with symbol. Text only through text nodes.
function setNote(id, text, kind = "", working = false) {
  const node = $(id);
  // The same line again (polling) must not restart its animation.
  if (node.textContent === text && (node.dataset.kind || "") === (text ? kind : "")) return;
  const fresh = Boolean(text && kind) && node.dataset.kind !== kind;
  node.replaceChildren();
  if (text && kind) {
    node.dataset.kind = kind;
    node.append(icon(NOTE_SYMBOLS[kind]));
  } else {
    delete node.dataset.kind;
  }
  node.append(text);
  if (text && working) {
    const bar = el("div", "progress wait");
    bar.append(el("i", ""));
    node.append(bar);
  }
  node.classList.remove("in");
  if (fresh) {
    void node.offsetWidth; // restarts the animation
    node.classList.add("in");
  }
}

function setSearchEnabled(on) {
  $("search-input").disabled = !on;
  $("search-btn").disabled = !on || state.locked; // the first reading keeps it locked (D-065)
  if (on) $("search-input").focus();
}

// -- the conversation in the middle (D-064, c6 view 1): question, passages, answer per section ------
// The first section comes from a search and holds its hit list; each follow-up adds a section with the
// passages its answer read (D-064, Weg A: the service stays as it is).

const SEARCH_LIMIT = 20;

const hasExtension = () => Boolean(state.llm && state.llm.available);

function newThread(chatId = null) {
  return { chatId, fromHistory: false, turns: [] };
}

function clearResults() {
  state.hits = [];
  state.active = null;
  state.order = [];
  state.listOpen = false;
  state.thread = newThread();
  hideCitePop(); // its number may be gone with the conversation
  $("results").replaceChildren();
  renderSummary();
}

// Text with the query terms marked; built from text nodes only.
function markedText(text, terms) {
  const node = document.createDocumentFragment();
  let i = 0;
  for (const [start, end] of markRanges(text, terms)) {
    node.append(text.slice(i, start), el("mark", "", text.slice(start, end)));
    i = end;
  }
  node.append(text.slice(i));
  return node;
}

const searchTurn = () => state.thread.turns.find((t) => t.kind === "search") || null;
const lastEntry = () => [...state.thread.turns].reverse().map((t) => t.entry).find((e) => e && e.id) || null;

// What the input card sends: a command, a follow-up while the reference stands, else a new search.
async function submitInput(text, asSearch = false) {
  const question = text.trim();
  if (!question || !state.project || state.locked) return;
  const command = parseCommand(question, commandScope());
  if (command) {
    setInput("");
    return runCommand(command);
  }
  if (!asSearch && inputMode(state.ref, hasExtension()) === "follow") return runFollow(question);
  return search(question);
}

// Kept for the scripts that drive the window (probe run): the search with the text in the field.
async function runSearch(event) {
  if (event && event.preventDefault) event.preventDefault();
  return search($("search-input").value.trim());
}

async function search(question) {
  if (!question || !state.project || state.locked) return;
  const run = ++state.searchRun;
  // A running answer is stopped first; only when it has ended is the conversation cleared (D-056).
  await stopThenClear({ running: state.answering, stop: stopAnswer, finished: state.answerDone, clear: () => {} });
  if (run !== state.searchRun) return;
  setInput("");
  setReference(null);
  clearResults();
  clearPage();
  state.question = question;
  showStatus("Suche läuft …", "info", true);
  try {
    const result = await api("POST", projectPath("/search"), { question, limit: SEARCH_LIMIT });
    if (run !== state.searchRun) return;
    state.hits = result.hits;
    state.shownQuestion = question; // the question of the hits on screen, for the answer
    state.terms = result.terms;
    state.thread.turns.push({ kind: "search", question, entry: null, open: true });
    state.fresh = true;
    renderThread();
    $("scroll").scrollTop = 0;
    if (state.ingest && (state.ingest.job === "wartet" || state.ingest.job === "laeuft")) showIngest(state.ingest);
    else showStatus("");
    loadCells(run);
  } catch (error) {
    showStatus(error.message, "err");
  }
}

// The whole conversation from the state; a section with a running answer keeps its card.
function renderThread() {
  const root = $("results");
  root.classList.toggle("dense", state.density === "kompakt");
  const t = state.thread;
  const nodes = [];
  if (t.fromHistory && t.chatId) nodes.push(threadHead());
  t.turns.forEach((turn, i) => nodes.push(turnNode(turn, i, i === t.turns.length - 1)));
  hideCitePop();
  root.replaceChildren(...nodes);
  state.fresh = false;
  updateOrder();
  markActive();
  renderComposer();
}

function threadHead() {
  const chat = currentChat();
  const head = el("div", "thread-head");
  head.append(icon("chat"), el("b", "", chat ? chat.title : "Verlauf"), el("span", "spacer"),
    button("Umbenennen …", renameChat, "quiet small"), button("Verlauf löschen …", deleteChat, "quiet small danger-text"));
  return head;
}

function turnSources(turn) {
  if (turn.entry) return turn.entry.sources || [];
  return turn.view ? turn.view.sources : [];
}

function turnNode(turn, index, last) {
  const open = last || turn.open === true;
  const node = el("section", `turn${open ? "" : " folded"}${state.fresh && last ? " fresh" : ""}`);
  node.dataset.t = String(index);
  turn.node = node;
  if (!open) {
    node.append(foldedRow(turn));
    return node;
  }
  const q = el("div", "turn-q");
  if (!last) q.append(withIcon(button("Zuklappen", () => { turn.open = false; renderThread(); }, "quiet small"), "chevU"));
  q.append(el("div", "bubble", turn.question));
  node.append(q);
  const surface = surfaceNode(turn);
  if (surface) node.append(surface);
  const slot = answerSlot(turn);
  if (slot) node.append(slot);
  return node;
}

// An older section, folded to one line; the hit list of the search stays reachable from here.
function foldedRow(turn) {
  const row = el("div", "fold-row");
  const n = turn.kind === "search" ? state.hits.length : turnSources(turn).length;
  const what = turn.kind === "search" ? (n === 1 ? "1 Fundstelle" : `${n} Fundstellen`) : n === 1 ? "1 gelesene Stelle" : `${n} gelesene Stellen`;
  const meta = turn.entry ? (turn.entry.no_sure ? `${what} · kein Entwurf` : `${what} · Antwort`) : what;
  const open = button("", () => { turn.open = true; renderThread(); }, "turn-fold", "Abschnitt aufklappen");
  open.append(icon("chevR"), el("span", "fold-q", turn.question), el("span", "fold-meta", meta));
  row.append(open);
  if (turn.kind === "search" && state.hits.length) {
    row.append(button(`Alle ${state.hits.length} Fundstellen anzeigen`, () => { turn.open = true; state.listOpen = true; renderThread(); }, "link"));
  }
  return row;
}

// -- passages of a section: cards on a tinted surface ----------------------------------------------

function surfaceNode(turn) {
  return turn.kind === "search" ? searchSurface(turn) : readSurface(turn);
}

function searchSurface(turn) {
  const box = el("div", "surface");
  const head = el("div", "s-head");
  head.append(icon("search"), el("b", "", "Fundstellen in deinen Unterlagen"), el("span", "spacer"));
  if (state.hits.length) head.append(el("span", "s-label", "Dichte"), densityGroup());
  box.append(head);
  const line = surfaceLine(state.hits);
  const sum = el("p", "s-line");
  const count = el("b", "", line.strong);
  count.id = "sum-count";
  sum.append(count);
  if (line.rest) sum.append(` ${line.strong.endsWith(".") ? "" : "· "}${line.rest}`);
  const cover = el("span", "", "");
  cover.id = "sum-cover";
  sum.append(cover);
  box.append(sum);
  const missing = el("div", "sum-missing");
  missing.id = "sum-missing";
  box.append(missing);
  if (state.hits.length) box.append(filterGroup());
  if (!state.hits.length) {
    const none = el("div", "no-hits");
    none.append(el("h2", "", "Keine Treffer"), el("p", "", `Zu „${turn.question}“ steht in den durchsuchten Dateien nichts. Versuch es mit anderen Wörtern oder einem kürzeren Begriff.`));
    box.append(none);
    setTimeout(renderSummary);
    return box;
  }
  const numbers = turnNumbers(turn);
  const indexes = topCards(state.hits, state.kindFilter, Object.keys(numbers).map(Number));
  const grid = el("div", "cards");
  indexes.forEach((index, position) => grid.append(hitCard(state.hits[index], index, numbers[state.hits[index].chunk_id], position)));
  const shown = groupHits(state.hits, state.kindFilter).reduce((n, g) => n + g.hits.length, 0);
  if (!shown) {
    const none = el("div", "no-hits");
    none.append(el("p", "", "In dieser Dateiart gibt es keine Fundstelle. "), button("Alle Fundstellen zeigen", () => setKindFilter("alle"), "link"));
    box.append(none);
  } else {
    const more = button("", toggleList, "more-tile");
    more.setAttribute("aria-expanded", String(state.listOpen));
    more.setAttribute("aria-controls", "hit-list");
    more.append(icon(state.listOpen ? "chevU" : "chevD"), state.listOpen ? "Liste ausblenden" : `Alle ${shown} Fundstellen anzeigen`);
    grid.append(more);
    box.append(grid);
  }
  if (state.listOpen && shown) {
    const list = el("div", "hitlist");
    list.id = "hit-list";
    groupHits(state.hits, state.kindFilter).forEach((group, position) => list.append(fileCard(group, position)));
    box.append(list);
  }
  setTimeout(renderSummary);
  return box;
}

// The passages a follow-up read: named differently from a hit list, with the way to all of them.
function readSurface(turn) {
  const sources = turnSources(turn);
  if (!sources.length) return null;
  const noSure = Boolean(turn.entry && turn.entry.no_sure);
  const box = el("div", "surface read");
  const head = el("div", "s-head");
  head.append(icon("list"), el("b", "", noSure ? `Ähnlichste Stellen (${sources.length})` : readHeading(sources.length)));
  box.append(head);
  const grid = el("div", "cards");
  sources.forEach((source, position) => grid.append(sourceCard(source, noSure ? null : source.n, position)));
  box.append(grid);
  box.append(el("p", "s-hint", "Das sind die Stellen, die die Antwort gelesen hat. Alle Fundstellen zeigt eine neue Suche: × am Bezug oder /neu, dann die Frage."));
  return box;
}

function turnNumbers(turn) {
  if (turn.entry && turn.entry.no_sure) return {};
  return sourceNumbers(turnSources(turn));
}

function weakMark() {
  const mark = withIcon(el("span", "state warn", "unsicher"), "warn");
  mark.title = "Die Wörter der Frage stehen hier nicht vollständig, und die Stelle ist inhaltlich nur entfernt ähnlich. Bitte prüfen.";
  return mark;
}

function cardBody(card, relPath, place, sure, n, snippet, terms, position) {
  card.style.setProperty("--g", String(position));
  const name = relPath.split("/").pop();
  const file = el("span", "c-file");
  const label = el("span", "c-name", name);
  file.append(icon(KIND_SYMBOLS[fileKind(relPath)] || "file"), label);
  card.title = `${relPath}, ${place}`;
  const where = el("span", "c-place");
  if (n) {
    card.dataset.n = String(n);
    const num = el("span", "num", String(n));
    num.setAttribute("aria-label", `Beleg ${n}`);
    where.append(num);
  }
  where.append(el("span", "c-loc", place));
  if (sure === false) where.append(weakMark());
  where.append(el("span", "spacer"), icon("arrowR", "go"));
  const text = el("span", "c-text");
  text.append(markedText(snippet || "", terms));
  card.append(file, where, text);
  return card;
}

function hitCard(hit, index, n, position) {
  const card = button("", () => selectHit(index), "hcard");
  card.dataset.i = String(index);
  card.setAttribute("aria-current", String(index === state.active));
  return cardBody(card, hit.rel_path, placeLabel(hit), hit.sure, n, hit.snippet, state.terms || [], position);
}

function sourceCard(source, n, position) {
  const card = button("", () => openSource(source), "hcard");
  return cardBody(card, source.rel_path, placeLabel(source), source.sure, n, source.snippet, [], position);
}

function filterGroup() {
  const group = el("div", "filters");
  group.setAttribute("role", "group");
  group.setAttribute("aria-label", "Dateiart");
  const counts = kindCounts(state.hits);
  for (const kind of ["alle", "pdf", "word", "excel"]) {
    if (kind !== "alle" && !counts[kind]) continue;
    const b = button(`${KIND_LABELS[kind]} ${counts[kind]}`, () => setKindFilter(kind), "");
    b.dataset.kind = kind;
    b.setAttribute("aria-pressed", String(kind === state.kindFilter));
    group.append(b);
  }
  return group;
}

function densityGroup() {
  const group = el("div", "seg");
  group.setAttribute("role", "group");
  group.setAttribute("aria-label", "Darstellung");
  for (const [density, label] of [["ausfuehrlich", "Ausführlich"], ["kompakt", "Kompakt"]]) {
    const b = button(label, () => setDensity(density), "");
    b.dataset.density = density;
    b.setAttribute("aria-pressed", String(density === state.density));
    group.append(b);
  }
  return group;
}

function toggleList() {
  state.listOpen = !state.listOpen;
  transition(renderThread);
  if (state.listOpen) setTimeout(() => { const list = $("hit-list"); if (list) list.scrollIntoView({ block: "nearest", behavior: motionLevel() === "aus" ? "auto" : "smooth" }); }, 50);
}

// Number in the text and card are the same (D-064): pointing at one lights up the other.
function lightCard(turnNode_, n, on) {
  if (!turnNode_) return;
  for (const card of turnNode_.querySelectorAll(`.hcard[data-n="${n}"]`)) card.classList.toggle("lit", on);
}

// -- the answer of a section ---------------------------------------------------------------------

function answerSlot(turn) {
  if (turn.card) return turn.card;
  if (turn.entry) return answerNode(turn.entry);
  if (turn.kind !== "search" || !hasExtension() || !state.hits.length) return null;
  const row = el("div", "ask-row");
  const look = answerButtonState(state.hits, state.kindFilter, true);
  const b = withIcon(button("Antwort aus diesen Fundstellen", answerFromHits, "", look.title), "chat");
  b.id = "btn-answer";
  b.disabled = !look.enabled || state.answering;
  const name = modelName(state.llm && state.llm.model_id);
  const why = onlyWeak(state.hits)
    ? "Eine Antwort braucht mindestens eine sichere Fundstelle. Formulier die Frage anders oder nimm ein Wort aus den Unterlagen."
    : look.enabled ? `Schreibt mit ${name} lokal einen Entwurf aus den obersten sicheren Fundstellen.` : look.title;
  row.append(b, el("span", "note", why));
  return row;
}

function renderAnswerButton() {
  const b = $("btn-answer");
  if (!b) return;
  const look = answerButtonState(state.hits, state.kindFilter, hasExtension());
  b.disabled = !look.enabled || state.answering;
  b.title = look.title;
}

async function answerFromHits() {
  if (state.answering || !hasExtension()) return;
  const turn = searchTurn();
  if (!turn || turn.entry || turn.view) return;
  const body = answerRequest({ question: state.shownQuestion, hits: state.hits }, state.kindFilter);
  if (!body.chunk_ids.length) return;
  await streamAnswer(body, turn);
}

async function runFollow(question) {
  if (state.answering || !state.ref) return;
  setInput("");
  for (const t of state.thread.turns) t.open = false;
  const turn = { kind: "follow", question, entry: null, open: true };
  state.thread.turns.push(turn);
  state.fresh = true;
  renderThread();
  turn.node.scrollIntoView({ block: "start", behavior: motionLevel() === "aus" ? "auto" : "smooth" });
  await streamAnswer({ question, chat_id: state.ref.chatId }, turn);
}

// The reference chip (c5 A): while it stands, the next input continues this history.
function setReference(ref) {
  state.ref = ref;
  renderComposer();
}

function setInput(text) {
  const input = $("search-input");
  input.value = text;
  fitComposer();
  hideCommands();
}

function renderComposer() {
  const follow = inputMode(state.ref, hasExtension()) === "follow";
  $("ref-chip").hidden = !follow;
  $("ref-text").textContent = follow ? state.ref.question : "";
  $("ref-text").title = follow ? state.ref.question : "";
  const input = $("search-input");
  input.placeholder = follow ? "Folgefrage stellen … (/neu für eine neue Suche)" : hasExtension() ? "Suchen oder fragen … (/ für Befehle)" : "Suchen … (/ für Befehle)";
  input.setAttribute("aria-label", follow ? "Folgefrage" : "Suchen");
  const send = $("search-btn");
  send.replaceChildren(icon(state.answering ? "stop" : "send"));
  send.classList.toggle("stop", state.answering);
  send.classList.toggle("primary", !state.answering);
  send.title = state.answering ? "Antwort stoppen" : "Senden (Enter)";
  send.setAttribute("aria-label", state.answering ? "Antwort stoppen" : "Senden");
  send.disabled = !state.project;
  const locked = state.locked && Boolean(state.project);
  $("search-form").classList.toggle("locked", locked);
  input.readOnly = locked;
  if (locked) {
    input.placeholder = "Du kannst suchen, sobald das Einlesen fertig ist.";
    input.setAttribute("aria-disabled", "true");
    input.setAttribute("aria-describedby", "lock-line");
  } else {
    input.removeAttribute("aria-disabled");
    input.removeAttribute("aria-describedby");
  }
  $("lock-line").hidden = !locked;
  send.disabled = send.disabled || locked;
  $("btn-plus").disabled = locked;
  renderAnswerButton();
}

function renderSummary() {
  const cover = coverage(state.files, state.ingest);
  $("sum-open").textContent = state.project ? coverShort(cover) : "";
  $("sum-open").hidden = !state.project || !$("ing-stat").hidden;
  const sumCover = $("sum-cover");
  if (sumCover) sumCover.textContent = ` · ${coverLine(cover)}`;
  const missing = $("sum-missing");
  if (!missing) return;
  missing.replaceChildren();
  if (!cover) return;
  const later = coverNote(cover, state.view_);
  if (later) {
    missing.append(el("span", "", later), " ", button("Aktivität", () => openPanel("activity"), "link"));
    return;
  }
  for (const group of cover.missing) {
    const line = el("div", "");
    line.append(el("span", "reason", `${group.reason}: `), namesLine(group.names));
    missing.append(line);
  }
  for (const note of cover.notes) missing.append(el("div", "", note));
}

// -- the grouped list from step 2, opened with "Alle n Fundstellen anzeigen" ---------------------------

function fileCard(group, position) {
  const card = el("section", "fcard");
  card.style.setProperty("--g", String(position));
  card.setAttribute("aria-label", group.path);
  const head = el("div", "fh");
  const name = el("b", "", group.path);
  name.title = group.path;
  head.append(icon(KIND_SYMBOLS[group.kind] || "file"), name, el("span", "cnt", group.hits.length === 1 ? "1 Stelle" : `${group.hits.length} Stellen`));
  const strip = stripNode(group);
  if (strip) head.append(strip);
  card.append(head);
  for (const { hit, index } of group.hits) card.append(hitRow(hit, index));
  return card;
}

function stripNode(group) {
  if (group.kind !== "pdf" || !state.files) return null;
  const file = state.files.files.find((f) => f.file_id === group.fileId);
  const pages = [...new Set(group.hits.map(({ hit }) => hit.page_no))].sort((a, b) => a - b);
  const bars = docMap(file ? file.pages : 0, pages);
  if (!bars.length) return null;
  const strip = el("span", "docmap");
  strip.setAttribute("role", "img");
  strip.setAttribute("aria-label", `Treffer auf Seite ${pages.join(", ")} von ${file.pages}`);
  strip.title = `Treffer auf Seite ${pages.join(", ")} von ${file.pages}`;
  for (const on of bars) strip.append(el("i", on ? "hl" : ""));
  return strip;
}

function hitRow(hit, index) {
  const row = button("", () => selectHit(index), "hit");
  row.dataset.i = String(index);
  row.style.setProperty("--vtn", `hit-${index}`);
  row.setAttribute("aria-current", String(index === state.active));
  const head = el("span", "hit-head");
  head.append(el("span", "hit-loc", placeLabel(hit)));
  if (hit.sure === false) head.append(weakMark());
  row.append(head);
  if (hit.title && fileKind(hit.rel_path) !== "excel") row.append(el("span", "hit-crumb", hit.title));
  const snippet = el("span", "snippet");
  snippet.append(markedText(hit.snippet, state.terms || []));
  row.append(snippet);
  if (hit.cells && hit.cells.length) addCells(row, hit.cells);
  return row;
}

function addCells(row, rows) {
  row.classList.add("has-cells");
  for (const { cells } of rows) {
    const box = el("span", "cells");
    for (const { name, value } of cells) {
      const cell = el("span", "cell");
      const shown = el("span", "v");
      shown.append(markedText(value, state.terms || []));
      cell.append(el("span", "k", name), shown);
      box.append(cell);
    }
    row.append(box);
  }
}

// Table passages: the search gives text; the cells come from the same call as the page view.
async function loadCells(run) {
  for (const [index, hit] of state.hits.entries()) {
    if (fileKind(hit.rel_path) !== "excel" || hit.cells) continue;
    try {
      const marks = await api("POST", projectPath(`/files/${hit.file_id}/pages/${hit.page_no}/marks`), { chunk_id: hit.chunk_id ?? null, question: state.question });
      if (run !== state.searchRun) return;
      hit.cells = matchedCells(marks.cells, state.terms || []);
      const row = document.querySelector(`#results .hit[data-i="${index}"]`);
      if (row && hit.cells.length) addCells(row, hit.cells);
    } catch {
      if (run !== state.searchRun) return; // the excerpt stays
    }
  }
}

// -- choosing a passage: cards, or the rows of the open list --------------------------------------------

function updateOrder() {
  if (!searchTurn() || !state.hits.length) {
    state.order = [];
  } else if (state.listOpen) {
    state.order = hitOrder(groupHits(state.hits, state.kindFilter));
  } else {
    state.order = topCards(state.hits, state.kindFilter, Object.keys(turnNumbers(searchTurn())).map(Number));
  }
}

function markActive() {
  for (const row of document.querySelectorAll("#results [data-i]")) {
    row.setAttribute("aria-current", String(Number(row.dataset.i) === state.active));
  }
  updateHitNav();
}

function updateHitNav() {
  const at = hitPosition(state.order, state.active);
  $("hit-nav").hidden = !at;
  if (!at) return;
  $("hit-pos").textContent = `Fundstelle ${at.position} von ${at.total}`;
  $("hit-prev").disabled = at.total < 2;
  $("hit-next").disabled = at.total < 2;
}

function activeRow() {
  return document.querySelector(`#results ${state.listOpen ? ".hit" : ".hcard"}[data-i="${state.active}"]`);
}

function selectHit(index) {
  if (!state.hits[index]) return;
  state.active = index;
  state.pageQuestion = state.question;
  markActive();
  const row = activeRow();
  if (row) row.scrollIntoView({ block: "nearest", behavior: motionLevel() === "aus" ? "auto" : "smooth" });
  const hit = state.hits[index];
  showPage(hit.file_id, hit.page_no, hit.chunk_id, hit.rel_path);
}

function stepHit(delta) {
  const turn = searchTurn();
  const turns = state.thread.turns;
  if (turn && !turn.open && turn !== turns[turns.length - 1]) {
    turn.open = true;
    renderThread();
  }
  const next = stepOrder(state.order, state.active, delta);
  if (next !== null) selectHit(next);
}

// A page opened from elsewhere (files, overview, wiki, answer) is not a passage of the hit list.
function openPage(fileId, pageNo, chunkId, relPath, question = "") {
  state.active = null;
  state.pageQuestion = question;
  markActive();
  showPage(fileId, pageNo, chunkId, relPath);
}

function setKindFilter(kind) {
  state.kindFilter = kind;
  savePreferences({ file_filter: kind });
  rearrange();
}

function setDensity(density) {
  state.density = density;
  savePreferences({ density });
  rearrange();
}

// Filter and density: passages keep their identity through the change, and move to their new place.
function rearrange() {
  const list = $("results");
  list.classList.add("moving");
  transition(() => {
    renderThread();
    if (state.active !== null && !state.order.includes(state.active)) clearPage();
  });
  setTimeout(() => list.classList.remove("moving"), 800);
}

function motionLevel() {
  return document.documentElement.dataset.motion || "dezent";
}

// View Transition where the window has it (Chromium from 111) and motion is on; else just the change.
function transition(change) {
  if (!document.startViewTransition || motionLevel() === "aus") {
    change();
    return Promise.resolve();
  }
  const running = document.startViewTransition(change);
  running.ready.catch(() => {}); // a newer transition replaced it: the change itself has happened
  running.finished.catch(() => {});
  return running.updateCallbackDone;
}

function focusSearch() {
  if (!state.project) return;
  if (state.tab !== "search") showTab("search");
  $("search-input").focus();
  $("search-input").select();
}

// -- commands and the plus menu (D-064 (6): only what exists) ---------------------------------------

function commandScope() {
  const turn = searchTurn();
  return {
    answer: Boolean(hasExtension() && turn && !turn.entry && !turn.view && answerButtonState(state.hits, state.kindFilter, true).enabled && !state.answering),
    hits: Boolean(turn && state.hits.length),
    entry: Boolean(hasExtension() && lastEntry() && !lastEntry().stopped),
  };
}

async function runCommand(name) {
  hideCommands();
  closePlus(false);
  if (name === "neu") {
    setReference(null);
    $("search-input").focus();
    showStatus("Die nächste Eingabe ist eine neue Suche.", "info");
  } else if (name === "antwort") {
    await answerFromHits();
  } else if (["alle", "pdf", "word", "excel"].includes(name)) {
    setKindFilter(name);
  } else if (name === "wiki") {
    const entry = lastEntry();
    if (entry) {
      const turn = state.thread.turns.find((t) => t.entry === entry);
      suggestWiki(entry, turn && turn.node ? turn.node.querySelector(".answer") : null);
    }
  }
}

function showCommands() {
  const list = $("cmd-list");
  const found = matchCommands($("search-input").value, commandScope());
  if (!found || !found.length) return hideCommands();
  state.commands = found;
  state.cmdIndex = Math.min(state.cmdIndex || 0, found.length - 1);
  list.replaceChildren(...found.map((c, i) => {
    const option = el("div", "cmd");
    option.id = `cmd-${c.name}`;
    option.setAttribute("role", "option");
    option.setAttribute("aria-selected", String(i === state.cmdIndex));
    option.append(el("b", "", `/${c.name}`), el("span", "", c.label), el("span", "note", c.hint));
    option.addEventListener("mousedown", (e) => { e.preventDefault(); chooseCommand(i); });
    return option;
  }));
  list.hidden = false;
  $("search-input").setAttribute("aria-expanded", "true");
  $("search-input").setAttribute("aria-activedescendant", `cmd-${found[state.cmdIndex].name}`);
}

function hideCommands() {
  $("cmd-list").hidden = true;
  state.commands = null;
  state.cmdIndex = 0;
  $("search-input").setAttribute("aria-expanded", "false");
  $("search-input").removeAttribute("aria-activedescendant");
}

function chooseCommand(i) {
  const command = state.commands && state.commands[i];
  if (!command) return;
  setInput("");
  runCommand(command.name);
}

function plusItems() {
  const can = commandScope();
  const items = [{ head: "Dateiart" }];
  for (const kind of ["alle", "pdf", "word", "excel"]) {
    items.push({ label: KIND_LABELS[kind], radio: true, checked: state.kindFilter === kind, disabled: !can.hits, run: () => runCommand(kind) });
  }
  if (hasExtension()) {
    items.push({ line: true });
    items.push({ label: "Antwort aus diesen Fundstellen", symbol: "chat", disabled: !can.answer, run: () => runCommand("antwort") });
    if (can.entry) items.push({ label: "Ins Wiki übernehmen …", symbol: "book", run: () => runCommand("wiki") });
  }
  items.push({ line: true });
  items.push({ label: "Neue Suche", symbol: "search", hint: "/neu", run: () => runCommand("neu") });
  return items;
}

function togglePlus(open = $("plus-menu").hidden) {
  if (!open) return closePlus();
  const menu = $("plus-menu");
  menu.replaceChildren();
  for (const item of plusItems()) {
    if (item.head) { menu.append(el("div", "menu-head", item.head)); continue; }
    if (item.line) { menu.append(el("div", "menu-line")); continue; }
    const b = button("", item.run, "");
    b.setAttribute("role", item.radio ? "menuitemradio" : "menuitem");
    if (item.radio) b.setAttribute("aria-checked", String(item.checked));
    b.disabled = Boolean(item.disabled);
    b.append(icon(item.radio ? "check" : item.symbol, item.radio ? "" : "show"), el("span", "", item.label));
    if (item.hint) b.append(el("span", "spacer"), el("kbd", "", item.hint));
    menu.append(b);
  }
  menu.hidden = false;
  $("btn-plus").setAttribute("aria-expanded", "true");
  const first = menu.querySelector("button:not(:disabled)");
  if (first) first.focus();
}

function closePlus(backToButton = true) {
  if ($("plus-menu").hidden) return;
  $("plus-menu").hidden = true;
  $("btn-plus").setAttribute("aria-expanded", "false");
  if (backToButton) $("btn-plus").focus();
}

function bindComposer() {
  const input = $("search-input");
  $("search-form").addEventListener("submit", (e) => {
    e.preventDefault();
    if (state.answering) return stopAnswer();
    submitInput(input.value);
  });
  input.addEventListener("input", () => { if (!state.locked) { fitComposer(); showCommands(); } });
  input.addEventListener("keydown", (e) => {
    const listOpen = !$("cmd-list").hidden && state.commands;
    if (listOpen && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
      e.preventDefault();
      state.cmdIndex = menuStep(state.cmdIndex, e.key, state.commands.length);
      showCommands();
      return;
    }
    if (listOpen && e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      hideCommands();
      return;
    }
    if (e.key !== "Enter" || e.shiftKey) return;
    e.preventDefault(); // Enter sends; during an answer it does nothing, what is typed stays (AP-9.22)
    if (state.locked) return;
    if (listOpen) return chooseCommand(state.cmdIndex);
    if (!state.answering) $("search-form").requestSubmit();
  });
  input.addEventListener("blur", () => setTimeout(hideCommands, 100));
  $("ref-x").addEventListener("click", () => { setReference(null); input.focus(); });
  $("btn-plus").addEventListener("click", () => togglePlus());
  const menu = $("plus-menu");
  menu.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { e.stopPropagation(); return closePlus(); }
    if (e.key === "Tab") return closePlus(false);
    const items = [...menu.querySelectorAll("button:not(:disabled)")];
    const next = menuStep(items.indexOf(document.activeElement), e.key, items.length);
    if (next !== null) {
      e.preventDefault();
      items[next].focus();
    }
  });
  document.addEventListener("click", (e) => {
    if (!menu.hidden && !e.target.closest("#plus-anchor")) closePlus(false);
  });
  $("sum-open").addEventListener("click", () => showTab("files"));
  $("ing-stat").addEventListener("click", () => (state.view_ && state.view_.mode === "ordner" ? showTab("files") : openPanel("activity")));
}

// -- page view (F4) -----------------------------------------------------------------------------

// The page tab without a page: the panel may stay open, it then says how a page comes in.
function clearPage() {
  state.view = null;
  state.active = null;
  markActive();
  $("page").hidden = true;
  $("text-view").hidden = true;
  $("text-view").replaceChildren();
  $("page-empty").hidden = false;
  $("doc-icon").replaceChildren();
  $("doc-name").textContent = "";
  $("page-label").textContent = "";
  for (const id of ["btn-prev", "btn-next", "btn-open", "btn-remember"]) $(id).disabled = true;
}

function clearView() {
  clearPage();
  $("page-panel").hidden = true;
  applyLayout();
}

function closePanel() {
  if ($("page-panel").hidden) return;
  const row = state.tab === "overview" ? $("ov-wrap").querySelector('td[tabindex="0"]') : activeRow();
  transition(() => {
    $("page-panel").hidden = true;
    applyLayout();
  });
  if (row && row.isConnected) row.focus({ preventScroll: true });
}

// Shows what is ready: the closed panel opens beside the middle; an open one stays, its content fades.
async function revealPage(change) {
  const panel = $("page-panel");
  $("page-empty").hidden = true;
  if (panel.hidden || state.sideTab !== "page") {
    showSide("page");
    await transition(() => {
      change();
      panel.hidden = false;
      applyLayout();
    });
  } else {
    change();
    const area = $("page-area");
    area.classList.remove("swap");
    void area.offsetWidth; // restarts the fade
    area.classList.add("swap");
  }
}

function showHead(relPath, label, pageNo, pageCount) {
  $("doc-icon").replaceChildren(icon(KIND_SYMBOLS[fileKind(relPath)] || "file"));
  $("doc-name").textContent = relPath;
  $("doc-name").title = relPath;
  $("page-label").textContent = label;
  $("page-label").title = label;
  $("btn-prev").disabled = pageNo <= 1;
  $("btn-next").disabled = pageNo >= pageCount;
  $("btn-open").disabled = false;
  $("btn-remember").disabled = false;
}

async function showPage(fileId, pageNo, chunkId, relPath) {
  const shown = $("page-panel").hidden || !$("page-area").clientWidth ? layoutFor($("layout").clientWidth, true, state.sideWanted).panel - 32 : $("page-area").clientWidth;
  const width = Math.min(2400, Math.round(shown * (window.devicePixelRatio || 1)));
  const token = Symbol();
  const isPdf = relPath.toLowerCase().endsWith(".pdf");
  state.view = { fileId, pageNo, relPath, chunkId: chunkId ?? null, token, isPdf };
  if (!isPdf) return showTextPage(fileId, pageNo, chunkId, relPath, token);
  try {
    const [marks, blob] = await Promise.all([
      api("POST", projectPath(`/files/${fileId}/pages/${pageNo}/marks`), { chunk_id: chunkId ?? null, question: state.pageQuestion }),
      api("GET", projectPath(`/files/${fileId}/pages/${pageNo}/image?width=${width}`)),
    ]);
    if (state.view.token !== token) return; // a newer page was requested meanwhile
    state.view.pageCount = marks.page_count;
    if (state.imageUrl) URL.revokeObjectURL(state.imageUrl);
    state.imageUrl = URL.createObjectURL(blob);
    const img = $("page-img");
    img.src = state.imageUrl;
    img.alt = `${relPath}, Seite ${pageNo}`;
    await img.decode().catch(() => {});
    if (state.view.token !== token) return;
    await revealPage(() => {
      drawMarks(marks);
      $("text-view").hidden = true;
      $("page").hidden = false;
      showHead(relPath, `Seite ${pageNo} von ${marks.page_count}`, pageNo, marks.page_count);
    });
    scrollToMark();
  } catch (error) {
    showStatus(error.message, "err");
  }
}

// Word and Excel (A-35): the part as text or as a table, built from text nodes only; the hit's
// lines are tinted, query terms marked by the same rule as in the hit list (logic.js).
async function showTextPage(fileId, pageNo, chunkId, relPath, token) {
  try {
    const marks = await api("POST", projectPath(`/files/${fileId}/pages/${pageNo}/marks`), { chunk_id: chunkId ?? null, question: state.pageQuestion });
    if (state.view.token !== token) return;
    state.view.pageCount = marks.page_count;
    const view = $("text-view");
    view.replaceChildren();
    const marked = (text) => markedText(text, state.terms);
    if (marks.cells) {
      const columns = [...new Set(marks.cells.flatMap(([, cells]) => cells.map(([c]) => c)))]
        .sort((a, b) => a.length - b.length || a.localeCompare(b));
      const table = el("table", "");
      const head = el("tr", "");
      head.append(el("th", "", ""), ...columns.map((c) => el("th", "", c)));
      table.append(head);
      for (const [row, cells] of marks.cells) {
        const tr = el("tr", "");
        tr.append(el("th", "", String(row)));
        const byColumn = new Map(cells);
        for (const c of columns) {
          const value = byColumn.get(c) || "";
          const td = el("td", markRanges(value, state.terms).length ? "hit" : "");
          td.title = `${c}${row}`;
          td.append(marked(value));
          tr.append(td);
        }
        table.append(tr);
      }
      view.append(table);
    } else {
      const region = new Set(marks.region_lines);
      marks.lines.forEach((line, i) => {
        const p = el("p", region.has(i) ? "region" : "");
        p.append(marked(line));
        view.append(p);
      });
    }
    await revealPage(() => {
      $("page").hidden = true;
      view.hidden = false;
      showHead(relPath, `${marks.label} · ${pageNo} von ${marks.page_count}`, pageNo, marks.page_count);
    });
    const first = view.querySelector("td.hit, mark, .region");
    if (first) first.scrollIntoView({ block: "center", behavior: "instant" });
    else $("page-area").scrollTop = 0;
  } catch (error) {
    showStatus(error.message, "err");
  }
}

function drawMarks(marks) {
  const layer = $("marks");
  layer.replaceChildren();
  const add = (box, cls) => {
    const [x0, y0, x1, y1] = box;
    const el = document.createElement("div");
    el.className = cls;
    el.style.left = `${x0 * 100}%`;
    el.style.top = `${y0 * 100}%`;
    el.style.width = `${(x1 - x0) * 100}%`;
    el.style.height = `${(y1 - y0) * 100}%`;
    layer.append(el);
  };
  marks.region.forEach((b) => add(b, "region"));
  marks.terms.forEach((b) => add(b, "term"));
}

function scrollToMark() {
  const first = $("marks").querySelector(".term, .region");
  if (first) first.scrollIntoView({ block: "center", behavior: "instant" });
  else $("page-area").scrollTop = 0;
}

function turnPage(delta) {
  const v = state.view;
  if (!v || !v.pageCount) return;
  const next = v.pageNo + delta;
  if (next < 1 || next > v.pageCount) return;
  showPage(v.fileId, next, null, v.relPath);
}

async function openOriginal() {
  const v = state.view;
  if (!v) return;
  try {
    const result = await api("POST", projectPath("/open"), { file_id: v.fileId, page_no: v.pageNo });
    if (!v.isPdf) showStatus("Original im zugehörigen Programm geöffnet.");
    else showStatus(result.page_jump ? `Original geöffnet auf Seite ${v.pageNo}.` : `Original geöffnet. Bitte dort zu Seite ${v.pageNo} blättern.`);
  } catch (error) {
    showStatus(error.message, "err");
  }
}

// -- dialogs ------------------------------------------------------------------------------------

// The Windows folder dialog of the window. Its interface may come a moment after the page; it is
// waited for briefly. Without a window (development in a browser) the path is typed instead.
async function pickFolder() {
  if (!hasDialogs()) {
    await new Promise((resolve) => {
      const timer = setTimeout(resolve, 3000);
      window.addEventListener("pywebviewready", () => { clearTimeout(timer); resolve(); }, { once: true });
    });
  }
  if (!hasDialogs()) return null;
  return window.pywebview.api.choose_folder();
}

function showNewFolder(folder) {
  $("new-folder").value = folder;
  const shown = $("new-folder-shown");
  shown.textContent = folder || "Noch kein Ordner gewählt";
  shown.classList.toggle("set", Boolean(folder));
  $("new-ok").disabled = !folder.trim();
}

async function chooseNewFolder() {
  const folder = await pickFolder();
  if (folder) {
    showNewFolder(folder);
    $("new-error").textContent = "";
    $("new-ok").focus();
  } else if (!hasDialogs()) {
    typeNewFolder();
  }
}

function typeNewFolder() {
  $("new-folder").hidden = false;
  $("new-type").hidden = true;
  $("new-folder").focus();
}

function openNewProject() {
  $("new-name").value = "";
  showNewFolder("");
  $("new-error").textContent = "";
  const typed = !window.pywebview; // development in a browser: no folder dialog
  $("new-folder").hidden = !typed;
  $("new-type").hidden = typed;
  $("dlg-new").showModal();
  $("new-name").focus();
}

async function createProject(event) {
  event.preventDefault();
  const name = $("new-name").value.trim();
  const folder = $("new-folder").value.trim();
  if (!name) { $("new-error").textContent = "Bitte einen Namen angeben."; return $("new-name").focus(); }
  if (!folder) { $("new-error").textContent = "Bitte einen Ordner wählen."; return $("new-choose").focus(); }
  try {
    const project = await api("POST", "/api/projects", { name, folders: [folder] });
    $("dlg-new").close();
    await loadProjects(project.id);
  } catch (error) {
    $("new-error").textContent = error.message;
  }
}

function renderFolders() {
  const list = $("folder-list");
  list.replaceChildren();
  for (const folder of state.project.folders) {
    const li = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = folder;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "quiet small";
    remove.textContent = "Entfernen";
    remove.addEventListener("click", () => changeFolder("revoke", folder));
    li.append(span, remove);
    list.append(li);
  }
}

async function changeFolder(action, folder) {
  const question = action === "grant"
    ? `Ordner freigeben?\n\n${folder}\n\n${state.product} liest dann auch diesen Ordner.`
    : `Freigabe entfernen?\n\n${folder}\n\nSeine Seiten verschwinden beim nächsten Einlesen aus der Suche.`;
  if (!window.confirm(question)) return;
  try {
    state.project = await api("POST", projectPath(`/folders/${action}`), { folder, confirm: true });
    $("folders-error").textContent = "";
    $("add-folder").value = "";
    $("add-typed").hidden = true;
    $("add-type").hidden = false;
    renderFolders();
    await api("POST", projectPath("/ingest"), {});
    watchIngest();
  } catch (error) {
    $("folders-error").textContent = error.message;
  }
}

function openFolders() {
  $("folders-error").textContent = "";
  const typed = !window.pywebview;
  $("add-typed").hidden = !typed;
  $("add-type").hidden = typed;
  renderFolders();
  $("dlg-folders").showModal();
}

// -- tabs -------------------------------------------------------------------------------------

const AREA_TITLES = { search: "Suche", files: "Dateien", overview: "Übersicht", wiki: "Wiki", global: "Gesamt-Wiki" };

function showTab(name) {
  if (!state.project && name !== "search" && name !== "global") name = "search";
  state.tab = name;
  for (const tab of ["search", "files", "overview", "wiki", "global"]) $(`panel-${tab}`).hidden = tab !== name;
  $("area-title").textContent = name === "global" ? AREA_TITLES.global : state.project ? `${state.project.name} · ${AREA_TITLES[name]}` : "";
  $("area-title").hidden = name === "search" || name === "overview";
  renderSidebar();
  if (name === "files") state.files ? (renderFiles(), loadFiles()) : loadFiles();
  $("tab-cell").hidden = name !== "overview";
  if (name !== "overview" && state.sideTab === "cell") showSide("page");
  if (name !== "overview") clearTimeout(state.ov.timer);
  if (name === "overview") loadOverview();
  if (name === "wiki") loadWiki();
  if (name === "global") loadGlobalWiki();
  if (name === "search" && state.focusOnReturn && !state.locked) {
    state.focusOnReturn = false;
    $("search-input").focus();
  }
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function button(label, onClick, className = "quiet", title = "") {
  const b = el("button", className, label);
  b.type = "button";
  if (title) b.title = title;
  if (title && !label && className.includes("icon")) b.setAttribute("aria-label", title);
  b.addEventListener("click", onClick);
  return b;
}

// Symbols come from the sprite in index.html (Lucide, D-044); no markup is ever built from text.
function icon(name, className = "") {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", `ic ${className}`.trim());
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", `#i-${name}`);
  svg.append(use);
  return svg;
}

function withIcon(node, name, className = "") {
  node.prepend(icon(name, className));
  return node;
}

// In the sidebar the label sits in a span of its own, so that a long name ends in an ellipsis.

// -- overview as a table (D-070, D-071, c8c): components x chapters --------------------------------

state.ov = { data: null, view: "kap", sub: null, filter: { ...EMPTY_FILTER }, sel: null, foc: { r: 0, c: 0 }, timer: null, cell: null, suggestions: null, showKinds: false, codes: [], noteTimer: null };

const tablePath = (suffix = "") => projectPath(`/table${suffix}`);
const ovRows = () => (state.ov.data ? state.ov.data.components.filter((c) => !c.hidden) : []);
const ovCols = () => (state.ov.data ? state.ov.data.chapters.filter((c) => c.visible) : []);
const ovFiles = () => (state.ov.data ? state.ov.data.files : []);
const docCols = () => ovFiles().filter((f) => f.readable && fileKind(f.rel_path));

async function loadOverview(quiet = false) {
  if (!state.project) return;
  clearTimeout(state.ov.timer);
  const pid = state.project.id;
  try {
    const data = await api("GET", tablePath());
    if (!state.project || state.project.id !== pid) return;
    const first = !state.ov.data || state.ov.data.pid !== pid;
    data.pid = pid;
    state.ov.data = data;
    state.ov.codes = fileCodes(data.files.map((f) => f.rel_path));
    if (first) {
      const saved = data.view || {};
      state.ov.filter = { ...EMPTY_FILTER, ...(saved.filter || {}) };
      state.ov.view = saved.view === "doc" ? "doc" : "kap";
      state.ov.sub = null;
      state.ov.sel = null;
      state.ov.foc = { r: 0, c: 0 };
    }
    renderOverview(first && !quiet);
    if (state.ov.sel && !$("page-panel").hidden && state.sideTab === "cell") refreshCellPanel();
  } catch (error) {
    showOvError(error.message);
  }
  const c = state.ov.data && state.ov.data.computing;
  const busy = c && (c.state === "wartet" || c.state === "laeuft" || c.first === "laeuft" || c.pending > 0);
  if (busy && state.tab === "overview") state.ov.timer = setTimeout(() => loadOverview(true), 1500);
}

function showOvError(text) {
  $("ov-progress").textContent = text;
}

function saveOvView() {
  api("POST", tablePath("/view"), { view: { filter: state.ov.filter, view: state.ov.view } }).catch(() => {});
}

function renderOverview(fresh = false) {
  const data = state.ov.data;
  if (!data) return;
  $("ov-proj").textContent = state.project.name;
  const counts = tableCounts(data);
  $("ov-qcount").textContent = counts.requests ? String(counts.requests) : "";
  $("ov-questions").setAttribute("aria-label", `Rückfrageliste, ${counts.requests} ${counts.requests === 1 ? "Punkt" : "Punkte"}`);
  const intro = $("ov-intro");
  if (fresh) intro.hidden = data.intro_seen;
  $("ov-help").setAttribute("aria-expanded", String(!intro.hidden));
  $("ov-view-kap").setAttribute("aria-pressed", String(state.ov.view === "kap"));
  $("ov-view-doc").setAttribute("aria-pressed", String(state.ov.view === "doc"));
  const chip = filterChip(state.ov.filter);
  $("ov-chip").hidden = !chip;
  $("ov-chip-text").textContent = chip;
  $("ov-progress").textContent = tableProgress(data.computing);
  const empty = !ovRows().length;
  $("ov-empty").hidden = !empty || Boolean(state.ov.sub);
  document.querySelector(".ov-bar").hidden = empty;
  $("ov-wrap").hidden = empty;
  $("ov-main").hidden = Boolean(state.ov.sub);
  $("ov-sub").hidden = !state.ov.sub;
  if (!empty) renderGrid();
  renderFilterPop();
  renderColsPop();
}

function cellOf(compKey, chapKey) {
  return (state.ov.data.cells || {})[`${compKey}|${chapKey}`] || {};
}

function renderGrid() {
  const wrap = $("ov-wrap");
  const hadFocus = wrap.contains(document.activeElement) && document.activeElement.matches("td");
  const scroll = [wrap.scrollLeft, wrap.scrollTop];
  const table = el("table", "ov-table");
  table.setAttribute("role", "grid");
  table.setAttribute("aria-label", state.ov.view === "kap" ? "Komponenten und Kapitel" : "Komponenten und Dokumente");
  const files = ovFiles();
  const filter = state.ov.filter;
  const cols = state.ov.view === "kap" ? ovCols() : docCols();
  const head = el("thead", "");
  const hr = el("tr", "");
  const corner = el("th", "corner", "Komponente");
  corner.scope = "col";
  hr.append(corner);
  for (const col of cols) {
    const th = el("th", state.ov.view === "kap" ? "colh" : "colh doc");
    th.scope = "col";
    if (state.ov.view === "kap") {
      th.textContent = col.name.replace("/", "/​");
      th.title = col.name;
    } else {
      const idx = files.indexOf(col);
      const name = col.rel_path.split("/").pop();
      th.append(button(`${state.ov.codes[idx]} · ${name}`, () => openDocDialog(col), "link", `${name}: Status und Stand`));
      const st = el("span", "dstate", { offen: "offen", gesichtet: "gesichtet", nicht_relevant: "nicht relevant" }[col.status] + (col.stand ? ` · ${col.stand}` : ""));
      if (col.changed) st.append(" · ", withIcon(el("span", "st-ask", "geändert seit Sichtung"), "warn"));
      th.append(st);
    }
    hr.append(th);
  }
  head.append(hr);
  const body = el("tbody", "");
  const rows = ovRows();
  const shown = [];
  for (const comp of rows) {
    const views = state.ov.view === "kap" ? cols.map((ch) => cellView(cellOf(comp.key, ch.key), files, filter, state.ov.codes)) : null;
    const statusFilter = filter.open || filter.ask || filter.hint;
    if (views && statusFilter && !views.some((v) => v.match)) continue;
    shown.push({ comp, views });
  }
  if (state.ov.foc.r >= shown.length) state.ov.foc.r = Math.max(0, shown.length - 1);
  if (state.ov.foc.c >= cols.length) state.ov.foc.c = Math.max(0, cols.length - 1);
  shown.forEach(({ comp, views }, r) => {
    const tr = el("tr", "");
    const th = el("th", "rowh", comp.name);
    th.scope = "row";
    th.title = comp.name;
    if (comp.aliases.length) th.append(el("span", "alias", `auch: ${comp.aliases.join(", ")}`));
    tr.append(th);
    cols.forEach((col, c) => {
      const td = state.ov.view === "kap" ? kapCell(comp, col, views[c]) : docCell(comp, col, files.indexOf(col));
      td.dataset.r = String(r);
      td.dataset.c = String(c);
      td.tabIndex = r === state.ov.foc.r && c === state.ov.foc.c ? 0 : -1;
      tr.append(td);
    });
    body.append(tr);
  });
  table.append(head, body);
  table.addEventListener("keydown", gridKey);
  // Chromium leaves a half visible cell where it is on focus; the whole cell comes into view
  // (scroll-padding keeps it clear of the fixed head row and name column).
  table.addEventListener("focusin", (e) => {
    if (e.target.matches("td")) e.target.scrollIntoView({ block: "nearest", inline: "nearest" });
  });
  table.addEventListener("click", (e) => {
    const td = e.target.closest("td");
    if (!td || e.target.closest("button")) return;
    focusCell(Number(td.dataset.r), Number(td.dataset.c));
    if (state.ov.view === "kap") openCell(td.dataset.comp, td.dataset.chap);
  });
  wrap.replaceChildren(table);
  if (!shown.length) wrap.append(el("p", "note ov-none", "Kein Feld passt zum Filter."));
  [wrap.scrollLeft, wrap.scrollTop] = scroll;
  if (hadFocus) focusCell(state.ov.foc.r, state.ov.foc.c);
}

function kapCell(comp, ch, v) {
  const td = el("td", `st-${v.status}`);
  td.setAttribute("role", "gridcell");
  td.dataset.comp = comp.key;
  td.dataset.chap = ch.key;
  if (!v.match) td.classList.add("off");
  if (v.wait) {
    td.classList.add("wait");
    td.append(el("span", "dash", "…"));
  } else if (v.count) {
    td.append(el("span", "n", String(v.count)));
    for (const f of v.files.slice(0, 3)) {
      const code = el("span", "fc", f.code);
      code.title = f.name;
      td.append(code);
    }
    if (v.files.length > 3) td.append(el("span", "fc more", `+${v.files.length - 3}`));
  } else {
    td.classList.add("empty");
    td.append(el("span", "dash", "–"), el("span", "why", "keine direkte Fundstelle"));
  }
  if (v.hintMark) {
    const mark = el("span", "hintmark st-hint");
    mark.title = v.hint === 1 ? "1 Hinweis, nicht bestätigt" : `${v.hint} Hinweise, nicht bestätigt`;
    mark.append(icon("bulb"));
    td.append(mark);
  }
  const corner = el("span", "corner");
  if (v.lost) corner.append(withIcon(el("span", "st-lost"), "warn"));
  if (v.note) corner.append(icon("note"));
  if (STATUS_SYMBOLS[v.status]) corner.append(icon(STATUS_SYMBOLS[v.status], { ok: "st-ok", rueckfrage: "st-ask", nicht_relevant: "st-nr" }[v.status]));
  if (corner.childNodes.length) td.append(corner);
  td.setAttribute("aria-label", cellLabel(comp.name, ch.name, v));
  td.title = v.count ? "" : "keine direkte Fundstelle";
  const sel = state.ov.sel;
  td.setAttribute("aria-selected", String(Boolean(sel && sel.comp === comp.key && sel.chap === ch.key)));
  return td;
}

function docCell(comp, file, fileIdx) {
  const td = el("td", "dcell");
  td.setAttribute("role", "gridcell");
  const pages = new Set();
  for (const ch of ovCols()) for (const [fi, p] of cellOf(comp.key, ch.key).d || []) if (fi === fileIdx) pages.add(p);
  const list = [...pages].sort((a, b) => a - b);
  const word = fileKind(file.rel_path) === "pdf" ? "S." : "Teil";
  if (list.length) {
    td.append(el("span", "n", String(list.length)));
    const text = `${word} ${list.slice(0, 6).join(", ")}${list.length > 6 ? " …" : ""}`;
    td.append(el("span", "pages", text));
    td.setAttribute("aria-label", `${comp.name}, ${file.rel_path.split("/").pop()}: ${list.length} ${list.length === 1 ? "Stelle" : "Stellen"}, ${word} ${list.join(", ")}`);
  } else {
    td.classList.add("empty");
    td.append(el("span", "dash", "–"), el("span", "why", "keine direkte Fundstelle"));
    td.setAttribute("aria-label", `${comp.name}, ${file.rel_path.split("/").pop()}: keine direkte Fundstelle`);
  }
  return td;
}

function focusCell(r, c) {
  const table = $("ov-wrap").querySelector("table");
  if (!table) return;
  const td = table.querySelector(`td[data-r="${r}"][data-c="${c}"]`);
  if (!td) return;
  for (const t of table.querySelectorAll('td[tabindex="0"]')) t.tabIndex = -1;
  td.tabIndex = 0;
  state.ov.foc = { r, c };
  td.focus({ preventScroll: false });
  td.scrollIntoView({ block: "nearest", inline: "nearest" });
}

function gridKey(e) {
  const td = e.target.closest("td");
  if (!td) return;
  const table = td.closest("table");
  const rows = table.tBodies[0].rows.length;
  const cols = table.tHead.rows[0].cells.length - 1;
  const move = gridMove(Number(td.dataset.r), Number(td.dataset.c), e.key, rows, cols);
  if (move) {
    e.preventDefault();
    e.stopPropagation();
    focusCell(move.r, move.c);
    return;
  }
  if (state.ov.view !== "kap" || e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    openCell(td.dataset.comp, td.dataset.chap);
    return;
  }
  const next = statusFromKey(e.key, cellOf(td.dataset.comp, td.dataset.chap).st || "offen");
  if (next) {
    e.preventDefault();
    setCellStatus(td.dataset.comp, td.dataset.chap, next);
  }
}

// -- one cell in the panel ---------------------------------------------------------------------

async function openCell(compKey, chapKey) {
  state.ov.sel = { comp: compKey, chap: chapKey };
  for (const td of $("ov-wrap").querySelectorAll("td[aria-selected]")) td.setAttribute("aria-selected", String(td.dataset.comp === compKey && td.dataset.chap === chapKey));
  await refreshCellPanel();
  openPanel("cell");
}

async function refreshCellPanel() {
  const sel = state.ov.sel;
  if (!sel) return;
  try {
    state.ov.cell = await api("GET", tablePath(`/cell?component=${encodeURIComponent(sel.comp)}&chapter=${encodeURIComponent(sel.chap)}`));
    renderCellPanel();
  } catch (error) {
    $("side-cell").replaceChildren(el("p", "error", error.message));
  }
}

function passageNode(entry, kind) {
  const box = el("div", `pass${entry.lost ? " lost" : ""}`);
  const name = entry.rel_path.split("/").pop();
  const place = placeLabel(entry);
  const open = el("button", "open");
  open.type = "button";
  const where = el("span", "where");
  where.append(icon(KIND_SYMBOLS[fileKind(entry.rel_path)] || "file"), `${name} · ${place}`);
  open.append(where);
  if (entry.snippet) open.append(el("span", "snip", entry.snippet));
  const ways = { stelle: "Komponente und Kapitelwort in der Stelle", ueberschrift: "Kapitelwort in der Überschrift", dateiname_titel: "Kapitelwort im Dateinamen oder Titel", bestaetigt: "von dir bestätigt" };
  const meta = [];
  if (entry.decision === "passt") meta.push("von dir bestätigt");
  else if (entry.way) meta.push(ways[entry.way] || entry.way);
  if (entry.sure === false) meta.push("unsicher");
  if (entry.similar && entry.similar.length) meta.push(`ähnlich: S. ${entry.similar.join(", ")}`);
  if (entry.lost) meta.push("Stelle nicht mehr gefunden: Seite geändert, Datei umbenannt oder entfernt");
  if (meta.length) open.append(el("span", "meta", meta.join(" · ")));
  if (entry.lost || !entry.file_id) open.disabled = Boolean(entry.lost);
  open.addEventListener("click", () => openPassage(entry));
  box.append(open);
  const judge = el("div", "judge");
  const fits = button("Passt", () => decide(entry, entry.decision === "passt" ? null : "passt"), "small", "Diese Stelle gehört in das Feld");
  fits.prepend(icon("check"));
  fits.setAttribute("aria-pressed", String(entry.decision === "passt"));
  const not = button("Passt nicht", () => decide(entry, entry.decision === "passt_nicht" ? null : "passt_nicht"), "small", "Diese Stelle gehört nicht in das Feld");
  not.prepend(icon("x"));
  not.setAttribute("aria-pressed", String(entry.decision === "passt_nicht"));
  if (entry.lost) judge.append(button("Entfernen", () => decide(entry, null), "small quiet", "Die alte Entscheidung löschen"));
  else judge.append(fits, not);
  box.append(judge);
  if (kind) box.dataset.kind = kind;
  return box;
}

function openPassage(entry) {
  if (!entry.file_id) return;
  openPage(entry.file_id, entry.page_no, entry.chunk_id || null, entry.rel_path, "");
}

function renderCellPanel() {
  const cell = state.ov.cell;
  const box = $("side-cell");
  if (!cell) return box.replaceChildren(el("p", "note", "Wähl ein Feld der Übersicht."));
  const nodes = [];
  nodes.push(el("h2", "", `${cell.component.name} × ${cell.chapter.name}`));
  const n = cell.direct.length;
  nodes.push(el("p", "sub", n ? `${n} ${n === 1 ? "direkte Fundstelle" : "direkte Fundstellen"}` : cell.computed ? "Keine direkte Fundstelle" : "Wird noch gesucht …"));
  const seg = el("div", "statusseg");
  seg.setAttribute("role", "radiogroup");
  seg.setAttribute("aria-label", "Status des Felds");
  for (const st of CELL_STATUS) {
    const b = button({ offen: "Offen", ok: "ok", rueckfrage: "Rückfrage", nicht_relevant: "Nicht relevant" }[st], () => setCellStatus(cell.component.key, cell.chapter.key, st), st);
    b.setAttribute("role", "radio");
    b.setAttribute("aria-checked", String(cell.status === st));
    if (STATUS_SYMBOLS[st]) b.prepend(icon(STATUS_SYMBOLS[st]));
    seg.append(b);
  }
  nodes.push(seg);
  const keys = el("p", "keys");
  keys.append("Tasten: ", el("kbd", "", "O"), " ok · ", el("kbd", "", "R"), " Rückfrage · ", el("kbd", "", "N"), " nicht relevant");
  nodes.push(keys);
  const area = el("textarea", "");
  area.id = "cell-note";
  area.rows = 2;
  area.maxLength = 2000;
  area.value = cell.note;
  area.placeholder = "Notiz, z. B. was fehlt oder wo es steht";
  area.setAttribute("aria-label", "Notiz zum Feld");
  area.addEventListener("input", () => {
    clearTimeout(state.ov.noteTimer);
    state.ov.noteTimer = setTimeout(() => saveNote(cell, area.value), 600);
  });
  area.addEventListener("blur", () => {
    clearTimeout(state.ov.noteTimer);
    if (area.value !== cell.note) saveNote(cell, area.value);
  });
  nodes.push(area);
  nodes.push(el("p", "note notehelp", cell.status === "rueckfrage" ? "Diese Notiz steht in der Rückfrageliste an den Kunden." : "Nur für dich. Mit Status Rückfrage kommt sie in die Rückfrageliste."));
  if (n) {
    for (const e of cell.direct) nodes.push(passageNode(e, "direkt"));
  } else if (cell.computed) {
    nodes.push(el("p", "explain", `Zu „${cell.component.name}“ und „${cell.chapter.name}“ gibt es in den durchsuchten Dateien keine direkte Fundstelle. Die Information kann fehlen, anders benannt sein oder in einer Zeichnung oder einem Scan stehen.`));
  }
  if (cell.hints.length) {
    const d = el("details", "");
    d.append(el("summary", "", `Hinweise, nicht bestätigt (${cell.hints.length})`));
    d.append(el("p", "note", "Diese Stellen nennen die Komponente, sind aber nicht sicher oder ohne Wort des Kapitels. Sie füllen das Feld erst, wenn du „Passt“ wählst."));
    for (const e of cell.hints) d.append(passageNode(e, "hinweis"));
    nodes.push(d);
  }
  if (cell.rejected.length) {
    const d = el("details", "");
    d.append(el("summary", "", `Von dir verworfen (${cell.rejected.length})`));
    for (const e of cell.rejected) d.append(passageNode(e, "verworfen"));
    nodes.push(d);
  }
  if (cell.lost.length) {
    const d = el("details", "");
    d.open = true;
    d.append(el("summary", "", `Stelle nicht mehr gefunden (${cell.lost.length})`));
    for (const e of cell.lost) d.append(passageNode(e, "verloren"));
    nodes.push(d);
  }
  const how = el("details", "");
  how.append(el("summary", "", "So hat Daengs gesucht".replace("Daengs", state.product || "Daengs")));
  const ul = el("ul", "");
  for (const q of cell.searched.questions) ul.append(el("li", "", `Suche: ${q}`));
  ul.append(el("li", "", `Komponente erkannt an: ${cell.searched.names.join(", ")} (auch als Teil eines Worts)`));
  ul.append(el("li", "", `Kapitelwörter: ${cell.searched.words.join(", ")}`));
  ul.append(el("li", "", "Direkt heißt: die Suche ist sicher, die Komponente steht in der Stelle und ein Kapitelwort in der Stelle, in ihrer Überschrift oder im Dateinamen bzw. Titel."));
  how.append(ul);
  nodes.push(how);
  box.replaceChildren(...nodes);
}

async function saveNote(cell, text) {
  try {
    const result = await api("POST", tablePath("/cell"), { component: cell.component.key, chapter: cell.chapter.key, note: text });
    cell.note = result.note;
    updateLocalCell(cell.component.key, cell.chapter.key, result);
  } catch (error) {
    showOvError(error.message);
  }
}

function updateLocalCell(compKey, chapKey, result) {
  const key = `${compKey}|${chapKey}`;
  const cells = state.ov.data.cells;
  cells[key] = { ...(cells[key] || {}), st: result.status };
  if (result.note) cells[key].n = result.note;
  else delete cells[key].n;
  renderOverview();
}

async function setCellStatus(compKey, chapKey, status) {
  try {
    const result = await api("POST", tablePath("/cell"), { component: compKey, chapter: chapKey, status });
    updateLocalCell(compKey, chapKey, result);
    if (state.ov.cell && state.ov.cell.component.key === compKey && state.ov.cell.chapter.key === chapKey) {
      state.ov.cell.status = result.status;
      const focused = document.activeElement && document.activeElement.closest("#side-cell .statusseg");
      renderCellPanel();
      if (focused) $("side-cell").querySelector('.statusseg [aria-checked="true"]').focus();
    }
    $("ov-live").textContent = `Status ${STATUS_LABELS[result.status]}`;
  } catch (error) {
    showOvError(error.message);
  }
}

async function decide(entry, decision) {
  const cell = state.ov.cell;
  try {
    state.ov.cell = await api("POST", tablePath("/decide"), { component: cell.component.key, chapter: cell.chapter.key, folder: entry.folder, rel_path: entry.rel_path, page_no: entry.page_no, decision });
    renderCellPanel();
    loadOverview(true);
  } catch (error) {
    showOvError(error.message);
  }
}

// -- menus of the head: filter, columns, more -----------------------------------------------------

function togglePop(btn, pop, open = pop.hidden) {
  for (const other of document.querySelectorAll(".ov .menu")) if (other !== pop && !other.hidden) closePop(other);
  pop.hidden = !open;
  btn.setAttribute("aria-expanded", String(open));
  if (open) {
    const first = pop.querySelector("input, select, button");
    if (first) first.focus();
  }
}

function closePop(pop, back = false) {
  pop.hidden = true;
  const btn = document.querySelector(`[aria-controls="${pop.id}"]`);
  if (btn) {
    btn.setAttribute("aria-expanded", "false");
    if (back) btn.focus();
  }
}

function renderFilterPop() {
  const f = state.ov.filter;
  $("f-open").checked = f.open;
  $("f-ask").checked = f.ask;
  $("f-hint").checked = f.hint;
  $("f-kind").value = f.kind;
  const langs = [...new Set(ovFiles().flatMap((x) => x.langs))].filter(Boolean).sort();
  const select = $("f-lang");
  const options = ["alle", ...langs];
  if ([...select.options].map((o) => o.value).join() !== options.join()) {
    select.replaceChildren(...options.map((l) => {
      const o = el("option", "", l === "alle" ? "Alle" : l.toUpperCase());
      o.value = l;
      return o;
    }));
  }
  select.value = options.includes(f.lang) ? f.lang : "alle";
  $("f-warn").hidden = f.kind === "alle" && f.lang === "alle";
  $("ov-filter-btn").classList.toggle("on", filterActive(f));
}

function setFilter(change) {
  state.ov.filter = { ...state.ov.filter, ...change };
  saveOvView();
  renderOverview();
}

function renderColsPop() {
  const data = state.ov.data;
  if (!data) return;
  $("tpl-standard").setAttribute("aria-pressed", String(data.template === "standard"));
  $("tpl-kurz").setAttribute("aria-pressed", String(data.template === "kurz"));
  $("tpl-note").textContent = data.template === "kurz" ? "Kurz zeigt Daten, Funktion und Wartung. Gilt für dieses Projekt." : data.template === "standard" ? "Standard zeigt alle Kapitel. Gilt für dieses Projekt." : "Eigene Auswahl für dieses Projekt.";
  const list = $("cols-list");
  if (list.contains(document.activeElement)) return;
  list.replaceChildren(...data.chapters.map((ch) => {
    const label = el("label", "pop-check");
    const box = el("input", "");
    box.type = "checkbox";
    box.checked = ch.visible;
    box.addEventListener("change", () => changeChapters({ action: "update", key: ch.key, visible: box.checked }));
    label.append(box, ` ${ch.name}`);
    if (ch.own) {
      label.append(el("span", "own", "eigene"));
      const del = button("", () => { if (window.confirm(`Spalte „${ch.name}“ entfernen? Status und Notizen ihrer Felder gehen verloren.`)) changeChapters({ action: "remove", key: ch.key }); }, "quiet icon small", `Spalte „${ch.name}“ entfernen`);
      del.append(icon("trash"));
      label.append(del);
    }
    return label;
  }));
}

async function changeChapters(change) {
  try {
    const data = await api("POST", tablePath("/chapters"), change);
    data.pid = state.project.id;
    state.ov.data = data;
    renderOverview();
    loadOverview(true);
  } catch (error) {
    showOvError(error.message);
  }
}

function openColDialog() {
  closePop($("ov-cols"));
  $("form-col").reset();
  $("col-error").textContent = "";
  $("dlg-col").showModal();
}

const splitWords = (text) => text.split(",").map((w) => w.trim()).filter(Boolean);

async function addColumn(event) {
  event.preventDefault();
  try {
    await changeChapters({ action: "add", name: $("col-name").value.trim(), words_de: splitWords($("col-words").value), words_en: splitWords($("col-words-en").value) });
    $("dlg-col").close();
  } catch (error) {
    $("col-error").textContent = error.message;
  }
}

async function exportTable(what, format) {
  try {
    const data = await api("GET", tablePath(`/export?what=${what}&format=${format}`));
    const saved = data.base64 ? await saveBinary(data.filename, data.base64) : await saveText(data.filename, data.text);
    showOvError(saved ? `${data.filename} gespeichert.` : "Nicht gespeichert.");
  } catch (error) {
    showOvError(error.message);
  }
}

async function saveBinary(filename, base64) {
  if (window.pywebview && window.pywebview.api && window.pywebview.api.save_binary) return window.pywebview.api.save_binary(filename, base64);
  const bytes = Uint8Array.from(atob(base64), (ch) => ch.charCodeAt(0));
  const url = URL.createObjectURL(new Blob([bytes], { type: "application/octet-stream" }));
  const link = el("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return true;
}

function showIntro(open) {
  $("ov-intro").hidden = !open;
  $("ov-help").setAttribute("aria-expanded", String(open));
  if (!open && state.ov.data && !state.ov.data.intro_seen) {
    state.ov.data.intro_seen = true;
    api("POST", tablePath("/view"), { intro_seen: true }).catch(() => {});
  }
}

// -- sub views: request list, editor, suggestions ---------------------------------------------------

function showSub(sub) {
  state.ov.sub = sub;
  if (!sub) {
    renderOverview();
    const td = $("ov-wrap").querySelector('td[tabindex="0"]');
    if (td) td.focus();
    else $("ov-questions").focus();
    return;
  }
  renderOverview();
  if (sub === "rueckfragen") renderQuestions();
  if (sub === "editor") renderEditor();
  if (sub === "vorschlaege") renderSuggestions();
}

async function renderQuestions() {
  const body = $("ov-sub-body");
  let data;
  try {
    data = await api("GET", tablePath("/questions"));
  } catch (error) {
    return body.replaceChildren(el("p", "error", error.message));
  }
  const items = data.items;
  const head = el("div", "subhead");
  const h = el("h1", "", "Rückfrageliste");
  h.tabIndex = -1;
  head.append(h, el("span", "count", items.length === 1 ? "1 Punkt" : `${items.length} Punkte`), el("span", "spacer"));
  const copy = button("Text kopieren", () => copyQuestions(items), "primary");
  copy.prepend(icon("copy"));
  copy.disabled = !items.length;
  const csv = button("Als CSV speichern …", () => exportTable("rueckfragen", "csv"), "quiet");
  const xlsx = button("Als Excel speichern …", () => exportTable("rueckfragen", "xlsx"), "quiet");
  csv.disabled = xlsx.disabled = !items.length;
  head.append(csv, xlsx, copy);
  const nodes = [head, el("p", "note subnote", `Der Text ist für den Kunden gedacht. Du kopierst oder exportierst ihn und schickst ihn selbst ab. ${state.product} versendet nichts.`)];
  if (!items.length) {
    nodes.push(el("p", "", "Noch keine Rückfragen. Setz in einem Feld den Status „Rückfrage“ (Taste R); die Notiz des Felds wird hier zur Frage an den Kunden."));
  } else {
    nodes.push(el("p", "", "Zu folgenden Punkten fehlen uns Informationen:"));
    const list = el("ol", "qlist");
    items.forEach((q, i) => {
      const li = el("li", "qitem");
      li.append(el("span", "nr", String(i + 1)));
      const what = el("span", "what");
      what.append(el("b", "", q.component_name), ` · ${q.chapter_name}`);
      li.append(what);
      li.append(button("Feld öffnen", () => gotoCell(q.component, q.chapter), "quiet small"));
      const area = el("textarea", "");
      area.rows = 2;
      area.maxLength = 2000;
      area.value = q.note;
      area.placeholder = "Bitte Unterlagen nachreichen.";
      area.setAttribute("aria-label", `Rückfrage zu ${q.component_name}, ${q.chapter_name}`);
      area.addEventListener("change", async () => {
        q.note = area.value;
        try {
          const result = await api("POST", tablePath("/cell"), { component: q.component, chapter: q.chapter, note: area.value });
          const key = `${q.component}|${q.chapter}`;
          state.ov.data.cells[key] = { ...(state.ov.data.cells[key] || {}), st: result.status, n: result.note };
        } catch (error) {
          showOvError(error.message);
        }
      });
      li.append(area);
      const facts = [q.direct ? `${q.direct} direkte Fundstellen` : "keine direkte Fundstelle"];
      if (q.hints) facts.push(q.hints === 1 ? "1 Hinweis nicht bestätigt" : `${q.hints} Hinweise nicht bestätigt`);
      li.append(el("span", "meta", `Nur für dich, steht nicht im Text: ${facts.join(", ")}`));
      list.append(li);
    });
    nodes.push(list);
  }
  body.replaceChildren(...nodes);
  h.focus();
}

async function copyQuestions(items) {
  const text = questionsText(items);
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const area = el("textarea", "");
    area.value = text;
    document.body.append(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }
  $("ov-live").textContent = "Rückfrageliste kopiert.";
  showOvError("Rückfrageliste kopiert.");
}

function gotoCell(compKey, chapKey) {
  state.ov.filter = { ...EMPTY_FILTER };
  state.ov.view = "kap";
  const ch = state.ov.data.chapters.find((c) => c.key === chapKey);
  if (ch && !ch.visible) changeChapters({ action: "update", key: chapKey, visible: true });
  state.ov.sub = null;
  renderOverview();
  const td = $("ov-wrap").querySelector(`td[data-comp="${compKey}"][data-chap="${chapKey}"]`);
  if (td) focusCell(Number(td.dataset.r), Number(td.dataset.c));
  openCell(compKey, chapKey);
}

async function changeComponents(change) {
  const data = await api("POST", tablePath("/components"), change);
  data.pid = state.project.id;
  state.ov.data = data;
  state.ov.codes = fileCodes(data.files.map((f) => f.rel_path));
  return data;
}

function renderEditor() {
  const body = $("ov-sub-body");
  const comps = state.ov.data.components;
  const head = el("div", "subhead");
  const h = el("h1", "", "Komponenten bearbeiten");
  h.tabIndex = -1;
  head.append(h, el("span", "count", comps.length === 1 ? "1 Komponente" : `${comps.length} Komponenten`));
  const add = el("div", "eadd");
  const area = el("textarea", "");
  area.rows = 3;
  area.placeholder = "Eine Komponente je Zeile, z. B. Getriebemotor GM 45";
  area.setAttribute("aria-label", "Neue Komponenten, eine je Zeile");
  const addBtn = button("Hinzufügen", async () => {
    const names = area.value.split("\n").map((x) => x.trim()).filter(Boolean);
    if (!names.length) return;
    try {
      await changeComponents({ action: "add", names });
      area.value = "";
      renderEditor();
    } catch (error) {
      showOvError(error.message);
    }
  }, "primary");
  add.append(area, addBtn);
  const tools = el("div", "etools");
  const merge = button("Zusammenführen", mergeSelected, "", "Gewählte Komponenten zu einer Zeile zusammenführen; die erste behält ihren Namen");
  merge.disabled = true;
  tools.append(button("Vorschläge prüfen …", () => showSub("vorschlaege"), ""), merge, el("span", "note", "Zum Zusammenführen mindestens zwei anhaken; die erste behält ihren Namen."));
  const list = el("ul", "elist");
  for (const comp of comps) {
    const li = el("li", `erow${comp.hidden ? " hidden-row" : ""}`);
    const box = el("input", "");
    box.type = "checkbox";
    box.dataset.key = comp.key;
    box.setAttribute("aria-label", `${comp.name} zum Zusammenführen wählen`);
    box.addEventListener("change", () => { merge.disabled = list.querySelectorAll("input[type=checkbox]:checked").length < 2; });
    const name = el("span", "name", comp.name);
    if (comp.aliases.length) name.append(el("span", "alias", `auch: ${comp.aliases.join(", ")}`));
    if (comp.hidden) name.append(el("span", "alias", "ausgeblendet"));
    const rename = button("", () => renameRow(li, comp), "quiet icon small", `„${comp.name}“ umbenennen`);
    rename.append(icon("pencil"));
    const hide = button(comp.hidden ? "Einblenden" : "Ausblenden", async () => {
      await changeComponents({ action: "update", key: comp.key, hidden: !comp.hidden });
      renderEditor();
    }, "quiet small", comp.hidden ? "Wieder als Zeile zeigen" : "Zeile ausblenden, Status und Notizen bleiben");
    const del = button("", async () => {
      if (!window.confirm(`„${comp.name}“ entfernen? Status, Notizen und Entscheidungen dieser Zeile gehen verloren. Ausblenden behält sie.`)) return;
      await changeComponents({ action: "remove", key: comp.key });
      renderEditor();
    }, "quiet icon small danger-text", `„${comp.name}“ entfernen`);
    del.append(icon("trash"));
    li.append(box, name, rename, hide, del);
    list.append(li);
  }
  body.replaceChildren(head, add, tools, list);
  h.focus();
}

function renameRow(li, comp) {
  const input = el("input", "");
  input.type = "text";
  input.value = comp.name;
  input.maxLength = 100;
  input.setAttribute("aria-label", `Neuer Name für ${comp.name}`);
  const ok = button("Übernehmen", async () => {
    try {
      await changeComponents({ action: "update", key: comp.key, name: input.value.trim() });
      renderEditor();
    } catch (error) {
      showOvError(error.message);
    }
  }, "small");
  const cancel = button("Abbrechen", renderEditor, "quiet small");
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") ok.click();
    if (e.key === "Escape") { e.stopPropagation(); renderEditor(); }
  });
  li.replaceChildren(input, ok, cancel);
  input.focus();
  input.select();
}

async function mergeSelected() {
  const keys = [...$("ov-sub-body").querySelectorAll(".elist input[type=checkbox]:checked")].map((b) => b.dataset.key);
  if (keys.length < 2) return;
  const names = keys.map((k) => state.ov.data.components.find((c) => c.key === k).name);
  if (!window.confirm(`${names.join(", ")} zu „${names[0]}“ zusammenführen? Die anderen Namen findet ${state.product} weiter.`)) return;
  try {
    await changeComponents({ action: "merge", key: keys[0], others: keys.slice(1) });
    renderEditor();
  } catch (error) {
    showOvError(error.message);
  }
}

async function renderSuggestions() {
  const body = $("ov-sub-body");
  body.replaceChildren(el("p", "note", "Vorschläge werden gesucht …"));
  let data;
  try {
    data = await api("GET", tablePath("/suggestions"));
  } catch (error) {
    return body.replaceChildren(el("p", "error", error.message));
  }
  state.ov.suggestions = data.suggestions;
  const hiddenKinds = data.suggestions.filter((s) => s.kind).length;
  const head = el("div", "subhead");
  const h = el("h1", "", "Vorschläge prüfen");
  h.tabIndex = -1;
  head.append(h);
  const intro = el("p", "subnote", `${state.product} hat ${data.total === 1 ? "1 Eintrag" : `${data.total} Einträge`} aus Stücklisten und Dokumenttiteln gefunden. Du entscheidest, was eine Zeile wird. Vorab angehakt sind Baugruppen und Benennungen, die auch in einem anderen Dokument stehen.`);
  const nodes = [head, intro];
  if (hiddenKinds) {
    const show = el("label", "check");
    const box = el("input", "");
    box.type = "checkbox";
    box.checked = state.ov.showKinds;
    box.addEventListener("change", () => { state.ov.showKinds = box.checked; drawList(); });
    show.append(box, ` Normteile und Betriebsstoffe zeigen (${hiddenKinds})`);
    nodes.push(show);
  }
  const list = el("ul", "elist");
  const foot = el("div", "sfoot");
  const countLine = el("span", "", "");
  const estimate = el("span", "note", "");
  const create = button("Übernehmen", acceptSuggestions, "primary");
  foot.append(countLine, estimate, el("span", "spacer"), button("Abbrechen", () => showSub(ovRows().length ? "editor" : null), "quiet"), create);
  const drawList = () => {
    list.replaceChildren();
    for (const s of state.ov.suggestions) {
      if (s.kind && !state.ov.showKinds) continue;
      const li = el("li", "erow");
      const label = el("label", "check name");
      const box = el("input", "");
      box.type = "checkbox";
      box.checked = s.ticked;
      box.addEventListener("change", () => { s.ticked = box.checked; updateFoot(); });
      label.append(box, ` ${s.name}`);
      const src = sourcesLine(s.sources) + (s.kind ? ` · ${s.kind === "normteil" ? "Normteil" : "Betriebsstoff"}` : "") + (s.elsewhere ? " · auch in einem anderen Dokument" : "");
      li.append(label, el("span", "src", src));
      list.append(li);
    }
  };
  const updateFoot = () => {
    const n = state.ov.suggestions.filter((s) => s.ticked).length;
    countLine.textContent = n === 1 ? "1 Zeile wird angelegt" : `${n} Zeilen werden angelegt`;
    const total = state.ov.data.components.length + n;
    create.disabled = !n;
    create.textContent = ovRows().length ? "Übernehmen" : "Tabelle erstellen";
    if (total >= TABLE_ESTIMATE_FROM) {
      const cells = total * Math.max(1, ovCols().length);
      estimate.textContent = `Die Tabelle braucht dann ${estimateText(tableEstimate(cells, state.ov.data.ms_per_cell, state.ingest ? state.ingest.chunks : 0))} zum Erstellen.`;
    } else estimate.textContent = "";
  };
  drawList();
  updateFoot();
  nodes.push(list, foot);
  if (!data.total) nodes.splice(2, 0, el("p", "", "Keine Vorschläge: Es gibt keine Stückliste mit einer Spalte wie „Benennung“ oder „Baugruppe“. Gib die Komponenten von Hand ein."));
  body.replaceChildren(...nodes);
  h.focus();
}

// "Baugruppe · VM320 Ersatzteile · Z. 2, 3, 4" instead of one entry per row.
function sourcesLine(sources) {
  const groups = new Map();
  for (const x of sources) {
    const [doc, row] = x.where.split(" · Z. ");
    const key = `${x.source} · ${doc}`;
    if (!groups.has(key)) groups.set(key, []);
    if (row) groups.get(key).push(row);
  }
  return [...groups].map(([key, rows]) => (rows.length ? `${key} · Z. ${rows.join(", ")}` : key)).join("; ");
}

async function acceptSuggestions() {
  const names = state.ov.suggestions.filter((s) => s.ticked).map((s) => s.name);
  try {
    await changeComponents({ action: "add", names });
    showSub(null);
    loadOverview(true);
  } catch (error) {
    showOvError(error.message);
  }
}

// -- documents ----------------------------------------------------------------------------------

function openDocDialog(file) {
  state.ov.doc = file;
  $("doc-title").textContent = file.rel_path.split("/").pop();
  $("doc-meta").textContent = `Dateidatum ${file.date}${file.changed ? " · geändert seit deiner Sichtung" : ""}`;
  for (const r of document.querySelectorAll('input[name="doc-status"]')) r.checked = r.value === file.status;
  $("doc-stand").value = file.stand;
  $("doc-error").textContent = "";
  $("dlg-doc").showModal();
}

async function saveDocument(event) {
  event.preventDefault();
  const file = state.ov.doc;
  const status = document.querySelector('input[name="doc-status"]:checked').value;
  try {
    await api("POST", tablePath("/document"), { folder: file.folder, rel_path: file.rel_path, status, stand: $("doc-stand").value.trim() });
    $("dlg-doc").close();
    loadOverview(true);
  } catch (error) {
    $("doc-error").textContent = error.message;
  }
}

function bindOverview() {
  $("ov-questions").addEventListener("click", () => showSub("rueckfragen"));
  $("ov-back").addEventListener("click", () => showSub(null));
  $("ov-help").addEventListener("click", () => showIntro($("ov-intro").hidden));
  $("ov-intro-x").addEventListener("click", () => { showIntro(false); $("ov-help").focus(); });
  $("ov-view-kap").addEventListener("click", () => { state.ov.view = "kap"; state.ov.foc = { r: 0, c: 0 }; saveOvView(); renderOverview(); });
  $("ov-view-doc").addEventListener("click", () => { state.ov.view = "doc"; state.ov.foc = { r: 0, c: 0 }; saveOvView(); renderOverview(); });
  $("ov-chip-x").addEventListener("click", () => { setFilter({ ...EMPTY_FILTER }); $("ov-filter-btn").focus(); });
  $("ov-empty-suggest").addEventListener("click", () => showSub("vorschlaege"));
  $("ov-empty-edit").addEventListener("click", () => showSub("editor"));
  const pops = [["ov-filter-btn", "ov-filter"], ["ov-cols-btn", "ov-cols"], ["ov-more", "ov-menu"]];
  for (const [b, p] of pops) $(b).addEventListener("click", () => togglePop($(b), $(p)));
  for (const [, p] of pops) {
    $(p).addEventListener("keydown", (e) => {
      if (e.key === "Escape") { e.stopPropagation(); closePop($(p), true); }
    });
  }
  const items = [...$("ov-menu").querySelectorAll("button")];
  $("ov-menu").addEventListener("keydown", (e) => {
    const next = menuStep(items.indexOf(document.activeElement), e.key, items.length);
    if (next !== null) { e.preventDefault(); items[next].focus(); }
    if (e.key === "Tab") closePop($("ov-menu"));
  });
  for (const item of items) {
    item.addEventListener("click", () => {
      closePop($("ov-menu"));
      const act = item.dataset.act;
      if (act === "editor") showSub("editor");
      if (act === "csv") exportTable("tabelle", "csv");
      if (act === "xlsx") exportTable("tabelle", "xlsx");
      if (act === "help") showIntro(true);
    });
  }
  document.addEventListener("click", (e) => {
    for (const [b, p] of pops) if (!$(p).hidden && !e.target.closest(`#${p}, #${b}`)) closePop($(p));
  });
  $("f-open").addEventListener("change", (e) => setFilter({ open: e.target.checked }));
  $("f-ask").addEventListener("change", (e) => setFilter({ ask: e.target.checked }));
  $("f-hint").addEventListener("change", (e) => setFilter({ hint: e.target.checked }));
  $("f-kind").addEventListener("change", (e) => setFilter({ kind: e.target.value }));
  $("f-lang").addEventListener("change", (e) => setFilter({ lang: e.target.value }));
  $("f-reset").addEventListener("click", () => setFilter({ ...EMPTY_FILTER }));
  $("tpl-standard").addEventListener("click", () => changeChapters({ action: "template", template: "standard" }));
  $("tpl-kurz").addEventListener("click", () => changeChapters({ action: "template", template: "kurz" }));
  $("col-add").addEventListener("click", openColDialog);
  $("form-col").addEventListener("submit", addColumn);
  $("col-cancel").addEventListener("click", () => $("dlg-col").close());
  $("form-doc").addEventListener("submit", saveDocument);
  $("doc-cancel").addEventListener("click", () => $("dlg-doc").close());
  // O, R, N also work while the panel of the selected cell has the focus (not while typing).
  $("side-cell").addEventListener("keydown", (e) => {
    if (e.target.closest("textarea, input") || e.ctrlKey || e.metaKey || e.altKey || !state.ov.cell) return;
    const next = statusFromKey(e.key, state.ov.cell.status);
    if (next) {
      e.preventDefault();
      setCellStatus(state.ov.cell.component.key, state.ov.cell.chapter.key, next);
    }
  });
}

async function saveText(filename, text) {
  if (window.pywebview && window.pywebview.api && window.pywebview.api.save_file) {
    return window.pywebview.api.save_file(filename, text);
  }
  // Development in a normal browser: download instead of a save dialog.
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const link = el("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return true;
}

// -- wiki (F6) ----------------------------------------------------------------------------------

async function loadWiki(selectId) {
  if (!state.project) return [];
  try {
    const pages = await api("GET", projectPath("/wiki"));
    const select = $("wiki-select");
    select.replaceChildren();
    for (const p of pages) {
      const option = el("option", "", `${p.title} (${p.refs})`);
      option.value = p.id;
      select.append(option);
    }
    select.hidden = pages.length === 0;
    setNote("wiki-status", pages.length ? "" : "Noch keine Wiki-Seiten. Leg eine an oder merk dir eine Fundstelle.");
    const wanted = Number(selectId ?? state.wikiPage?.id ?? pages[0]?.id);
    if (pages.some((p) => p.id === wanted)) {
      select.value = String(wanted);
      await openWikiPage(wanted);
    } else {
      $("wiki-page").hidden = true;
    }
    return pages;
  } catch (error) {
    setNote("wiki-status", error.message, "err");
    return [];
  }
}

async function openWikiPage(id) {
  renderWikiPage(await api("GET", projectPath(`/wiki/${Number(id)}`)));
}

function renderWikiPage(page) {
  state.wikiPage = page;
  $("wiki-page").hidden = false;
  $("wiki-title").value = page.title;
  $("wiki-body").value = page.body;
  $("wiki-draft").hidden = !page.draft;
  $("wiki-restore").hidden = !page.can_restore;
  const list = $("wiki-refs");
  list.replaceChildren();
  $("wiki-refs-empty").hidden = page.refs.length > 0;
  for (const ref of page.refs) {
    const li = el("li");
    const text = el("div", "ref-text");
    text.append(el("div", "where", `${ref.rel_path}, ${placeLabel(ref)}`));
    if (ref.note) text.append(el("div", "", ref.note));
    text.append(el("div", "quote", ref.quote));
    if (ref.file_id === null) {
      text.append(el("div", "gone", "Datei ist nicht mehr in der Lieferung."));
    } else {
      text.addEventListener("click", () => {
        openPage(ref.file_id, ref.page_no, ref.chunk_id, ref.rel_path);
      });
    }
    li.append(text, button("Entfernen", async () => renderWikiPage(await api("POST", projectPath(`/wiki/${page.id}/refs/${ref.id}/delete`), {})), "quiet small"));
    list.append(li);
  }
}

async function newWikiPage() {
  const title = window.prompt("Titel der neuen Wiki-Seite:");
  if (!title || !title.trim()) return;
  try {
    const page = await api("POST", projectPath("/wiki"), { title });
    await loadWiki(page.id);
  } catch (error) {
    setNote("wiki-status", error.message, "err");
  }
}

async function saveWikiPage() {
  try {
    const page = await api("POST", projectPath(`/wiki/${state.wikiPage.id}`), { title: $("wiki-title").value, body: $("wiki-body").value });
    await loadWiki(page.id);
    setNote("wiki-status", "Gespeichert.", "ok");
  } catch (error) {
    setNote("wiki-status", error.message, "err");
  }
}

async function deleteWikiPage() {
  const page = state.wikiPage;
  if (!page || !window.confirm(`Wiki-Seite „${page.title}“ mit allen gemerkten Fundstellen löschen?`)) return;
  await api("POST", projectPath(`/wiki/${page.id}/delete`), { confirm: true });
  state.wikiPage = null;
  await loadWiki();
}

// -- Gesamt-Wiki (M9d, A-31): for all projects, without customer content ---------------------------

async function loadGlobalWiki(selectId) {
  try {
    const pages = await api("GET", "/api/global-wiki");
    const select = $("global-select");
    select.replaceChildren();
    for (const p of pages) {
      const option = el("option", "", p.title);
      option.value = p.id;
      select.append(option);
    }
    select.hidden = pages.length === 0;
    setNote("global-status", pages.length ? "" : "Noch keine Seiten. Leg eine an oder übernimm eine Erkenntnis aus dem Wiki eines Projekts.");
    const wanted = Number(selectId ?? state.globalPage?.id ?? pages[0]?.id);
    if (pages.some((p) => p.id === wanted)) {
      select.value = String(wanted);
      renderGlobalPage(await api("GET", `/api/global-wiki/${wanted}`));
    } else {
      state.globalPage = null;
      $("global-page").hidden = true;
    }
  } catch (error) {
    setNote("global-status", error.message, "err");
  }
}

function renderGlobalPage(page) {
  state.globalPage = page;
  $("global-page").hidden = false;
  $("global-title").value = page.title;
  $("global-body").value = page.body;
  $("global-restore").hidden = !page.can_restore;
}

async function newGlobalPage() {
  const title = window.prompt("Titel der neuen Seite im Gesamt-Wiki:");
  if (!title || !title.trim()) return;
  try {
    const page = await api("POST", "/api/global-wiki", { title });
    await loadGlobalWiki(page.id);
    $("global-body").focus();
  } catch (error) {
    setNote("global-status", error.message, "err");
  }
}

async function saveGlobalPage() {
  try {
    const page = await api("POST", `/api/global-wiki/${state.globalPage.id}`, { title: $("global-title").value, body: $("global-body").value });
    await loadGlobalWiki(page.id);
    setNote("global-status", "Gespeichert.", "ok");
  } catch (error) {
    setNote("global-status", error.message, "err");
  }
}

async function deleteGlobalPage() {
  const page = state.globalPage;
  if (!page || !window.confirm(`Seite „${page.title}“ aus dem Gesamt-Wiki löschen?`)) return;
  await api("POST", `/api/global-wiki/${page.id}/delete`, { confirm: true });
  state.globalPage = null;
  await loadGlobalWiki();
}

// The text is checked again after each change; "Übernehmen" waits for the check of what is written.
let checkTimer = null;
let checkRun = 0;

function openToGlobal() {
  $("to-global-title").value = $("wiki-title").value;
  $("to-global-body").value = $("wiki-body").value;
  $("to-global-error").textContent = "";
  $("dlg-to-global").showModal();
  checkToGlobal();
}

function checkSoon() {
  $("to-global-ok").disabled = true;
  clearTimeout(checkTimer);
  checkTimer = setTimeout(checkToGlobal, 500);
}

async function checkToGlobal() {
  const run = ++checkRun;
  $("to-global-ok").disabled = true;
  try {
    const result = await api("POST", projectPath("/global-wiki/check"), { title: $("to-global-title").value, body: $("to-global-body").value });
    if (run !== checkRun) return;
    renderHints(result.hints);
    $("to-global-existing").hidden = !result.existing;
    $("to-global-error").textContent = "";
    $("to-global-ok").disabled = false;
  } catch (error) {
    if (run === checkRun) $("to-global-error").textContent = error.message;
  }
}

function renderHints(groups) {
  const box = $("to-global-hints");
  box.replaceChildren(el("h3", "", groups.length ? "Das sieht nach Kundeninhalt aus. Bitte prüfen:" : "Nichts Auffälliges gefunden."));
  if (!groups.length) box.append(el("p", "note", `Die Prüfung findet nicht alles: Namen und Inhalte, die nicht in der Lieferung stehen, erkennt ${state.product || "sie"} nicht. Du entscheidest.`));
  for (const group of groups) {
    const items = el("div", "hint-items");
    for (const item of group.items) items.append(el("span", "", item));
    if (group.more) items.append(el("span", "", `und ${group.more} weitere`));
    const block = el("div", "hint-group");
    block.append(el("div", "hint-label", group.label), items);
    box.append(block);
  }
}

async function acceptToGlobal(event) {
  event.preventDefault();
  try {
    const page = await api("POST", "/api/global-wiki/accept", { title: $("to-global-title").value, body: $("to-global-body").value, confirm: true });
    state.globalPage = page;
    $("dlg-to-global").close();
    setNote("wiki-status", `Ins Gesamt-Wiki übernommen: ${page.title}`, "ok");
  } catch (error) {
    $("to-global-error").textContent = error.message;
  }
}

async function openRemember() {
  const v = state.view;
  if (!v) return;
  const pages = await api("GET", projectPath("/wiki"));
  const select = $("remember-page");
  select.replaceChildren();
  for (const p of pages) {
    const option = el("option", "", p.title);
    option.value = p.id;
    select.append(option);
  }
  const fresh = el("option", "", "Neue Seite …");
  fresh.value = "";
  select.append(fresh);
  if (state.wikiPage && pages.some((p) => p.id === state.wikiPage.id)) select.value = String(state.wikiPage.id);
  $("remember-new-label").hidden = select.value !== "";
  $("remember-where").textContent = `${v.relPath}, ${v.isPdf ? `Seite ${v.pageNo}` : $("page-label").textContent.split(" · ")[0]}`;
  $("remember-new").value = "";
  $("remember-note").value = "";
  $("remember-error").textContent = "";
  $("dlg-remember").showModal();
}

async function rememberPassage(event) {
  event.preventDefault();
  const v = state.view;
  try {
    let pageId = $("remember-page").value;
    if (pageId === "") {
      const title = $("remember-new").value.trim();
      if (!title) { $("remember-error").textContent = "Bitte einen Titel angeben."; return; }
      pageId = (await api("POST", projectPath("/wiki"), { title })).id;
    }
    const page = await api("POST", projectPath(`/wiki/${Number(pageId)}/refs`), { file_id: v.fileId, page_no: v.pageNo, chunk_id: v.chunkId, note: $("remember-note").value });
    state.wikiPage = page;
    $("dlg-remember").close();
    showStatus(`Fundstelle auf „${page.title}“ gemerkt.`, "ok");
    if (state.tab === "wiki") loadWiki(page.id);
    loadSaved();
  } catch (error) {
    $("remember-error").textContent = error.message;
  }
}

// -- delete a project (F7) ----------------------------------------------------------------------

const normalName = (text) => text.trim().split(/\s+/).join(" ");

function openDelete() {
  $("delete-name").textContent = state.project.name;
  $("delete-confirm").value = "";
  $("delete-error").textContent = "";
  $("delete-ok").disabled = true;
  $("dlg-delete").showModal();
  $("delete-confirm").focus();
}

async function deleteProject(event) {
  event.preventDefault();
  try {
    await api("POST", projectPath("/delete"), { confirm_name: $("delete-confirm").value });
    $("dlg-delete").close();
    clearTimeout(state.poll);
    state.lastProject = "";
    await loadProjects();
    showStatus("Projekt gelöscht.", "ok");
  } catch (error) {
    $("delete-error").textContent = error.message;
  }
}

// -- self-test and diagnostic report (F8) -------------------------------------------------------

// -- updates (13, D-037): the update program does the work; this only shows its files ------------

async function loadUpdates() {
  const status = await api("GET", "/api/updates");
  state.updates = status;
  const button_ = $("btn-updates");
  button_.hidden = !status.offered && !status.result.version;
  button_.textContent = status.available ? `Update ${status.available.version}` : "Updates";
  button_.classList.toggle("quiet", !status.available);
  button_.classList.toggle("primary", Boolean(status.available));
  if ($("dlg-updates").open) renderUpdates();
  renderActivity();
  return status;
}

function renderUpdates() {
  const s = state.updates;
  const when = s.last_check ? new Date(s.last_check * 1000).toLocaleString("de-DE") : "noch nicht";
  const running = s.progress.state === "laedt";
  const ready = s.progress.state === "bereit";
  $("update-info").textContent = `Deine Fassung: ${s.version}. Zuletzt geprüft: ${when}.`;
  $("update-enabled").checked = s.enabled;
  $("update-check").disabled = !s.enabled || !s.offered;
  const result = $("update-result");
  result.hidden = !s.result.version;
  result.textContent = !s.result.version ? "" : s.result.ok
    ? `Update auf ${s.result.version} installiert, der Selbsttest ist in Ordnung.`
    : `Das Update auf ${s.result.version} hat nicht geklappt: ${s.result.message} Deine bisherige Fassung läuft weiter.`;
  $("update-available").hidden = !s.available;
  // Too old for the small update setup: the full installer comes on a medium (D-074).
  const mediumOnly = Boolean(s.available) && s.available.loadable === false;
  if (s.available) {
    $("update-title").textContent = mediumOnly ? `Version ${s.available.version} verfügbar`
      : `Version ${s.available.version} verfügbar (${Math.ceil(s.available.size / 2 ** 20)} MB)`;
    $("update-changes").replaceChildren(...s.available.changes.map((line) => el("li", "", line)));
    $("update-progress").textContent = running ? `Wird geladen: ${s.progress.size ? Math.floor((100 * s.progress.done) / s.progress.size) : 0} %`
      : ready ? "Geladen und geprüft. Beim Aktualisieren schließt sich das Programm und startet danach neu."
      : s.progress.state === "fehler" ? s.progress.error
      : s.progress.state === "abgebrochen" ? "Abgebrochen; es geht beim nächsten Mal an derselben Stelle weiter."
      : mediumOnly ? "Deine Fassung ist für das Update zu alt. Die neue Version kommt per Vollinstaller (Datenträger)." : "";
  }
  $("update-bar").hidden = !s.available || !running;
  $("update-bar").firstElementChild.style.width = `${s.progress.size ? Math.floor((100 * s.progress.done) / s.progress.size) : 0}%`;
  $("update-now").hidden = !s.available || running || mediumOnly;
  $("update-now").textContent = ready ? "Jetzt aktualisieren" : "Update laden";
  $("update-cancel").hidden = !running;
}

function watchUpdates() {
  clearTimeout(state.updateTimer);
  if (!$("dlg-updates").open) return;
  state.updateTimer = setTimeout(async () => {
    try { await loadUpdates(); } finally { watchUpdates(); }
  }, 1000);
}

async function openUpdates() {
  $("update-error").textContent = "";
  await loadUpdates();
  renderUpdates();
  $("dlg-updates").showModal();
  watchUpdates();
}

async function updateNow() {
  $("update-error").textContent = "";
  try {
    if (state.updates.progress.state !== "bereit") {
      await api("POST", "/api/updates/download", {});
      await loadUpdates();
      return;
    }
    await api("POST", "/api/updates/install", { confirm: true });
    if (window.pywebview) await window.pywebview.api.close_window();
    else $("update-error").textContent = "Bitte schließ das Programm jetzt.";
  } catch (error) {
    $("update-error").textContent = error.message;
  }
}

// The update program checks in a process of its own: read its outcome until it is there (at most
// 30 s), so the button shows "Update x.y.z" without waiting for the next start (m23).
async function refreshAfterCheck() {
  const before = state.updates ? state.updates.last_check : null;
  for (let i = 0; i < 15; i++) {
    const status = await loadUpdates();
    if (status.last_check && status.last_check !== before) return;
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }
}

// At the start: the hint once, the result of the last update, and the outcome of the daily check.
async function startUpdates() {
  const status = await loadUpdates();
  if (status.offered && status.hint_pending) $("dlg-update-hint").showModal();
  else if (status.result.version) await openUpdates();
  setTimeout(() => { loadUpdates().catch(() => {}); }, 10000);
}

async function openDiagnose() {
  $("diagnose-text").textContent = "Selbsttest läuft …";
  $("dlg-diagnose").showModal();
  try {
    const data = await api("GET", "/api/diagnostics");
    $("diagnose-text").textContent = data.text;
  } catch (error) {
    $("diagnose-text").textContent = error.message;
  }
}

function bindM5() {
  $("wiki-select").addEventListener("change", (e) => openWikiPage(e.target.value));
  $("wiki-new").addEventListener("click", newWikiPage);
  $("wiki-save").addEventListener("click", saveWikiPage);
  $("wiki-to-global").addEventListener("click", openToGlobal);
  $("to-global-title").addEventListener("input", checkSoon);
  $("to-global-body").addEventListener("input", checkSoon);
  $("form-to-global").addEventListener("submit", acceptToGlobal);
  $("to-global-cancel").addEventListener("click", () => $("dlg-to-global").close());
  $("side-global").addEventListener("click", () => showTab("global"));
  $("global-select").addEventListener("change", async (e) => renderGlobalPage(await api("GET", `/api/global-wiki/${Number(e.target.value)}`)));
  $("global-new").addEventListener("click", newGlobalPage);
  $("global-save").addEventListener("click", saveGlobalPage);
  $("global-delete").addEventListener("click", deleteGlobalPage);
  $("global-restore").addEventListener("click", async () => {
    if (!state.globalPage || !window.confirm("Die Fassung vor der letzten Änderung zurückholen? Die jetzige wird dann zur früheren.")) return;
    renderGlobalPage(await api("POST", `/api/global-wiki/${state.globalPage.id}/restore`, {}));
  });
  $("wiki-delete").addEventListener("click", deleteWikiPage);
  $("wiki-restore").addEventListener("click", async () => {
    if (!state.wikiPage || !window.confirm("Die Fassung vor der letzten Änderung zurückholen? Die jetzige wird dann zur früheren.")) return;
    renderWikiPage(await api("POST", projectPath(`/wiki/${state.wikiPage.id}/restore`), {}));
  });
  $("btn-remember").addEventListener("click", openRemember);
  $("remember-page").addEventListener("change", (e) => { $("remember-new-label").hidden = e.target.value !== ""; });
  $("form-remember").addEventListener("submit", rememberPassage);
  $("remember-cancel").addEventListener("click", () => $("dlg-remember").close());
  $("delete-confirm").addEventListener("input", (e) => { $("delete-ok").disabled = normalName(e.target.value) !== state.project.name; });
  $("form-delete").addEventListener("submit", deleteProject);
  $("delete-cancel").addEventListener("click", () => $("dlg-delete").close());
  $("btn-diagnose").addEventListener("click", () => { closeSettingsMenu(false); openDiagnose(); });
  $("btn-updates").addEventListener("click", openUpdates);
  $("update-now").addEventListener("click", updateNow);
  $("update-check").addEventListener("click", async () => { await api("POST", "/api/updates/check", {}); });
  $("update-cancel").addEventListener("click", async () => { await api("POST", "/api/updates/cancel", {}); });
  $("update-enabled").addEventListener("change", async (e) => { await api("POST", "/api/updates/settings", { enabled: e.target.checked }); await loadUpdates(); });
  $("dlg-updates").addEventListener("close", async () => { if (state.updates && state.updates.result.version) { await api("POST", "/api/updates/result", {}); await loadUpdates(); } });
  $("dlg-update-hint").addEventListener("close", async () => { await api("POST", "/api/updates/settings", { hint_seen: true }); await refreshAfterCheck(); });
  $("diagnose-save").addEventListener("click", () => saveText(`${state.product}_Diagnosebericht.txt`, $("diagnose-text").textContent));
}

// -- answers with sources (F10, extension D-022) ------------------------------------------------

async function detectLlm() {
  try {
    state.llm = await api("GET", "/api/llm");
  } catch {
    state.llm = { available: false };
  }
  // Without the extension there is no history and no answer; the input only searches.
  showModel();
  renderComposer();
  renderActivity();
}

async function loadChats() {
  if (!state.project || !hasExtension()) return;
  try {
    state.chats = await api("GET", projectPath("/chats"));
  } catch {
    state.chats = [];
  }
  renderSidebar();
}

// A history from the sidebar (D-055: the history of the answers), shown like the conversation.
async function openHistory(chatId) {
  if (!state.project || !hasExtension()) return;
  const run = ++state.searchRun;
  await stopThenClear({ running: state.answering, stop: stopAnswer, finished: state.answerDone, clear: () => {} });
  if (run !== state.searchRun) return;
  try {
    const history = await api("GET", projectPath(`/chats/${chatId}`));
    if (run !== state.searchRun) return;
    clearResults();
    clearPage();
    state.question = "";
    state.terms = [];
    state.thread = newThread(chatId);
    state.thread.fromHistory = true;
    state.thread.turns = history.map((entry) => ({ kind: "follow", question: entry.question, entry, open: false }));
    const last = history[history.length - 1];
    setReference(last ? { chatId, question: last.question } : null);
    showTab("search");
    renderThread();
    const node = state.thread.turns.length ? state.thread.turns[state.thread.turns.length - 1].node : null;
    if (node) node.scrollIntoView({ block: "start" });
  } catch (error) {
    showStatus(error.message, "err");
  }
}

function currentChat() {
  return state.chats.find((c) => c.id === state.thread.chatId);
}

async function renameChat() {
  const chat = currentChat();
  if (!chat) return;
  const title = window.prompt("Neuer Name des Verlaufs:", chat.title);
  if (title === null || !title.trim()) return;
  try {
    await api("POST", projectPath(`/chats/${chat.id}/rename`), { title });
    await loadChats();
    renderThread();
  } catch (error) {
    showStatus(error.message, "err");
  }
}

async function deleteChat() {
  const chat = currentChat();
  if (!chat || !window.confirm(`Verlauf „${chat.title}“ mit allen Antworten löschen?`)) return;
  try {
    await api("POST", projectPath(`/chats/${chat.id}/delete`), { confirm: true });
    clearResults();
    setReference(null);
    await loadChats();
    showStatus("Verlauf gelöscht.", "ok");
  } catch (error) {
    showStatus(error.message, "err");
  }
}

function openSource(source) {
  openPage(source.file_id, source.page_no, source.chunk_id, source.rel_path);
}

function citeButton(source, n) {
  const chip = button(String(n), () => { hideCitePop(); openSource(source); }, "cite", `Beleg ${n} öffnen`);
  chip.dataset.n = String(n);
  const light = (on) => lightCard(chip.closest(".turn"), n, on);
  chip.addEventListener("mouseenter", () => { showCitePop(chip, source); light(true); });
  chip.addEventListener("focus", () => { showCitePop(chip, source); light(true); });
  chip.addEventListener("mouseleave", () => { hideCitePop(); light(false); });
  chip.addEventListener("blur", () => { hideCitePop(); light(false); });
  return chip;
}

// Preview of a source at its number: where it stands and what it says, as text only.
function showCitePop(chip, source) {
  const pop = $("cite-pop");
  $("cite-pop-where").textContent = `${source.rel_path}, ${placeLabel(source)}`;
  $("cite-pop-text").textContent = source.snippet;
  pop.hidden = false;
  const at = chip.getBoundingClientRect();
  const left = Math.max(8, Math.min(at.left, window.innerWidth - pop.offsetWidth - 8));
  const above = at.top - pop.offsetHeight - 6;
  pop.style.left = `${left}px`;
  pop.style.top = `${above >= 8 ? above : at.bottom + 6}px`;
}

function hideCitePop() {
  $("cite-pop").hidden = true;
}

// Head of an answer (c6): "Antwort", the mark of an AI draft, the model; no coloured stripe.
function answerHead(labelText, modelId) {
  const head = el("div", "a-head");
  head.append(icon("chat"), el("b", "", "Antwort"), el("span", "label", labelText), el("span", "spacer"));
  if (modelId) head.append(el("span", "a-model", `${modelName(modelId)} · lokal`));
  return head;
}

// Built from text nodes only: the answer is model output about untrusted documents.
function answerNode(entry) {
  if (entry.no_sure) return noSureNode(entry);
  const box = el("article", "answer");
  box.append(answerHead(entry.label, entry.model_id));
  if (entry.missing_terms && entry.missing_terms.length) box.append(missingNode(entry.missing_terms));
  const bySource = new Map(entry.sources.map((s) => [s.n, s]));
  const text = el("div", "text");
  for (const sentence of entry.sentences) {
    const uncited = !sentence.sources.length && !sentence.invalid_sources.length && entry.sources.length;
    const part = el("span", uncited ? "nosrc" : "");
    let at = 0;
    for (const number of sentence.numbers) {
      part.append(sentence.text.slice(at, number.start));
      if (number.found) {
        part.append(sentence.text.slice(number.start, number.end));
      } else {
        const mark = el("span", "unverified", sentence.text.slice(number.start, number.end));
        mark.title = "Diese Zahl steht so nicht in der angegebenen Quelle. Bitte prüfen.";
        part.append(mark);
      }
      at = number.end;
    }
    part.append(sentence.text.slice(at));
    text.append(part);
    for (const n of sentence.sources) text.append(citeButton(bySource.get(n), n));
    for (const n of sentence.invalid_sources) {
      const bad = el("span", "cite bad", String(n));
      bad.title = "Diese Quellennummer gibt es nicht.";
      text.append(bad);
    }
    if (uncited) text.append(el("span", "uncited", "(ohne Beleg)"));
    text.append(" ");
  }
  box.append(text);
  if (entry.stopped) box.append(el("div", "stopped", "Abgebrochen – die Antwort ist unvollständig."));
  else box.append(checkNode(entry));
  const foot = el("div", "a-foot");
  foot.append(howNode(entry), actionsNode(entry));
  box.append(foot);
  return box;
}

function checkNode(entry) {
  const warnings = checkWarnings(entry);
  const line = el("div", warnings.length ? "check-line warn" : "check-line ok");
  line.append(icon(warnings.length ? "warn" : "check"), warnings.length ? `Geprüft: ${warnings.join(" · ")}` : "Zahlen und Belege geprüft");
  return line;
}

// Only weak passages: no draft (D-053). A note from the program, so no mark of an AI draft.
function noSureNode(entry) {
  const box = el("article", "answer no-sure");
  const head = el("div", "check-line warn");
  head.append(icon("warn"), "Keine sicheren Stellen");
  box.append(head, el("p", "", `Zu dieser Frage steht in den Unterlagen nichts, das sicher passt. ${state.product} schreibt deshalb keinen Entwurf. Die ähnlichsten Stellen stehen oben, du kannst sie selbst ansehen.`));
  return box;
}

function missingNode(terms) {
  const words = terms.map((t) => `„${t}“`).join(", ");
  return el("div", "missing", `${words} steht so nicht in den Unterlagen; die Antwort nennt die Bezeichnung aus dem Dokument.`);
}

// "How did the answer come about?" (M9a): the steps with their times, folded.
function howNode(entry) {
  const box = el("details", "how");
  box.append(el("summary", "", "Wie entstand die Antwort?"));
  const steps = entry.steps || {};
  const list = el("ul", "");
  const seconds = (v) => (v === undefined ? "" : ` (${String(v).replace(".", ",")} s)`);
  list.append(
    el("li", "", `Zeit und Modell: ${entry.seconds} s · ${entry.model_id}`),
    el("li", "", entry.from_hits
      ? `Übernommen: ${entry.sources.length} Stellen aus der Trefferliste, ohne neue Suche`
      : `Gesucht: ${entry.sources.length} Stellen${seconds(steps.suche)}`),
    ...(entry.searches || []).map((query) => el("li", "", `In den ersten Stellen stand nichts dazu; nochmals gesucht mit: „${query}“`)),
    el("li", "", `Gelesen: die Sätze um die Fragewörter${seconds(steps.lesen)}`),
    el("li", "", `Geschrieben: ${entry.model_id}${entry.tokens ? `, ${entry.tokens} Textteile` : ""}${seconds(steps.schreiben)}`),
    el("li", "", "Geprüft: jede Belegnummer und jede Zahl gegen die Quelle"),
  );
  box.append(list);
  return box;
}

function actionsNode(entry) {
  const row = el("div", "answer-actions");
  row.append(withIcon(button("Kopieren", () => copyAnswer(entry), "quiet small", "Antwort mit Quellen kopieren"), "copy"));
  if (entry.id && !entry.stopped) {
    row.append(withIcon(button("Ins Wiki übernehmen …", () => suggestWiki(entry, row.closest("article")), "quiet small",
      "Vorschlag für eine Wiki-Seite aus dieser Antwort; gespeichert wird erst, wenn du bestätigst"), "book"));
  }
  if (entry.id) {
    for (const [value, symbol, title] of [[1, "up", "Hilfreich"], [-1, "down", "Nicht hilfreich"]]) {
      const b = withIcon(button("", () => rateAnswer(entry, value, row), "quiet small icon", title), symbol);
      b.dataset.value = String(value);
      b.setAttribute("aria-pressed", String(entry.rating === value));
      row.append(b);
    }
  }
  return row;
}

// -- wiki suggestions (M9b, A-39): shown as a card, written only when the user confirms ---------

async function suggestWiki(entry, card) {
  const next = card && card.nextElementSibling;
  if (next && next.classList.contains("suggestion")) return next.scrollIntoView({ block: "nearest" });
  showStatus("Vorschlag wird erstellt …", "info", true);
  try {
    const proposal = await api("GET", projectPath(`/chats/${entry.chat_id}/messages/${entry.id}/wiki`));
    showStatus("");
    if (!proposal.body) {
      showStatus("Diese Antwort hat keinen belegten Satz; daraus wird keine Wiki-Seite.", "warn");
      return;
    }
    showSuggestion(proposal, card);
  } catch (error) {
    showStatus(error.message, "err");
  }
}

function showSuggestion(proposal, after) {
  const box = el("div", "suggestion");
  const render = (editing) => {
    box.replaceChildren();
    const addition = Boolean(proposal.page_id);
    box.append(el("div", "head", addition
      ? `Vorschlag: Ich würde die Wiki-Seite „${proposal.page_title}“ ergänzen`
      : `Vorschlag: Ich würde diese Wiki-Seite anlegen: „${proposal.title}“`));
    if (editing) {
      const title = el("input", "");
      title.value = proposal.title;
      title.disabled = addition;
      title.setAttribute("aria-label", "Titel");
      const body = el("textarea", "");
      body.value = proposal.body;
      body.setAttribute("aria-label", "Text");
      box.append(title, body);
      box.append(row([
        button(addition ? "Ergänzen" : "Anlegen", () => { proposal.title = title.value; proposal.body = body.value; acceptSuggestion(proposal, box); }, "primary"),
        button("Abbrechen", () => render(false)),
      ]));
      return;
    }
    const pre = el("pre", "");
    if (addition && proposal.page_body) pre.append(el("span", "old", `${proposal.page_body.trim()}\n\n`));
    pre.append(el("span", addition ? "new" : "", proposal.body));
    box.append(pre);
    const notes = [`${proposal.refs.length} Quelle(n) werden als gemerkte Fundstellen mitgenommen.`];
    if (proposal.skipped) notes.push(`${proposal.skipped} Satz/Sätze ohne Beleg nicht übernommen.`);
    box.append(el("div", "note", notes.join(" ")));
    box.append(row([
      button(addition ? "Ergänzen" : "Anlegen", () => acceptSuggestion(proposal, box), "primary"),
      button("Bearbeiten", () => render(true), ""),
      button("Verwerfen", () => box.remove(), "quiet", "Nichts wird gespeichert"),
    ]));
  };
  const row = (buttons) => {
    const r = el("div", "row");
    r.append(...buttons);
    return r;
  };
  render(false);
  if (after && after.isConnected) after.after(box);
  else $("results").append(box);
  box.scrollIntoView({ block: "nearest" });
}

async function acceptSuggestion(proposal, box) {
  try {
    const page = await api("POST", projectPath("/wiki/accept"), {
      title: proposal.title, body: proposal.body, refs: proposal.refs, page_id: proposal.page_id || undefined,
    });
    box.replaceChildren(
      el("div", "head", proposal.page_id ? `Wiki-Seite „${page.title}“ ergänzt.` : `Wiki-Seite „${page.title}“ angelegt.`),
      button("Öffnen", async () => { showTab("wiki"); await loadWiki(page.id); }, "primary"),
    );
    loadSaved();
  } catch (error) {
    box.append(el("div", "stopped", error.message));
  }
}

async function copyAnswer(entry) {
  const text = copyText(entry);
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const area = el("textarea", "");
    area.value = text;
    document.body.append(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }
  showStatus("Antwort mit Quellen kopiert.", "ok");
}

// Thumbs stay in the project on this computer, as proposals for new gold questions (D-028).
async function rateAnswer(entry, value, row) {
  const next = entry.rating === value ? 0 : value;
  let note = "";
  if (next === -1) note = window.prompt("Was war falsch? (optional, bleibt auf diesem Rechner)", "") || "";
  try {
    await api("POST", projectPath(`/chats/${entry.chat_id}/messages/${entry.id}/rating`), { value: next, note });
    entry.rating = next || null;
    for (const b of row.querySelectorAll("button[data-value]")) b.setAttribute("aria-pressed", String(Number(b.dataset.value) === entry.rating));
  } catch (error) {
    showStatus(error.message, "err");
  }
}

// The card while the answer comes about (M9a). It is added to, not rebuilt: words that are there stay,
// new ones fade in, and a number in the text can be clicked at once. The passages stand as cards above.
function renderLive(card, view) {
  if (!card.live) {
    card.live = { steps: el("ul", "steps"), bar: el("div", "progress readbar"), missing: el("div", ""), text: el("div", "live-text"), error: el("div", ""), shown: 0 };
    card.live.bar.append(el("i", ""));
    card.live.bar.hidden = true;
    const { steps, bar, missing, text, error } = card.live;
    card.append(answerHead("KI-Entwurf – entsteht gerade", state.llm && state.llm.model_id), steps, bar, missing, text, error);
  }
  const live = card.live;
  view.steps.forEach((step, i) => {
    let item = live.steps.children[i];
    if (!item) {
      item = el("li", "pop");
      live.steps.append(item);
    }
    const label = stepLabel(step);
    if (item.dataset.label === label) return;
    item.dataset.label = label;
    item.classList.toggle("done", step.done);
    item.replaceChildren(icon(step.done ? "check" : "spinner", step.done ? "" : "spin"), label);
  });
  const reading = view.steps.some((s) => s.step === "lesen" && !s.done);
  const share = readShare(view);
  live.bar.hidden = !reading;
  live.bar.classList.toggle("wait", reading && share === null);
  live.bar.firstChild.style.width = share === null ? "" : `${Math.round(share * 100)}%`;
  live.missing.replaceChildren(...(view.missing.length ? [missingNode(view.missing)] : []));
  if (view.text.length < live.shown) {
    live.text.replaceChildren();
    live.shown = 0;
  }
  const { parts, upto } = liveParts(view.text, live.shown);
  live.shown = upto;
  const bySource = new Map(view.sources.map((s) => [s.n, s]));
  for (const part of parts) {
    if (part.text !== undefined) live.text.append(el("span", "wnew", part.text));
    else if (bySource.has(part.n)) live.text.append(citeButton(bySource.get(part.n), part.n));
    else live.text.append(el("span", "wnew", `[${part.n}]`));
  }
  live.error.replaceChildren(...(view.error ? [el("div", "stopped", view.error)] : []));
}

function setAnswering(on) {
  state.answering = on;
  renderComposer();
}

async function stopAnswer() {
  try {
    await api("POST", projectPath("/answer/stop"), {});
  } catch (error) {
    showStatus(error.message, "err");
  }
}

// The passages of a section anew, e.g. when the answer names its sources: numbers come onto the cards.
function renderSurface(turn) {
  if (!turn.node || !turn.node.isConnected) return;
  const old = turn.node.querySelector(".surface");
  const fresh = surfaceNode(turn);
  if (old && fresh) old.replaceWith(fresh);
  else if (fresh) turn.node.querySelector(".turn-q").after(fresh);
  updateOrder();
  markActive();
}

// One answer into a section. ``body``: the question, and either chunk_ids (a new history from the
// hits on screen) or chat_id (a follow-up in the history it belongs to).
async function streamAnswer(body, turn) {
  showStatus("");
  const card = el("article", "answer live");
  turn.card = card;
  turn.view = chatView();
  const view = turn.view;
  renderLive(card, view);
  const slot = turn.node && turn.node.querySelector(".ask-row");
  if (slot) slot.replaceWith(card);
  else if (turn.node) turn.node.append(card);
  const scroller = $("scroll");
  let finished;
  state.answerDone = new Promise((resolve) => { finished = resolve; });
  setAnswering(true);
  try {
    const response = await fetch(projectPath("/answer/stream"), {
      method: "POST",
      headers: { Authorization: `Bearer ${state.token}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!response.ok) throw new Error((await response.json()).fehler || "Fehler");
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      const parsed = parseEvents(buffer + decoder.decode(value, { stream: true }));
      buffer = parsed.rest;
      const atBottom = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 80;
      for (const e of parsed.events) {
        applyEvent(view, e, performance.now());
        if (e.type === "sources") renderSurface(turn);
      }
      renderLive(card, view);
      if (atBottom) scroller.scrollTop = scroller.scrollHeight;
    }
    if (view.entry) {
      turn.entry = view.entry;
      turn.card = null;
      turn.view = null;
      state.thread.chatId = view.entry.chat_id;
      setReference({ chatId: view.entry.chat_id, question: body.question });
      if (card.isConnected) {
        renderSurface(turn);
        const done = answerNode(view.entry);
        card.replaceWith(done);
        if (view.suggestion) showSuggestion(view.suggestion, done);
      }
      await loadChats();
    } else if (!view.error) {
      throw new Error("Die Antwort wurde unterbrochen.");
    }
  } catch (error) {
    view.error = error.message;
    renderLive(card, view);
  } finally {
    setAnswering(false);
    finished();
    hideCitePop();
    detectLlm();
  }
}

// The field grows with its text up to 6 lines (CSS holds the limit).
function fitComposer() {
  const area = $("search-input");
  area.style.height = "auto";
  area.style.height = `${area.scrollHeight + 2}px`;
  area.style.overflowY = area.scrollHeight > 150 ? "auto" : "hidden";
}

async function toggleModelPop() {
  const pop = $("model-pop");
  if (!pop.hidden) return closeModelPop();
  await detectLlm();
  pop.hidden = false;
  $("btn-model").setAttribute("aria-expanded", "true");
}

function closeModelPop() {
  $("model-pop").hidden = true;
  $("btn-model").setAttribute("aria-expanded", "false");
}

// Status line under the input card: model and its state, or that there is none.
function showModel() {
  const has = hasExtension();
  $("model-anchor").hidden = !has;
  $("no-model").hidden = has || !state.llm;
  if (!has) return;
  const name = modelName(state.llm.model_id);
  const running = state.llm.running;
  $("model-name").textContent = `${name} · lokal · ${running ? "geladen" : "bereit"}`;
  $("model-pop-name").textContent = name;
  $("model-state").replaceChildren(icon("check"), running ? "geladen" : "bereit, lädt beim ersten Antworten");
}

function bindM7() {
  bindComposer();
  $("btn-model").addEventListener("click", toggleModelPop);
  document.addEventListener("click", (e) => {
    if (!$("model-pop").hidden && !e.target.closest("#model-anchor")) closeModelPop();
  });
}

// -- settings: level of motion (D-045), kept on this computer ---------------------------------------

function applyMotion(level) {
  document.documentElement.dataset.motion = level;
  for (const item of $("menu-settings").querySelectorAll("[data-motion]")) {
    item.setAttribute("aria-checked", String(item.dataset.motion === level));
  }
}

async function loadPreferences() {
  const choices = await api("GET", "/api/preferences");
  applyMotion(choices.motion);
  state.density = choices.density;
  state.kindFilter = choices.file_filter;
  state.lastProject = choices.last_project;
}

async function savePreferences(changes) {
  try {
    await api("POST", "/api/preferences", changes);
  } catch (error) {
    showStatus(error.message, "err");
  }
}

function openSettingsMenu() {
  const menu = $("menu-settings");
  const at = $("btn-settings").getBoundingClientRect();
  menu.style.position = "fixed";
  menu.style.left = `${Math.round(at.left)}px`;
  menu.style.right = "auto";
  menu.style.top = "auto";
  menu.style.bottom = `${Math.round(window.innerHeight - at.top + 4)}px`;
  menu.hidden = false;
  $("btn-settings").setAttribute("aria-expanded", "true");
  menu.querySelector('[aria-checked="true"]').focus();
}

function closeSettingsMenu(backToButton = true) {
  $("menu-settings").hidden = true;
  $("btn-settings").setAttribute("aria-expanded", "false");
  if (backToButton) $("btn-settings").focus();
}

async function chooseMotion(level) {
  const before = document.documentElement.dataset.motion;
  applyMotion(level);
  closeSettingsMenu();
  try {
    await api("POST", "/api/preferences", { motion: level });
  } catch (error) {
    applyMotion(before);
    showStatus(error.message, "err");
  }
}

function bindSettings() {
  const menu = $("menu-settings");
  const items = [...menu.querySelectorAll("[data-motion], #btn-diagnose")];
  $("btn-settings").addEventListener("click", () => (menu.hidden ? openSettingsMenu() : closeSettingsMenu()));
  for (const item of items) if (item.dataset.motion) item.addEventListener("click", () => chooseMotion(item.dataset.motion));
  menu.addEventListener("keydown", (e) => {
    if (e.key === "Escape") return closeSettingsMenu();
    if (e.key === "Tab") return closeSettingsMenu(false);
    const next = menuStep(items.indexOf(document.activeElement), e.key, items.length);
    if (next !== null) {
      e.preventDefault();
      items[next].focus();
    }
  });
  document.addEventListener("click", (e) => {
    if (!menu.hidden && !e.target.closest("#menu-settings, #btn-settings")) closeSettingsMenu(false);
  });
}

// -- start --------------------------------------------------------------------------------------

// Nacharbeit 3c (a): a window in the background or minimized does not animate (about 20 % of a
// core while reading, AP-9.29); the state stays in the text.
function watchWindowState() {
  const update = () => {
    const on = animationActive(document.visibilityState === "visible", document.hasFocus());
    document.documentElement.dataset.active = on ? "ja" : "nein";
  };
  document.addEventListener("visibilitychange", update);
  window.addEventListener("focus", update);
  window.addEventListener("blur", update);
  update();
}

function bind() {
  watchWindowState();
  $("btn-new").addEventListener("click", openNewProject);
  $("btn-welcome-new").addEventListener("click", openNewProject);
  $("form-new").addEventListener("submit", createProject);
  $("new-cancel").addEventListener("click", () => $("dlg-new").close());
  $("new-choose").addEventListener("click", chooseNewFolder);
  $("new-type").addEventListener("click", typeNewFolder);
  $("new-folder").addEventListener("input", () => { $("new-ok").disabled = !$("new-folder").value.trim(); });
  bindDrop();
  $("add-choose").addEventListener("click", async () => {
    const folder = await pickFolder();
    if (folder) changeFolder("grant", folder);
    else if (!hasDialogs()) { $("add-typed").hidden = false; $("add-type").hidden = true; $("add-folder").focus(); }
  });
  $("add-type").addEventListener("click", () => { $("add-typed").hidden = false; $("add-type").hidden = true; $("add-folder").focus(); });
  $("add-ok").addEventListener("click", () => {
    const folder = $("add-folder").value.trim();
    if (folder) changeFolder("grant", folder);
  });
  $("btn-prev").addEventListener("click", () => turnPage(-1));
  $("btn-next").addEventListener("click", () => turnPage(1));
  $("btn-open").addEventListener("click", openOriginal);
  $("btn-close").addEventListener("click", closePanel);
  $("hit-prev").addEventListener("click", () => stepHit(-1));
  $("hit-next").addEventListener("click", () => stepHit(1));
  bindM5();
  bindOverview();
  bindM7();
  bindSettings();
  bindProjectMenu();
  bindPanel();
  document.addEventListener("keydown", (e) => {
    if (document.querySelector("dialog[open]")) return;
    if (e.key === "Escape" && !$("model-pop").hidden) {
      closeModelPop();
      $("btn-model").focus();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
      e.preventDefault();
      focusSearch();
      return;
    }
    if (e.key === "Escape" && !$("page-panel").hidden && !e.target.closest(".menu")) {
      e.preventDefault();
      closePanel();
      return;
    }
    if (e.target.closest("input, select, textarea, .menu, [role=tab]")) return;
    if (e.key === "ArrowLeft") turnPage(-1);
    if (e.key === "ArrowRight") turnPage(1);
    if ((e.key === "ArrowDown" || e.key === "ArrowUp") && state.tab === "search" && state.order.length) {
      e.preventDefault();
      stepHit(e.key === "ArrowDown" ? 1 : -1);
      const row = activeRow();
      if (row) row.focus({ preventScroll: true });
    }
  });
}

// The product name comes from the program (daengs.PRODUCT, D-023), not from this page.
async function showProduct() {
  state.product = (await api("GET", "/api/status")).product;
  document.title = state.product;
  for (const node of document.querySelectorAll(".product")) node.textContent = state.product;
}

async function start() {
  bind();
  try {
    state.token = await obtainToken();
    await loadPreferences();
    await showProduct();
    await detectLlm();
    await loadProjects();
    await startUpdates();
  } catch (error) {
    showStatus(error.message || "Das Programm ist nicht erreichbar.", "err");
  }
}

// Scripts that drive the window (probe run, screenshots) wait for this before they act;
// otherwise the page's own start could open another project in between (M8).
window.daengsReady = start();
