// Pure UI rules without DOM access; loaded before app.js and tested with Node (tests/ui/).
"use strict";

// Terms shorter than this are only marked as whole words: "ins" not in "Instandsetzung" (M8).
const WHOLE_WORD_BELOW = 4;
const WORD_CHAR = /[\p{L}\p{N}]/u;

function isWordChar(ch) {
  return ch !== undefined && ch !== "" && WORD_CHAR.test(ch);
}

// [start, end) ranges of the terms in text, left to right, never overlapping.
function markRanges(text, terms) {
  const lower = text.toLowerCase();
  const wanted = [...new Set(terms.map((t) => t.toLowerCase()).filter((t) => t.length >= 2))]
    .sort((a, b) => b.length - a.length);
  const ranges = [];
  let i = 0;
  while (i < text.length) {
    let best = -1, length = 0;
    for (const t of wanted) {
      let at = lower.indexOf(t, i);
      if (t.length < WHOLE_WORD_BELOW) {
        while (at >= 0 && (isWordChar(lower[at - 1]) || isWordChar(lower[at + t.length]))) {
          at = lower.indexOf(t, at + 1);
        }
      }
      if (at >= 0 && (best < 0 || at < best)) { best = at; length = t.length; }
    }
    if (best < 0) break;
    ranges.push([best, best + length]);
    i = best + length;
  }
  return ranges;
}

// Sources an answer cites, and the other checked passages (shown folded, M8).
function splitSources(entry) {
  const cited = new Set();
  for (const sentence of entry.sentences) for (const n of sentence.sources) cited.add(n);
  return {
    cited: entry.sources.filter((s) => cited.has(s.n)),
    others: entry.sources.filter((s) => !cited.has(s.n)),
  };
}

// Where a passage is: page for PDF, section for Word, sheet and cells for Excel (A-35).
function placeLabel(hit) {
  return hit.place || `Seite ${hit.page_no}`;
}

// -- design system (14 §5) --------------------------------------------------------------------------

const NOTE_SYMBOLS = { info: "info", ok: "check", warn: "warn", err: "warn" };

// Mark of a file state: signal colour and symbol, next to its text.
const STATE_LOOKS = {
  eingelesen: { kind: "ok", symbol: "check" },
  laeuft: { kind: "info", symbol: "spinner", spin: true },
  wartet: { kind: "", symbol: "clock" },
  texterkennung: { kind: "info", symbol: "spinner", spin: true },
  neu: { kind: "warn", symbol: "plus" },
  geaendert: { kind: "warn", symbol: "refresh" },
  nicht_lesbar: { kind: "err", symbol: "warn" },
  nicht_erreichbar: { kind: "err", symbol: "warn" },
};

function stateLook(state) {
  return STATE_LOOKS[state] || { kind: "", symbol: "file" };
}

// Next item of a menu for a key, or null when the key does not move it.
function menuStep(index, key, length) {
  if (key === "ArrowDown") return (index + 1) % length;
  if (key === "ArrowUp") return (index - 1 + length) % length;
  if (key === "Home") return 0;
  if (key === "End") return length - 1;
  return null;
}

// -- hits as file cards (14 §4.3, D-039) -------------------------------------------------------------

const KIND_SYMBOLS = { pdf: "pdf", word: "word", excel: "table" };
const KIND_LABELS = { alle: "Alle", pdf: "PDF", word: "Word", excel: "Excel" };

function fileKind(relPath) {
  const name = relPath.toLowerCase();
  if (name.endsWith(".pdf")) return "pdf";
  if (name.endsWith(".docx")) return "word";
  if (name.endsWith(".xlsx")) return "excel";
  return "";
}

function kindCounts(hits) {
  const counts = { alle: hits.length, pdf: 0, word: 0, excel: 0 };
  for (const hit of hits) {
    const kind = fileKind(hit.rel_path);
    if (kind) counts[kind] += 1;
  }
  return counts;
}

// Hits come ranked; a file stands where its best passage stands, so the best passage stays on top.
function groupHits(hits, filter = "alle") {
  const groups = new Map();
  hits.forEach((hit, index) => {
    const kind = fileKind(hit.rel_path);
    if (filter !== "alle" && kind !== filter) return;
    if (!groups.has(hit.file_id)) groups.set(hit.file_id, { fileId: hit.file_id, path: hit.rel_path, kind, hits: [] });
    groups.get(hit.file_id).hits.push({ hit, index });
  });
  return [...groups.values()];
}

// The order on screen, as indexes into the hit list.
function hitOrder(groups) {
  return groups.flatMap((group) => group.hits.map((entry) => entry.index));
}

// The next passage for a step of +1 or -1; goes round, starts at an end when none is chosen.
function stepOrder(order, active, delta) {
  if (!order.length) return null;
  const at = order.indexOf(active);
  if (at < 0) return delta > 0 ? order[0] : order[order.length - 1];
  return order[(at + delta + order.length) % order.length];
}

function hitPosition(order, active) {
  const at = order.indexOf(active);
  return at < 0 ? null : { position: at + 1, total: order.length };
}

// Strip of a PDF: one bar per page, or per stretch of pages when the document is long.
function docMap(pages, hitPages, bars = 40) {
  if (!pages || pages < 2) return [];
  const count = Math.min(pages, bars);
  const map = Array.from({ length: count }, () => false);
  for (const page of hitPages) {
    if (page >= 1 && page <= pages) map[Math.floor(((page - 1) * count) / pages)] = true;
  }
  return map;
}

// Rows of a table passage that contain a search word, each cell with its column's name. The first
// row of the block is the sheet's header (ingest repeats it), so it names the columns.
function matchedCells(cells, terms, maxRows = 3) {
  if (!cells || !cells.length) return [];
  const names = new Map(cells[0][1]);
  const rows = [];
  for (const [row, values] of cells.slice(1)) {
    if (!values.some(([, value]) => markRanges(value, terms).length)) continue;
    rows.push({ row, cells: values.map(([column, value]) => ({ name: names.get(column) || column, value })) });
    if (rows.length === maxRows) break;
  }
  return rows;
}

// -- how complete the search is: nothing is left unsaid (14 §2, rule 4) -------------------------------

const OPEN_REASONS = [
  ["nicht_durchsucht", "Diese Dateiart wird nicht durchsucht"],
  ["texterkennung", "Scan, Texterkennung läuft noch"],
  ["laeuft", "Wird gerade eingelesen"],
  ["wartet", "Wartet auf das Einlesen"],
  ["neu", "Neu, noch nicht eingelesen"],
  ["geaendert", "Geändert, noch nicht neu eingelesen"],
  ["nicht_lesbar", "Nicht lesbar"],
  ["nicht_erreichbar", "Ordner nicht erreichbar"],
];

function coverage(listing, ingest) {
  if (!listing) return null;
  const files = listing.files.filter((f) => f.state !== "entfernt");
  const name = (f) => f.rel_path.split("/").pop();
  const missing = [];
  for (const [state, reason] of OPEN_REASONS) {
    const names = files.filter((f) => f.state === state).map(name);
    if (names.length) missing.push({ state, reason, names });
  }
  const notes = [];
  if (listing.unreachable && listing.unreachable.length) notes.push(listing.unreachable.length === 1 ? "Ein Lieferordner ist gerade nicht erreichbar." : `${listing.unreachable.length} Lieferordner sind gerade nicht erreichbar.`);
  if (listing.truncated) notes.push("Die Dateiliste ist gekürzt, es gibt mehr Dateien.");
  if (ingest && ingest.vectors_pending) notes.push(`Der Suchindex ist noch nicht fertig (${ingest.vectors_pending} ${ingest.vectors_pending === 1 ? "Abschnitt" : "Abschnitte"} offen); die Suche findet noch nicht alles.`);
  const searched = files.filter((f) => f.state === "eingelesen").length;
  return { total: files.length, searched, open: files.length - searched, missing, notes };
}

// The search marks passages without a safe sign of a match (D-040); it leaves nothing out.
function weakCount(hits) {
  return hits.filter((h) => h.sure === false).length;
}

function onlyWeak(hits) {
  return hits.length > 0 && weakCount(hits) === hits.length;
}

// "6 Fundstellen in 3 Dateien"; the search returns at most ``limit``, and says so when it is reached.
function hitsLine(hits, limit) {
  if (!hits.length) return "Keine Fundstellen";
  if (onlyWeak(hits)) return "Keine sichere Fundstelle";
  const weak = weakCount(hits);
  const fileCount = new Set(hits.map((h) => h.file_id)).size;
  const passages = hits.length === 1 ? "1 Fundstelle" : `${hits.length} Fundstellen`;
  const start = hits.length >= limit ? `Die besten ${hits.length} Fundstellen` : passages;
  return `${start} in ${fileCount === 1 ? "1 Datei" : `${fileCount} Dateien`}${weak ? `, davon ${weak} unsicher` : ""}`;
}

function coverLine(cover) {
  return cover ? `${cover.searched} von ${cover.total} ${cover.total === 1 ? "Datei" : "Dateien"} durchsucht` : "Dateistand wird geprüft";
}

// A few names of a group of files, the rest as a number.
function namesLine(names, shown = 3) {
  const first = names.slice(0, shown).join(", ");
  return names.length > shown ? `${first} und ${names.length - shown} weitere` : first;
}

// Width of the page view for a width of the window's main area; same numbers as .layout.page-open.
function panelWidth(layoutWidth) {
  return Math.round(Math.min(720, Math.max(600, layoutWidth * 0.5)));
}

// -- chat (M9a, A-38): what the answer card shows while the answer comes about --------------------

const STEP_TEXT = {
  suche: ["Sucht in den Unterlagen …", "Gesucht"],
  stellen: ["Übernimmt die Fundstellen …", "Fundstellen übernommen"],
  lesen: ["Liest die Stellen …", "Stellen gelesen"],
  schreiben: ["Schreibt die Antwort …", "Antwort geschrieben"],
  pruefen: ["Prüft Zahlen und Belege …", "Zahlen und Belege geprüft"],
};

function chatView() {
  return { steps: [], progress: null, sources: [], missing: [], text: "", entry: null, error: "" };
}

function closeStep(view, now) {
  const running = view.steps.find((s) => !s.done);
  if (running) {
    running.done = true;
    running.seconds = Math.max(0, (now - running.start) / 1000);
  }
}

// One server event into the view; ``now`` in milliseconds, so the step times can be shown.
function applyEvent(view, event, now) {
  if (event.type === "step") {
    closeStep(view, now);
    view.steps.push({ step: event.step, start: now, done: false, detail: "", query: event.query });
    if (event.step === "lesen") view.progress = null;
  } else if (event.type === "sources") {
    view.sources = event.sources;
    view.missing = event.missing_terms || [];
    const search = [...view.steps].reverse().find((s) => s.step === "suche" || s.step === "stellen");
    if (search && event.new !== undefined) {
      // The further search when the first passages did not answer the question (M9c).
      const found = event.new === 0 ? "nichts Neues" : event.new === 1 ? "1 weitere Stelle" : `${event.new} weitere Stellen`;
      search.detail = `Mit anderen Wörtern gesucht („${search.query}“): ${found}`;
    } else if (search) {
      const n = event.sources.length;
      search.detail = search.step === "stellen" ? (n === 1 ? "1 Fundstelle übernommen" : `${n} Fundstellen übernommen`) : n === 1 ? "1 Stelle gefunden" : `${n} Stellen gefunden`;
    }
  } else if (event.type === "progress") {
    view.progress = { done: event.done, total: event.total };
  } else if (event.type === "reset") {
    view.text = "";
  } else if (event.type === "delta") {
    view.text += event.text;
  } else if (event.type === "done") {
    closeStep(view, now);
    view.entry = event.entry;
  } else if (event.type === "wiki_suggestion") {
    view.suggestion = event.suggestion;
  } else if (event.type === "error") {
    closeStep(view, now);
    view.error = event.fehler || "Fehler";
  }
  return view;
}

function stepLabel(step) {
  const [running, done] = STEP_TEXT[step.step] || [step.step, step.step];
  if (!step.done && step.query !== undefined) {
    return step.query ? `Sucht mit anderen Wörtern: „${step.query}“ …` : "In den Stellen steht nichts dazu. Sucht mit anderen Wörtern …";
  }
  if (!step.done) return running;
  if (step.query === "") return "Andere Suchwörter überlegt";
  const seconds = step.seconds >= 0.1 ? ` (${step.seconds.toFixed(1).replace(".", ",")} s)` : "";
  return `${step.detail || done}${seconds}`;
}

// Share of the reading done, 0..1; null while unknown.
function readShare(view) {
  if (!view.progress || !view.progress.total) return null;
  return Math.min(1, view.progress.done / view.progress.total);
}

// Live text from a position on: text and [n] apart; a number still coming in waits for its bracket.
function liveParts(text, from = 0) {
  const rest = text.slice(from);
  const open = /\[\d{0,3}$/.exec(rest);
  const upto = open ? text.length - open[0].length : text.length;
  const parts = [];
  const pattern = /\[(\d{1,3})\]/g;
  const body = text.slice(from, upto);
  let at = 0;
  let match;
  while ((match = pattern.exec(body))) {
    if (match.index > at) parts.push({ text: body.slice(at, match.index) });
    parts.push({ n: Number(match[1]) });
    at = match.index + match[0].length;
  }
  if (at < body.length) parts.push({ text: body.slice(at) });
  return { parts, upto };
}

// What the check found, as one line; empty when all is fine (M7).
function checkWarnings(entry) {
  const c = entry.checks;
  const warnings = [];
  if (c.unbelegte_zahlen) warnings.push(c.unbelegte_zahlen === 1 ? "1 Zahl steht so nicht in der Quelle" : `${c.unbelegte_zahlen} Zahlen stehen so nicht in der Quelle`);
  if (c.saetze_ohne_beleg && entry.sources.length) warnings.push(c.saetze_ohne_beleg === 1 ? "1 Satz ohne Beleg" : `${c.saetze_ohne_beleg} Sätze ohne Beleg`);
  if (c.ungueltige_belege) warnings.push(c.ungueltige_belege === 1 ? "1 ungültige Quellennummer" : `${c.ungueltige_belege} ungültige Quellennummern`);
  return warnings;
}

const MODEL_NAMES = { "qwen3.5-4b-q4_k_m": "Qwen3.5 4B" };

function modelName(modelId) {
  return MODEL_NAMES[modelId] || modelId || "";
}

// Plain text to copy: answer with its sources as a list (for Word, mail, notes).
function copyText(entry) {
  const lines = [entry.answer.trim(), "", `${entry.label}`];
  if (entry.sources.length) {
    lines.push("", "Quellen:");
    for (const s of entry.sources) lines.push(`[${s.n}] ${s.rel_path}, ${placeLabel(s)}`);
  }
  return lines.join("\n");
}

// Server-sent events from a growing text buffer: complete events and the rest still to come.
function parseEvents(buffer) {
  const events = [];
  let at;
  while ((at = buffer.indexOf("\n\n")) >= 0) {
    const block = buffer.slice(0, at);
    buffer = buffer.slice(at + 2);
    for (const line of block.split("\n")) {
      if (line.startsWith("data:")) events.push(JSON.parse(line.slice(5)));
    }
  }
  return { events, rest: buffer };
}

// -- answer from the hits on screen (D-055) ---------------------------------------------------------

const ANSWER_HITS = 4; // passages for the model, like settings.sources of the service

// The passages the answer is made from: by rank (not in the order of the file cards), only those
// of the active file kind, only sure ones, the first ``limit``. The service checks them again.
function answerHits(hits, filter = "alle", limit = ANSWER_HITS) {
  const chosen = hits
    .filter((hit) => hit.sure !== false && (filter === "alle" || fileKind(hit.rel_path) === filter))
    .sort((a, b) => a.rank - b.rank)
    .slice(0, limit);
  return { hits: chosen, ids: chosen.map((hit) => hit.chunk_id) };
}

// The button next to the hit count: hidden without the extension, off with a reason when no sure hit.
function answerButtonState(hits, filter, hasExtension) {
  if (!hasExtension || !hits.length) return { visible: false, enabled: false, title: "" };
  if (onlyWeak(hits)) {
    return { visible: true, enabled: false, title: "Keine sicheren Treffer: Aus schwachen Stellen schreibt Daengs keinen Entwurf." };
  }
  if (!answerHits(hits, filter).ids.length) {
    return { visible: true, enabled: false, title: "In dieser Dateiart gibt es keine sicheren Treffer." };
  }
  return { visible: true, enabled: true, title: "Fasst die obersten sicheren Fundstellen zu einem Entwurf zusammen." };
}

// Body for "Antwort aus diesen Fundstellen": the question of the hits on screen, not what stands in
// the search field now (the user may have typed on since).
function answerRequest(shown, filter) {
  return { question: shown.question, chunk_ids: answerHits(shown.hits, filter).ids };
}

// A new search while an answer is running: stop it, wait until it has ended and stored what was
// written, and only then clear the block (D-056).
async function stopThenClear({ running, stop, finished, clear }) {
  if (running) {
    await stop();
    await finished;
  }
  clear();
}

// -- layout c4 (D-064): three columns, the panel beside the middle, never over it -------------------

const SIDE_FULL = 240; // sidebar with names
const SIDE_RAIL = 56; // sidebar as a bar of symbols
const CENTER_MIN = 600; // below this the sidebar folds to symbols when the panel is open
const CENTER_FLOOR = 320; // the middle never gets narrower; the panel gives way instead
const PANEL_MIN = 380;
const PANEL_MAX = 640;

// Widths of the three columns for a window width. The panel always stands next to the middle and
// makes it narrower; when both do not fit, the sidebar folds to its bar of symbols first.
function layoutFor(width, panelOpen, sideWanted = true) {
  const panel = panelOpen ? Math.round(Math.min(PANEL_MAX, Math.max(PANEL_MIN, width * 0.36))) : 0;
  const side = sideWanted && width - SIDE_FULL - panel >= CENTER_MIN ? "full" : "rail";
  const sideWidth = side === "full" ? SIDE_FULL : SIDE_RAIL;
  const shown = panelOpen ? Math.max(0, Math.min(panel, width - sideWidth - CENTER_FLOOR)) : 0;
  return { side, panel: shown, center: Math.max(0, width - sideWidth - shown), forced: sideWanted && side === "rail" };
}

// -- middle column c6 view 1 (D-064): cards for the best passages, the full list on request ------------

const CARDS = 5;

// Which hits stand as cards: the best by rank in the active file kind, and every passage the answer
// read, so that each number in the text has its card. Shown in the order of rank.
function topCards(hits, filter = "alle", sourceIds = [], count = CARDS) {
  const shown = hits
    .map((hit, index) => ({ hit, index }))
    .filter(({ hit }) => filter === "alle" || fileKind(hit.rel_path) === filter)
    .sort((a, b) => (a.hit.rank ?? a.index) - (b.hit.rank ?? b.index));
  const wanted = new Set(sourceIds);
  const read = shown.filter(({ hit }) => wanted.has(hit.chunk_id));
  const rest = shown.filter(({ hit }) => !wanted.has(hit.chunk_id)).slice(0, Math.max(0, count - read.length));
  const chosen = new Set([...read, ...rest].map(({ index }) => index));
  return shown.filter(({ index }) => chosen.has(index)).map(({ index }) => index);
}

// Number of a passage in the answer, by chunk id: the same number in the text and at the card.
function sourceNumbers(sources) {
  const numbers = {};
  for (const s of sources || []) if (s.chunk_id !== undefined && s.chunk_id !== null) numbers[s.chunk_id] = s.n;
  return numbers;
}

// Head line of the passages of a search: "20 Stellen in 3 Dateien" and what is left to say.
function surfaceLine(hits) {
  if (!hits.length) return { strong: "Keine Fundstellen", rest: "" };
  const files = new Set(hits.map((h) => h.file_id)).size;
  const inFiles = files === 1 ? "1 Datei" : `${files} Dateien`;
  const weak = weakCount(hits);
  if (weak === hits.length) {
    return { strong: "Keine sicheren Treffer.", rest: `${hits.length === 1 ? "1 ähnliche Stelle" : `${hits.length} ähnliche Stellen`} in ${inFiles}, ${hits.length === 1 ? "unsicher" : "alle unsicher"}` };
  }
  return { strong: `${hits.length === 1 ? "1 Stelle" : `${hits.length} Stellen`} in ${inFiles}`, rest: weak ? `${weak} unsicher` : "" };
}

// Heading of the passages a follow-up read (D-064, Weg A): not the hit list of a search.
function readHeading(count) {
  return `Gelesene Stellen (${count})`;
}

// Status line under the input: how much is searched, short.
function coverShort(cover) {
  if (!cover) return "Dateistand wird geprüft";
  const parts = [coverLine(cover)];
  const unsearchable = cover.missing.filter((m) => m.state === "nicht_durchsucht").reduce((n, m) => n + m.names.length, 0);
  const other = cover.open - unsearchable;
  if (unsearchable) parts.push(`${unsearchable} nicht durchsuchbar`);
  if (other > 0) parts.push(`${other} offen`);
  return parts.join(" · ");
}

// -- input card c5 A (D-064): one field for search and follow-up, commands with "/" -------------------

// Only functions that exist already (D-064 (6)); "when" names what must be there.
const COMMANDS = [
  { name: "neu", label: "Neue Suche", hint: "Bezug lösen, die nächste Eingabe sucht neu", when: "always" },
  { name: "antwort", label: "Antwort aus diesen Fundstellen", hint: "Entwurf aus den obersten sicheren Fundstellen", when: "answer" },
  { name: "alle", label: "Dateiart: Alle", hint: "Alle Fundstellen zeigen", when: "hits" },
  { name: "pdf", label: "Dateiart: PDF", hint: "Nur Fundstellen in PDF-Dateien", when: "hits" },
  { name: "word", label: "Dateiart: Word", hint: "Nur Fundstellen in Word-Dateien", when: "hits" },
  { name: "excel", label: "Dateiart: Excel", hint: "Nur Fundstellen in Excel-Dateien", when: "hits" },
  { name: "wiki", label: "Ins Wiki übernehmen …", hint: "Vorschlag aus der letzten Antwort", when: "entry" },
];

// The commands that can be used now: ``can`` says what is there ({ answer, hits, entry }).
function availableCommands(can) {
  return COMMANDS.filter((c) => c.when === "always" || can[c.when]);
}

// "/pd" -> the commands starting with "pd"; null when the text is not a command being typed.
function matchCommands(text, can) {
  const m = /^\/(\S*)$/.exec(text.trim());
  if (!m) return null;
  const typed = m[1].toLowerCase();
  return availableCommands(can).filter((c) => c.name.startsWith(typed));
}

// A sent text that is a command: its name; else null (then it is a question).
function parseCommand(text, can) {
  const m = /^\/(\S+)\s*$/.exec(text.trim());
  if (!m) return null;
  const found = availableCommands(can).find((c) => c.name === m[1].toLowerCase());
  return found ? found.name : null;
}

// What the next input does: a follow-up while a reference to an answer stands, else a new search.
function inputMode(reference, hasExtension) {
  return hasExtension && reference ? "follow" : "search";
}

// -- reading made visible (D-065) ------------------------------------------------------------------

const BUSY = ["wartet", "laeuft"];
const fileWord = (n) => (n === 1 ? "Datei" : "Dateien");
const pageWord = (n) => (n === 1 ? "Seite" : "Seiten");
const de = (n) => n.toLocaleString("de-DE");

// What the reading of the open project means for the screen. "erst": the first reading, the input
// is locked; "ordner": the first reading cannot go on, a folder is away (no endless animation);
// "lesen" and "ocr": later reading, the input stays free; "ruhe": nothing runs.
function ingestView(s, projectName = "", product = "") {
  if (!s) return { mode: "ruhe", locked: false, running: false };
  const busy = BUSY.includes(s.job);
  const total = s.files_total || 0;
  const done = Math.min(s.files_done || 0, total);
  const counted = total ? `${de(done)} von ${de(total)} ${fileWord(total)}` : "";
  const fileName = s.current ? s.current.split("/").pop() : "";
  const base = { total, done, fraction: total ? done / total : 0, fileName, projectName, failed: s.failed_files || 0 };
  if (s.first === "laeuft") {
    if (s.phase === "ordner_fehlt") {
      const folders = s.unreachable || [];
      return {
        ...base, mode: "ordner", locked: true, running: false, folders,
        title: `${projectName} kann nicht weiter eingelesen werden`,
        line: folders.length === 1 ? "Der Ordner mit der Lieferung ist nicht erreichbar:" : "Diese Ordner der Lieferung sind nicht erreichbar:",
        note: "Schließ das Laufwerk an oder stell die Verbindung her. Sobald der Ordner wieder da ist, geht das Einlesen von selbst weiter.",
        status: "Einlesen angehalten · Ordner nicht erreichbar",
        live: "Einlesen angehalten. Der Ordner der Lieferung ist nicht erreichbar.",
      };
    }
    const waiting = s.job === "wartet" && s.ahead;
    const line = waiting ? `Wartet, bis ${s.ahead} eingelesen ist` : counted ? `Wird eingelesen … ${counted}` : "Wird eingelesen …";
    return {
      ...base, mode: "erst", locked: true, running: true, waiting: Boolean(waiting),
      title: `${projectName} wird eingelesen`,
      line,
      note: `Das Einlesen läuft im Hintergrund weiter, solange ${product || "das Programm"} geöffnet ist.`,
      status: waiting ? `Wartet auf ${s.ahead}` : counted ? `Wird eingelesen · ${counted}` : "Wird eingelesen",
      live: waiting ? line : counted ? `Wird eingelesen, ${counted}` : "Wird eingelesen",
    };
  }
  if (busy && s.phase === "texterkennung") {
    const open = s.ocr_pending || 0;
    const text = open ? `Texterkennung · noch ${de(open)} ${pageWord(open)}` : "Texterkennung";
    return { ...base, mode: "ocr", locked: false, running: true, status: `${text} · Suche bleibt nutzbar`, live: `${text}. Die Suche bleibt nutzbar.` };
  }
  if (busy) {
    const what = s.job === "wartet" && s.ahead ? `Wartet auf ${s.ahead}` : counted ? `Wird eingelesen · ${counted}` : "Wird eingelesen";
    return { ...base, mode: "lesen", locked: false, running: true, status: `${what} · du kannst weitersuchen`, live: `${what}. Du kannst weitersuchen.` };
  }
  return { ...base, mode: "ruhe", locked: false, running: false };
}

// Remaining time from how fast the open embeddings go down (samples: {t: ms, left: count}).
// Says nothing until it has watched for a while; rounds, so the number does not jump about.
const ETA_WINDOW_MS = 60000;
const ETA_MIN_SPAN_MS = 8000;

function etaText(samples, now) {
  const recent = samples.filter((x) => now - x.t <= ETA_WINDOW_MS);
  if (recent.length < 2) return "Restzeit wird geschätzt …";
  const first = recent[0];
  const last = recent[recent.length - 1];
  const span = last.t - first.t;
  const gone = first.left - last.left;
  if (span < ETA_MIN_SPAN_MS || gone <= 0) return "Restzeit wird geschätzt …";
  if (last.left <= 0) return "gleich fertig";
  const seconds = (last.left / gone) * (span / 1000);
  if (seconds < 45) return "gleich fertig";
  const minutes = Math.max(1, Math.round(seconds / 60));
  if (minutes >= 90) return `noch etwa ${Math.round(minutes / 60)} Stunden`;
  return minutes === 1 ? "noch etwa 1 Minute" : `noch etwa ${minutes} Minuten`;
}

// Keeps a series of {t, left}: drops old ones and starts over when the count goes up (a new run).
function etaSample(samples, now, left) {
  if (left === null || left === undefined) return [];
  const last = samples[samples.length - 1];
  const kept = last && left > last.left ? [] : samples.filter((x) => now - x.t <= ETA_WINDOW_MS);
  return [...kept, { t: now, left }];
}

// The live region reads the progress at most every LIVE_EVERY_MS; a change of kind at once.
const LIVE_EVERY_MS = 10000;

function liveDue(last, now, text, kind) {
  if (!text || (last && last.text === text)) return false;
  return !last || last.kind !== kind || now - last.t >= LIVE_EVERY_MS;
}

// Files of the reading for the activity tab: the one in work, the waiting ones, OCR, unreadable;
// the read ones only as a number. At most ``limit`` rows.
const ACTIVITY_ORDER = ["laeuft", "texterkennung", "wartet", "nicht_lesbar"];

function activityRows(listing, limit = 12) {
  if (!listing) return { rows: [], more: 0, read: 0 };
  const files = listing.files.filter((f) => f.state !== "entfernt");
  const rows = ACTIVITY_ORDER.flatMap((state) => files.filter((f) => f.state === state));
  return { rows: rows.slice(0, limit), more: Math.max(0, rows.length - limit), read: files.filter((f) => f.state === "eingelesen").length };
}

// Nacharbeit 3c (c): while files are read later, the completeness above the passages is one line
// that points to the activity instead of a list of reasons (also in the hint bar, status line).
function coverNote(cover, view) {
  if (!cover || !view || !view.running || view.locked) return "";
  // Files that are never searched (drawings) do not wait for the reading.
  const never = cover.missing.filter((m) => m.state === "nicht_durchsucht").reduce((n, m) => n + m.names.length, 0);
  const open = cover.open - never;
  if (open <= 0) return "";
  return `${open} ${open === 1 ? "Datei ist" : "Dateien sind"} noch nicht durchsucht, das Einlesen läuft.`;
}

// -- overview table (D-070, D-071): components x chapters ------------------------------------------

const CELL_STATUS = ["offen", "ok", "rueckfrage", "nicht_relevant"];
const STATUS_LABELS = { offen: "offen", ok: "ok", rueckfrage: "Rückfrage", nicht_relevant: "nicht relevant" };
const STATUS_SYMBOLS = { ok: "check", rueckfrage: "help", nicht_relevant: "ban" };
const STATUS_KEYS = { o: "ok", r: "rueckfrage", n: "nicht_relevant" };

// O, R, N set a status; the same key again sets the cell back to "offen" (c8c).
function statusFromKey(key, current) {
  const wanted = STATUS_KEYS[String(key || "").toLowerCase()];
  if (!wanted) return null;
  return current === wanted ? "offen" : wanted;
}

// Short codes for the files of a project, shown in the cells: the words a name does not share
// with all the others, their first letters ("VM320_Betriebsanleitung" -> "BE"), unique.
function fileCodes(names) {
  const stems = names.map((n) => n.split("/").pop().replace(/\.[^.]+$/, ""));
  const tokens = stems.map((s) => s.split(/[\s_\-.]+/).filter(Boolean));
  const shared = names.length > 1 ? tokens[0].filter((t) => tokens.every((ts) => ts.includes(t))) : [];
  const used = new Set();
  return tokens.map((ts, i) => {
    const own = ts.filter((t) => !shared.includes(t));
    const words = (own.length ? own : ts).filter((t) => /\p{L}/u.test(t));
    let code = words.length >= 2 ? words[0][0] + words[1][0] : (words[0] || stems[i]).slice(0, 2);
    code = code.toUpperCase();
    let unique = code;
    for (let k = 2; used.has(unique); k++) unique = `${code}${k}`;
    used.add(unique);
    return unique;
  });
}

const EMPTY_FILTER = { open: false, ask: false, hint: false, kind: "alle", lang: "alle" };

const filterActive = (f) => Boolean(f && (f.open || f.ask || f.hint || f.kind !== "alle" || f.lang !== "alle"));

// What one cell shows under a filter: the direct passages of the chosen file kind and language,
// as a number and file codes; whether it matches the status and hint filters.
function cellView(cell, files, filter = EMPTY_FILTER, codes = []) {
  const c = cell || {};
  const f = filter || EMPTY_FILTER;
  const direct = (c.d || []).filter(([fi, , lang]) => {
    const file = files[fi];
    if (!file) return false;
    if (f.kind !== "alle" && fileKind(file.rel_path) !== f.kind) return false;
    return f.lang === "alle" || (lang || "") === f.lang;
  });
  const fileIdx = [...new Set(direct.map(([fi]) => fi))];
  const status = c.st || "offen";
  const statusWanted = f.open || f.ask;
  const statusOk = !statusWanted || (f.open && status === "offen") || (f.ask && status === "rueckfrage");
  const hint = c.h || 0;
  const count = new Set(direct.map(([fi, p]) => `${fi}/${p}`)).size;
  return {
    count,
    files: fileIdx.map((fi) => ({ code: codes[fi] || "", name: files[fi].rel_path.split("/").pop() })),
    status,
    note: c.n || "",
    hint,
    // The hint mark stands only where there is no direct passage: there it says "look here".
    hintMark: count === 0 && hint > 0,
    lost: c.lost || 0,
    wait: Boolean(c.wait),
    match: statusOk && (!f.hint || (count === 0 && hint > 0)),
  };
}

// Words for a screen reader: the empty cell always says "keine direkte Fundstelle" (D-069 (2)).
function cellLabel(component, chapter, view) {
  const parts = [`${component}, ${chapter}`];
  if (view.wait) parts.push("wird noch gesucht");
  else if (view.count) parts.push(`${view.count} ${view.count === 1 ? "direkte Fundstelle" : "direkte Fundstellen"} in ${view.files.map((f) => f.name).join(", ")}`);
  else parts.push("keine direkte Fundstelle");
  if (view.hint) parts.push(view.hint === 1 ? "1 Hinweis, nicht bestätigt" : `${view.hint} Hinweise, nicht bestätigt`);
  parts.push(`Status ${STATUS_LABELS[view.status] || view.status}`);
  if (view.note) parts.push("mit Notiz");
  if (view.lost) parts.push(view.lost === 1 ? "1 Stelle nicht mehr gefunden" : `${view.lost} Stellen nicht mehr gefunden`);
  return parts.join(", ");
}

// Counts for the head: requests to the customer, open cells (not relevant does not count as open).
function tableCounts(data) {
  const counts = { offen: 0, ok: 0, rueckfrage: 0, nicht_relevant: 0, cells: 0 };
  const shownRows = (data.components || []).filter((c) => !c.hidden);
  const shownCols = (data.chapters || []).filter((c) => c.visible);
  for (const comp of shownRows) {
    for (const ch of shownCols) {
      const st = ((data.cells || {})[`${comp.key}|${ch.key}`] || {}).st || "offen";
      counts[st] = (counts[st] || 0) + 1;
      counts.cells += 1;
    }
  }
  // Requests are listed whatever is shown: a hidden column keeps its request.
  counts.requests = Object.values(data.cells || {}).filter((c) => c.st === "rueckfrage").length;
  return counts;
}

// Short text for the chip of an active filter.
function filterChip(f) {
  if (!filterActive(f)) return "";
  const parts = [];
  if (f.open) parts.push("Nur offene");
  if (f.ask) parts.push("Nur Rückfragen");
  if (f.hint) parts.push("Nur mit Hinweis");
  if (f.kind !== "alle") parts.push(KIND_LABELS[f.kind] || f.kind);
  if (f.lang !== "alle") parts.push(f.lang.toUpperCase());
  return parts.length === 1 ? parts[0] : `${parts.length} Filter`;
}

// Arrow keys, Home/End and page keys in the grid; null for other keys.
function gridMove(r, c, key, rows, cols) {
  if (!rows || !cols) return null;
  const at = { ArrowDown: [r + 1, c], ArrowUp: [r - 1, c], ArrowRight: [r, c + 1], ArrowLeft: [r, c - 1], Home: [r, 0], End: [r, cols - 1], PageDown: [r + 5, c], PageUp: [r - 5, c] }[key];
  if (!at) return null;
  return { r: Math.max(0, Math.min(rows - 1, at[0])), c: Math.max(0, Math.min(cols - 1, at[1])) };
}

// The request list as plain text for the customer (copied by the user, never sent by Daengs).
function questionsText(items) {
  const lines = ["Zu folgenden Punkten fehlen uns Informationen:", ""];
  items.forEach((q, i) => {
    const text = (q.note || "").trim() || "Bitte Unterlagen nachreichen.";
    lines.push(`${i + 1}. ${q.component_name} (${q.chapter_name}): ${text}`);
  });
  return `${lines.join("\n")}\n`;
}

// Time a table of ``cells`` needs: measured milliseconds per cell of this project, else a guess
// from its size (Messung AP-9.30: about 50 ms per cell at 100 passages, 75 at 1,700, two searches).
const TABLE_ESTIMATE_FROM = 50; // components from which the time is shown before building

function tableEstimate(cells, msPerCell, chunks = 0) {
  const ms = msPerCell || 40 + chunks * 0.02;
  return Math.round((cells * ms) / 1000);
}

function estimateText(seconds) {
  if (seconds < 20) return "wenige Sekunden";
  if (seconds < 90) return `etwa ${Math.round(seconds / 10) * 10} Sekunden`;
  const minutes = Math.round(seconds / 60);
  return minutes === 1 ? "etwa 1 Minute" : `etwa ${minutes} Minuten`;
}

// Progress of the table in one place: what still runs, or nothing.
function tableProgress(computing) {
  if (!computing) return "";
  if (computing.first === "laeuft") return "Die Tabelle entsteht, sobald das Einlesen fertig ist.";
  if (!computing.pending) return "";
  if (computing.state === "laeuft" && computing.of) return `Wird aktualisiert · ${computing.done} von ${computing.of}`;
  return "Wird aktualisiert …";
}

// Animations run only while the window can be seen and has the focus (Nacharbeit 3c (a)).
function animationActive(visible, focused) {
  return Boolean(visible && focused);
}

if (typeof module !== "undefined") {
  module.exports = {
    markRanges, splitSources, placeLabel, WHOLE_WORD_BELOW,
    chatView, applyEvent, stepLabel, readShare, copyText, parseEvents,
    NOTE_SYMBOLS, stateLook, menuStep,
    KIND_SYMBOLS, KIND_LABELS, fileKind, kindCounts, groupHits, hitOrder, stepOrder, hitPosition, docMap, matchedCells,
    liveParts, checkWarnings, modelName,
    coverage, weakCount, onlyWeak, hitsLine, coverLine, namesLine, panelWidth,
    ANSWER_HITS, answerHits, answerButtonState, answerRequest, stopThenClear,
    SIDE_FULL, SIDE_RAIL, CENTER_MIN, CENTER_FLOOR, PANEL_MIN, PANEL_MAX, layoutFor,
    CARDS, topCards, sourceNumbers, surfaceLine, readHeading, coverShort,
    COMMANDS, availableCommands, matchCommands, parseCommand, inputMode,
    ingestView, etaText, etaSample, liveDue, LIVE_EVERY_MS, activityRows,
    CELL_STATUS, STATUS_LABELS, STATUS_SYMBOLS, statusFromKey, fileCodes, EMPTY_FILTER, filterActive, cellView, cellLabel,
    tableCounts, filterChip, gridMove, questionsText, coverNote, TABLE_ESTIMATE_FROM, tableEstimate, estimateText, tableProgress, animationActive,
  };
}
