"""UI: web interface shown in the pywebview window (D-012). Files only; no Python logic."""

from pathlib import Path

STATIC_DIR = Path(__file__).resolve().parent / "static"
