"""Diagnostics: self-test and report without content or file names (F8)."""

from daengs.diagnostics.report import Check, as_text, report, selftest

__all__ = ["Check", "as_text", "report", "selftest"]
