"""Self-test and diagnostic report (F8, A-19): support without remote access.

The report holds no document content, no file or folder names, no project names and no paths
(a path alone can name a customer or a person). Only versions, counts, sizes and check results.
"""

import ctypes
import os
import platform
import shutil
import sqlite3
import sys
import time
import uuid
from dataclasses import asdict, dataclass
from importlib import metadata
from pathlib import Path
from typing import Any

from daengs import PRODUCT
from daengs.core import PDFIUM_LOCK, Settings

PACKAGES = ("numpy", "onnxruntime", "pillow", "pypdfium2", "pywebview", "rapidocr", "tokenizers")


@dataclass(frozen=True)
class Check:
    name: str
    ok: bool
    detail: str = ""


def _version(package: str) -> str:
    try:
        return metadata.version(package)
    except metadata.PackageNotFoundError:
        return "fehlt"


def _ram_gb() -> float | None:
    if sys.platform != "win32":
        return None

    class MemoryStatus(ctypes.Structure):
        _fields_ = [
            ("length", ctypes.c_ulong),
            ("load", ctypes.c_ulong),
            ("total", ctypes.c_ulonglong),
            ("available", ctypes.c_ulonglong),
            ("page_total", ctypes.c_ulonglong),
            ("page_available", ctypes.c_ulonglong),
            ("virtual_total", ctypes.c_ulonglong),
            ("virtual_available", ctypes.c_ulonglong),
            ("extended", ctypes.c_ulonglong),
        ]

    status = MemoryStatus(length=ctypes.sizeof(MemoryStatus))
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        return None
    return round(status.total / 2**30, 1)


def system() -> dict[str, Any]:
    from daengs import __version__

    return {
        "daengs": __version__,
        "python": platform.python_version(),
        "system": f"{platform.system()} {platform.release()} ({platform.version()})",
        "architektur": platform.machine(),
        "prozessoren": os.cpu_count(),
        "arbeitsspeicher_gb": _ram_gb(),
        "sqlite": sqlite3.sqlite_version,
        "pakete": {p: _version(p) for p in PACKAGES},
    }


def selftest(settings: Settings) -> list[Check]:
    checks = [_data_dir(settings.data_dir), _sqlite(), _pdfium()]
    models = [("Texterkennung", settings.ocr_models), ("Bedeutungssuche", settings.embedding)]
    if settings.llm is not None:  # optional extension (D-022): only checked when installed
        models.append(("Antworten (Erweiterung)", settings.llm))
    for label, model in models:
        if model is None:
            checks.append(Check(f"Modell {label}", False, "nicht eingerichtet"))
            continue
        missing = sum(not p.is_file() for p in model.files())
        size = sum(p.stat().st_size for p in model.files() if p.is_file())
        detail = f"{size / 2**20:.0f} MB" if not missing else f"{missing} Datei(en) fehlen"
        checks.append(Check(f"Modell {label}", not missing, detail))
    return checks


def _data_dir(data_dir: Path) -> Check:
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        probe = data_dir / f"_selbsttest_{uuid.uuid4().hex}"
        probe.write_bytes(b"ok")
        probe.unlink()
        free = shutil.disk_usage(data_dir).free / 2**30
        return Check("Datenort beschreibbar", True, f"{free:.1f} GB frei")
    except OSError as exc:
        return Check("Datenort beschreibbar", False, type(exc).__name__)


def _sqlite() -> Check:
    try:
        con = sqlite3.connect(":memory:")
        con.execute(
            "create virtual table probe_word using fts5(text,"
            " tokenize='unicode61 remove_diacritics 2')"
        )
        con.execute("create virtual table probe_tri using fts5(text, tokenize='trigram')")
        con.close()
        return Check("Volltext (SQLite FTS5)", True, sqlite3.sqlite_version)
    except sqlite3.Error as exc:
        return Check("Volltext (SQLite FTS5)", False, type(exc).__name__)


def _pdfium() -> Check:
    try:
        import pypdfium2 as pdfium

        with PDFIUM_LOCK:
            pdf = pdfium.PdfDocument.new()
            pdf.new_page(200, 200)
            bitmap = pdf[0].render(scale=1)
            ok = bitmap.width == 200
            bitmap.close()
            pdf.close()
        return Check("PDF lesen und anzeigen (PDFium)", ok, _version("pypdfium2"))
    except Exception as exc:  # report any failure, never stop the report
        return Check("PDF lesen und anzeigen (PDFium)", False, type(exc).__name__)


def report(settings: Settings, projects: list[dict[str, Any]]) -> dict[str, Any]:
    """``projects``: one dict of counts per project; anything that is not a number is dropped."""
    numbers = [
        {k: v for k, v in p.items() if isinstance(v, int | float) and not isinstance(v, bool)}
        for p in projects
    ]
    return {
        "erstellt": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "system": system(),
        "modelle": {
            "bedeutungssuche": settings.embedding.model_id if settings.embedding else "keins",
            "texterkennung": "PP-OCRv6 small" if settings.ocr_models else "keins",
            "antworten": settings.llm.model_id if settings.llm else "keins",
        },
        "selbsttest": [asdict(c) for c in selftest(settings)],
        "projekte": [{"nr": i + 1, **p} for i, p in enumerate(numbers)],
    }


LABELS = {
    "files": "Dateien",
    "failed_files": "nicht lesbar",
    "pages": "Seiten",
    "text_layer": "mit Textschicht",
    "ocr": "Texterkennung fertig",
    "ocr_pending": "Texterkennung offen",
    "ocr_failed": "Texterkennung fehlgeschlagen",
    "chunks": "Abschnitte",
    "vectors_pending": "Suchindex offen",
    "folders": "Ordner",
    "bytes": "Größe in Bytes",
    "wiki_pages": "Wiki-Seiten",
    "assemblies": "Baugruppen",
}


def as_text(data: dict[str, Any]) -> str:
    """The report as plain German text, for the user to read before sending it."""
    s = data["system"]
    lines = [
        f"{PRODUCT} Diagnosebericht",
        "Enthält keine Inhalte, keine Datei-, Ordner- oder Projektnamen und keine Pfade.",
        "",
        f"Erstellt: {data['erstellt']}",
        f"{PRODUCT} {s['daengs']}, Python {s['python']}, SQLite {s['sqlite']}",
        f"System: {s['system']}, {s['architektur']}, {s['prozessoren']} Prozessoren,"
        f" {s['arbeitsspeicher_gb']} GB Arbeitsspeicher",
        "Pakete: " + ", ".join(f"{k} {v}" for k, v in s["pakete"].items()),
        f"Modelle: Bedeutungssuche {data['modelle']['bedeutungssuche']},"
        f" Texterkennung {data['modelle']['texterkennung']},"
        f" Antworten {data['modelle'].get('antworten', 'keins')}",
        "",
        "Selbsttest:",
    ]
    for c in data["selbsttest"]:
        lines.append(f"  {'OK    ' if c['ok'] else 'FEHLER'} {c['name']}: {c['detail']}")
    if "updates" in data:
        u = data["updates"]
        lines += [
            "",
            f"Updates: {'an' if u['eingeschaltet'] else 'aus'}"
            f"{'' if u['angeboten'] else ' (in dieser Fassung nicht verfügbar)'},"
            f" letzte Prüfung {u['letzte_pruefung']}",
        ]
    lines += ["", f"Projekte: {len(data['projekte'])}"]
    for p in data["projekte"]:
        parts = [f"{LABELS.get(k, k)} {v}" for k, v in p.items() if k != "nr"]
        lines.append(f"  Projekt {p['nr']}: " + ", ".join(parts))
    return "\n".join(lines) + "\n"
